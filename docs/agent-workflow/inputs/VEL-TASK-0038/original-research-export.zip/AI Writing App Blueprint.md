# AI Writing App Blueprint

## User

You see, if you're working on quite a lot of things from the other chapters you can see, right? But thinking about, turning this into a software or a site or an app. That's what is intriguing right now. So imagine this. The ideas are going to be very, it will be your job to organize them. Yes, but do not lose track of any, even the tiniest detail or things mentioned. So look at this just like most of the other AI writing sites that have popped up. You see how they are being able to choose a model, being able to work, yes, being able to use the model to write, give it ideas, and so on. So look at this. With this, you see with this, when I wanted to actually start a book, I had to go and research, find out, oh, I'm going to use AI to write, right? So what am I going to be? What are the rules that need to be set in to prevent that, and so on. So that's one thing that I want to be quite different from this app or site or software, that, yes, being able to set this type of rules with UI should be one of the transformative parts of this app: being able to set these type of rules itself for the AI to follow. For a book, we can scope it to a book. We can scope it to all your projects, and so on. This mainly for book writing, but if any of these fall under any type of other, should be included. The project is quite this, so it should take note of that part too. Mainly for book writing, but if it falls under any of the other type of jobs or anything, take note of that also. So yeah. So that's the first part I think should be unique about being able to set these type of rules for it having an UI. Then also, yes, about the editing, it should still feel like, it shouldn't lose the edge of normal writing software or app. That's one thing that most AI writing platforms have lost. They focus mainly on the AI writing part, the normal editing part that makes it feel like you're really writing a book is not. So we just need to do quite a lot of research. We only want to build the editing, like when I say editing, I mean that for example Google Docs, you see they are formatting and editing. Those ones that they have that you can, when you're writing, or writing a document, and this and you can put, you can use the varieties. Yeah, that's when I mention editing, that's what I mean. Like, yeah, most AI writing platforms don't have this yet. Or if they have, I haven't seen them yet, but they should be included in what we are going to build. So I want to research, I want to build that editing software or this one, like that part of the feature ourselves. Research whatever open-source project allows us to get that type of editing feature very advanced and up-to-date that we can use and not have to actually create them ourselves, managing. Yes, that's not one of the, we're going to use an open-source project, or if it's no open-source, many open-source, it should be free, for commercial use. Yes, so think that one too is something you have to research. Then also, yes. So its formatability should still feel like a normal writing software. And now coming to the AI writing ability. So we're thinking both using you, the writer yourself, to input API keys for now, API keys, and being able to set up an MCP connection with whichever ChatGPT, ChatGPT Cloud, and DeepSeek, being able to set an MCP, yes, MCP within them so that they can basically act as your assistant. So we have an API key from any of these, or MCP. So API key, then MCP. So research on that too about that part. So now we, yes, that's mainly the AI writing part. So you see, then you could also include meta niche ideas. That won't be time-wasting, but very good to include in this project. I'm thinking about what else should I add? Apart from the editing part. So research with templates, tools, and that writers normally use when actually publishing books and other stuff, and research on the types of features that they really like about them. Can we get them for free? We can build them now. There's the cost, we'll be rationalizing them later on. So what again? Yes. And we should also consider how, yes, the different formats in which the book can be displayed. You see, some apps or softwares, and when you're displaying some type of, yes, like PDF, and how they look. Yes, you should also consider the different formats that they can be put in, and all that. That should be also looked into, the different formats that they can be put in, the arrangement, and also, us writers, like, the way they design their pages, and so on. Quite a lot of stuff. The way they design pages, their book cover especially. Yes. The book cover, the book cover. The book cover especially. So, in the book cover, relating to both the AI being able to generate this one, and yes, the AI is not going to just present on one particular. It depends on whether they're able to list different options, like preview of what, this one. And it's mainly going to be using proper editing software. So, using Canva with, yes, MCP. That is good. ChatGPT with MCP, like any of the AI, this one with MCP, that would be great to that. Yes. You don't want any generic. See how these generic book covers have been popping up all over Web Novel. So yes, yes, yes, yes, yes. So what again? What again? Yeah, so talking about book covers, talking about designing the pages. What again? So about the rules, yeah. Yes, and we have to consider the printability of it, because you're going to be working with writers, which. Yes, you want to print the manuscript and so on. Yes. So that one should also be considered, the printability of the book after it's written. If there are any great or good ideas, mention them. Okay? Mention them. But don't let them be generic ideas such as this, that, yes. Okay? Some of them might be actually normal that should be existing. Just including them would be quite a problem. But yes. So you get the type of good ideas that I'm talking about that I should include. But if it's normal that is vital, is generic, like a vital part of it, then you, yes, mention to include that ones too inside. Okay?

## ChatGPT

I’ll turn this into a product research and architecture study, using the fiction-writing system already developed as the foundation. I’ll examine editor frameworks and their commercial licenses, AI/API/MCP integration, book formatting and print production, cover design, and established writing workflows. I’ll also preserve the ideas as a structured requirements document so smaller details don’t disappear.

## ChatGPT

Two findings materially affect the design. Tiptap, Lexical, and ProseMirror offer commercially usable MIT-licensed foundations, so a capable native editor is feasible without writing its core from scratch. Canva now offers MCP-based design operations, but its usage policy places restrictions on competing products and extraction, so it should be an optional, permissioned integration—not the foundation of our own cover editor. I also found gaps in the earlier fiction-system ZIP that the software's import process should handle explicitly.

## ChatGPT

# Research and Product Blueprint: An AI-Powered Writing and Publishing Studio

<text color="secondary" size="xs">Initial product architecture · Research reviewed October 7, 2026</text>

The product you're describing should be much broader than an AI novel generator.

I would define it as an **author-controlled writing, editing, storytelling, design, and publishing environment**, with AI integrated into the workflow rather than dominating it.

Three things could distinguish it:

1. **A visual AI rules and quality-control system.** Writers configure exactly how their AI should behave, across their entire workspace, a series, an individual book, or a specific scene. Your existing fiction-writing system becomes the foundation.
2. **A genuine manuscript editor.** Even when AI is disabled, the software should be worth using for writing novels, revising manuscripts, collaborating with editors, formatting pages, and preparing books for publication.
3. **Model-independent AI assistance.** Writers can use supported API providers or connect external AI assistants through MCP, while retaining control of their manuscripts, story memory, and editorial decisions.

There is an important technical distinction already established by the research: **API integration and MCP integration are different capabilities**. API integration allows the app to call an AI model. MCP allows compatible AI assistants to access tools exposed by the app, or allows the app to work with external tools such as Canva. Both should exist, but neither automatically substitutes for the other. <Cite refs={["","","",""]}/>

## 1. The product's overall structure

<box border radius="xl" padding={3} gap={3}>
 <box background="surface-secondary" radius="lg" padding={3} align="center" gap={1}>
 **Writer's Workspace**
 <text color="secondary" size="xs" textAlign="center">Projects · Series · Books · Manuscripts · Assets · Rules</text>
 </box>
 <grid columns={2} gap={2}>
 {#each [
 ["Book Editor","Google Docs-level editing"],
 ["AI Studio","Models, API keys, MCP"],
 ["Rules Engine","Scoped writing instructions"],
 ["Story Intelligence","Canon, memory, continuity"],
 ["Design Studio","Covers, typography, layouts"],
 ["Publishing Studio","EPUB, PDF, print, web"]
 ] as p}
 <grid-item>
 <box background="surface-secondary" radius="md" padding={3} gap={1}>
 <text weight="medium" size="sm">{p[0]}</text>
 <text color="secondary" size="xs">{p[1]}</text>
 </box>
 </grid-item>
 {/each}
 </grid>
 <box border radius="md" padding={3} align="center" gap={1}>
 **Shared Project Data and Version History**
 <text color="secondary" size="xs" textAlign="center">One authoritative manuscript · Persistent story state · Controlled AI changes</text>
 </box>
</box>

The central design rule is that writers should never have to sacrifice a conventional writing capability merely because they're using an AI-focused platform.

## 2. Research: which open-source editor should we build upon?

This is one of the most important technology decisions. You want Google Docs-like formatting and manuscript editing without licensing costs that become prohibitive as the platform grows.

I compared the main candidates using their documented licensing and capabilities.

| Editor technology | Commercial licensing | Assessment |
|---|---|---|
| <Entity category="software" value="Tiptap" disambig="Rich-text editor framework"/> | MIT core; some paid extensions | **Best starting point** |
| <Entity category="software" value="Lexical" disambig="Meta rich-text editor framework"/> | MIT | Strong alternative |
| <Entity category="software" value="ProseMirror" disambig="Rich-text editing framework"/> | MIT | Excellent lower-level foundation |
| <Entity category="software" value="BlockNote" disambig="Block-based React editor"/> | MPL-2.0 core; GPL/commercial XL packages | Good for Notion-like interfaces |
| <Entity category="software" value="CKEditor 5" disambig="Rich-text editor"/> | GPL-2+ or commercial | Licensing consideration |
| <Entity category="software" value="ONLYOFFICE Docs" disambig="Online document editing suite"/> | AGPL-3.0 community edition | Strong word processor; more complicated embedding |

These distinctions are supported by the projects' official documentation and repositories. <Cite refs={["","","","","",""]}/>

### Recommended editor: Tiptap + ProseMirror

<row align="start" gap={3}>
 <AsyncImage query="Tiptap rich text editor UI toolbar document editing screenshot" aspectRatio="4:3" maxWidth="160px"/>
 <box flex="1" gap={1}>
 Tiptap provides an extensible editing foundation that can support custom toolbars, formatting controls, structured content, and specialized novel-writing interactions.

 Its open-source editor core is MIT licensed, but we must separately check the licenses of any advanced extensions, especially comments, version history, or paid page-management features. <Cite refs={["",""]}/>
 </box>
</row>

I would not attempt to write a rich-text editing engine from scratch. Instead, I would develop our own author-focused interface around an established engine.

The editor should eventually support two distinct experiences:

- **Writing view:** continuous manuscript editing, chapters, distraction-free composition, comments, search, revisions, and AI assistance.
- **Page layout view:** facing pages, exact trim sizes, typography, chapter opening designs, running headers, page numbers, and print previews.

These should use the same underlying manuscript content, with layout kept separate wherever possible.

That distinction matters because an EPUB can reflow to fit different screens, whereas a print PDF must preserve exact page geometry. Trying to make one fixed page layout serve both formats would create avoidable problems.

## 3. API keys, ChatGPT, Claude, DeepSeek, and MCP

These should be separate connection options within the software.

| Connection | What it enables | Important limitation |
|---|---|---|
| OpenAI API key | Generate, revise, analyze, and audit manuscripts inside our app | Separate API billing |
| Anthropic API key | Use Claude models inside our app | Separate API billing |
| DeepSeek API key | Use DeepSeek models, including supported tool calling | MCP tools require compatible orchestration |
| ChatGPT through MCP | Use compatible ChatGPT configurations to access our project's tools | Full write-capable MCP depends on plan and permissions |
| Claude through MCP | Let Claude work with authorized manuscript tools | Requires a remote MCP server |
| Canva through MCP | Create, modify, and export designs through Canva | OAuth, credits, permissions, and usage restrictions |

Current documentation confirms Claude's custom remote connector support and ChatGPT's more restrictive full-MCP availability. DeepSeek's Responses API does not natively execute built-in MCP tools, although application-side function calling can bridge this capability. <Cite refs={["","","",""]}/>

**The implementation should have two independent systems:** an AI-provider adapter for models inside our app, and a secure MCP server exposing our book tools to compatible external assistants.

For example, an authorized external assistant could retrieve chapter 17, inspect approved character facts, suggest a continuation, and submit proposed changes for the author to review. The assistant must not overwrite approved manuscript text silently.

## 4. Story intelligence: converting our existing fiction system

The earlier fiction system should become structured application functionality, rather than remain a collection of documents that the AI must read in full each time.

<box border radius="xl" padding={3} gap={2}>
 <title size="md">Example: visual Rule Studio</title>
 <text color="secondary" size="xs">Illustrative configuration, not a working implementation</text>
 {@body const initialRules = [
 {name:"Avoid repetitive rhetorical structures",scope:"Workspace",on:true},
 {name:"Preserve character knowledge boundaries",scope:"Book",on:true},
 {name:"Protect established character traits",scope:"Series",on:true},
 {name:"Allow deliberate lyrical repetition",scope:"Scene",on:false},
 {name:"Audit unresolved narrative consequences",scope:"Book",on:true}
 ]}
 {@body const [rules,setRules] = DIL.useState(initialRules)}
 {#each rules as rule,i}
 <row key={rule.name} align="center" justify="between" gap={2}>
 <box flex="1" gap={1}>
 <text size="sm" weight="medium">{rule.name}</text>
 <text color="tertiary" size="2xs">{rule.scope}</text>
 </box>
 <checkbox checked={rule.on} onChange={v=>setRules(old=>old.map((r,j)=>j===i?{...r,on:v}:r))} lineThrough={false}/>
 </row>
 {/each}
 <divider color="subtle"/>
 <row justify="between" align="center">
 <text color="secondary" size="xs">{rules.filter(r=>r.on).length} of {rules.length} example rules enabled</text>
 <button size="sm" variant="outline" color="secondary" onClick={()=>GenUI.copy(rules.map(r=>`${r.on?"Enabled":"Disabled"} | ${r.scope} | ${r.name}`).join("\n"))}>
 <icon name="copy" size="xs"/> Copy configuration
 </button>
 </row>
</box>

Crucially, the system must distinguish writing preferences from established fictional facts. A rule about reducing repetitive dialogue should offer editorial guidance; an approved fact that a character has lost an arm should trigger a continuity warning when contradicted.

My review of your ZIP also identified some specific migration gaps: separate Domain 1 and Domain 13 Markdown files were not present, nor was the separately numbered Post-Draft Audit module. A Story Bible PDF was present. The software importer should flag and reconcile these distinctions without discarding the material.

## 5. Cover design, book layouts, and publishing

<text weight="medium">The cover studio should use editable design layers.</text>

<row align="start" gap={3}>
 <AsyncImage query="professional fantasy paperback book cover typography design mockups front spine back book cover layouts" aspectRatio="4:3" maxWidth="160px"/>
 <box flex="1" gap={1}>
 Writers should be able to compare multiple visual directions, edit typography independently from the artwork, adjust composition, and generate separate ebook and print versions.

 <Entity category="software" value="Konva" disambig="Open-source JavaScript canvas framework"/> or <Entity category="software" value="Fabric.js" disambig="Open-source JavaScript graphics editing framework"/> are credible MIT-licensed foundations for a native editor. <Cite refs={["",""]}/>
 </box>
</row>

Canva is useful as an optional integration, but its MCP policies specifically restrict using the integration to build a competing design product. We should not base our native cover-editing infrastructure on Canva's tools without resolving that contractual boundary. <Cite refs={["",""]}/>

For publishing, the application needs separate output profiles rather than one universal export button.

| Output | Key requirements |
|---|---|
| EPUB 3 | Reflowable typography, navigation, chapters, validation |
| Reader PDF | Comfortable viewing and proofing |
| Print PDF | Exact trim, gutter, bleed, font embedding, image resolution |
| DOCX | Manuscript editing, submissions, professional review |
| HTML / Web novel | Mobile-friendly serialized chapters and configurable paragraph spacing |
| Cover files | Ebook front cover; printer-specific full-wrap files |

Amazon KDP's current print specifications include changing gutter requirements by page count, 300-DPI minimum image resolution, and specific cover dimensions and bleed rules. The software should validate these automatically against the selected publication profile. <Cite refs={["","",""]}/>

## 6. Additional features worth seriously considering

These are stronger differentiators than adding another generic AI chat interface.

- **Narrative debt tracker:** remembers mysteries, promises, conflicts, and consequences that the book still needs to address.
- **Character knowledge firewall:** identifies when characters refer to something they have not learned.
- **Scene-function analysis:** detects chapters that repeat a dramatic function without advancing the narrative.
- **Authorial voice protection:** checks whether AI editing is making deliberately distinctive writing unnecessarily uniform.
- **Publication change-impact analysis:** warns when a manuscript revision changes pagination, chapter references, or cover spine dimensions.
- **Versioned AI decisions:** allows writers to see exactly which model, rules, story facts, and manuscript revision informed an AI suggestion.
- **Portable project archive:** exports both the manuscript and its rules, canon, continuity records, and publishing assets so authors are not locked into the platform.

These should be prioritized by demonstrated usefulness, not feature count.

## 7. The master research document

I compiled the findings into a Markdown document designed to be extended as the product develops.

<box border radius="xl" padding={3} gap={2}>
 <row align="center" gap={3}>
 <icon name="file-text" size="2xl" color="secondary"/>
 <box flex="1" gap={1}>
 **AI Writing Studio — Research & Product Blueprint v0.1**
 <text color="secondary" size="xs">Markdown · 20 sections · Approximately 8,100 words</text>
 </box>
 </row>
 [Download the complete research and product blueprint (.md)](sandbox:/mnt/data/AI_WRITING_STUDIO_RESEARCH_AND_PRODUCT_BLUEPRINT_v0.1.md)
 <text color="secondary" size="xs">Includes 42 individually tracked requirements from your ideas, editor licensing research, MCP architecture, cover workflows, publishing formats, technology recommendations, development stages, acceptance criteria, and source links.</text>
</box>

The generated document was checked for its 20 sections and 42 distinct retained requirements. <CodeCite tool="container" citation_id="5fB48D" line_range_start={1} line_range_end={3}/>

**My recommended first development milestone is the manuscript editor plus the visual Rules Studio.** That combination establishes the product's identity and proves that ordinary writing and AI-assisted writing can coexist properly. From there, the existing fiction system becomes the story-intelligence engine, followed by specialized publishing and cover-design capabilities.

This is a research-backed starting specification, not yet a complete implementation PRD or verified production architecture. It gives us a foundation for making those decisions without losing the ideas that led to them.

## ChatGPT

## 3. API keys, ChatGPT, Claude, DeepSeek, and MCP

These should be separate connection options within the software.

| Connection | What it enables | Important limitation |
|---|---|---|
| OpenAI API key | Generate, revise, analyze, and audit manuscripts inside our app | Separate API billing |
| Anthropic API key | Use Claude models inside our app | Separate API billing |
| DeepSeek API key | Use DeepSeek models, including supported tool calling | MCP tools require compatible orchestration |
| ChatGPT through MCP | Use compatible ChatGPT configurations to access our project's tools | Full write-capable MCP depends on plan and permissions |
| Claude through MCP | Let Claude work with authorized manuscript tools | Requires a remote MCP server |
| Canva through MCP | Create, modify, and export designs through Canva | OAuth, credits, permissions, and usage restrictions |

Current documentation confirms Claude's custom remote connector support and ChatGPT's more restrictive full-MCP availability. DeepSeek's Responses API does not natively execute built-in MCP tools, although application-side function calling can bridge this capability. <Cite refs={["","","",""]}/>

**The implementation should have two independent systems:** an AI-provider adapter for models inside our app, and a secure MCP server exposing our book tools to compatible external assistants.

For example, an authorized external assistant could retrieve chapter 17, inspect approved character facts, suggest a continuation, and submit proposed changes for the author to review. The assistant must not overwrite approved manuscript text silently.

## 4. Story intelligence: converting our existing fiction system

The earlier fiction system should become structured application functionality, rather than remain a collection of documents that the AI must read in full each time.

<box border radius="xl" padding={3} gap={2}>
 <title size="md">Example: visual Rule Studio</title>
 <text color="secondary" size="xs">Illustrative configuration, not a working implementation</text>
 {@body const initialRules = [
 {name:"Avoid repetitive rhetorical structures",scope:"Workspace",on:true},
 {name:"Preserve character knowledge boundaries",scope:"Book",on:true},
 {name:"Protect established character traits",scope:"Series",on:true},
 {name:"Allow deliberate lyrical repetition",scope:"Scene",on:false},
 {name:"Audit unresolved narrative consequences",scope:"Book",on:true}
 ]}
 {@body const [rules,setRules] = DIL.useState(initialRules)}
 {#each rules as rule,i}
 <row key={rule.name} align="center" justify="between" gap={2}>
 <box flex="1" gap={1}>
 <text size="sm" weight="medium">{rule.name}</text>
 <text color="tertiary" size="2xs">{rule.scope}</text>
 </box>
 <checkbox checked={rule.on} onChange={v=>setRules(old=>old.map((r,j)=>j===i?{...r,on:v}:r))} lineThrough={false}/>
 </row>
 {/each}
 <divider color="subtle"/>
 <row justify="between" align="center">
 <text color="secondary" size="xs">{rules.filter(r=>r.on).length} of {rules.length} example rules enabled</text>
 <button size="sm" variant="outline" color="secondary" onClick={()=>GenUI.copy(rules.map(r=>`${r.on?"Enabled":"Disabled"} | ${r.scope} | ${r.name}`).join("\n"))}>
 <icon name="copy" size="xs"/> Copy configuration
 </button>
 </row>
</box>

Crucially, the system must distinguish writing preferences from established fictional facts. A rule about reducing repetitive dialogue should offer editorial guidance; an approved fact that a character has lost an arm should trigger a continuity warning when contradicted.

My review of your ZIP also identified some specific migration gaps: separate Domain 1 and Domain 13 Markdown files were not present, nor was the separately numbered Post-Draft Audit module. A Story Bible PDF was present. The software importer should flag and reconcile these distinctions without discarding the material.

## 5. Cover design, book layouts, and publishing

<text weight="medium">The cover studio should use editable design layers.</text>

<row align="start" gap={3}>
 <AsyncImage query="professional fantasy paperback book cover typography design mockups front spine back book cover layouts" aspectRatio="4:3" maxWidth="160px"/>
 <box flex="1" gap={1}>
 Writers should be able to compare multiple visual directions, edit typography independently from the artwork, adjust composition, and generate separate ebook and print versions.

 <Entity category="software" value="Konva" disambig="Open-source JavaScript canvas framework"/> or <Entity category="software" value="Fabric.js" disambig="Open-source JavaScript graphics editing framework"/> are credible MIT-licensed foundations for a native editor. <Cite refs={["",""]}/>
 </box>
</row>

Canva is useful as an optional integration, but its MCP policies specifically restrict using the integration to build a competing design product. We should not base our native cover-editing infrastructure on Canva's tools without resolving that contractual boundary. <Cite refs={["",""]}/>

For publishing, the application needs separate output profiles rather than one universal export button.

| Output | Key requirements |
|---|---|
| EPUB 3 | Reflowable typography, navigation, chapters, validation |
| Reader PDF | Comfortable viewing and proofing |
| Print PDF | Exact trim, gutter, bleed, font embedding, image resolution |
| DOCX | Manuscript editing, submissions, professional review |
| HTML / Web novel | Mobile-friendly serialized chapters and configurable paragraph spacing |
| Cover files | Ebook front cover; printer-specific full-wrap files |

Amazon KDP's current print specifications include changing gutter requirements by page count, 300-DPI minimum image resolution, and specific cover dimensions and bleed rules. The software should validate these automatically against the selected publication profile. <Cite refs={["","",""]}/>

## 6. Additional features worth seriously considering

These are stronger differentiators than adding another generic AI chat interface.

- **Narrative debt tracker:** remembers mysteries, promises, conflicts, and consequences that the book still needs to address.
- **Character knowledge firewall:** identifies when characters refer to something they have not learned.
- **Scene-function analysis:** detects chapters that repeat a dramatic function without advancing the narrative.
- **Authorial voice protection:** checks whether AI editing is making deliberately distinctive writing unnecessarily uniform.
- **Publication change-impact analysis:** warns when a manuscript revision changes pagination, chapter references, or cover spine dimensions.
- **Versioned AI decisions:** allows writers to see exactly which model, rules, story facts, and manuscript revision informed an AI suggestion.
- **Portable project archive:** exports both the manuscript and its rules, canon, continuity records, and publishing assets so authors are not locked into the platform.

These should be prioritized by demonstrated usefulness, not feature count.

## 7. The master research document

I compiled the findings into a Markdown document designed to be extended as the product develops.

<box border radius="xl" padding={3} gap={2}>
 <row align="center" gap={3}>
 <icon name="file-text" size="2xl" color="secondary"/>
 <box flex="1" gap={1}>
 **AI Writing Studio — Research & Product Blueprint v0.1**
 <text color="secondary" size="xs">Markdown · 20 sections · Approximately 8,100 words</text>
 </box>
 </row>
 [Download the complete research and product blueprint (.md)](sandbox:/mnt/data/AI_WRITING_STUDIO_RESEARCH_AND_PRODUCT_BLUEPRINT_v0.1.md)
 <text color="secondary" size="xs">Includes 42 individually tracked requirements from your ideas, editor licensing research, MCP architecture, cover workflows, publishing formats, technology recommendations, development stages, acceptance criteria, and source links.</text>
</box>

The generated document was checked for its 20 sections and 42 distinct retained requirements. <CodeCite tool="container" citation_id="5fB48D" line_range_start={1} line_range_end={3}/>

**My recommended first development milestone is the manuscript editor plus the visual Rules Studio.** That combination establishes the product's identity and proves that ordinary writing and AI-assisted writing can coexist properly. From there, the existing fiction system becomes the story-intelligence engine, followed by specialized publishing and cover-design capabilities.

This is a research-backed starting specification, not yet a complete implementation PRD or verified production architecture. It gives us a foundation for making those decisions without losing the ideas that led to them.



---

*Generated with [ChatGPT Pro Tools](https://chromewebstore.google.com/detail/chatgpt-pro-tools/blehigjjjlnlbbgjghhfnllglnelijkg?utm_source=extension&utm_medium=export-footer)*
