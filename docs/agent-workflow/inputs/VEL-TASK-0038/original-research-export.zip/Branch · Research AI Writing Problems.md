# Branch · Research AI Writing Problems

## User

I want you to do a very, very, very deep research. You are to delve into other sites. Yes. This research is to basically find the problems people have with AI-written books, novels, etc. Go to discussions to find the exact problem people get, or people see, when they are reading AI-written works. Research deeply, discussions in communities. Research very, very deeply the problems people have, people see, people come across when they are reading AI-generated or written works. All type of written works: novels, web novels, etc. All.

## ChatGPT

I’ll treat this as a community-sentiment research project, not a generic “AI writing is bad” overview. I’m going to separate reader complaints by medium (novels, web fiction, fanfic, publishing/marketplaces), look for recurring language people use, and distinguish firsthand reading complaints from creator/publisher backlash.

## ChatGPT

The strongest pattern so far is not simply “bad grammar.” Readers repeatedly describe the opposite: prose that is superficially competent but mechanically patterned, over-emphatic, repetitive, and contextually “off.” They especially notice dialogue cadence, continuity failures, characters converging into the same voice, and scenes that repeat emotional or plot functions without genuine development. 

## ChatGPT

I dug through reader and writer communities, including Royal Road, Reddit communities around progression fantasy, LitRPG, fanfiction/AO3, Kindle, beta reading, self-publishing, Goodreads discussions, Scribble Hub, OpenAI community discussions, plus recent academic work on AI-assisted fiction and creative homogenization.

One qualification matters before the findings: **none of the stylistic traits below proves that a text was AI-generated.** Many are ordinary weaknesses in human writing too. What communities are reacting to is usually a *cluster* of traits appearing repeatedly, especially when the prose suddenly changes style or when long-range story logic starts failing. False accusations have themselves become a serious problem. ([Goodreads](https://www.goodreads.com/topic/show/24586503-ai-accusation-against-new-authors?order=a&page=1&utm_source=chatgpt.com))

## The central finding

The complaint is much deeper than “AI writes badly.”

Readers repeatedly describe an uncanny mismatch:

**The sentence is competent. The paragraph is competent. Sometimes even the scene is competent. But the story as a whole does not seem to understand why its sentences, paragraphs, and scenes exist.**

A Royal Road critique expressed this unusually well: an individual line can sound as if a professional wrote it, while its *function in the scene* makes little sense. The prose possesses the appearance of literary significance without the underlying narrative intention. ([Royal Road](https://www.royalroad.com/forums/thread/151501?page=25&utm_source=chatgpt.com))

That single phenomenon explains a large fraction of the complaints I found.

---

# 1. Repetition is probably the most consistently reported problem

This occurs at several levels simultaneously.

### Repeated wording

Readers notice favorite phrases, adjectives, metaphors, sentence openings, gestures and emotional descriptions being recycled.

A Kindle reader who bought a suspected AI book reported that the narrative seemed to reach its natural ending halfway through and then simply continued repeating essentially the same message. ([Reddit](https://www.reddit.com/r/kindle/comments/1amg1k5?utm_source=chatgpt.com))

Royal Road readers similarly describe getting buried beneath “endless repetitions and purple prose.” ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

### Repeated sentence architecture

This is more irritating than repeated individual words because it creates a recognizable rhythm.

People repeatedly complain about constructions resembling:

- “Not X. Not Y. But Z.”
- “It wasn't merely X. It was Y.”
- “Not because X, but because Y.”
- short statement → dramatic fragment → explanatory sentence
- assertion → reassertion in slightly grander language
- three parallel fragments followed by a conclusion
- question followed immediately by an emphatic answer
- adjective pairs and stacked descriptive clauses

Royal Road users specifically called out the “Not this. Not this. But that.” structure as jarring. An OpenAI community discussion independently complains about repetitive structures such as “It’s not just X, it’s also Y.” ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

These structures are perfectly legitimate human rhetoric. The complaint is **frequency**.

A rhetorical flourish stops functioning as emphasis when everything receives emphasis.

---

# 2. Everything is written as if it is important

This is a surprisingly precise recurring complaint.

AI prose often seems unable to establish a hierarchy of significance.

A character opening a door, discovering a murdered king and deciding what cereal to eat can all receive approximately the same stylistic weight.

One Royal Road participant described the problem as AI being able to generate sophisticated-sounding prose but not knowing how to **pace the impacts**, comparing it to someone emphasizing every word while reading aloud. ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This creates what I would call **importance inflation**.

Instead of:

ordinary → interesting → tense → extraordinary → climax

the narrative becomes:

**meaningful → meaningful → profound → meaningful → profound → devastating → meaningful → profound**

Eventually none of it feels meaningful.

This is closely related to another Royal Road critique describing AI prose as exhibiting **“vague grandiosity”**: impressive-looking sentences whose presentation does not correspond to the actual significance or function of what is happening. ([Royal Road](https://www.royalroad.com/forums/thread/151501?page=25&utm_source=chatgpt.com))

---

# 3. Purple prose without observational specificity

Readers frequently complain that AI fiction is simultaneously **overwritten and vague**.

That sounds contradictory, but it isn't.

There may be many adjectives, metaphors, abstractions and emotional descriptions while remarkably little concrete information.

Royal Road discussions repeatedly characterize AI-heavy writing as:

- flowery,
- generic,
- ornate,
- exposition-heavy,
- cliché-driven,
- excessively metaphorical. ([Royal Road](https://www.royalroad.com/forums/thread/141654?utm_source=chatgpt.com))

One Reddit reader noticed a sequel suddenly oscillating between very short clipped prose and passages containing numerous metaphors and similes within only a few paragraphs. ([Reddit](https://www.reddit.com/r/litrpg/comments/1vcvwn1/list_of_confirmed_ai_books/?utm_source=chatgpt.com))

The underlying complaint isn't “metaphors are bad.”

It is:

**The prose sounds decorated rather than observed.**

Human description often reveals what *this particular viewpoint character* would notice.

AI-like description often seems to ask:

> What sounds literary here?

rather than:

> What would this person notice here, and why?

---

# 4. Metaphors that sound good locally but mean very little

This appears frequently in reader descriptions.

A metaphor may be syntactically elegant and emotionally suggestive while collapsing if examined literally.

Goodreads participants discussing AI writing described metaphor-heavy prose where the images feel like plausible pattern matches rather than deliberately chosen comparisons. ([Goodreads](https://www.goodreads.com/Topic/24739576/comments?subject=24739576&utm_source=chatgpt.com))

This produces a particular reading sensation:

**You understand the emotional category of the sentence without understanding its actual image.**

The reader thinks:

“Apparently this is supposed to mean sadness.”

But the metaphor itself doesn't deepen sadness.

It simply announces it.

---

# 5. Emotional paraphrasing

One emotion gets explained repeatedly.

For example, instead of allowing:

> She closed the door and kept her hand on the knob.

to carry emotional meaning, AI-style prose tends toward something structurally like:

> She closed the door. 
> The finality settled over her. 
> It wasn't merely sadness. 
> It was the realization that something had ended. 
> Something irreversible. 
> And for the first time she understood that there was no going back.

The problem isn't any individual sentence.

It is that **all six sentences perform essentially one emotional action**.

Readers repeatedly report this feeling of the text telling them the same thing again and again instead of progressing. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

This contributes enormously to perceived bloat.

---

# 6. Characters begin speaking in “LLM prose”

This phrasing came directly from a reader discussing a work whose plot, worldbuilding and characters they otherwise liked.

Later chapters apparently changed, and suddenly the **characters' thoughts and speech acquired the same AI-like prose style**. The reader described this as ruining an otherwise competent story. ([Reddit](https://www.reddit.com/r/ProgressionFantasy/comments/1vh8e7f/it_was_the_worst_feeling_not_great_not_good_but/?utm_source=chatgpt.com))

This points toward an important distinction:

AI voice doesn't stay confined to narration.

It can infect:

- dialogue,
- internal monologue,
- letters,
- jokes,
- arguments,
- villains,
- children,
- ancient beings,
- soldiers,
- academics.

Everyone starts sounding as though they were generated through the same rhetorical engine.

---

# 7. Character voices converge

This is one of the most important long-form complaints.

Royal Road readers describe AI-influenced fiction where every story—and frequently every character—shares an oddly similar voice: polished, modern, snappy and structurally alike regardless of setting or personality. ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

A sarcastic rogue, shy teenager, 900-year-old emperor and exhausted mother may technically use different vocabulary while sharing exactly the same:

- cadence,
- sentence length,
- emotional articulation,
- degree of self-awareness,
- argumentative structure,
- wit,
- rhetorical sophistication.

The result is **character differentiation by facts rather than by consciousness**.

They have different biographies but the same mind.

---

# 8. Dialogue feels like alternating “beats,” not conversation

This was described especially clearly in a recent Royal Road discussion.

Readers observed terse dialogue where each line exists primarily to set up the next:

A speaks.

B mirrors A.

A reformulates.

B answers symmetrically.

A challenges.

B produces a neat reversal.

The complaint was that characters didn't use the connective mess found in real conversation:

- hesitation,
- correction,
- filler,
- interruption,
- misunderstanding,
- unfinished thought,
- change of subject,
- answering the wrong part of a question,
- avoiding the question entirely.

Instead, every line becomes a **perfect conversational unit**.

Royal Road readers said the result feels closer to scripted beats than natural interaction and breaks immersion. ([Royal Road](https://www.royalroad.com/forums/thread/175111?utm_source=chatgpt.com))

---

# 9. Characters repeat one another

A related dialogue tell:

> “You're leaving.”
>
> “I'm leaving.”
>
> “You've decided.”
>
> “I have.”

Nothing is technically wrong.

But information does not move.

Several community discussions point to dialogue where one character essentially restates the previous character's statement before continuing. ([Royal Road](https://www.royalroad.com/forums/thread/175111?utm_source=chatgpt.com))

This creates **semantic ping-pong**.

Conversation happens without discovery.

---

# 10. Dialogue can be unnaturally self-aware

Characters often explain themselves too well.

They know:

- what they are feeling,
- why they are feeling it,
- what childhood event produced it,
- what contradiction they are experiencing,
- how the other person must feel,
- what lesson the moment represents.

Human beings, especially during conflict, are often much worse at this.

They:

- rationalize,
- evade,
- misunderstand themselves,
- lash out for the wrong reason,
- say something they regret,
- focus on irrelevant details,
- refuse to articulate the obvious.

AI dialogue often produces people who behave like their own therapists.

This is one reason community members repeatedly describe it as lacking contradiction, vulnerability or genuine subtext. ([Royal Road](https://www.royalroad.com/forums/thread/154464?page=1&utm_source=chatgpt.com))

---

# 11. Excessive explicit emotional labeling

Readers don't merely see sadness.

The text tells them someone is:

- conflicted,
- determined,
- vulnerable,
- resolute,
- uncertain,
- relieved,
- apprehensive,
- quietly devastated.

And then often explains why.

This removes interpretive participation.

Human fiction can say:

> “Fine,” he said, carefully placing the cracked cup in the sink.

and allow the reader to infer anger.

AI-style prose frequently feels compelled to complete the equation for the reader.

That is part of what communities mean when they complain of excessive **telling instead of showing**. ([Royal Road](https://www.royalroad.com/forums/thread/156581?utm_source=chatgpt.com))

---

# 12. Emotional reactions become generic physical choreography

Readers repeatedly notice reusable emotional actions.

Characters:

- narrow their eyes,
- furrow their brows,
- clench their jaws,
- release breaths,
- stiffen,
- soften,
- pause “for a beat,”
- let silence stretch,
- feel something tighten in their chest,
- feel something twist in their stomach,
- swallow hard.

Again: human authors use every one of these.

The AI-like impression emerges when the gestures become an almost closed vocabulary for human interiority.

A Scribble Hub reader even described an AI-heavy story repeatedly producing inappropriate brow-furrowing, including for a dog. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

That example is humorous, but the underlying issue is serious:

**the model associates an emotional context with a probable gesture and inserts it without sufficiently modeling embodiment.**

---

# 13. Contextually inappropriate behavior

Readers often describe moments where a sentence makes perfect grammatical sense but is bizarre in context.

A Royal Road reader summarized one suspected AI-assisted story as showing:

- odd comments that don't fit the scene,
- weak contextual memory,
- distinctive but inappropriate conversation cadence. ([Reddit](https://www.reddit.com/r/royalroad/comments/1rfygrx/gave_honest_and_nonnegative_feedback_on_an_ai/?utm_source=chatgpt.com))

Fanfiction readers describe similar failures: actions, concepts or behaviors appear where they don't belong because the generator seemingly recognized a local association without understanding the larger situation. ([Reddit](https://www.reddit.com/r/AO3/comments/zbpv03?utm_source=chatgpt.com))

This is an important distinction:

**AI errors are frequently pragmatic rather than grammatical.**

---

# 14. Scene-level amnesia

Long fiction creates facts.

Those facts become obligations.

If chapter 4 establishes that:

- Mara can't swim,
- the north gate is destroyed,
- James hates alcohol,
- vampires can't enter churches,
- Elena already knows the secret,

chapter 27 must respect those facts unless something changes.

Communities repeatedly report AI-written stories violating these commitments.

Examples include:

- names changing,
- prior discoveries being forgotten,
- locations shifting,
- relationships resetting,
- powers changing,
- established facts vanishing,
- characters rediscovering information they already know. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

Current research supports the broader limitation. A 2026 benchmark of long-horizon interactive narratives found a substantial gap between linguistic fluency and preservation of narrative commitments: excellent surface language did not guarantee consistency over extended sequences. ([arXiv](https://arxiv.org/abs/2608.08160?utm_source=chatgpt.com))

---

# 15. Character-name instability

This deserves its own mention because it is so visible.

Scribble Hub readers describe characters whose names drift or alternate inexplicably in AI-heavy stories. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

It destroys reader confidence unusually quickly because a name is among the simplest persistent facts a novel is expected to maintain.

Readers naturally ask:

> If the book cannot remember her name, what else isn't it remembering?

---

# 16. Personality drift

A more subtle continuity problem:

the character keeps their name but stops being themselves.

A selfish protagonist becomes strangely altruistic for one scene.

A coward suddenly behaves fearlessly without an arc.

A brilliant strategist becomes stupid to enable the plot.

A restrained character delivers an ornate emotional monologue.

Then the old characterization returns.

Royal Road discussions describe plot-serving characters whose motivation, intelligence or behavior changes whenever needed. ([Royal Road](https://www.royalroad.com/forums/thread/173903?utm_source=chatgpt.com))

Human authors absolutely commit this error.

AI seems especially vulnerable because it can optimize the immediate scene without sufficiently protecting the character model that earlier scenes established.

---

# 17. “Character growth” that is actually character replacement

This is the stronger version of personality drift.

A genuine arc has causality:

experience → resistance → consequence → changed belief → changed behavior.

AI-generated arcs sometimes jump directly from:

**old personality → dramatic scene → new personality.**

The prose announces transformation but the reader hasn't *experienced* the transformation.

This produces characters who appear to have developed when they have merely been rewritten.

---

# 18. Characters exist to perform the scene's function

A recurring criticism in community discussions is that secondary characters behave less like independent people and more like mechanisms.

They arrive to:

- encourage the protagonist,
- deliver exposition,
- misunderstand something,
- praise the hero,
- start an argument,
- introduce the next quest,
- validate the romance,
- deliver thematic wisdom.

Then vanish.

Readers often describe this as **plot-serving characterization**. 

Human genre fiction does this frequently too.

The AI version becomes especially noticeable because characters can be *very

## User

I want you to do a very, very, very deep research. You are to delve into other sites. Yes. This research is to basically find the problems people have with AI-written books, novels, etc. Go to discussions to find the exact problem people get, or people see, when they are reading AI-written works. Research deeply, discussions in communities. Research very, very deeply the problems people have, people see, people come across when they are reading AI-generated or written works. All type of written works: novels, web novels, etc. All.

## ChatGPT

I’m expanding this beyond Reddit. I’ll sample reader/author communities around general books, fanfiction, web novels/serials, LitRPG/progression fantasy, self-publishing/Kindle, and AI-writing communities themselves, then cross-check recurring complaints against publishing/editorial and research sources. The goal is to identify **specific textual failure modes readers actually notice**, not just ethical objections to AI.

## ChatGPT

A second important distinction is emerging: readers complain about **two different layers of failure**. At the sentence level, they report templated rhetorical patterns, adjective stacking, purple prose, bland “perfect” grammar, and repeated emphasis; over many chapters, they report plot/character memory failures, scene-function repetition, voice homogenization, and loss of causal continuity. Royal Road readers in particular say the long-form defects become much easier to notice after 10–20 chapters than from a paragraph-sized “AI tell.” 

## ChatGPT

The community evidence and the research literature line up unusually well on the long-form problems. A 2026 ACL benchmark found factual and temporal consistency errors are especially common in long AI-generated stories; a 2026 survey of 57 story-generation papers still lists narrative coherence, character consistency, storyline diversity, and plot control as open problems. Separately, recent work finds AI-assisted writing becomes more stylistically homogeneous at scale. 

## ChatGPT

# Deep research: what readers actually dislike about AI-written fiction

I researched this as a **reader-experience problem**, rather than starting from the assumption that “AI writing is bad.” I reviewed discussions from r/books, r/kindle, Kindle Unlimited communities, r/litrpg, r/royalroad, r/FanFiction, r/AO3 and other fanfiction communities; Royal Road's own forums; Scribble Hub; SpaceBattles; Goodreads reviews; AI-writing communities where people openly discuss the defects they have to edit out; official Royal Road/Amazon policies; and recent academic work on long-form story generation.

There is a surprisingly coherent picture across these communities.

The central complaint is **not that AI cannot produce grammatically correct sentences**. In fact, readers often say the grammar is suspiciously clean. The deeper problem is this:

> **AI fiction can be locally fluent while being globally unintelligent.**

A paragraph can sound polished. A description can sound literary. A dialogue exchange can sound superficially plausible. But after enough pages, readers start noticing that the story does not seem to understand what deserves emphasis, what has already happened, what a character should know, how one event psychologically changes the next, or why a particular sentence is being written at all.

That distinction explains a huge portion of the complaints I found.

---

## 1. The single biggest prose complaint: everything sounds *written*

One of the most repeated descriptions is some variation of **overwritten, flowery, overly dramatic, overly polished, sterile, exhausting, or “trying to sound literary.”**

A LitRPG reader described suspected AI books as “over the top, floraly, soulless” and repetitive. A Royal Road forum user said AI prose may combine sophisticated-sounding words but fails to control where the emphasis belongs: it is like hearing somebody read a passage while **emphasizing every single word**. Scribble Hub users similarly complain about grammatically correct but excessively flowery prose. ([Reddit](https://www.reddit.com/r/litrpg/comments/1i9y3b7?utm_source=chatgpt.com))

This is an important distinction from ordinary purple prose. Human purple prose often comes from an identifiable artistic obsession: the writer loves Gothic imagery, sensual description, nature, architecture, grotesquerie, etc. What readers call “AI purple prose” frequently feels **ornamental without a governing aesthetic**. It embellishes because embellishment sounds like Writing™, rather than because the point-of-view character or scene requires it.

SpaceBattles readers repeatedly complained about superfluous details, unnecessary adjectives, elaborate comparisons and metaphors that collapse when examined closely. One commenter described a recurring pattern in which a character walks through a location while their clothes and accessories somehow become symbols of contrasting personality traits. Another complained that generated metaphors appear everywhere yet often do not withstand literal or thematic scrutiny. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-usage-in-stories.1272482/?utm_source=chatgpt.com))

The result is something several communities independently describe as **exhausting**. The prose constantly asks the reader to feel that something is significant without earning that significance.

---

## 2. The infamous “not X, but Y” problem is real — but the real issue is frequency

This was probably the most consistently named sentence-level pattern across the communities I searched.

Readers describe variations such as:

“Not X, but Y.”

“Not A. Not B. Just C.”

“It wasn't X. It was Y.”

“Not merely X, but something deeper.”

One Kindle reader complained of encountering the same “not A, not B, just/but C” structure hundreds of times across books. Royal Road readers call it the “Digiorno cadence.” Fanfiction readers report fics riddled with constructions like “not x, not y, but z.” Even people in communities specifically devoted to **writing with AI** complain that models keep reverting to the structure after being explicitly told not to. ([Reddit](https://www.reddit.com/r/kindle/comments/1wbsj8z/books_obviously_written_by_ai/?utm_source=chatgpt.com))

The rhetorical device itself is ancient and perfectly legitimate human writing. Shakespeare used contrastive structures. The community complaint is therefore not **presence**, but **density and inappropriate placement**.

A useful observation from one discussion was that humans normally deploy this construction when there is some reason to correct, distinguish, intensify or persuade. AI-like prose may use it for trivial observations where nothing actually needs reframing. That creates a strange sensation that the narrator is perpetually arguing against an interpretation the reader never had. ([Reddit](https://pl.reddit.com/r/antiai/comments/1u7ugzj/what_is_it_that_makes_ai_writing_so_bad/?utm_source=chatgpt.com))

That leads to a broader problem.

## 3. AI prose frequently **pre-interprets itself**

Readers repeatedly object to prose that tells them what a moment means immediately after showing the moment.

A character performs an action. Then the narration explains the psychological significance of the action. Then it explains how the other character interpreted it. Then it explains what this says about their relationship. Sometimes it then concludes with a pseudo-profound sentence.

A user in r/WritingWithAI said they routinely cut roughly a third of generated prose because of its “constant overexplaining,” psychological analysis of every action, and apparent inability to remain comfortably inside a limited point of view. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1uadqis/this_is_what_its_like_writing_with_ai/?utm_source=chatgpt.com))

This destroys **subtext**.

Good fiction often lets the reader infer:

He did not answer.

She folded the letter and placed it back inside the envelope.

Neither looked at the empty chair.

AI-like prose has a tendency to convert those moments into explanations of grief, hesitation, unresolved tension, suppressed resentment or emotional distance. The reader is deprived of the pleasure of interpretation.

This is why people often describe the writing as paradoxically both **verbose and shallow**. There can be a great deal of language while very little remains for the reader to discover.

---

# 4. “Pseudo-depth”: sentences that sound profound without adding information

Fanfiction readers specifically complained about repeated “pseudo-profound” sentences, including dramatic one-sentence paragraphs and closing formulations such as “…and that was enough.” One Harry Potter fanfiction reader described a story containing multiple metaphors that went nowhere, vague worldbuilding, constant drama and little payoff. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

This is a recurring phenomenon across other discussions too: **abstract nouns replacing concrete insight**.

The prose talks about silence, weight, truth, darkness, destiny, possibility, tension, something unspoken, something shifting, something ancient, something fragile, the space between people, the gravity of a moment, and so forth.

These abstractions are not automatically bad. The complaint is that the language often creates **the shape of meaning without committing to a specific meaning**.

A Scribble Hub discussion of an apparently AI-like passage noted heavy reliance on sweeping abstractions such as honor, loyalty, sacrifice, death and pain. ([Scribble Hub Forum](https://forum.scribblehub.com/threads/first-chapter-ai-check-for-shoots-and-giggles.23104/?utm_source=chatgpt.com))

That is closely connected to another complaint: **vagueness masquerading as sophistication**.

---

# 5. Strange allocation of detail

One unusually specific complaint from fanfiction readers was that AI-like writing can be extraordinarily detailed about the wrong things.

A room receives an extravagant description.

A corridor gets three metaphors.

Weather receives symbolic significance.

A character's coat receives multiple adjectives.

Yet an important secondary character remains visually, psychologically and socially vague.

One fanfiction reader described exactly this imbalance: highly detailed locations but barely any meaningful characterization of side characters, even original characters who should matter to the story. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

This produces the sensation that the prose knows how to **decorate a scene** but does not know what information the story requires.

SpaceBattles discussions repeatedly return to the same issue under different names: meaningless details, superfluous description and “purple prose emphasizing the wrong actions.” ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/?utm_source=chatgpt.com))

This is one reason AI prose may feel visually rich yet strangely unmemorable.

---

# 6. Repetition occurs at several different levels simultaneously

“Repetitive” is probably the most common general adjective I encountered, but it actually describes several separate phenomena.

### Lexical repetition

The same words, adjectives, gestures and phrases recur. Goodreads reviewers of suspected AI-generated fantasy have complained about words and even whole sentences being repeated. ([Goodreads](https://www.goodreads.com/book/show/230030991-elven-blood?utm_source=chatgpt.com))

### Syntactic repetition

Different sentences contain the same underlying rhetorical machine:

Not X, but Y.

Three-item sequences.

One-sentence dramatic paragraph.

Description → contrast → emotional interpretation.

Dialogue → enormous reaction paragraph.

Question → rhetorical reframing → tidy conclusion.

This is what causes readers to say they recognize the same “sentence structure” over and over even when the vocabulary changes. ([Reddit](https://www.reddit.com/r/kindle/comments/1wbsj8z/books_obviously_written_by_ai/?utm_source=chatgpt.com))

### Scene repetition

More seriously, entire **dramatic functions** repeat. Characters argue about essentially the same issue, reconcile in approximately the same way, encounter another obstacle fulfilling the same purpose, or repeat emotional revelations without actually evolving.

Royal Road users have described AI-heavy serials as repeating essentially the same action and lack-of-growth cycle with names or surface details changed. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

That is much more damaging than an overused word because the reader begins feeling that **nothing accumulates**.

---

# 7. Characters repeatedly return to baseline

This emerged strongly in discussions of web novels and long fanfiction.

A human-written character should normally have a history inside the book itself. After betrayal, intimacy, injury, revelation or failure, later behavior should be influenced by what occurred earlier.

Readers complain that AI-generated characters instead seem prone to **psychological resetting**.

The character learns something but behaves later as though they never learned it.

A relationship deepens, but the next conversation has the same emotional distance as before.

Someone resolves an insecurity, then repeats the original insecurity almost unchanged.

A conflict is apparently settled, yet the same conversation comes back because the generator finds that conflict statistically appropriate for those characters.

This is partly why readers describe AI characters as “flat” even when the prose contains a huge amount of emotion. An OpenAI community discussion on book generation similarly identified repeated actions/dialogue, weak psychological depth and the feeling that each continuation starts afresh rather than genuinely inheriting everything that happened before. ([OpenAI Developer Community](https://community.openai.com/t/can-ai-really-write-books/976399?utm_source=chatgpt.com))

That complaint is not merely anecdotal. Current research on long-form LLM narratives finds precisely these broader consistency challenges.

---

# 8. Characterization whiplash

The opposite of resetting also occurs: characters suddenly become someone else.

SpaceBattles readers gave very concrete examples: a protagonist may abruptly change personality without sufficient setup; characters talk or behave in ways that contradict their portrayal just paragraphs earlier; characterization becomes increasingly irregular as the story grows. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

Another reader called this **“immersion breaking characterization whiplash.”** ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-2?utm_source=chatgpt.com))

This is particularly damaging in fanfiction because readers already possess a detailed model of the canonical character. An AI can reproduce obvious traits—sarcasm, sternness, cleverness, timidity—while missing the constraints underneath them.

A character may therefore say something that resembles their surface voice while reasoning in a way they never would.

---

# 9. Everyone slowly acquires the same voice

This complaint appears at two levels.

First, **characters inside one story begin sounding alike**. A Royal Road discussion explicitly lists dialogue where characters sound too similar among the common AI-like defects readers notice. ([Reddit](https://www.reddit.com/r/royalroad/comments/1uwps94/nightmare_fuel_being_accused_of_using_ai_because/?utm_source=chatgpt.com))

Second, **completely unrelated books begin sounding like the same author**.

A Royal Road forum reader said that after sampling story after story, the authorial voice appeared strangely identical despite changes in character and setting: “snappy, sharp, modern.” ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

Royal Road's own official policy acknowledges this issue indirectly. It defines AI assistance as situations where the author's creativity and structure remain but the prose may acquire the **AI's “voice and tone.”** ([Royal Road](https://www.royalroad.com/blog/57/royal-road-ai-text-policy?utm_source=chatgpt.com))

Recent research supports the broader homogenization concern. A 2026 *Nature Human Behaviour* research briefing reports results across roughly 880,000 texts showing that LLM writing assistance preserved meaning while reducing linguistic variation and altering signals of author identity. A separate 2025 study comparing humans with GPT writing found lower collective idea diversity in GPT outputs even after attempts to increase model creativity. ([Nature](https://www.nature.com/articles/s41562-026-02549-7?utm_source=chatgpt.com))

And a *Science Advances* experiment on short fiction found something particularly important: AI ideas could improve individual writers' rated creativity and enjoyment, particularly for weaker writers, **while simultaneously making the resulting stories more similar to one another**. ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com))

So “everything is beginning to sound the same” is not merely an aesthetic complaint. There is empirical evidence for a homogenizing effect.

---

# 10. Dialogue often feels like generated dialogue rather than conversation

Readers describe several recurring problems.

One is **excessive explicitness**. People say exactly what they feel and what the conflict is about.

Another is **symmetry**: one character makes a carefully shaped point, another provides a neatly complementary response, and the exchange proceeds almost too logically.

Another is the recurring corrective pattern:

“You're saying X.”

“I'm saying Y. There's a difference.”

SpaceBattles readers specifically identified this as a recurring generated-dialogue cadence. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

A more structural version is **short dialogue followed by an enormous analytical reaction**. One reader described exchanges where a single curt sentence receives a reaction paragraph ten times its length, containing elaborate internal analysis and unlikely deductions. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-2?utm_source=chatgpt.com))

The conversation therefore stops feeling temporally real. Two people are supposedly interacting, yet every utterance creates enough interior analysis to fill several minutes.

Readers also complain about conversations that simply **go nowhere**—characters exchange polished statements without anything materially changing. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

---

# 11. Emotional writing can be extremely explicit but strangely unfelt

This is where the word **“soulless”** appears constantly.

It would be easy to dismiss “soulless” as anti-AI ideology, but when readers explain what they mean, the complaint becomes much more specific.

There may be lots of emotional vocabulary but little **emotional causality**.

The story knows that a scene requires grief, anger, desire or fear, so it supplies the conventional language associated with grief, anger, desire or fear. But the emotion does not necessarily arise from the character's individual history in a surprising or revealing way.

Royal Road commenters describe this as technically sophisticated prose without consistent underlying meaning; Scribble Hub readers call it grammatically correct yet off-putting; Goodreads reviewers of suspected AI works describe “words on a page” without emotional substance. ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

The distinction is roughly:

**Emotion described** is not the same as **emotion dramatized**.

And **emotion dramatized** is not necessarily the same as **emotion specifically belonging to this character**.

---

# 12. AI frequently “shows” and then immediately “tells”

This deserves separate treatment because it explains why some generated prose feels simultaneously detailed and patronizing.

An AI may successfully produce a gesture:

Her fingers tightened around the glass.

But then it may add the interpretation:

The gesture betrayed the anger she had tried so desperately to suppress.

Then perhaps an abstraction:

It was the anger of someone who had spent years being unseen.

The first sentence may already have done the work.

Readers and AI-writing users complain about this pattern because every action becomes self-commentary. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1uadqis/this_is_what_its_like_writing_with_ai/?utm_source=chatgpt.com))

Over hundreds of pages, this makes prose feel padded.

---

# 13. The narration often does not understand importance

This may be the deepest sentence-level criticism I found.

Good narrative prose constantly performs **selection**.

A writer decides this door matters but that door doesn't.

This facial reaction deserves half a sentence.

This kiss deserves three pages.

This battle can be summarized in two paragraphs.

This cup should never be mentioned.

Generated prose often gives readers the impression that it has weaker discrimination between **high-value and low-value narrative information**.

Hence the recurring complaint that everything is dramatic, everything gets metaphorical treatment, every silence is weighted, every glance is meaningful, every choice is “something more.”

One community participant summarized the underlying aesthetic problem well: experienced writers learn that **if everything is emphasized, nothing is**. ([Reddit](https://pl.reddit.com/r/antiai/comments/1u7ugzj/what_is_it_that_makes_ai_writing_so_bad/?utm_source=chatgpt.com))

This also explains why readers can find AI text tiring even when no individual sentence is technically wrong.

---

# 14. Pacing problems: lots happens, yet nothing moves

Readers describe AI pacing in apparently contradictory ways:

too fast;

too slow;

too much filler;

too much summary;

constant dramatic events;

nothing meaningful happening.

Those complaints can coexist.

A story can generate many **events** while producing little **narrative movement**.

Royal Road discussions describe repeated action without character growth. Fanfiction readers complain about conversations that lead nowhere. LitRPG readers report logical inconsistencies and poor pacing even in relatively short AI-like books. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

Some SpaceBattles readers also report a deterioration pattern: intriguing initial premise, followed by increasingly repetitive prose and rapid introduction of new alternate-universe or invented elements that are immediately glossed over rather than integrated. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-15?utm_source=chatgpt.com))

That is a particularly important problem for web novels, where constant generation makes it easy to substitute **more content** for **development**.

---

# 15. Weak setup and payoff

A story can constantly promise significance but fail to cash those promises.

One fanfiction reader summarized the sensation as “everything feeling dramatic with no payout.” ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

AI-generated prose is quite good at producing the *language* of foreshadowing:

A strange feeling.

A meaningful glance.

An unexplained object.

A warning.

A secret.

A name the protagonist vaguely recognizes.

The challenge is making those elements converge dozens of chapters later in ways that feel inevitable but not obvious.

Long-form plotting requires remembering not merely facts but **narrative obligations**.

Once a story introduces a mystery, it has implicitly promised a resolution of appropriate magnitude.

When generators lose those obligations, readers experience apparently meaningful details that dissolve into nothing.

---

# 16. Long-form continuity is one of the most serious failures

This was one of the strongest points of agreement between communities and academic research.

Community examples include characters occupying different physical positions when a scene resumes; information appearing as though previously introduced when it was not; people referring to years-long relationships even though the characters met recently; items being handed over twice; actions occurring before necessary preparatory actions; and characters apparently forgetting what they just experienced. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

A particularly good SpaceBattles description called it an entire story “struggling with the linear passage of time.” ([SpaceBattles Forums](https://forums.spacebattles.com/threads/dealing-with-ai-isms-how-to-criticise-works-that-might-be-ai-generated.1307253/page-4?utm_source=chatgpt.com))

That is almost exactly what recent research finds.

The 2026 ACL paper **“Lost in Stories: Consistency Bugs in Long Story Generation by LLMs”** evaluated long narratives using 2,000 prompts and a taxonomy covering five categories with 19 subtypes. The researchers found that LLMs still contradict established facts, character traits and world rules; factual and temporal errors were particularly common. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.410/?utm_source=chatgpt.com))

A 2026 systematic survey of 57 story-generation studies likewise identifies narrative coherence, character consistency, storyline diversity and plot controllability as continuing challenges. ([ACL Anthology](https://aclanthology.org/2026.eacl-srw.39/?utm_source=chatgpt.com))

This is therefore one of the complaints I would put in the **highest-confidence category**.

---

# 17. Spatial continuity breaks too

This receives less attention than timeline errors but is highly immersion-breaking.

A sword is used before it has been drawn.

An object gets handed over twice.

A character is standing beside someone and is suddenly across the room.

Someone exits and then participates in a conversation without re-entering.

The geography of a chase ceases to make sense.

The scene continues across chapter boundaries with people inexplicably repositioned.

These are exactly the sorts of errors human readers notice once they stop merely admiring sentence fluency and start maintaining a mental simulation of the scene. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

---

# 18. Characters know things they should not know

A SpaceBattles discussion supplied a very revealing example: a character raised in a desert uses a concept tied to the deep sea despite lacking the experience that would plausibly give them that comparison. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-14?utm_source=chatgpt.com))

This is broader than factual hallucination.

Fiction depends on **epistemic boundaries**:

What does the narrator know?

What does this character know?

What vocabulary would they possess?

What cultural assumptions would occur naturally to them?

What secrets have they heard?

What metaphors would their life experience make available?

An LLM possesses far more world knowledge than the character it is portraying. Unless this boundary is actively managed, inappropriate knowledge leaks into narration or dialogue.

The resulting sentence can be perfectly elegant and completely wrong for the character.

---

# 19. Fanfiction has an additional problem: “surface canon” without deep canon

Fanfiction readers are especially sensitive to this.

A model may know the catchphrases, relationships, setting terminology and headline personality traits of a franchise.

That does not mean it possesses a coherent causal model of the canon.

SpaceBattles users experimenting with crossover generation describe outputs that seem unable to fully “master” the source fiction; generated scenarios drift toward generic storytelling expectations rather than the specific logic of the original works. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-13?utm_source=chatgpt.com))

This produces characters who look canon-compliant sentence by sentence yet make decisions that a longtime fan immediately recognizes as alien.

---

# 20. Plot invention tends toward high-probability solutions

Another recurring complaint is **genericness**.

This does not necessarily mean every premise is generic. AI can be prompted with a bizarre premise.

The genericness tends to appear when the system must answer questions such as:

What should happen next?

How should these characters reconcile?

How should the villain's arc end?

What revelation would explain this mystery?

How should the protagonist overcome this insecurity?

Royal Road commenters argue that these questions often pull generated stories toward highly conventional average solutions. ([Royal Road](https://www.royalroad.com/forums/thread/163455?page=5&utm_source=chatgpt.com))

The empirical research on creative homogenization reinforces the concern. AI-assisted short stories can score well individually while becoming more similar as a population. ([PubMed](https://pubmed.ncbi.nlm.nih.gov/38996021/?utm_source=chatgpt.com))

So an AI story may feel surprising at the **premise** level while becoming highly predictable at the **development** level.

---

# 21. The “technically good, aesthetically bad” uncanny valley

This is one of the most interesting findings.

Many readers are not complaining that AI writes like an incompetent beginner.

They're complaining that it combines abilities in an unnatural way:

very clean grammar;

large vocabulary;

complex metaphors;

smooth sentence construction;

yet poor scene logic;

weak characterization;

repetitive rhetoric;

bad pacing;

shallow subtext;

obvious contradictions.

SpaceBattles participants explicitly note this combination: technically proficient but stylistically clumsy, highly prolific and narratively confused. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/?utm_source=chatgpt.com))

That mismatch can create the **uncanny feeling** readers keep describing.

A normal beginner tends to make beginner mistakes across several dimensions simultaneously. A generated text can produce immaculate punctuation while forgetting where a character is standing.

---

# 22. The prose lacks idiosyncrasy

Human authors are often interesting partly because of their irregularities.

They may favor fragments.

They may hate adjectives.

They may use absurdly long sentences.

They may be obsessed with food.

They may almost never describe faces.

They may create strange analogies nobody else would choose.

They may possess regional syntax, professional vocabulary, private humor or peculiar rhythms.

AI editing can remove precisely those irregularities.

Royal Road readers explicitly complain that AI assistance can make prose “sound the same as everything else.” ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This is why some people prefer flawed human prose to more technically correct generated prose: the flaws can be **evidence of selection, personality and intention** rather than noise.

---

# 23. Readers often experience a missing author behind the text

This is not a technical prose defect, but it is central to the reading experience.

A considerable group of readers views literature partly as contact with another mind.

They do not merely want to know what happens next. They want to encounter somebody's choices:

Why did this person choose this image?

Why did they make the protagonist cruel here?

Why does this writer keep returning to fathers and sons?

Why did they leave that ending ambiguous?

When readers believe those decisions were generated statistically, some feel that the interpretive relationship collapses.

A recent essay about AI and reading describes the resulting uncertainty as damaging the implicit human connection on which literary reading often depends. ([The Atlantic](https://www.theatlantic.com/ideas/2026/06/ai-writing-reading-nazir/687419/?utm_source=chatgpt.com))

Royal Road users make the point more bluntly: why invest time reading something the poster could not be bothered to write? ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This objection will not affect every reader. Some people actively enjoy custom AI fiction, interactive storytelling and highly personalized generated fantasies. Recent reporting documents a real audience for that experience. ([WIRED](https://www.wired.com/story/chatbot-generated-fiction-i-like-my-big-rat-wife?utm_source=chatgpt.com))

So this is a **value difference**, not an objective defect.

But it is a major market reality.

---

# 24. Nondisclosure creates a feeling of betrayal

This is stronger than simple dislike.

One r/books reader described enjoying an indie novel until the later pages abruptly became what they perceived as AI-generated prose: generic phrases, nonsensical passages and “word salad.” Their reaction was not merely “this got bad”; they described feeling **betrayed**. ([Reddit](https://www.reddit.com/r/books/comments/1qygilu/a_really_fun_book_i_was_reading_turned_out_to_be/?utm_source=chatgpt.com))

That reaction appears because readers believe they made one kind of transaction and received another.

This is why labeling matters disproportionately.

Royal Road requires stories to distinguish AI-assisted from AI-generated material. Amazon KDP requires publishers to disclose AI-generated text, images and translations **to Amazon**, although AI-assisted content does not require such disclosure. ([Royal Road](https://www.royalroad.com/support/knowledgebase/114?utm_source=chatgpt.com))

---

# 25. AI suspicion itself is now damaging reading

This was one of the most unexpected consequences.

Some readers say they can no longer comfortably read modern prose containing:

em dashes;

flowery descriptions;

similes;

contrastive sentences;

triplets;

very polished grammar;

certain elevated words.

A reader in r/literature described abandoning books after developing a constant suspicion of AI writing, even while acknowledging that the supposed signals are perfectly legitimate human techniques. ([Reddit](https://www.reddit.com/r/literature/comments/1ox7too/constant_exposure_to_aigenerated_writing_has/?utm_source=chatgpt.com))

Writers report the corresponding anxiety: they are afraid ordinary beginner mistakes, poetic descriptions, em dashes or clean prose will make readers accuse them of AI use. ([Reddit](https://www.reddit.com/r/royalroad/comments/1uwps94/nightmare_fuel_being_accused_of_using_ai_because/?utm_source=chatgpt.com))

This is a genuine secondary harm: **AI has contaminated certain stylistic features by association**.

---

# 26. There is no reliable single “AI tell”

This is critical.

An em dash is not proof.

“Not X but Y” is not proof.

Purple prose is not proof.

Perfect grammar is not proof.

Triplets are not proof.

A metaphor is not proof.

Bad continuity is not proof.

Humans have done every one of these things for centuries.

Experienced readers repeatedly say that what convinces them is **density plus interaction**: several recurring patterns combined with deeper narrative failures over many chapters. ([Reddit](https://www.reddit.com/r/royalroad/comments/1rg903j/not_every_poorly_written_story_is_ai/?utm_source=chatgpt.com))

Long-form problems are far more informative than one punctuation mark.

And automated detectors should not be treated as definitive evidence either. Recent studies find substantial variation among detectors, particularly for hybrid or lightly AI-polished text. An ACL study found detectors frequently flag AI-polished human text and cannot reliably distinguish degrees of AI involvement; another 2026 study found commercial tools performed particularly poorly on hybrid writing. ([ACL Anthology](https://aclanthology.org/2025.findings-acl.1303/?utm_source=chatgpt.com))

So a responsible conclusion should be:

**“This prose exhibits patterns readers frequently associate with generated writing”** is defensible.

**“This phrase proves ChatGPT wrote this”** generally is not.

---

# 27. AI makes discovery worse even for readers who never open an AI book

This is the marketplace problem.

Kindle and Kindle Unlimited readers complain that finding books now requires additional investigation: checking publication frequency, reviews, author history, covers and samples. One user said they did not want to have to “thoroughly investigate every author.” Another Cozy Fantasy reader said avoiding suspected AI content had made choosing the next book significantly more laborious. ([Reddit](https://www.reddit.com/r/kindle/comments/1un1a9q/how_we_avoiding_ai_slop/?utm_source=chatgpt.com))

LitRPG readers similarly describe searching through rapidly published books and short AI-like titles with weak pacing and logical inconsistencies before finding something they consider normally written. ([Reddit](https://www.reddit.com/r/litrpg/comments/1uz10oy/ai_book_covers_and_ai_slop/?utm_source=chatgpt.com))

Scribble Hub users describe spending substantial time opening stories only to immediately close them because multiple synopses possess the same generated style. ([Scribble Hub Forum](https://www.scribblehubforum.com/threads/we-need-a-new-content-warning-asap.22004/?utm_source=chatgpt.com))

So there is a **search-cost externality**: low-cost generation makes everybody else spend more time sorting.

---

# 28. It damages trust in self-publishing and web fiction

This may become one of the most economically important consequences.

Kindle Unlimited readers report becoming reluctant to try unknown self-published authors because they no longer trust whether a new book represents ordinary amateur writing or mass-produced generated text. ([Reddit](https://www.reddit.com/r/KindleUnlimited/comments/1sxqjut/concerns_about_ai_slop_in_ku/?utm_source=chatgpt.com))

That harms precisely the human indie writers who most need readers willing to experiment.

The problem therefore is not merely “bad AI books compete with good books.”

It is that **AI suspicion increases the risk of trying an unfamiliar author**.

---

# 29. High output itself becomes suspicious

Web-fiction and Kindle communities repeatedly bring up impossible-looking publication schedules.

Ten thousand words every day.

Several enormous books within months.

Multiple simultaneous series.

A new 500-page title every few weeks.

This is not textual evidence, and highly productive human writers certainly exist. But readers increasingly combine extreme release velocity with stylistic and continuity problems as circumstantial evidence. ([Reddit](https://www.reddit.com/r/royalroad/comments/1tjepgh/i_hate_ai_and_i_hate_that_people_dont_see_it_when/?utm_source=chatgpt.com))

That creates another unfortunate consequence: genuinely prolific writers can now be treated with suspicion.

---

# 30. Covers, blurbs and reviews have become trust signals for the text

Readers frequently use an AI-looking cover as a **risk indicator**, not necessarily because the cover proves the manuscript is AI-written, but because it changes their prior expectation.

Some Royal Road readers explicitly say a visibly generated cover makes them expect similar lack of refinement inside. Kindle/LitRPG users say an obviously generated blurb can make them distrust the manuscript before opening it. ([Reddit](https://www.reddit.com/r/ProgressionFantasy/comments/1vy6kiz/removed/?utm_source=chatgpt.com))

There is an important counterpoint: communities repeatedly warn that plenty of genuine indie writers use inexpensive AI covers while writing their text themselves. ([Reddit](https://www.reddit.com/r/litrpg/comments/1vs2t6a/ai_written_books/?utm_source=chatgpt.com))

Again, the issue is probabilistic perception, not proof.

---

# What problems are strongest across *all* the material?

After separating ethical objections from complaints about actual reading, I would rank the recurrent problems approximately like this:

| Reader problem | How consistently it appeared | Research support |
|---|---|---|
| Repetitive rhetorical/sentence structures | Extremely strong | Indirect support through homogenization research |
| Purple/overdramatic prose | Extremely strong | Primarily community evidence |
| Overexplaining / lack of subtext | Very strong | Primarily community evidence |
| Generic or homogenized authorial voice | Extremely strong | Strong empirical support |
| Repetitive scenes and emotional beats | Very strong | Consistent with story-generation research |
| Character inconsistency | Extremely strong | Strong research support |
| Timeline/factual continuity errors | Extremely strong | Direct 2026 ACL evidence |
| Weak long-range plot coherence | Extremely strong | Strong survey/research support |
| Dialogue voices becoming similar | Strong | Supporting dialogue/persona research |
| Character knowledge leaking incorrectly | Strong | Consistent with long-context/persona limitations |
| Everything receiving too much emphasis | Very strong | Community evidence |
| Generic/clichéd solutions to plot problems | Strong | Supported indirectly by homogenization studies |
| Poor setup/payoff | Strong | Consistent with long-form planning limitations |
| Emotional flatness despite emotional vocabulary | Extremely strong reader perception | Harder to quantify objectively |
| Loss of author-reader connection | Extremely strong among anti-AI readers | Value-dependent rather than technical |
| Suspicion/false accusations contaminating human writing | Strong and growing | Detector research supports caution |
| Discovery fatigue / marketplace flooding | Extremely strong in Kindle/web-fiction communities | Ecosystem rather than prose issue |

---

# The most useful insight from all of this

If someone wanted to create AI-assisted fiction that readers **do not experience as AI writing**, simply banning words such as *delve*, removing em dashes and deleting “not X but Y” would solve only the superficial layer.

The deeper reader complaints operate in a hierarchy:

**Level 1 — vocabulary:** favorite words, stock adjectives, cliché metaphors.

**Level 2 — syntax:** contrastive reframing, triplets, staccato fragments, repeated rhetorical structures.

**Level 3 — paragraph logic:** saying the same thing multiple ways, explaining the meaning of actions, unnecessary emotional interpretation.

**Level 4 — scene logic:** repetitive conversations, excessive introspection, bad information prioritization, no subtext.

**Level 5 — character logic:** same voices, unstable motivations, forgotten experiences, incorrect knowledge.

**Level 6 — narrative logic:** contradictions, repeated plot functions, weak causality, poor setups/payoffs, abandoned threads.

**Level 7 — artistic identity:** the absence of a peculiar, coherent sensibility controlling what the book notices, ignores, emphasizes, finds funny, finds ugly, refuses to explain, or chooses to leave unresolved.

Most “AI detector” discussions obsess over Levels 1–2.

The communities with the most experienced long-form readers keep pointing toward **Levels 4–7**.

That is probably the single most important conclusion of this research.

A generated novel does not usually fail because one sentence contains an em dash.

It fails when, after 150 pages, the reader realizes that **the book can continuously produce prose without continuously accumulating meaning**.

That is the complaint underneath “soulless,” “slop,” “word salad,” “repetitive,” “generic,” “AI cadence,” “nothing happens,” and “something feels off.”

And that conclusion is remarkably consistent across conventional book readers, Kindle readers, fanfiction communities, Royal Road/web-fiction readers, people who actively write with AI, and current long-form narrative research. ([Reddit](https://www.reddit.com/r/books/comments/1qygilu/a_really_fun_book_i_was_reading_turned_out_to_be/?utm_source=chatgpt.com))

One important counterweight should remain in view: this does **not** mean AI-assisted fiction is automatically worse. Experimental evidence has found AI ideas can make individual short stories better written and more enjoyable, especially for weaker writers, and some readers genuinely enjoy AI-driven personalized fiction. The more defensible conclusion is narrower: **current AI-heavy writing has characteristic failure modes that become particularly damaging when generation replaces sustained human control over voice, causality, character memory and narrative selection.** ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com))

If your purpose behind this research is to **design a writing system or prompt that produces novels without these problems**, this material can be taken much further: the next step would be to turn these findings into a **comprehensive “anti-AI-writing” specification**—possibly 100+ concrete prohibitions, tests and revision rules covering prose, dialogue, characterization, emotional logic, continuity, pacing, worldbuilding and chapter-to-chapter memory.

## User

yes with the findings i want you to create a type of system with chatgpt, before you move onto creating a writing first

i want to know how these problems can be made comprehensive and put in a chatgpt project so that it act as constant reminder

## ChatGPT

Yes. The right approach is **not** to dump 100+ rules into one giant prompt. The project should have a layered control system: a short set of non-negotiable principles always active, a detailed reference manual for edge cases, and mandatory checks ChatGPT must run before and after every piece of fiction.

## ChatGPT

Yes. The best design is to make the project behave less like “ChatGPT with a long prompt” and more like a **fiction-writing operating system**.

ChatGPT Projects currently support project-specific instructions, uploaded files, and project memory/context across chats. Project instructions apply only inside that project and override your global custom instructions. Files and chats inside the project can also supply ongoing context. ([OpenAI Help Center](https://help.openai.com/en/articles/10169521?utm_source=chatgpt.com))

The key is **redundancy by design**. We should not trust one enormous document to keep 100+ problems active in the model’s attention.

I would build it in these layers:

1. **Project Constitution — always active.** This goes directly into the Project Instructions. It contains perhaps 20–30 high-level, non-negotiable rules distilled from all the research. Things like: preserve causal continuity; never explain an emotion already demonstrated; characters must have distinct cognitive voices; scenes must change the state of the story; don't manufacture significance through rhetorical emphasis; preserve epistemic boundaries; don't reset resolved conflicts; never substitute ornament for specificity. These are principles rather than enormous lists of banned phrases.

2. **AI-Writing Failure Manual — detailed reference file.** This would contain the comprehensive research translated into perhaps **100–200 identifiable failure modes**. Each failure would have a name, definition, bad pattern, why readers dislike it, warning signs, exceptions, and correction method. For example, `FM-017: Emotional Paraphrasing`, `FM-032: Contrastive Reframing Overuse`, `FM-061: Character Knowledge Leakage`, `FM-088: Psychological Reset`, `FM-112: False Foreshadowing`, etc. This becomes the project's encyclopedia.

3. **Prose & Style Control Manual.** Sentence- and paragraph-level failures belong here: repetitive syntax, “not X but Y,” triplets, unnecessary fragments, fake profundity, adjective stacking, vague metaphors, excessive em-dash cadence, unnecessary interpretation, over-description, generic body language, artificial paragraph endings, excessive rhetorical symmetry, and so on. Importantly, these should usually be controlled by **frequency and function**, not crude bans.

4. **Character Intelligence System.** A separate file should govern characterization because it is too important to bury among prose rules. For every major character we eventually track worldview, vocabulary, emotional habits, knowledge boundaries, contradictions, fears, conversational habits, what they notice, what they ignore, what they misunderstand, what they refuse to admit, and how those properties change. This directly attacks the “everyone sounds like ChatGPT” problem.

5. **Narrative Continuity System.** This governs facts across chapters: timeline, geography, injuries, possessions, relationships, promises, unresolved mysteries, character knowledge, abilities, world rules, planted information and consequences. Every new chapter must preserve previous commitments unless the story deliberately changes them.

6. **Scene Causality System.** Every scene should have a before-state and an after-state. The system should ask internally: *What changed because this scene occurred?* Information, relationship, intention, danger, knowledge, resources, emotional state or plot position should move. If nothing meaningful changes, the scene risks being AI-style content generation rather than narrative progression.

7. **Anti-Repetition System.** This should operate at several scales simultaneously: words, phrases, syntax, metaphors, gestures, dialogue structures, emotional beats, conflict types, scene structures and plot functions. This matters because ordinary repetition detection catches “he sighed” appearing five times but misses five completely different scenes performing the same narrative job.

8. **Subtext & Restraint System.** This tells ChatGPT what **not to explain**. It should deliberately leave some motivations inferred, allow gestures to carry emotional information, preserve ambiguity when appropriate, avoid translating dialogue into psychology, and trust readers to connect obvious implications.

9. **Long-Range Story State.** For an actual novel, we create a living Story Bible plus a Continuity Ledger. These hold current canonical facts rather than general writing rules. After chapters are established, important state changes are recorded there: who knows what, wounds, relationships, locations, unresolved promises, mysteries, resources, changed beliefs, etc. Project context can draw from files and prior project conversations, but important canon should still be explicitly maintained rather than entrusted only to conversational memory. ([OpenAI Help Center](https://help.openai.com/en/articles/10169521?utm_source=chatgpt.com))

10. **Mandatory Pre-Writing Gate.** Before producing prose, ChatGPT should internally check the upcoming scene against character state, continuity, scene purpose, POV knowledge, emotional progression, previously used structures and unresolved threads. This prevents many problems *before* they appear rather than trying to edit them away afterward.

11. **Mandatory Post-Writing Audit.** After drafting, ChatGPT should inspect its own work against the failure manual before presenting it. Not just grammar. It should check things such as duplicated meaning, excessive explanation, repeated rhetorical structures, generic gestures, false profundity, character voice convergence, continuity errors, unnecessary metaphors, weak causality and scene redundancy. It should silently repair violations rather than merely tell you they exist.

12. **Adversarial “AI-smell” pass.** I would make this distinct from normal editing. ChatGPT temporarily acts like a hostile reader trying to identify why the passage feels generated. It asks: *Where can I predict the sentence ending? Where does the narrator over-interpret? Where is importance artificially inflated? Where could another character say this exact line? Where is language replacing thought? Where did the story forget to accumulate consequences?* Then it revises those portions.

13. **Authorial-Identity Layer.** Avoiding bad AI prose isn't enough. Otherwise we merely produce clean but generic prose. The project eventually needs a positive style specification describing what **this particular work does well**: observational habits, humor, sentence rhythm, degree of exposition, tolerance for ambiguity, narrative distance, sensory priorities, philosophical preoccupations, vocabulary range, violence treatment, dialogue density, etc. The goal becomes “write like this story,” not merely “don't sound like AI.”

14. **Rule hierarchy and conflict handling.** The project needs an explicit hierarchy so instructions don't fight each other. Canonical facts should outrank stylistic convenience. Character truth should outrank a desire for dramatic dialogue. Scene causality should outrank pretty prose. Specificity should normally outrank generic intensification. Established authorial voice should outrank generic notions of “better writing.” And deliberate exceptions should be allowed when they have a narrative reason.

15. **A compact permanent reminder.** This is important. The detailed manual may eventually become tens of thousands of words. We therefore create a short “Core Reminder” embedded directly in Project Instructions that effectively says: *Before writing or revising fiction, apply the Constitution, consult the relevant project references, preserve canon and character state, run the preflight and post-draft checks, and prioritize narrative intention over locally impressive prose.* That keeps the larger system anchored every turn.

The architecture would therefore look approximately like:

**Project Instructions** 
→ Fiction Constitution + mandatory workflow

**Project Files** 
→ `01_AI_WRITING_FAILURE_MANUAL` 
→ `02_PROSE_AND_STYLE_CONTROL` 
→ `03_CHARACTER_AND_VOICE_SYSTEM` 
→ `04_NARRATIVE_CONTINUITY_SYSTEM` 
→ `05_SCENE_AND_PACING_SYSTEM` 
→ `06_DIALOGUE_AND_SUBTEXT_SYSTEM` 
→ `07_PREWRITE_AND_POSTWRITE_AUDIT` 
→ `08_STORY_BIBLE` 
→ `09_CONTINUITY_LEDGER` 
→ `10_AUTHORIAL_STYLE_PROFILE`

That setup is better than putting everything directly into Project Instructions because the instructions remain **short enough to stay behaviorally important**, while the detailed files provide depth when needed.

There is also an important conceptual change I would make.

We should **not call the system simply an “AI tell remover.”**

That would encourage superficial tricks such as deleting em dashes and replacing “not X but Y.” Instead, its objective should be:

> **Produce fiction exhibiting sustained intentionality, causal accumulation, character-specific consciousness, narrative memory, stylistic variation, subtext, specificity and controlled emphasis.**

Then the “AI tells” become diagnostic symptoms of deeper failures.

For example:

**Repeated “not X but Y”** 
→ deeper problem: manufactured rhetorical emphasis.

**Everyone sounds alike** 
→ deeper problem: insufficient character-specific cognition.

**Purple prose** 
→ deeper problem: description isn't governed by POV or narrative importance.

**Repeated emotional conflicts** 
→ deeper problem: story state isn't accumulating.

**Overexplaining** 
→ deeper problem: insufficient trust in reader inference.

**Continuity mistakes** 
→ deeper problem: narrative commitments aren't being treated as persistent state.

**Generic plot developments** 
→ deeper problem: local probability is replacing long-range intentionality.

That is how I think we should make the research genuinely comprehensive rather than merely assembling a gigantic blacklist.

And Projects are a suitable place to build this because their purpose is precisely to keep instructions, files and related conversations together across an ongoing body of work. Project-only memory can additionally keep that context isolated from unrelated work if desired. ([OpenAI Help Center](https://help.openai.com/en/articles/10169521?utm_source=chatgpt.com))

**I would build this before we write any novel.** The next stage should be constructing the actual **AI-Writing Failure Taxonomy** from the research—probably around **120–200 concrete failure modes**, organized into prose, description, dialogue, characterization, psychology, POV, scene construction, pacing, continuity, plot, worldbuilding, emotional writing, style and long-range narrative structure. Once that taxonomy is complete, we can convert it into the Project Constitution and the supporting manuals.

## User

make 20 plus passes and retrieval over the internet, source, etc to see whether that is all before we begin

and remember the goal is not to create strict rules for the chatgpt or the AI, but rather guide to a better result

remember these guide can be used for any novel, so they need to abit generalised

## ChatGPT

I’m going to stress-test the existing findings rather than assume the first research pass was complete. I’ll do more than 20 separate retrieval passes across reader communities, writing forums, publishing discussions, AI-writing communities, and recent research, specifically looking for **missing failure modes, counterexamples, and problems that are genre-independent**. I’ll also keep the end goal in mind: these should become flexible guidance, not rigid prohibitions.

## ChatGPT

The expanded search is adding several categories the first pass underweighted: **over-neat plot structure, weak or absent subplots, characters functioning as exposition tools, excessive protagonist validation, premature emotional payoffs, over-analysis of micro-expressions, and “static-vs-drifting” characterization**—where characters either repeat themselves mechanically or evolve without a believable psychological bridge. Importantly, several AI-writing practitioners independently report that long “do not do X” lists make prose flatter; positive targets and context-specific guidance work better. 

## ChatGPT

Yes. I did another **24+ separate search/retrieval passes**, deliberately trying to break the first research rather than confirm it. I searched reader communities, author communities, AI-writing communities, web-fiction forums, genre communities, Goodreads reviews, traditional writing discussions, and current academic research on narrative generation, long-form consistency, characterization, linguistic homogenization, and reader judgments.

The result is useful: **the original research was directionally correct, but it was not complete enough to build the final system yet.** Several deeper categories emerged that should be incorporated before we write the Project guidance.

The original research already correctly concluded that the serious problems occur above the word/sentence level—scene logic, character logic, narrative logic, and artistic identity. The expanded research strengthens that conclusion considerably.

## The biggest correction to our approach

We should **not build an “anti-AI rulebook.”**

That would actually make the writing worse.

People who actively work with LLM fiction repeatedly report that enormous negative constraint lists—“don't use X,” “never do Y,” “avoid Z”—can make prose flatter and more mechanical. One experienced AI-writing discussion made the useful distinction that positive guidance about what the prose should *reach for* worked better than pure prohibition. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com))

This also solves your requirement that the eventual system work for **any kind of novel**.

Instead of:

> Never use sentence fragments.

we want:

> Let sentence length and fragmentation follow voice, pacing, emphasis, and the immediate dramatic situation. Watch for repeated fragmentation becoming an automatic cadence rather than an intentional effect.

Instead of:

> Never use “not X, but Y.”

we want:

> Contrastive constructions are useful when genuine contrast, correction, or reframing is occurring. Notice when the same rhetorical mechanism begins appearing reflexively or where no meaningful contrast exists.

That difference is fundamental.

The final system should therefore consist primarily of **principles, questions, preferences, warning signs, and revision lenses**, with very few absolute prohibitions.

---

# What the additional research uncovered

The first research concentrated heavily on repetition, prose cadence, overexplaining, characterization drift and continuity. All of those remain valid. But the deeper passes revealed at least **twenty additional or substantially more nuanced areas** we should capture:

1. **Resolution bias.** AI tends to treat a problem as something that should be solved because assistant models are optimized to be helpful. AI-writing practitioners report betrayal → confrontation → explanation → emotional closure occurring almost immediately rather than being allowed to generate consequences over several scenes. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1r3ls6v/how_to_stop_ai_from_rushing_your_story/?utm_source=chatgpt.com)) The generalized lesson is not “delay every resolution”; it is **let consequences mature for as long as the story benefits from them**.

2. **Over-neat narrative architecture.** StoryScope found that AI stories disproportionately favor tidy, single-track construction and explicitly explained themes. Narrative characteristics alone distinguished its AI and human corpora surprisingly strongly even after surface style was excluded. ([arXiv](https://arxiv.org/abs/2604.03136?utm_source=chatgpt.com)) We should therefore watch not only prose but whether the entire story has become suspiciously frictionless and symmetrical.

3. **Subplot poverty.** This was underrepresented in our original research. AI tends toward one dominant narrative track. Human novels often have side relationships, secondary ambitions, unrelated obligations, background events and subplots that collide with the main plot instead of merely supporting it. StoryScope's findings directly point toward this broader single-track tendency. ([arXiv](https://arxiv.org/abs/2604.03136?utm_source=chatgpt.com))

4. **Theme announcement.** We had “pseudo-depth,” but the deeper phenomenon is larger: models often make the *meaning* of the story explicit. Themes migrate into narration and dialogue instead of emerging from recurring decisions, consequences, images and contradictions. StoryScope specifically found more explicit thematic explanation in generated stories. ([GitHub](https://github.com/jenna-russell/storyscope?utm_source=chatgpt.com)) The guide should favor **thematic embodiment over thematic explanation**, without banning explicit reflection where appropriate.

5. **Moral tidiness.** StoryScope also found human stories more likely to frame protagonist decisions with moral ambiguity. ([arXiv](https://arxiv.org/abs/2604.03136?utm_source=chatgpt.com)) This suggests a broader AI tendency toward making the reader understand who was right, what was learned and how an event should be evaluated. General guidance should preserve the possibility that events remain morally unresolved.

6. **Premature emotional payoff.** AI often recognizes the emotional destination correctly but arrives there before enough narrative investment exists. AI-writing users describe major emotional hits being inserted because a scene is apparently “supposed” to feel important rather than because earlier events earned that emotional weight. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) This is different from purple prose. The underlying problem is **emotional timing**.

7. **Compulsive protagonist validation.** This appeared strongly in the second research. Secondary characters frequently “see” the protagonist remarkably well, understand the pain underneath their behavior, recognize their hidden competence, admire them, forgive them or articulate their internal conflict. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) A healthier general principle is that other people should have their **own incomplete models** of the protagonist.

8. **Mind-reading characters.** Related, but distinct. Characters infer one another's psychology too accurately. They interpret micro-expressions, silences and motives with almost diagnostic precision. This reduces misunderstanding and competing interpretation—the things that produce much human conflict.

9. **Character-as-mouthpiece syndrome.** The first research identified exposition-heavy dialogue, but the broader pattern is that characters often speak because **the narrative needs information transmitted**, rather than because that particular person would choose to say it at that time. This was repeatedly reported in AI-writing analysis. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com))

10. **Excessive composure.** Characters remain extraordinarily articulate during grief, panic, combat, humiliation, sexual tension and physical danger. They deliver complete arguments, perfectly diagnose themselves and choose precisely calibrated language. Community readers repeatedly complain that actual hesitation, fumbling, contradiction, losing one's train of thought and saying the wrong thing are missing. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/golden-asoiaf-joffrey-si.1312374/page-5?utm_source=chatgpt.com)) The generalized principle is not “make dialogue messy,” but **let cognitive and emotional conditions affect communicative ability**.

11. **POV permeability.** This deserves its own category. Models can remain grammatically in third-person limited while quietly introducing information, interpretation or conceptual language the viewpoint character could not reasonably possess. Research on persona consistency supports the broader difficulty of sustaining persona knowledge boundaries over extended interaction. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.1175/?utm_source=chatgpt.com))

12. **Static personality versus believable evolution.** Our first research had “personality drift.” Newer research offers a better conceptual model: identity should contain both relatively stable traits **and adaptive psychological state**. Too much stability becomes robotic repetition; too much adaptability becomes character drift. A 2026 ACL paper explicitly describes this tension as “robotic repetition” versus catastrophic persona drift and proposes distinguishing identity stability from history-dependent psychological evolution. ([ACL Anthology](https://aclanthology.org/2026.acl-long.1336/?utm_source=chatgpt.com)) This should become a central character principle.

13. **Character memory is not the same as character personality.** Models may remember that someone is “sarcastic” while forgetting what specifically happened to them, what they believe happened, what they misunderstood and what memories are emotionally available in the current situation. Recent persona research emphasizes retrieval and application of relevant character memory rather than merely attaching personality labels. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.1175/?utm_source=chatgpt.com))

14. **Chronological simplicity.** StoryScope found greater temporal complexity in the human-written comparison stories. ([arXiv](https://arxiv.org/abs/2604.03136?utm_source=chatgpt.com)) This does **not** mean we should force flashbacks into every novel. The general lesson is that chronology should serve the work rather than defaulting automatically to simple event-A → event-B → event-C narration.

15. **Flat escalation.** StoryScope found model-specific differences, including notably flat event escalation for one model. ([arXiv](https://arxiv.org/abs/2604.03136?utm_source=chatgpt.com)) This points to a broader question we hadn't sufficiently captured: tension shouldn't simply remain high or mechanically increase. It needs modulation—pressure, release, misdirection, recovery, secondary pressure, escalation, reversal.

16. **Scene-shape repetition.** We previously captured repeated scene *content*, but not enough of repeated scene architecture. Experienced AI users describe models repeatedly producing setup → tension → emotional articulation → mini-resolution structures, causing every scene to feel like an episode that neatly closes itself. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) We need to watch structural rhythm across scenes just as much as sentence rhythm.

17. **Negative-space overdescription.** Models sometimes describe what something *isn't* almost as often as what it is: “not angry,” “not afraid,” “not quite disappointment,” “not silence exactly.” AI-writing practitioners specifically identify this as a recurring habit. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) The problem is not negative description itself; it is using negation as a habitual substitute for precise perception.

18. **Micro-expression obsession.** Eyes narrow, mouths twitch, shoulders tighten, fingers flex, breath catches, jaws harden. Our first research touched generic body language, but the broader failure is **continuous emotional telemetry**—as though every emotion must be externally registered. AI-writing reviewers specifically report excessive narration of micro-expressions. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) Sometimes the narratively correct reaction is no visible reaction.

19. **Social-world thinness.** A character may possess a family, friend, enemy and love interest, yet everybody primarily orbits the protagonist and main plot. Ordinary relationships, acquaintances, obligations, reputations, institutional pressures and social consequences are weak. Older writing communities already identified “lack of social worldbuilding” independently of AI, which is important because this is a **general craft failure amplified by AI**, not an AI-exclusive defect. ([Scribble Hub Forum](https://www.scribblehubforum.com/threads/biggest-mistakes-when-writing.5000/post-126545?utm_source=chatgpt.com))

20. **Developmental plausibility.** Romance readers described generated children behaving at implausible developmental ages and numerical timelines drifting. ([Reddit](https://www.reddit.com/r/RomanceBooks/comments/1u5352k/identifying_ai_novels_a_guide/?utm_source=chatgpt.com)) This generalizes to age, expertise, profession, disability, culture, education, class and experience. A person's behavior should emerge from who they actually are, not the generic narrative role they occupy.

21. **Physical-common-sense failures.** Readers report gestures and physical descriptions that are linguistically plausible but bodily impossible—for example spatial relationships that would not permit the described action. ([Reddit](https://www.reddit.com/r/RomanceBooks/comments/1djmv0q/have_people_started_to_see_romance_written_by_ai/?utm_source=chatgpt.com)) This deserves separation from continuity. It is **embodied plausibility**.

22. **Metafictional knowledge leakage.** One of the strongest additional examples comes from authors/readers observing that once an important fact is known to the narrative, unrelated characters begin acting as though they know it too. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1tta460/i_used_to_think_i_hate_ai_writing_and_writers/?utm_source=chatgpt.com)) This is different from ordinary factual contradiction: the model confuses **narrator knowledge with character knowledge**.

23. **Meaningless optimization/rationalization.** Progression-fantasy readers describe protagonists constantly analyzing, organizing and optimizing ordinary interaction. ([Reddit](https://www.reddit.com/r/ProgressionFantasy/comments/1v244uc/noticing_a_weird_trend/?utm_source=chatgpt.com)) This may partly reflect genre convention, so it must not become a ban. The more general principle is: **the mode of thought should arise from this character and this genre, not from the model's habitual analytical voice**.

24. **Friction avoidance.** This appeared repeatedly in AI-writing practitioner discussions. Models often smooth relationships toward understanding, sympathy, cooperation and closure. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1v3jhwt/writing_well_is_not_evidence_against_you_fiction/?utm_source=chatgpt.com)) Yet fiction frequently depends on competing legitimate interests, irrational grudges, incompatible needs, social constraints and unresolved resentment. The guide should protect productive friction rather than demanding constant conflict.

25. **Overdetermined symbolism.** We previously identified repetitive motifs. The deeper issue is that once an object becomes symbolic, AI may keep reminding the reader of its symbolic function. The reader is never allowed to forget what the rain, ring, scar, photograph or empty chair “means.” The better principle is to let motifs **accumulate associations without continuously decoding them**.

26. **Generic worldbuilding vocabulary.** Worldbuilding communities notice recurring labels and concepts that feel generated because they sit at the statistical center of genre vocabulary. ([Reddit](https://www.reddit.com/r/worldbuilding/comments/1waqhrf/ai_worldbuilding_tells/?utm_source=chatgpt.com)) We should not blacklist words such as *weaver*, *veil*, *nexus* or *ancient*. Instead, the guide should ask whether terminology emerges organically from the world's history, institutions and people.

27. **Causal shallowness disguised by logical prose.** AI can produce a sequence where every immediate transition makes sense while the larger causal chain is weak. “Because A, B happens; because B, C happens” is not enough if characters had other plausible options or institutions should have reacted differently. This is one reason character simulation has been found useful in research: generating behavior through modeled characters can outperform straightforward outline-to-prose elaboration. ([ACL Anthology](https://aclanthology.org/2025.in2writing-1.9/?utm_source=chatgpt.com))

28. **The middle-of-the-book danger zone.** The 2026 ConStory benchmark found consistency errors disproportionately appearing around the middle of long narratives, particularly factual and temporal inconsistencies. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.410/?utm_source=chatgpt.com)) That suggests our eventual audit process should pay particular attention to **accumulation**, not assume later chapters are the only place drift occurs.

29. **Consistency needs multiple dimensions.** The same research defines nineteen fine-grained consistency error subtypes across five larger categories. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.410/?utm_source=chatgpt.com)) Our future continuity system therefore shouldn't merely ask “Did names and facts stay the same?” It should check temporal, factual, character, world-rule and event consistency separately.

30. **Originality can decrease even while local quality improves.** This is particularly important for our philosophy. Controlled research found that AI assistance could make individual short stories more creative, better written and more enjoyable—especially for weaker writers—while making the collection of stories more similar overall. ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com)) A new Nature study across more than 880,000 texts similarly found reduced linguistic variation under LLM rewriting, including a 21–50% reduction in variance of writing complexity in the datasets/models they studied. ([Colin Leitner](https://ltnr.ca/morty/?mortyurl=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41562-026-02550-0%3Ferror%3Dcookies_not_supported%26code%3D99f87014-95de-4fb7-9268-5454d852343b&utm_source=chatgpt.com))

That last result is why our system must **preserve difference**, not enforce a universal definition of “good prose.”

---

# There is an important counterfinding

The research does **not** justify treating AI prose as inherently inferior.

This matters tremendously for how we design the system.

A 2026 Cambridge study involving 2,587 adults across three experiments found that participants could not reliably distinguish the tested human and AI short stories; the AI stories were actually rated higher for quality and absorption in the first study, although participants rated stories more favorably when told they were human-written. ([Cambridge University Press](https://www.cambridge.org/core/journals/judgment-and-decision-making/article/bot-or-not-can-people-tell-the-difference-between-stories-written-by-a-human-or-by-an-ai-system/45E6DC0BB90AA648654D5AE243F6C667?utm_source=chatgpt.com))

A Japanese fiction study found **human–AI collaboration ranked highest in perceived quality**, ahead of original human writing, detailed-prompt AI and zero-shot AI, although collaborative writing also scored lowest in originality. ([Sage Journals](https://journals.sagepub.com/doi/10.1177/09732586261463934?utm_source=chatgpt.com))

And the Science Advances experiment found AI-supported writers could produce individually better-rated short fiction. ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com))

So our target cannot sensibly be:

> “Make AI write like humans.”

That is too vague and sometimes empirically wrong.

Our target should be:

> **Help the model sustain the narrative qualities that strong novels require, while protecting the particular identity, logic, irregularities, priorities and intentions of the individual work.**

That is much better.

---

# The first research therefore remains valid—but needs reframing

Your existing research file concluded that Levels 4–7—scene logic through artistic identity—matter more than superficial “AI tells.” 

I now think that conclusion is **even more correct than we originally realized**.

The second research suggests a revised hierarchy:

**Surface expression** concerns vocabulary, syntax, rhythm and rhetorical repetition.

**Perceptual selection** concerns what the narration notices, ignores, describes and emphasizes.

**Dialogue intelligence** concerns what people choose to say, conceal, misunderstand and fail to articulate.

**Character cognition** concerns knowledge, memory, worldview, biases, competence, emotional state and individual interpretation.

**Interpersonal dynamics** concerns friction, mistaken models of others, relationships, status, competing interests and social consequences.

**Scene intelligence** concerns purpose, causal movement, escalation, withholding, payoff, dramatic duration and structural variety.

**Narrative accumulation** concerns consequences, subplots, unresolved obligations, setup/payoff and transformations that survive subsequent chapters.

**World intelligence** concerns rules, institutions, geography, economics, social structures, physical plausibility and consequences beyond the protagonist.

**Long-range continuity** concerns time, facts, identities, possessions, injuries, relationships, knowledge and prior decisions.

**Thematic intelligence** concerns allowing meaning to emerge rather than automatically interpreting it.

**Structural variety** concerns temporal complexity, subplot interaction, scene shapes, escalation patterns and information revelation.

**Artistic identity** concerns why *this* novel chooses these particular things—its obsessions, omissions, rhythms, strangeness, values and forms of attention.

That is a more complete framework than our original seven levels.

---

# And yes: the future guide must remain generalized

This requirement should become part of the system's design philosophy.

A romance novel, progression fantasy, murder mystery, literary novel, comedy, grimdark epic, children's novel and surrealist novella should **not** all be pushed toward the same prose, pacing or psychological style.

So the eventual manual should repeatedly use language such as:

**“Consider…”**

**“Watch for…”**

**“Prefer when appropriate…”**

**“Ask whether…”**

**“This can become a problem when…”**

**“The issue is repeated/default use, not the technique itself.”**

**“Preserve deliberate exceptions.”**

It should rarely say:

**“Never…”**

The Royal Road community actually produced an interesting set of AI-writing guardrails very close to this philosophy: preserve author voice, distinguish a genuine problem from mere stylistic preference, protect intentional fragments/repetition, prioritize meaningful reader problems over arbitrary line editing, and leave passages alone when they already work. ([Royal Road](https://www.royalroad.com/forums/thread/175498?page=1&utm_source=chatgpt.com))

That is much closer to what we need than a blacklist.

---

# What should *not* become rules

This is now clear enough that I want it settled before we construct anything.

Em dashes should **not** be banned.

Fragments should **not** be banned.

One-line paragraphs should **not** be banned.

Purple or ornate prose should **not** be universally banned.

Introspection should **not** be capped mechanically.

“Not X but Y” should **not** be banned.

Three-part rhetorical structures should **not** be banned.

Metaphors should **not** be rationed numerically.

Explicit emotion should **not** always be replaced with body language.

“Show, don't tell” should **not** become an absolute command.

Simple chronological narratives should **not** be regarded as inferior.

Happy resolution should **not** be treated as suspicious.

Clean grammar should obviously **not** be degraded merely to seem human.

SpaceBattles discussions contain useful counterexamples where supposed “AI tells” were perfectly appropriate because the passage was a religious speech; repetition, heightened diction and rhetorical parallelism made sense in that context. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-11?utm_source=chatgpt.com)) Fanfiction communities likewise repeatedly warn that single traits cannot establish AI authorship because these devices all originated in human writing. ([Reddit](https://www.reddit.com/r/AO3/comments/1q2xw1j/the_fics_feel_fake/?utm_source=chatgpt.com))

That principle needs to run through the entire future system:

> **Context decides whether a technique is effective. Frequency alone is a warning; function decides whether it is a problem.**

---

# So: have we found “all” the problems?

Not literally. No taxonomy of fiction can ever be complete because models change, genres differ, and writers invent new forms.

But after the original research plus these **24+ additional retrieval passes**, I think we have reached the point of **strong diminishing returns**.

The remaining searches mostly started rediscovering the same underlying mechanisms under different names:

repetition → weak intentional variation;

purple prose → weak information prioritization;

same-voice dialogue → weak character cognition;

overexplaining → weak reader trust;

continuity errors → weak persistent narrative state;

generic plot → probability replacing specific intention;

rapid resolution → assistant/helpfulness bias;

flat characters → weak memory and adaptive psychological state;

fake depth → interpretation without earned specificity;

soullessness → local fluency without accumulated consequence;

formulaic storytelling → repeated narrative architecture;

lack of originality → homogenization of linguistic and narrative decisions.

That convergence is what tells me the research phase has become mature enough.

We **should not start writing the novel yet**, but I think we can now stop hunting randomly for more complaints and move to the next stage:

**build the complete generalized taxonomy first.**

Not 150 “rules.”

More like **120–180 guidance items**, each expressed as:

**Underlying principle → common failure pattern → why it weakens fiction → diagnostic questions → better direction → legitimate exceptions.**

For example, instead of:

> **Rule 47: Do not overexplain emotions.**

we would eventually encode something closer to:

> **Reader inference and emotional restraint** 
> Emotional meaning can be carried by action, thought, dialogue, omission, setting, direct statement or combinations of these. Watch for passages that communicate the same emotional conclusion several times through different channels. When the reader can already infer the intended feeling, additional explanation may weaken the moment rather than strengthen it. Direct emotional explanation remains useful when clarity, voice, pacing or the character's mode of thought calls for it.

That is the kind of **general-purpose guidance** I now recommend for the ChatGPT Project.

And importantly, it won't try to make every novel “correct.”

It will try to make ChatGPT **notice what it is doing, understand why it is doing it, preserve deliberate choices, and avoid falling unconsciously into its own defaults.**

## User

let start 

## ChatGPT

We’ll start with the **master taxonomy**, because everything else—the Project Instructions, reference manuals, audits, and story-specific files—will be derived from it. I’ll structure every item as guidance rather than prohibition: **principle → failure mode → why it matters → diagnostic questions → better direction → valid exceptions**.

## ChatGPT

The source research already supports the core premise: the most damaging failures are not isolated words or punctuation but failures of **scene logic, character logic, narrative accumulation, and artistic identity**. So I’m making the taxonomy hierarchical: surface-level guidance exists, but deeper story intelligence outranks it.

## ChatGPT

We should begin with the **Master Fiction Guidance Taxonomy**. The research repeatedly shows that surface “AI tells” matter less than failures in accumulated meaning, character logic, scene purpose, continuity, and artistic identity. 

This version is deliberately **genre-neutral**. It is meant to work for romance, fantasy, horror, literary fiction, progression fantasy, mystery, fanfiction, web novels, science fiction, comedy, historical fiction, and hybrids.

# MASTER FICTION GUIDANCE TAXONOMY

## Purpose

This system is not a blacklist of AI habits.

It is a collection of **creative guidance lenses** intended to help a writing model notice when it is falling into automatic, repetitive, overly convenient, shallow, or context-insensitive choices.

Its purpose is to improve:

- narrative intentionality;
- character individuality;
- causal continuity;
- emotional specificity;
- dialogue authenticity;
- scene progression;
- reader inference;
- long-range coherence;
- stylistic flexibility;
- and the distinct identity of the individual work.

The system should **guide judgment rather than replace judgment**.

No technique is automatically wrong merely because AI often overuses it.

Fragments, repetition, ornate prose, direct exposition, simple chronology, heightened dialogue, rhetorical contrast, internal monologue, symbolism, one-line paragraphs, explicit emotion, and familiar genre conventions may all be excellent when they serve the particular story.

The central question is therefore rarely:

> Is this technique allowed?

The more useful question is:

> Why is this choice here, what is it accomplishing, and is it arising from this story rather than from an automatic writing habit?

---

# I. FOUNDATIONAL OPERATING PRINCIPLES

## Principle 1 — Function before appearance

A passage should not merely resemble good fiction.

Its choices should perform useful work for character, atmosphere, information, tension, rhythm, theme, world, relationship, plot, or reader experience.

Polish is not a substitute for purpose.

---

## Principle 2 — Context before rule

A technique should be judged according to:

- genre;
- viewpoint;
- character;
- tone;
- scene purpose;
- narrative distance;
- intended readership;
- pacing;
- surrounding prose;
- and the established identity of the book.

No isolated stylistic feature should automatically trigger revision.

---

## Principle 3 — Patterns matter more than isolated occurrences

One ornate metaphor is not purple prose.

One contrastive sentence is not repetitive AI cadence.

One explicit statement of emotion is not overexplaining.

One familiar gesture is not generic characterization.

The system should pay more attention to **density, recurrence, predictability, and function** than to isolated instances.

---

## Principle 4 — Preserve deliberate irregularity

Humanly compelling prose is not always maximally smooth.

Awkwardness may be intentional.

Repetition may create obsession.

Fragments may express panic.

Long sentences may embody a particular consciousness.

A strange metaphor may belong uniquely to a character.

The guide should not polish away useful eccentricity merely because a cleaner alternative exists.

---

## Principle 5 — Story truth outranks generic writing advice

Established character psychology, world rules, narrative voice, and story-specific intention take precedence over generic recommendations about what fiction “should” do.

---

## Principle 6 — Accumulation matters

A novel should remember itself.

Scenes, decisions, revelations, injuries, relationships, promises, failures, successes, suspicions, and emotional experiences should leave traces.

Later material should exist in a world changed by earlier material.

---

## Principle 7 — Characters are not narrative utilities

Characters may serve structural functions, but they should usually possess enough independent motivation, knowledge, limitation, interpretation, and interest to feel like people rather than delivery mechanisms.

---

## Principle 8 — Reader inference has value

The reader does not need every implication completed for them.

Meaning may be carried through:

- behavior;
- omission;
- contradiction;
- sequence;
- juxtaposition;
- physical detail;
- dialogue;
- silence;
- consequence;
- remembered context.

Explanation should be used where it adds something rather than automatically following implication.

---

## Principle 9 — Variation should be meaningful, not random

Avoiding repetition does not mean constantly forcing novelty.

Consistency can create identity.

Variation is useful when changes in:

- sentence structure;
- scene form;
- emotional response;
- dialogue rhythm;
- descriptive density;
- or narrative pacing

follow changes in situation, character, viewpoint, or dramatic need.

---

## Principle 10 — The individual novel outranks the system

The guidance exists to support the book.

The book does not exist to satisfy the guidance.

A deliberate violation that strengthens the work is preferable to technically perfect compliance that weakens its personality.

---

# II. TAXONOMY ARCHITECTURE

The full system contains **13 domains and 130 guidance lenses**.

Each lens will ultimately contain:

1. **Core principle**
2. **Common drift**
3. **Why it may weaken fiction**
4. **Diagnostic questions**
5. **Better direction**
6. **Valid exceptions**
7. **Long-form warning signs**
8. **Revision considerations**

These are diagnostic lenses, not commandments.

---

# DOMAIN 1 — NARRATIVE INTENTIONALITY & SELECTION

### NI-01 — Purposeful inclusion
Ask why a sentence, detail, exchange, or scene deserves space.

### NI-02 — Hierarchy of importance
Give different narrative weight to things of different importance.

### NI-03 — Selective emphasis
Avoid treating every glance, silence, decision, or object as equally meaningful.

### NI-04 — Information value
Prefer information that changes understanding, atmosphere, expectation, character, or story state.

### NI-05 — Concrete specificity
Use specificity where it creates meaningful distinction rather than decorative detail.

### NI-06 — Narrative economy
Notice when several sentences or beats perform essentially the same function.

### NI-07 — Productive omission
Allow some information, emotion, history, and implication to remain unstated.

### NI-08 — Consequential selection
Favor events and details capable of affecting what follows.

### NI-09 — Attention consistency
Let narrative attention reflect viewpoint, genre, tone, and the particular concerns of the work.

### NI-10 — Intentional asymmetry
Do not assume every important element requires equal explanation, description, or resolution.

---

# DOMAIN 2 — PROSE, SYNTAX & RHYTHM

### PR-01 — Sentence-pattern awareness
Notice repeated syntactic templates across nearby prose.

### PR-02 — Contrastive-reframing moderation
Use “not X but Y” and related constructions when genuine contrast warrants them.

### PR-03 — Fragment intentionality
Let fragments arise from rhythm, voice, thought, or dramatic need rather than automatic emphasis.

### PR-04 — Rhetorical-triplet awareness
Use groups of three intentionally rather than as a default persuasive cadence.

### PR-05 — Paragraph-shape variation
Avoid every paragraph following the same setup → elaboration → concluding punch pattern.

### PR-06 — Cadence responsiveness
Let syntax respond to scene conditions rather than maintaining one universal rhythm.

### PR-07 — Lexical recurrence awareness
Notice involuntary reuse of favored words, modifiers, verbs, and abstractions.

### PR-08 — Emphasis economy
Reserve typographic and rhetorical emphasis for moments that benefit from it.

### PR-09 — Sentence-ending predictability
Watch for repeated dramatic conclusions, aphorisms, reversals, or summary statements.

### PR-10 — Voice over polish
Prefer prose appropriate to the work over prose that merely sounds sophisticated.

---

# DOMAIN 3 — DESCRIPTION, IMAGERY & SENSORY SELECTION

### DS-01 — Viewpoint-specific observation
Describe what this observer would plausibly notice.

### DS-02 — Relevant detail
Distinguish vivid detail from detail that merely occupies prose.

### DS-03 — Sensory distribution
Avoid defaulting repeatedly to the same sensory channels.

### DS-04 — Metaphor integrity
Let comparisons clarify, deepen, surprise, or characterize rather than merely decorate.

### DS-05 — Image coherence
Avoid imagery whose emotional impression works but whose literal relationship collapses.

### DS-06 — Description proportionality
Let descriptive density respond to narrative significance and pacing.

### DS-07 — Embodied plausibility
Keep bodies, movement, posture, spatial relationships, and physical reactions believable.

### DS-08 — Environmental interaction
Allow setting to affect action rather than existing purely as visual wallpaper.

### DS-09 — Generic-body-language awareness
Notice overdependence on brows, jaws, breaths, fists, shoulders, eyes, and stomach sensations.

### DS-10 — Object significance restraint
Allow objects to acquire meaning without repeatedly announcing that meaning.

---

# DOMAIN 4 — EMOTION, INTERIORITY & SUBTEXT

### EM-01 — Emotional causality
Let emotion arise from specific character history and present circumstances.

### EM-02 — Emotional progression
Allow feelings to change, compound, recede, contradict, or transform.

### EM-03 — Inference space
Avoid explaining emotional meaning already adequately conveyed.

### EM-04 — Channel diversity
Emotion may appear through thought, behavior, speech, silence, avoidance, sensation, or direct statement.

### EM-05 — Emotional timing
Let emotional payoff arrive when sufficiently supported by prior experience.

### EM-06 — Contradictory emotion
Permit characters to experience incompatible feelings simultaneously.

### EM-07 — Imperfect self-knowledge
Characters need not correctly understand their own motives.

### EM-08 — Restraint calibration
Not every emotionally important moment needs maximal verbal intensity.

### EM-09 — Internal-monologue purpose
Use introspection to alter or deepen understanding rather than paraphrase visible action.

### EM-10 — Residual emotion
Allow earlier emotional experiences to affect later behavior.

---

# DOMAIN 5 — DIALOGUE & CONVERSATIONAL DYNAMICS

### DG-01 — Speaker-specific language
Let dialogue emerge from individual education, temperament, culture, history, and situation.

### DG-02 — Unequal articulation
Different people should possess different abilities to express themselves.

### DG-03 — Conversational imperfection
Permit interruption, evasion, misunderstanding, correction, silence, and incomplete responses where appropriate.

### DG-04 — Information motivation
Characters should usually have reasons to say what they say.

### DG-05 — Exposition resistance
Avoid making dialogue unnaturally informative merely because the reader requires information.

### DG-06 — Subtextual speech
Characters may speak around what matters instead of naming it directly.

### DG-07 — Conversational movement
An exchange should usually change knowledge, relationship, intention, tension, or emotional state.

### DG-08 — Mirror-response awareness
Notice dialogue where one character merely reformulates another's previous line.

### DG-09 — Conflict asymmetry
Arguments need not consist of perfectly balanced claims and counterclaims.

### DG-10 — Situational speech
Stress, injury, exhaustion, desire, fear, authority, privacy, and danger should influence how people communicate.

---

# DOMAIN 6 — CHARACTER IDENTITY, COGNITION & DEVELOPMENT

### CH-01 — Stable identity
Preserve recognizable traits and behavioral tendencies.

### CH-02 — Adaptive state
Allow experience to modify behavior without erasing identity.

### CH-03 — Character-specific cognition
Different characters should notice, reason, remember, and misinterpret differently.

### CH-04 — Motivational continuity
Actions should remain connected to wants, fears, beliefs, loyalties, and circumstances.

### CH-05 — Competence continuity
Avoid convenient shifts in intelligence, courage, skill, or judgment solely to enable the plot.

### CH-06 — Believable development
Let significant personality change emerge through accumulated causes.

### CH-07 — Individual contradiction
Characters may contain tensions that are stable parts of who they are.

### CH-08 — Memory-shaped behavior
Past experiences should influence current expectations and reactions.

### CH-09 — Independent agency
Secondary characters should retain goals beyond serving the protagonist.

### CH-10 — Unequal interpretive frameworks
Different characters may understand the same event very differently.

---

# DOMAIN 7 — POV, KNOWLEDGE & INFORMATION BOUNDARIES

### PV-01 — Viewpoint knowledge
Keep narration within what the chosen POV permits unless deliberate omniscience applies.

### PV-02 — Character knowledge boundaries
Track who knows each significant fact.

### PV-03 — Knowledge acquisition
Characters should obtain information through plausible channels.

### PV-04 — Vocabulary plausibility
Concepts and comparisons should fit the character's experience and culture.

### PV-05 — Narrator-character separation
Do not accidentally give viewpoint characters the model's wider knowledge.

### PV-06 — Interpretation uncertainty
A POV character's interpretation need not equal objective truth.

### PV-07 — Information withholding
Withhold information honestly when the POV would not naturally attend to it.

### PV-08 — Revelation consequences
New knowledge should alter expectations, strategy, emotion, or relationships when appropriate.

### PV-09 — Secret integrity
Preserve distinctions between reader knowledge, narrator knowledge, and character knowledge.

### PV-10 — Metafictional leakage awareness
Prevent plot-important information from mysteriously spreading to characters who were never told.

---

# DOMAIN 8 — RELATIONSHIPS & SOCIAL WORLD

### RS-01 — Independent social models
Characters should hold incomplete and sometimes inaccurate models of one another.

### RS-02 — Relationship memory
Shared experiences should alter subsequent interaction.

### RS-03 — Uneven intimacy
People need not understand one another equally well.

### RS-04 — Productive misunderstanding
Misinterpretation can arise naturally from personality, history, culture, fear, or incomplete information.

### RS-05 — Protagonist-validation restraint
Other characters need not continuously recognize the protagonist's hidden worth, suffering, or competence.

### RS-06 — Social obligations
Family, work, community, status, law, institutions, reputation, and friendship may exert pressure outside the central plot.

### RS-07 — Secondary relationships
Supporting characters can have relationships that do not involve the protagonist.

### RS-08 — Social consequences
Actions can change reputation, trust, access, obligation, or status.

### RS-09 — Relationship-specific language
The same character may communicate differently with different people.

### RS-10 — Friction persistence
Not every interpersonal conflict requires immediate understanding or closure.

---

# DOMAIN 9 — SCENE DESIGN & DRAMATIC MOVEMENT

### SC-01 — Scene purpose
Understand what the scene contributes before expanding it.

### SC-02 — State change
Track what is different after the scene.

### SC-03 — Scene-shape variation
Avoid repeatedly using identical dramatic architecture.

### SC-04 — Entry timing
Begin scenes where meaningful pressure or information begins when appropriate.

### SC-05 — Exit timing
Do not automatically continue until every implication has been explained.

### SC-06 — Internal progression
Let scenes develop rather than merely sustain one emotional note.

### SC-07 — Competing pressures
Scenes may carry several simultaneous concerns.

### SC-08 — Environmental consequences
Physical surroundings should matter to what can happen.

### SC-09 — Scene-specific attention
Different scenes may warrant different balances of action, description, thought, and dialogue.

### SC-10 — Non-resolution
Some scenes may intensify, complicate, defer, fracture, or redirect rather than resolve.

---

# DOMAIN 10 — PACING, TENSION & ESCALATION

### PC-01 — Variable narrative speed
Use summary, compression, scene, pause, and omission deliberately.

### PC-02 — Tension modulation
Sustained maximum intensity is not the only form of tension.

### PC-03 — Earned escalation
Escalation should grow from consequences rather than merely introducing larger threats.

### PC-04 — Recovery space
Allow contrast between high-pressure and low-pressure sequences where beneficial.

### PC-05 — Delayed consequence
Not every consequence must appear immediately.

### PC-06 — Emotional pacing
Characters may require different amounts of time to process events.

### PC-07 — Information pacing
Revelations should arrive according to dramatic function rather than uniform intervals.

### PC-08 — Conflict duration
Some problems resolve quickly; others gain power by persisting.

### PC-09 — Middle-book vigilance
Watch for stagnation, repetition, continuity drift, and artificial escalation as accumulated complexity grows.

### PC-10 — Rhythm across chapters
Chapter pacing should vary according to the larger movement of the book.

---

# DOMAIN 11 — PLOT, CAUSALITY, SUBPLOTS & PAYOFF

### PL-01 — Causal connection
Major developments should arise plausibly from earlier conditions, choices, or events.

### PL-02 — Character-driven causality
Ask what characters would actually choose rather than what the outline requires.

### PL-03 — Alternative-action awareness
Consider whether obvious alternatives would undermine the intended event.

### PL-04 — Consequence persistence
Major actions should continue affecting the story where logically appropriate.

### PL-05 — Setup integrity
Remember implications, promises, questions, clues, and expectations introduced earlier.

### PL-06 — Payoff proportionality
The importance of resolution should broadly correspond to the narrative investment that preceded it.

### PL-07 — Subplot independence
Subplots should have enough internal logic to exist as more than decorations for the main plot.

### PL-08 — Subplot interaction
Allow narrative threads to interfere with, reshape, delay, or complicate one another.

### PL-09 — Predictability awareness
Avoid always selecting the statistically most familiar next development when the story supports more specific alternatives.

### PL-10 — Ending inheritance
The conclusion should reflect the actual accumulated history of the novel rather than a generic resolution template.

---

# DOMAIN 12 — CONTINUITY, WORLD LOGIC & EMBODIED REALITY

### CT-01 — Temporal continuity
Track time, duration, age, sequence, deadlines, and chronology.

### CT-02 — Spatial continuity
Track position, distance, entrances, exits, movement, and geography.

### CT-03 — Object continuity
Track possession, condition, location, use, and transfer of important objects.

### CT-04 — Physical-state continuity
Track injuries, fatigue, hunger, clothing, bodily limitations, and recovery.

### CT-05 — Relationship continuity
Track changes in trust, hostility, obligation, affection, and familiarity.

### CT-06 — World-rule continuity
Respect established magic, technology, law, culture, economics, and institutions.

### CT-07 — Numerical continuity
Track ages, dates, money, travel time, quantities, ranks, and measurements.

### CT-08 — Consequence ecology
Ask how events affect people and systems beyond the immediate protagonists.

### CT-09 — Developmental plausibility
Keep behavior compatible with age, experience, expertise, culture, and circumstance.

### CT-10 — Canon authority
When established canon conflicts with convenient invention, preserve canon unless the story deliberately changes it.

---

# DOMAIN 13 — THEME, SYMBOLISM, GENRE & ARTISTIC IDENTITY

### AR-01 — Emergent theme
Allow themes to arise through choices, consequences, patterns, and contradictions.

### AR-02 — Thematic restraint
Avoid explaining the lesson of every emotionally significant event.

### AR-03 — Symbolic accumulation
Allow symbols to gather meaning without repeatedly decoding them.

### AR-04 — Moral complexity
Do not automatically force events into neat moral interpretation.

### AR-05 — Genre intelligence
Use conventions knowingly rather than reproducing genre averages automatically.

### AR-06 — Work-specific obsessions
Let the individual book develop recurring concerns unique to itself.

### AR-07 — Authorial attention
Establish what this narrative habitually notices, ignores, finds beautiful, funny, frightening, disgusting, or important.

### AR-08 — Productive eccentricity
Protect strange but coherent choices that contribute identity.

### AR-09 — Homogenization resistance
Do not revise every passage toward universally smooth, neutral, conventionally “good” prose.

### AR-10 — Artistic coherence
Let style, imagery, structure, characterization, and theme feel as though they belong to the same particular work.

---

# III. FULL EXPANSION — DOMAIN 1

The following shows the final level of detail each of the 130 lenses should eventually receive.

---

## NI-01 — PURPOSEFUL INCLUSION

### Core principle

Narrative space carries weight.

A detail does not need to advance the plot directly, but its presence should ideally contribute something: atmosphere, characterization, rhythm, humor, tension, world texture, thematic resonance, reader orientation, expectation, contrast, or another useful effect.

### Common drift

Generated fiction can continuously supply plausible material simply because the material fits the current context.

A room gains extra description.

A character remembers something loosely related.

A conversation receives several additional exchanges.

An emotional observation follows an already complete beat.

Nothing is egregiously wrong, yet the passage grows without becoming richer.

### Why it may weaken fiction

Accumulated low-value material creates:

- bloat;
- slower perceived pacing;
- weakened emphasis;
- reduced reader attention;
- repetition of meaning;
- and a feeling that prose is continuing because it can rather than because it should.

### Diagnostic questions

- What does this passage add?
- Would removing it alter the reader's experience?
- Is it creating texture, or merely occupying space?
- Does it reveal something specific?
- Is its function already being performed elsewhere?
- Is this detail interesting because of this story, or merely because it sounds novelistic?

### Better direction

Prefer material whose inclusion can be connected to some deliberate effect.

The effect need not be plot advancement.

A joke can justify itself through pleasure.

A description can justify itself through atmosphere.

An apparently irrelevant detail can establish normality that later becomes important.

The goal is not maximal efficiency.

The goal is **intentional presence**.

### Valid exceptions

Meandering, digressive, contemplative, comic, slice-of-life, maximalist, stream-of-consciousness, and highly atmospheric fiction may deliberately devote substantial space to material with little conventional plot function.

In those works, apparent digression may itself be part of the desired reading experience.

---

## NI-02 — HIERARCHY OF IMPORTANCE

### Core principle

Narrative attention tells readers what matters.

Different events, objects, gestures, discoveries, and emotions should not automatically receive equal stylistic weight.

### Common drift

Automatic prose may intensify routine actions using the same techniques used for major moments:

- dramatic fragments;
- lingering pauses;
- symbolic description;
- heavy internal analysis;
- heightened metaphor;
- solemn concluding lines.

### Why it may weaken fiction

If everything is emphasized, emphasis loses informational value.

Readers become less sensitive to actual turning points because the prose has trained them to treat every moment as significant.

### Diagnostic questions

- How important is this moment relative to surrounding events?
- Is the prose communicating roughly that degree of importance?
- Has a routine action been stylistically inflated?
- Has a major event been treated too casually?
- What deserves the reader's strongest attention here?

### Better direction

Create contrast.

Ordinary moments can remain ordinary.

Major moments may slow, sharpen, simplify, intensify, or become unexpectedly understated.

Importance can be conveyed through many techniques rather than always through grander prose.

### Valid exceptions

A comic narrator may deliberately treat trivial matters with epic seriousness.

A detached narrator may underplay catastrophe.

A character with obsessive tendencies may assign enormous importance to things others consider trivial.

The correct hierarchy is therefore the hierarchy of the **chosen narrative consciousness**, not an external universal scale.

---

## NI-03 — SELECTIVE EMPHASIS

### Core principle

Emphasis should direct attention rather than saturate it.

### Common drift

Repeated use of:

- italics;
- fragments;
- rhetorical questions;
- one-line paragraphs;
- dramatic pauses;
- “something changed” formulations;
- symbolic statements;
- intensifying adjectives;
- emotional interpretation.

### Why it may weaken fiction

Frequent emphasis becomes normal rhythm.

Once normalized, stronger moments require even more exaggeration to feel important.

### Diagnostic questions

- What specifically deserves emphasis here?
- Is another nearby line using the same mechanism?
- Would understatement produce more force?
- Is the emphasis serving meaning or compensating for weak meaning?

### Better direction

Use emphasis as one tool among many.

Sometimes the strongest line is the plainest sentence in the chapter.

### Valid exceptions

Highly rhetorical narration, comedy, melodrama, oral storytelling, satire, mythic narration, and certain genre voices may intentionally maintain heightened emphasis.

---

## NI-04 — INFORMATION VALUE

### Core principle

Narrative information should preferably alter something in the reader's model of the story.

### Common drift

A passage supplies information that is accurate but does not change:

- expectation;
- understanding;
- atmosphere;
- characterization;
- tension;
- world knowledge;
- or interpretation.

### Why it may weaken fiction

Correct information is not necessarily useful information.

Excess neutral information can obscure what the reader actually needs to retain.

### Diagnostic questions

- What becomes newly knowable because of this?
- Does this confirm something that required confirmation?
- Is this information required now?
- Could it be more meaningful in another context?
- Does it alter how the reader understands an existing fact?

### Better direction

Favor information that creates or modifies relationships among existing story elements.

### Valid exceptions

Some genres value encyclopedic detail, procedural accuracy, immersion, atmosphere, or informational pleasure as ends in themselves.

---

## NI-05 — CONCRETE SPECIFICITY

### Core principle

Specificity is most powerful when it distinguishes this place, person, moment, or world from alternatives.

### Common drift

Generated prose may contain many details while remaining generic:

a weathered table;

a weary face;

ancient stone;

a bustling marketplace;

piercing eyes;

the smell of spices;

a cold wind.

These details are concrete in grammatical form but not necessarily distinctive in narrative function.

### Why it may weaken fiction

Readers receive an image without discovering anything particular.

The prose appears detailed while the imaginative world remains interchangeable.

### Diagnostic questions

- Could this description belong unchanged in hundreds of similar novels?
- What detail could only plausibly belong here?
- What would this POV character notice that another person would not?
- Does the detail reveal history, use, personality, environment, or culture?

### Better direction

Prefer specificity produced by relationships between details and the surrounding story.

Specificity should usually emerge from **particularity**, not merely from adding adjectives.

### Valid exceptions

Generic description can be useful when something genuinely is ordinary or when detailed description would distract from the important material.

---

## NI-06 — NARRATIVE ECONOMY

### Core principle

Multiple sentences are worthwhile when each performs additional work.

### Common drift

Generated prose may:

1. show an action;
2. name its emotional meaning;
3. explain the meaning;
4. restate the conclusion abstractly;
5. summarize what changed.

All five statements may be individually competent while collectively redundant.

### Why it may weaken fiction

Redundancy slows movement and reduces the power of the strongest expression.

### Diagnostic questions

- Are several sentences reaching the same conclusion?
- Does each new sentence add a new dimension?
- Has interpretation merely paraphrased demonstration?
- Which version is strongest?
- Would removing one line make the moment clearer or stronger?

### Better direction

Let multiple channels reinforce one another when they provide genuinely different information.

Action + thought + dialogue can be powerful when each complicates rather than duplicates the others.

### Valid exceptions

Repetition may deliberately communicate obsession, ritual, persuasion, comedy, trauma, panic, lyricism, or rhetorical force.

---

## NI-07 — PRODUCTIVE OMISSION

### Core principle

What a story chooses not to say can be part of its meaning.

### Common drift

Automatic generation tends to complete patterns.

Questions receive answers.

Gestures receive interpretation.

Arguments receive clarification.

Emotional moments receive summaries.

Ambiguities receive explanations.

### Why it may weaken fiction

Continuous completion can remove:

- mystery;
- ambiguity;
- subtext;
- interpretive participation;
- suspense;
- unease;
- and emotional aftertaste.

### Diagnostic questions

- Does the reader already possess enough information to infer this?
- Would leaving this unstated create useful tension?
- Is ambiguity part of the intended effect?
- Does the character themselves actually understand the answer?
- Is the story explaining something mainly because the model knows it?

### Better direction

Allow uncertainty to remain where uncertainty improves the experience.

Omission should be purposeful rather than confusing.

### Valid exceptions

Mystery is not inherently superior to clarity.

Genre expectations, younger readerships, procedural fiction, important world rules, complex plots, and emotionally direct narrative voices may benefit from explicit explanation.

---

## NI-08 — CONSEQUENTIAL SELECTION

### Core principle

Events and details gain narrative strength when they participate in later consequences.

### Common drift

A generated story may continuously introduce:

- colorful side characters;
- strange objects;
- emotional revelations;
- unusual locations;
- warnings;
- mysteries;
- new powers;
- symbolic details

without allowing many of them to influence later material.

### Why it may weaken fiction

The reader learns not to invest attention.

Apparently important material begins to feel disposable.

### Diagnostic questions

- Does this create an expectation?
- If so, will the story honor that expectation somehow?
- Can this affect a later choice, obstacle, understanding, relationship, or atmosphere?
- Is this detail worth remembering?
- If not, does it still provide enough immediate value to justify itself?

### Better direction

Not everything requires payoff.

But the more strongly the prose signals significance, the greater the narrative obligation created.

### Valid exceptions

Red herrings, realism, thematic fragments, atmosphere, misdirection, absurdism, and deliberately unresolved fiction may introduce meaningful material without conventional payoff.

---

## NI-09 — ATTENTION CONSISTENCY

### Core principle

What the narration notices should feel connected to the consciousness and identity of the work.

### Common drift

AI prose may describe whatever is conventionally describable:

eyes during emotion;

weather during mood;

architecture upon entry;

clothing upon introduction;

food during meals.

The prose becomes competent but interchangeable.

### Why it may weaken fiction

Narrative attention is one of the strongest sources of authorial and viewpoint identity.

Generic attention produces generic consciousness.

### Diagnostic questions

- Why is the narration noticing this?
- Would this specific viewpoint character notice it?
- What does this book habitually care about?
- What does it consistently ignore?
- Could another character describe the same place differently?

### Better direction

Develop patterns of attention distinctive to:

- viewpoint;
- profession;
- culture;
- fears;
- desires;
- genre;
- narrative voice;
- thematic concerns.

### Valid exceptions

Neutral description may be desirable in transparent, fast-moving, or distant narration.

---

## NI-10 — INTENTIONAL ASYMMETRY

### Core principle

Stories need not distribute attention, explanation, development, or closure evenly.

### Common drift

Generated fiction often seeks symmetry:

every character receives a neat arc;

every argument receives both sides;

every mystery receives explicit resolution;

every emotional beat gets acknowledgment;

every introduced relationship receives closure.

### Why it may weaken fiction

Excess symmetry can make the story feel constructed rather than lived.

Real narrative importance is often uneven.

Some relationships dominate.

Some questions remain unanswered.

Some characters misunderstand what happened.

Some consequences arrive too late to be resolved.

### Diagnostic questions

- Is this being included because the story needs it or because symmetry feels complete?
- Does every element truly deserve equal narrative attention?
- Would unresolved imbalance create a stronger or more truthful effect?
- Is this closure earned or merely tidy?

### Better direction

Permit asymmetry when it matches the story.

Completeness and satisfaction are not identical.

### Valid exceptions

Highly formal stories, myths, fairy tales, mysteries, closed-circle plots, comedies, romances, and deliberately symmetrical structures may derive much of their satisfaction from completion and balance.

---

# IV. HOW THE TAXONOMY SHOULD BE USED

The system should not evaluate a chapter by asking:

> Did the chapter violate any rule?

Instead it should ask:

> Which guidance lenses are materially relevant to this chapter?

A quiet conversation may strongly activate:

- dialogue;
- relationship memory;
- subtext;
- emotional progression;
- POV knowledge.

It may barely require:

- subplot interaction;
- world-rule continuity;
- physical escalation.

A battle chapter may activate an entirely different cluster.

This keeps the system from mechanically applying all 130 lenses to every paragraph.

---

# V. GUIDANCE PRIORITY

When guidance conflicts, use roughly this priority:

1. **Explicit user/story intent**
2. **Established canon**
3. **Character truth**
4. **Causal and world consistency**
5. **Scene purpose**
6. **POV integrity**
7. **Emotional and relationship continuity**
8. **Work-specific style**
9. **Genre expectations**
10. **General craft guidance**
11. **Surface-level anti-repetition preferences**

This means, for example:

If a particular character genuinely speaks in repetitive ritualistic phrases, preserving that character voice is more important than satisfying a generic anti-repetition check.

If a horror novel intentionally withholds causal explanation, preserving uncertainty is more important than maximizing clarity.

If a comedy intentionally overemphasizes trivial details, comic voice outranks the usual hierarchy-of-importance guidance.

---

# VI. CENTRAL REMINDER

The aim is not to eliminate recognizable AI tendencies one by one.

The aim is to encourage the model to continually ask:

**Why this word? 
Why this detail? 
Why this reaction? 
Why this character? 
Why this information now? 
Why this scene? 
Why this consequence? 
Why this structure? 
Why this resolution? 
Why does this belong specifically to this novel?**

When those questions have convincing answers, many superficial AI-writing problems disappear naturally.

When they do not, replacing a few phrases will not solve the deeper problem.

This gives us the **130-item skeleton plus the fully developed first domain**. It also establishes the most important constraint for everything we build afterward: a lens should activate only when relevant, and story-specific intent can override general guidance.

The uploaded research strongly supports this hierarchy: readers repeatedly complain about repetition and overexplaining, but the more serious long-form failures are unstable character logic, forgotten experiences, weak causality, abandoned setups, and absence of a coherent artistic sensibility. 

The next logical construction unit is **Domain 2: Prose, Syntax & Rhythm**, where we can turn the superficial “AI tells” into nuanced guidance without banning em dashes, fragments, triplets, contrastive phrasing, ornate prose, or any other legitimate technique.

## User

lets go 

at the end of every reponse list the ones remaining

## ChatGPT

Next is **Domain 2: Prose, Syntax & Rhythm**. This is where we turn the most visible “AI tells” from the research—repeated cadence, contrastive phrasing, fragments, triplets, punchline endings, over-polish—into flexible craft guidance rather than bans. The research file repeatedly supports treating these as pattern-and-function problems, not proof of AI authorship. 

## ChatGPT

# DOMAIN 2 — PROSE, SYNTAX & RHYTHM

## Domain purpose

This domain governs the **movement of prose** at sentence and paragraph level.

Its purpose is not to force stylistic neutrality or make every sentence structurally different. A strong novel may intentionally rely on recurring rhythms, unusual punctuation, fragments, long sentences, rhetorical parallelism, or highly stylized narration.

The concern is **automatic recurrence**.

A prose technique becomes a problem when it appears because the model habitually reaches for it rather than because the voice, character, scene, rhythm, or meaning benefits from it.

The guiding distinction is:

> Repetition can create style. 
> Unnoticed repetition creates predictability.

A recognizable prose voice should emerge from intentional tendencies rather than from the model's default linguistic habits.

---

# PR-01 — SENTENCE-PATTERN AWARENESS

## Core principle

Sentence structure should respond to meaning, rhythm, viewpoint, and dramatic circumstance.

Variation is not desirable merely for its own sake. What matters is avoiding the unconscious repetition of the same syntactic machinery.

## Common drift

Generated prose may repeatedly rely on a small collection of sentence forms even while vocabulary changes.

Examples include:

statement → fragment;

observation → interpretation;

action → emotional explanation;

short sentence → short sentence → longer concluding sentence;

dependent clause → dramatic main clause;

description → contrastive correction;

three parallel clauses → concluding statement.

Individually, all of these are normal prose techniques.

The issue emerges when readers begin predicting the grammatical shape of the next sentence.

## Why it may weaken fiction

Repeated architecture can make prose feel manufactured even when every sentence is technically competent.

The reader stops encountering thought and begins encountering a pattern.

This can create:

- rhythmic monotony;
- artificial emphasis;
- predictable paragraph construction;
- weakened surprise;
- homogenized narrative voice;
- and the sense that different scenes are being processed through the same linguistic template.

## Diagnostic questions

Ask:

Does this paragraph contain several sentences with essentially the same architecture?

Have previous paragraphs relied on the same rhythm?

Could the reader predict where the sentence is going before reaching its end?

Is the repeated structure contributing to voice or merely recurring automatically?

Does the scene's emotional condition justify this cadence?

Would another sentence shape express the thought more naturally?

## Better direction

Let syntax arise from the underlying act of thought.

A character noticing several things quickly may produce compressed syntax.

A reflective narrator may unfold ideas through longer dependent structures.

A frightened viewpoint may fragment.

A confident speaker may use controlled declaratives.

A confused person may circle, restart, qualify, or contradict themselves.

Variation should therefore come from **changes in consciousness and circumstance**, not from artificial sentence shuffling.

## Valid exceptions

Highly stylized narrators may deliberately use repetitive syntax.

Liturgical prose, oral storytelling, fairy tales, children's fiction, satire, comedy, epic narration, ritual speech, propaganda, obsession, and stream-of-consciousness may gain power from repeated structures.

## Long-form warning signs

Across chapters, watch for:

the same sentence rhythms appearing in every POV;

climactic scenes using the same cadence as quiet scenes;

unrelated characters producing similarly structured internal thoughts;

the same paragraph rhythm appearing at emotionally significant moments;

and prose becoming recognizable through structure rather than through the distinctive consciousness of the work.

## Revision considerations

Do not mechanically rewrite every repeated structure.

First ask whether the repetition is audible and whether it serves a purpose.

If revision is needed, reconsider the thought itself before merely changing syntax.

Sometimes repetitive syntax indicates that the underlying ideas are also repetitive.

---

# PR-02 — CONTRASTIVE-REFRAMING MODERATION

## Core principle

Contrastive constructions are strongest when they perform genuine correction, distinction, escalation, or reinterpretation.

Forms such as:

“not X, but Y”;

“it wasn't X; it was Y”;

“not because X, but because Y”;

“not merely X, but something more”;

can be excellent rhetorical tools.

The concern is reflexive use.

## Common drift

The narrator repeatedly rejects an interpretation the reader was never likely to make.

For example, a sensation is introduced and then immediately corrected:

It wasn't fear. It was something colder.

Or an ordinary observation is inflated through contrast:

It wasn't simply a door. It was a boundary.

The construction creates rhetorical importance even when the underlying distinction contributes little.

## Why it may weaken fiction

Frequent contrastive reframing can make narration sound as though it is constantly arguing with an invisible reader.

It also produces predictable emphasis.

When every concept becomes:

not this → actually that,

the rhetorical device loses force.

It can also create pseudo-specificity, where the prose sounds precise because it distinguishes two terms without actually deepening the reader's understanding.

## Diagnostic questions

What genuine distinction is being made?

Was the rejected interpretation actually plausible?

Does the second term provide more specificity?

Would a direct statement be stronger?

Has this construction appeared repeatedly nearby?

Is the contrast arising from the character's thought process or from a habitual narrative cadence?

## Better direction

Use correction when correction matters.

If a character initially misreads an emotion and then recognizes it more accurately, contrast may reveal psychological movement.

If two concepts genuinely differ, rhetorical distinction can sharpen meaning.

When no meaningful correction exists, state the perception directly.

## Valid exceptions

Argumentative narrators, philosophical fiction, speeches, sermons, legal dialogue, polemical voices, characters who habitually revise themselves, and moments of realization may naturally employ frequent contrasts.

## Long-form warning signs

Watch for recurring constructions such as:

not anger but disappointment;

not fear but anticipation;

not silence but expectation;

not weakness but restraint;

not defeat but transformation.

The vocabulary may change while the logical pattern remains identical.

## Revision considerations

Do not simply delete the word “not.”

Ask what the sentence is actually trying to discover.

If the second idea matters, express that idea in the form most natural to the viewpoint.

If the distinction itself matters, retain the contrast.

---

# PR-03 — FRAGMENT INTENTIONALITY

## Core principle

Sentence fragments are rhythmic and expressive tools.

They can create:

speed;

shock;

hesitation;

emphasis;

intimacy;

disorientation;

comic timing;

or the impression of unfinished thought.

They should not automatically be treated as grammatical defects.

## Common drift

Generated prose may use fragments whenever it wants intensity.

A dramatic statement appears.

Then another.

Short. Sharp. Important.

This often creates the appearance of tension without increasing actual dramatic pressure.

## Why it may weaken fiction

When fragments become the default marker of seriousness, the prose's emotional vocabulary narrows.

Readers begin anticipating:

full sentence → fragment → fragment → dramatic conclusion.

The technique loses force because every scene is punctuated the same way.

## Diagnostic questions

Why is this sentence incomplete?

Does the fragment alter rhythm in a useful way?

Does it represent thought, voice, interruption, shock, or emphasis?

Would a complete sentence actually carry more force?

Have several recent emotional moments used identical fragmentation?

Is the fragment intensifying genuine content or attempting to manufacture intensity?

## Better direction

Use fragments when incompleteness itself contributes meaning or rhythm.

Allow some dramatic moments to remain syntactically ordinary.

A complete, quiet sentence can sometimes carry greater emotional weight precisely because it refuses overt emphasis.

## Valid exceptions

A narrator's established voice may naturally be fragment-heavy.

Fragments may also dominate:

action sequences;

panic;

experimental fiction;

diary entries;

stream-of-consciousness;

spoken narration;

poetry-adjacent prose;

or intentionally clipped genres.

## Long-form warning signs

Different POV characters share the same fragment habits.

Every chapter climax breaks into fragments.

Paragraph endings repeatedly isolate a two- or three-word sentence.

Fragments appear at predictable intervals regardless of scene type.

## Revision considerations

Do not replace every fragment with a complete sentence.

Instead examine whether the prose is relying on fragments to perform emotional work that the underlying scene has not earned.

If so, strengthen the scene rather than merely repairing the grammar.

---

# PR-04 — RHETORICAL-TRIPLET AWARENESS

## Core principle

Groups of three are naturally satisfying and memorable.

They are deeply embedded in human rhetoric.

The problem is not the number three.

The problem is automatic triadic construction.

## Common drift

Generated prose may repeatedly organize description, emotion, action, and argument into three-part structures.

Three adjectives.

Three examples.

Three fragments.

Three escalating clauses.

Three things a character remembers.

Three reasons something matters.

## Why it may weaken fiction

A repeated three-beat rhythm creates excessive rhetorical polish.

Characters may sound as though they are unconsciously delivering speeches.

Narration may acquire an overly designed quality.

Repeated triplets can also make paragraphs feel self-contained and packaged rather than organically unfolding.

## Diagnostic questions

Why are there three elements?

Do all three contribute something distinct?

Would two be stronger?

Would four feel more natural?

Is this character likely to think or speak in polished parallel structures?

Has the surrounding prose repeatedly used the same rhetorical number?

## Better direction

Let the number of examples or clauses emerge from what needs to be expressed.

Sometimes one is enough.

Sometimes two creates sharper opposition.

Sometimes an accumulating list should continue beyond three.

Sometimes exactly three is perfect.

## Valid exceptions

Speeches, comedy, fairy tales, oral traditions, persuasive dialogue, ritual, rhetoric, myth, political language, children's storytelling, and stylized narration may deliberately exploit triadic rhythm.

## Long-form warning signs

The novel repeatedly uses:

three adjectives;

three fragments;

three memories;

three sensory details;

three emotional labels;

three reasons;

three consequences.

Readers may perceive the architecture even if no individual use seems objectionable.

## Revision considerations

Do not mechanically alter every triplet.

Look for clusters.

Keep the strongest and most natural instances.

Revise only where the pattern has become predictable or unnecessarily symmetrical.

---

# PR-05 — PARAGRAPH-SHAPE VARIATION

## Core principle

Paragraphs are units of attention and movement.

Their shape should respond to what the narrative is doing.

## Common drift

AI-generated paragraphs may repeatedly follow a recognizable structure:

opening assertion;

explanation;

elaboration;

emotional interpretation;

punchy final line.

Another common pattern is:

action;

reaction;

interpretation;

summary.

This can happen even when sentence structure varies.

## Why it may weaken fiction

Predictable paragraph structure makes prose feel modular.

Readers begin sensing that every paragraph is engineered as a small complete package.

That can reduce:

continuity of thought;

narrative momentum;

natural interruption;

surprise;

and tonal variation.

## Diagnostic questions

Does every paragraph conclude its own meaning?

Could the thought naturally spill into the next paragraph?

Are paragraphs consistently similar in length?

Are one-line conclusions appearing too regularly?

Does paragraphing reflect shifts in attention, speaker, action, or thought?

Or is it following a default formatting rhythm?

## Better direction

Allow paragraphs to serve different functions.

Some may be a single line.

Some may carry sustained thought.

Some may contain quick action.

Some may interrupt one another.

Some may end unresolved.

Some may bridge seamlessly into the next.

Paragraph boundaries should organize experience rather than manufacture constant miniature climaxes.

## Valid exceptions

Certain voices deliberately use balanced, compact paragraphs.

Web fiction and mobile-first fiction may favor shorter paragraphs for readability.

Epistolary forms, children's fiction, thrillers, and highly stylized narration may have distinctive paragraph conventions.

## Long-form warning signs

Chapters repeatedly consist of similarly sized paragraphs.

Every paragraph seems to end with a quotable sentence.

Narrative paragraphs and character-thought paragraphs have identical shapes.

High-action and reflective scenes use the same paragraph rhythm.

## Revision considerations

Read several pages for **shape**, not meaning.

If the page visually and rhythmically repeats itself, determine whether that is deliberate.

Do not vary paragraph length merely to create cosmetic irregularity.

---

# PR-06 — CADENCE RESPONSIVENESS

## Core principle

Rhythm should react to what is happening.

Prose need not become short during action or long during reflection, but its movement should feel compatible with the narrative condition.

## Common drift

A model may retain the same polished cadence across:

combat;

romance;

grief;

conversation;

travel;

terror;

quiet domestic scenes;

and exposition.

The content changes, but the linguistic engine does not.

## Why it may weaken fiction

Uniform cadence reduces tonal differentiation.

Scenes may feel interchangeable because they are experienced through the same rhythmic filter.

It also contributes to voice convergence across characters.

## Diagnostic questions

What is the current mental and physical tempo?

How much attention can the viewpoint character realistically devote to observation?

Is the prose moving at the speed the scene requires?

Is the syntax too composed for the character's condition?

Would a slower or more spacious rhythm improve perception?

Is the rhythm changing because the scene changed—or merely because the model wants variety?

## Better direction

Allow rhythm to emerge from:

breath;

attention;

urgency;

confidence;

fatigue;

intoxication;

fear;

social control;

expertise;

memory;

and narrative distance.

Cadence can become part of embodied viewpoint.

## Valid exceptions

A deliberately detached narrator may preserve calm prose through catastrophe.

Comedy may describe frantic action in elaborate sentences.

A highly stylized omniscient narrator may impose one strong cadence across the entire novel.

## Long-form warning signs

All POVs possess similar rhythm.

Every emotional climax becomes clipped.

Every reflective scene becomes ornate.

Action scenes repeatedly shorten sentences in the same mechanical fashion.

## Revision considerations

Do not use simplistic formulas such as:

action = short sentences;

emotion = fragments;

reflection = long sentences.

Instead ask what this specific consciousness would sound like in this specific moment.

---

# PR-07 — LEXICAL RECURRENCE AWARENESS

## Core principle

Repeated words can create cohesion, motif, voice, humor, obsession, or thematic resonance.

The concern is unconscious lexical clustering.

## Common drift

Models may favor recurring vocabulary associated with particular emotional or descriptive categories.

Words related to:

weight;

silence;

shifting;

tightening;

softening;

sharpness;

something unnamed;

something ancient;

something fragile;

something between characters;

may recur because they are high-probability literary language.

The exact vocabulary will vary across models and genres.

## Why it may weaken fiction

Repeated preferred words can make otherwise unrelated scenes sound generated from the same linguistic inventory.

They can also replace specific observation with reusable abstraction.

## Diagnostic questions

Has this word appeared several times recently?

Is it part of a deliberate motif?

Would another word actually be more precise?

Is the repeated vocabulary tied to this narrator or shared across all characters?

Is the word carrying real meaning or functioning as literary atmosphere?

## Better direction

Favor the word that belongs to:

the exact object;

the exact sensation;

the exact social context;

the exact character;

and the exact moment.

Do not replace recurring words merely with thesaurus alternatives.

Variation without improved precision is cosmetic.

## Valid exceptions

Key vocabulary may legitimately recur because of:

theme;

worldbuilding;

profession;

ritual;

character obsession;

running jokes;

symbols;

or technical terminology.

## Long-form warning signs

A small set of “literary” words appears throughout the novel regardless of POV.

Several characters describe emotions using the same abstract vocabulary.

Repeated words appear most often in moments the prose wants the reader to treat as important.

## Revision considerations

Distinguish meaningful repetition from vocabulary habit.

If a recurring term belongs to the novel's identity, preserve it.

If it belongs mainly to generic literary diction, reconsider the underlying observation rather than merely substituting synonyms.

---

# PR-08 — EMPHASIS ECONOMY

## Core principle

Emphasis gains strength from contrast.

The prose should have quieter areas against which emphasized moments can register.

## Common drift

Automatic prose may continually signal importance through:

italics;

fragments;

one-line paragraphs;

repetition;

rhetorical questions;

heightened metaphor;

dramatic punctuation;

explicit statements of significance;

and solemn concluding lines.

## Why it may weaken fiction

Continuous emphasis creates rhetorical inflation.

The reader's sensitivity adjusts upward.

Eventually the prose must work increasingly hard to create the same effect.

## Diagnostic questions

What specifically deserves emphasis?

What would happen if this line were presented plainly?

Has the surrounding prose already signaled the importance?

Does the emotional or dramatic content carry enough force without additional highlighting?

Is this the strongest possible place to spend rhetorical emphasis?

## Better direction

Create hierarchy.

Let routine moments breathe.

Allow important lines to stand out because surrounding prose does not constantly compete with them.

Understatement can itself become emphasis.

## Valid exceptions

Melodrama, comedy, camp, gothic narration, mythic prose, pulp, oral storytelling, satire, and certain highly expressive narrators may intentionally operate at elevated rhetorical intensity.

## Long-form warning signs

Every chapter contains several “big” lines.

Nearly every emotional revelation receives a one-line paragraph.

Climaxes repeatedly use identical emphasis tools.

Minor observations are formatted like major revelations.

## Revision considerations

Remove emphasis only when the underlying moment already carries enough weight or when the emphasis misrepresents importance.

Do not flatten a work whose identity genuinely depends on heightened rhetoric.

---

# PR-09 — SENTENCE-ENDING PREDICTABILITY

## Core principle

Sentence endings control rhythm, emphasis, and reader expectation.

Not every sentence needs to land.

Some sentences should simply continue thought.

## Common drift

Generated prose often seeks satisfying closure at the sentence or paragraph level.

This can produce recurring endings involving:

reversal;

aphorism;

emotional summary;

contrast;

ominous implication;

dramatic abstraction;

or a short final phrase.

A sentence repeatedly wants to sound quotable.

## Why it may weaken fiction

Constantly polished endings create a “written” quality.

Every sentence calls attention to its construction.

This can interfere with immersion and make narration feel self-conscious.

## Diagnostic questions

Is this sentence ending naturally or trying to produce a literary effect?

Do nearby sentences also end with emphasis?

Would a less conclusive ending improve flow?

Is the concluding phrase adding information?

Could the thought continue without a miniature rhetorical landing?

## Better direction

Allow sentences to finish in different ways.

Some may:

resolve;

trail conceptually into the next;

end on concrete detail;

end quietly;

end awkwardly because the character is awkward;

or simply transmit information.

Reserve conspicuous closure for places where closure contributes something.

## Valid exceptions

Aphoristic narrators, comic voices, noir, satire, fables, philosophical fiction, and deliberately polished first-person voices may rely heavily on pointed endings.

## Long-form warning signs

Readers begin anticipating a “punch line” at paragraph ends.

Repeated structures appear such as:

And that was the problem.

And somehow, that was worse.

For now, it would have to be enough.

But nothing would ever be the same.

The exact wording is less important than the repeated **function**.

## Revision considerations

Do not create a blacklist of concluding phrases.

Instead ask whether each ending has become predictable because the novel repeatedly uses the same rhetorical function.

---

# PR-10 — VOICE OVER POLISH

## Core principle

The strongest prose is not necessarily the smoothest prose.

It is prose appropriate to the consciousness, world, genre, and identity of the work.

## Common drift

AI revision frequently moves sentences toward:

clarity;

balance;

grammatical completeness;

moderate vocabulary;

smooth transitions;

explicit relationships;

and conventional literary elegance.

These qualities can improve weak prose.

They can also erase personality.

## Why it may weaken fiction

A distinctive narrator may become generic.

Characters may lose educational, cultural, historical, emotional, or regional differences.

Strange but meaningful images may be replaced with cleaner clichés.

Useful awkwardness may disappear.

Prose may become technically stronger while the novel becomes less recognizable.

## Diagnostic questions

Whose voice is this?

Would this narrator actually phrase the thought this way?

Has revision made the sentence better—or merely smoother?

Does the irregularity reveal character?

Is the polished version more generic than the original?

Does this wording belong specifically to this book?

## Better direction

Treat style as a system of meaningful preferences rather than a collection of errors awaiting correction.

Preserve:

peculiar vocabulary;

rhythmic habits;

unexpected comparisons;

deliberate roughness;

regional or cultural syntax where appropriate;

character-specific humor;

and unusual patterns of attention.

Polish should strengthen intelligibility and effect **without automatically normalizing identity**.

## Valid exceptions

Some projects deliberately seek transparent, unobtrusive prose.

Commercial thrillers, children's fiction, instructional fiction, fast-paced serials, or certain genre conventions may value clarity and accessibility over stylistic eccentricity.

That, too, is an artistic identity.

## Long-form warning signs

Multiple POV characters gradually sound increasingly alike after revision.

Early chapters possess stronger personality than later chapters.

Dialogue and narration become uniformly polished.

Character-specific linguistic quirks disappear.

The model repeatedly “fixes” deliberate irregularities.

## Revision considerations

Before changing unusual prose, ask:

Is this confusing?

Or merely unconventional?

Is it ineffective?

Or merely not how the model would naturally phrase it?

Revision should target **failure of effect**, not deviation from statistical normality.

---

# DOMAIN 2 — CROSS-LENS GUIDANCE

The ten lenses above should not operate independently.

Several common problems emerge from combinations.

## Artificial intensity

This often results from:

sentence fragments;

emphasis;

contrastive reframing;

dramatic endings;

and repeated short paragraphs

working together.

None is inherently problematic.

The combined density may be.

## Synthetic polish

This often results from:

balanced sentences;

triplets;

smooth transitions;

complete emotional explanation;

symmetrical paragraphs;

and pointed conclusions.

The prose can become impressive yet strangely frictionless.

## Voice homogenization

This can emerge when:

sentence structure;

lexical preferences;

cadence;

paragraph shape;

and revision toward smoothness

remain consistent across every character and viewpoint.

## Predictability

Readers may recognize AI-like prose not from any individual word but from anticipating the next rhetorical move.

The system should therefore ask periodically:

> Can the reader hear the machinery?

If yes, revision should investigate **why the same machinery keeps being selected**, not simply disguise it with synonyms.

---

# DOMAIN 2 — PRACTICAL REVIEW LENS

When reviewing prose, do not ask whether every sentence is unique.

Ask whether the prose demonstrates enough responsiveness to:

meaning;

character;

scene;

pace;

tone;

viewpoint;

and dramatic importance.

A useful review sequence is:

First read for meaning.

Then read for rhythm.

Then read several paragraphs together for repeated architecture.

Then compare the passage to other scenes.

Then compare different POVs.

Only after identifying a meaningful pattern should revision occur.

The purpose is not maximal variation.

The purpose is **intentional cadence**.

---

# DOMAIN 2 — CENTRAL REMINDER

Syntax is not decoration placed on top of meaning.

Syntax is part of meaning.

Rhythm tells the reader:

what matters;

how quickly consciousness is moving;

what kind of mind is perceiving;

how emotionally controlled the speaker is;

where attention falls;

and whether the narrative itself feels calm, fractured, comic, ceremonial, intimate, distant, frightened, impatient, confident, or uncertain.

Therefore:

> Do not make prose varied merely to avoid sounding like AI.

Make prose responsive enough that its patterns feel like consequences of the story rather than habits of the generator.

That completes **Domain 2**.

The important principle from the research remains intact: repeated rhetorical devices are warning signs only when they become automatic, dense, predictable, or detached from narrative function. The research file also repeatedly notes that human writers legitimately use every one of these devices; it is their interaction and recurrence that readers tend to notice. 

**Remaining:** 
1. Domain 3 — Description, Imagery & Sensory Selection 
2. Domain 4 — Emotion, Interiority & Subtext 
3. Domain 5 — Dialogue & Conversational Dynamics 
4. Domain 6 — Character Identity, Cognition & Development 
5. Domain 7 — POV, Knowledge & Information Boundaries 
6. Domain 8 — Relationships & Social World 
7. Domain 9 — Scene Design & Dramatic Movement 
8. Domain 10 — Pacing, Tension & Escalation 
9. Domain 11 — Plot, Causality, Subplots & Payoff 
10. Domain 12 — Continuity, World Logic & Embodied Reality 
11. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 3 — Description, Imagery & Sensory Selection**. This domain addresses one of the clearest problems from the research: prose can be vivid yet still feel generic when description is ornamental, misallocated, repetitive, physically implausible, or detached from the viewpoint character. 

# DOMAIN 3 — DESCRIPTION, IMAGERY & SENSORY SELECTION

## Domain purpose

Description is not simply the act of telling the reader what things look like.

Description determines:

- what the narrative considers worth noticing;
- what the viewpoint character pays attention to;
- how the world feels;
- what information readers receive;
- how quickly a scene moves;
- how character and setting interact;
- and what becomes memorable.

A passage may contain many descriptive details while revealing remarkably little.

The goal of this domain is therefore not “more vivid description.”

It is **more purposeful perception**.

A strong descriptive passage should usually feel as though these details were noticed here, by this narrative consciousness, for reasons connected to this particular story.

The central distinction is:

> Detail is not the same as specificity.

And:

> Imagery is not automatically insight.

---

# DS-01 — VIEWPOINT-SPECIFIC OBSERVATION

## Core principle

What gets noticed should normally reflect the person or narrative consciousness doing the noticing.

Two characters may enter the same room and perceive almost entirely different rooms.

A medic may notice breathing, pallor, posture, and injury.

A thief may notice exits, locks, sightlines, valuables, and distracted people.

A child may notice height, noise, forbidden objects, unfamiliar adults, and things within reach.

A grieving person may notice something connected to absence.

A person who has lived in the room for twenty years may barely describe it at all.

## Common drift

Generated prose often produces the details most statistically associated with a setting.

A tavern gets:

wooden tables;

firelight;

mugs;

low conversation;

the smell of ale.

A palace gets:

marble;

gold;

high ceilings;

guards;

tapestries.

A forest gets:

filtered sunlight;

rustling leaves;

birds;

damp earth.

These details may be correct without being specific to the viewpoint.

## Why it may weaken fiction

When perception is generic, POV becomes partially decorative.

The reader learns what the model thinks belongs in a setting rather than what the character actually experiences.

This weakens:

- characterization;
- immersion;
- voice;
- cultural specificity;
- and narrative identity.

## Diagnostic questions

Why would this character notice this?

Would another viewpoint character notice something different?

Does this detail connect to the observer's:

profession;

history;

desire;

fear;

social class;

culture;

physical condition;

or current goal?

Is the detail present because it belongs here or because this type of setting usually contains it?

## Better direction

Let observation reveal the observer.

A character need not consciously analyze every detail.

Their selection alone can characterize them.

Description can therefore perform two functions simultaneously:

show the world;

show the person looking at the world.

## Valid exceptions

Omniscient, objective, panoramic, cinematic, or deliberately neutral narration may describe independently of a specific character's attention.

Even then, the **narrative voice itself** should possess some logic governing what it chooses to notice.

## Long-form warning signs

Every POV describes locations similarly.

Characters of radically different backgrounds notice the same categories of detail.

Description remains equally elaborate regardless of familiarity.

The narration notices genre-typical details more reliably than character-relevant ones.

## Revision considerations

Do not artificially force profession-specific observations into every paragraph.

The goal is not constant characterization.

Instead ask whether, across enough scenes, the viewpoint develops a recognizable pattern of attention.

---

# DS-02 — RELEVANT DETAIL

## Core principle

A vivid detail is useful when it contributes to the reader's experience.

It may contribute through:

orientation;

mood;

characterization;

worldbuilding;

foreshadowing;

physical constraint;

theme;

humor;

contrast;

tension;

or aesthetic pleasure.

Description does not need to advance plot directly.

But it should ideally earn the attention it receives.

## Common drift

Generated prose frequently supplies descriptive detail because elaboration seems appropriate.

A door receives carving details.

A coat receives fabric, cut, color, condition, and symbolic implication.

A corridor receives several sensory observations even though the character is sprinting through it.

The details may be vivid individually while collectively misallocated.

## Why it may weaken fiction

Attention is finite.

Excess detail can obscure what readers actually need to notice.

It may also create false emphasis: the reader assumes heavily described objects matter.

## Diagnostic questions

Why is this detail here?

Does it affect what the reader imagines, understands, anticipates, or feels?

Does it deserve this much space?

Is a more important detail receiving less attention?

Could the same effect be achieved through one stronger observation?

## Better direction

Select details based on **narrative value**, not completeness.

A bedroom need not be visually inventoried.

Three distinctive details may create more reality than twelve generic ones.

## Valid exceptions

Slow, lush, maximalist, historical, atmospheric, travel-oriented, gothic, worldbuilding-heavy, or object-focused fiction may deliberately value descriptive abundance.

Abundance itself may create the desired pleasure.

## Long-form warning signs

Minor locations routinely receive more descriptive development than recurring characters.

Background objects receive extensive attention but later prove irrelevant.

Description appears at a nearly fixed density regardless of pacing.

## Revision considerations

Do not reduce description merely because it is long.

Ask instead whether the chosen details collectively produce an effect worth their narrative time.

---

# DS-03 — SENSORY DISTRIBUTION

## Core principle

Human experience is multisensory, but sensory writing should remain selective.

The goal is not to include every sense.

The goal is to avoid unconscious dependence on the same narrow sensory vocabulary.

## Common drift

Description often defaults to:

sight;

sound;

temperature;

breathing;

heart rate;

smell during obvious food or decay scenes.

Other physical experiences receive less attention:

weight;

texture;

balance;

pressure;

humidity;

pain;

proprioception;

taste;

fatigue;

spatial restriction;

air movement;

vibration.

Another common drift is formulaic sensory sequencing:

what the character sees;

what they hear;

what they smell.

## Why it may weaken fiction

Mechanical multisensory description can feel like a checklist.

Conversely, purely visual description can make scenes feel bodiless.

## Diagnostic questions

What sensations would actually dominate this moment?

Would the character consciously notice them?

Are sensory details helping immersion or simply demonstrating descriptive completeness?

Is one sensory channel repeatedly doing all the work?

How does the body encounter this environment?

## Better direction

Choose sensations according to situation.

During a fight, balance and impact may matter more than visual detail.

During fever, temperature and texture may dominate.

In darkness, distance, sound, and touch become more important.

Sensory priorities should emerge from circumstance.

## Valid exceptions

Some narrative voices are intentionally visually oriented.

Others may avoid physical sensation for stylistic or thematic reasons.

The objective is not equal representation.

## Long-form warning signs

Every scene begins with visual orientation.

Smell appears mainly as an atmospheric embellishment.

Emotional scenes repeatedly move toward heartbeat, breath, warmth, or cold.

Sensory detail feels inserted rather than experienced.

## Revision considerations

Do not add sensory information simply to make writing “immersive.”

Add it when the body, environment, or viewpoint makes it relevant.

---

# DS-04 — METAPHOR INTEGRITY

## Core principle

A metaphor or comparison should normally contribute something beyond the bare emotional category.

It may:

clarify;

surprise;

characterize;

connect themes;

intensify;

compress complex perception;

or reveal how a particular mind organizes experience.

## Common drift

Generated prose can create metaphors that sound emotionally correct but become vague or nonsensical when examined.

A metaphor may indicate:

danger;

grief;

tension;

love;

silence;

power;

without adding any more specific understanding.

Another drift is excessive metaphorical treatment of ordinary material.

## Why it may weaken fiction

Metaphorical density creates an illusion of richness.

But if comparisons do not withstand examination, the prose may feel decorative rather than perceptive.

Readers understand that a sentence is supposed to feel profound without gaining a sharper image or thought.

## Diagnostic questions

What does this metaphor actually reveal?

Is the comparison internally coherent?

Could the viewpoint character plausibly produce it?

Does it clarify something difficult to describe directly?

Is it surprising because it is apt or merely because the images are unusual?

Does the scene need a metaphor here?

## Better direction

Use metaphors whose relationships have substance.

A metaphor may be strange.

It does not need to be literally perfect.

But there should be something meaningful connecting source and target.

Character-specific metaphors are especially valuable.

A sailor, surgeon, accountant, boxer, gardener, priest, and child are unlikely to construct the same figurative language.

## Valid exceptions

Surrealism, dream sequences, poetry-adjacent prose, absurdism, altered states, magical realism, and intentionally unstable narration may use associative imagery whose logic is emotional rather than literal.

## Long-form warning signs

Characters share the same metaphorical vocabulary.

Every emotional moment receives figurative language.

Metaphors consistently rely on the same categories:

weight;

storms;

knives;

shadows;

fire;

ice;

oceans;

gravity;

fractures.

## Revision considerations

Do not simply replace familiar metaphors with stranger ones.

Novelty without accuracy can make the problem worse.

Strengthen the underlying perception first.

---

# DS-05 — IMAGE COHERENCE

## Core principle

Individual images in a passage should normally be able to coexist.

The reader should not be forced to mentally reconcile incompatible spatial, material, or conceptual imagery unless the instability is intentional.

## Common drift

Generated prose may layer comparisons rapidly:

a voice cuts like glass;

then settles like smoke;

then hangs like iron;

then becomes a tide.

Each image may sound plausible alone.

Together they may produce no coherent sensory experience.

Another form occurs when verbs conflict with the physical nature of the image.

## Why it may weaken fiction

The reader receives emotional signals but cannot form a stable mental representation.

This contributes to the feeling of prose being impressive on first contact but empty under scrutiny.

## Diagnostic questions

Can these images exist together?

Are several metaphors competing for the same moment?

Does the verb fit the object being described?

What physical or emotional experience is the passage actually trying to create?

Would one strong image carry more force?

## Better direction

Allow images enough room to establish themselves.

When several metaphors appear close together, consider whether they belong to a coherent image family or whether they are fighting for attention.

## Valid exceptions

Hallucinatory, psychedelic, surreal, comic, manic, or intentionally disorienting prose may benefit from rapid incompatible imagery.

## Long-form warning signs

Descriptions continually shift metaphorical frames.

Images appear powerful locally but leave little memorable picture.

Repeated metaphor stacking replaces direct observation.

## Revision considerations

Read the image literally once.

Not because metaphor must be literally possible, but because literal examination often reveals accidental incoherence.

---

# DS-06 — DESCRIPTION PROPORTIONALITY

## Core principle

The amount and intensity of description should reflect narrative purpose rather than a fixed descriptive habit.

## Common drift

A model may describe:

a temporary hallway;

a stranger seen once;

routine clothing;

minor weather;

background furniture

with the same density used for:

a first view of an important place;

a lover;

a murder scene;

a supernatural revelation;

a symbolically important object.

## Why it may weaken fiction

Narrative emphasis becomes confused.

Readers often assume space equals significance.

Overdescription may also slow scenes that depend on urgency.

Underdescription can make crucial moments feel weightless.

## Diagnostic questions

How important is this to the current experience?

How familiar is the setting to the POV?

How much time does the character realistically have to observe it?

Is the reader encountering this for the first time?

Will this matter later?

Would slowing down increase the desired effect?

## Better direction

Let descriptive bandwidth change.

Some places deserve one noun.

Some deserve a paragraph.

Some deserve pages.

Proportionality should arise from **importance, novelty, viewpoint, and pacing**.

## Valid exceptions

A deliberately obsessive narrator may lavish attention on seemingly trivial objects.

A comic narrator may intentionally overdescribe insignificance.

A minimalist narrator may intentionally underdescribe major events.

## Long-form warning signs

Description length remains remarkably consistent across scene types.

Every new room gets an introductory paragraph.

Every new character receives a visual inventory.

Action repeatedly stops for environmental description.

## Revision considerations

Do not assume shorter is better.

The issue is whether narrative attention matches the intended experience.

---

# DS-07 — EMBODIED PLAUSIBILITY

## Core principle

Bodies occupy space.

Physical actions should normally respect:

anatomy;

distance;

balance;

orientation;

reach;

weight;

injury;

fatigue;

clothing;

objects;

and environmental constraints.

## Common drift

Generated prose may produce physically plausible-sounding actions that cannot actually occur as described.

Examples may include:

impossible body positioning;

hands apparently performing multiple incompatible actions;

characters touching each other despite established distance;

injuries disappearing during action;

objects changing orientation;

faces being described from impossible viewpoints;

movement occurring without necessary repositioning.

## Why it may weaken fiction

Physical impossibility can destroy immersion instantly.

This is especially important in:

romance;

combat;

sports;

dance;

medical scenes;

physical comedy;

intimate scenes;

and tightly blocked conversations.

## Diagnostic questions

Where is everyone standing?

What are their hands doing?

Can they reach?

What are they holding?

What injuries or restrictions apply?

Does the body need to reposition before performing the described movement?

What can the POV physically see from here?

## Better direction

Maintain a simple spatial model during complex physical scenes.

Not every movement needs description.

But movements that are described should usually be possible.

## Valid exceptions

Dream logic, slapstick, supernatural bodies, altered physics, animation-inspired prose, and deliberately impossible worlds may violate ordinary physical expectations.

Even then, violations should follow the fiction's own rules.

## Long-form warning signs

Combatants teleport subtly between positions.

Characters repeatedly forget objects in their hands.

Intimate scenes accumulate impossible limb arrangements.

Injuries affect characters only when narratively convenient.

## Revision considerations

Imagine or physically mime complicated movements when necessary.

Simpler blocking is often stronger than elaborate but incoherent choreography.

---

# DS-08 — ENVIRONMENTAL INTERACTION

## Core principle

Setting becomes more convincing when characters interact with it rather than merely observe it.

## Common drift

Description is presented as a visual pause.

The character enters a location.

The narration describes it.

Then the story resumes almost independently of the environment.

The place could be replaced with a different backdrop with little effect.

## Why it may weaken fiction

The world feels decorative rather than inhabited.

Setting loses causal power.

## Diagnostic questions

What can this environment make easier?

What can it make harder?

What do characters touch, avoid, use, trip over, smell, hear through, hide behind, or depend upon?

How does weather, architecture, crowding, darkness, terrain, noise, or temperature affect behavior?

Would the scene unfold differently somewhere else?

## Better direction

Let setting participate.

A restaurant affects privacy.

A cramped room affects body positioning.

Rain affects visibility, clothing, smell, footing, traffic, and mood.

A wealthy house changes how some characters behave.

A battlefield constrains movement.

Environment can shape action without becoming an exposition block.

## Valid exceptions

Some scenes deliberately use a neutral or interchangeable location.

Minimalist fiction may suppress environmental interaction.

## Long-form warning signs

Settings receive elaborate descriptions but rarely affect action.

Characters behave identically in public and private environments.

Weather appears primarily as mood decoration.

Locations lack practical consequences.

## Revision considerations

Do not force every setting to become a plot obstacle.

Often one or two natural interactions are enough to make a place feel materially present.

---

# DS-09 — GENERIC BODY-LANGUAGE AWARENESS

## Core principle

Physical reactions can communicate emotion efficiently.

The problem arises when a limited vocabulary of gestures becomes a substitute for character-specific behavior.

## Common drift

Repeated reactions include:

jaw tightening;

eyes narrowing;

brows furrowing;

fists clenching;

shoulders stiffening;

breath catching;

swallowing hard;

stomach twisting;

heart hammering;

hands trembling;

a smile not reaching the eyes;

releasing a breath one did not realize one was holding.

Any one of these may be perfectly effective.

The concern is cumulative predictability.

## Why it may weaken fiction

Characters begin sharing the same body.

Different emotions produce interchangeable gestures.

The prose becomes an emotional signaling system rather than observation.

## Diagnostic questions

Is this reaction physically plausible?

Is it distinctive to this person or merely recognizable shorthand?

Has the same gesture appeared recently?

Would this character conceal the reaction?

Would there be any visible reaction at all?

What does this person actually do when uncomfortable?

## Better direction

Develop behavioral specificity.

One person cleans.

Another jokes.

Another talks too much.

Another becomes extremely polite.

Another stops making eye contact.

Another becomes still.

Another changes the subject.

Another displays no outward sign.

Physical reaction should emerge from both **emotion and character**.

## Valid exceptions

Certain physiological reactions really are common.

Fear can accelerate breathing.

Pain can cause tension.

The system should not avoid ordinary bodily behavior merely to create novelty.

## Long-form warning signs

Every character displays anger through jaw or fist tension.

Every attraction scene involves breath, heat, pulse, or stomach sensations.

Micro-reactions appear after nearly every line of dialogue.

## Revision considerations

Do not replace one stock gesture with a rarer stock gesture.

Instead ask whether a gesture is needed at all.

---

# DS-10 — OBJECT SIGNIFICANCE RESTRAINT

## Core principle

Objects can carry emotional and thematic significance without the narration repeatedly explaining that significance.

## Common drift

Once an object becomes meaningful, generated prose may continually remind the reader.

A ring is no longer simply handled.

It is:

the ring representing the promise;

the weight of memory;

the symbol of what was lost;

the reminder of another life.

A photograph, weapon, necklace, scar, doorway, chair, letter, flower, or childhood object may receive similar repeated interpretation.

## Why it may weaken fiction

Repeated decoding reduces symbolic power.

The reader stops participating in the association.

The object becomes a labelled device rather than a living part of the story.

## Diagnostic questions

Has the object's meaning already been established?

Can its recurrence carry that meaning without explanation?

Has the meaning changed since its earlier appearance?

Would the character consciously interpret it every time?

Is the object becoming more complex or simply being re-labelled?

## Better direction

Let objects accumulate associations.

An object may mean one thing early and something different later.

Its physical condition, context, ownership, absence, or treatment may communicate development.

The narration does not always need to translate that change.

## Valid exceptions

A character may consciously obsess over an object.

Ritual, grief, trauma, religious practice, symbolism-heavy narration, children's fiction, or mythic storytelling may repeatedly articulate an object's meaning.

## Long-form warning signs

Every reappearance of a symbolic object receives interpretive commentary.

Characters continually think about what the object represents.

Motifs do not evolve; they are merely reiterated.

## Revision considerations

When an object returns, ask:

What is different now?

If nothing has changed, repetition may still create motif.

But if the prose repeatedly explains the same meaning, consider allowing recognition alone to carry the effect.

---

# DOMAIN 3 — CROSS-LENS GUIDANCE

Several recurring descriptive problems emerge from combinations of these lenses.

## Ornamental description

Usually involves:

weak viewpoint specificity;

low information value;

heavy metaphor;

excess descriptive density;

and insufficient environmental interaction.

The prose may be vivid while the world remains generic.

---

## False specificity

A passage may contain many nouns, textures, colors, and adjectives while still feeling interchangeable.

Specificity is not measured by the number of details.

A detail becomes genuinely specific when it establishes something particular about:

this environment;

this culture;

this person;

this history;

or this moment.

---

## Decorative POV

The narration technically remains inside a character's perspective while the descriptive choices could belong to anyone.

True viewpoint is not merely controlling pronouns and knowledge.

It also involves **attention**.

---

## Emotional telemetry

Body language, sensations, and micro-expressions may appear so frequently that the prose continuously reports emotional status.

This can create:

dialogue line;

reaction;

interpretation;

dialogue line;

reaction;

interpretation.

Sometimes conversation should move without visible emotional annotation.

---

## Symbolic overmanagement

A model may recognize a motif correctly and then protect it by repeatedly reminding the reader.

Strong symbolism often benefits from less supervision.

---

# DOMAIN 3 — PRACTICAL REVIEW LENS

When reviewing description, ask in roughly this order:

### 1. Whose perception is this?

Determine the viewpoint or narrative consciousness.

### 2. Why is this detail being selected?

Establish its contribution.

### 3. Is the level of attention proportional?

Compare the space given to its importance.

### 4. Does the body and environment make sense?

Check physical coherence.

### 5. Are images actually meaningful?

Test metaphor and imagery for substance.

### 6. Is emotion being repeatedly translated into body language?

Look for automatic reaction vocabulary.

### 7. Is symbolism being explained unnecessarily?

Protect reader inference.

### 8. Does this description belong specifically to this novel?

This final question matters most.

---

# DOMAIN 3 — CENTRAL REMINDER

Description is an act of selection.

A camera could record nearly infinite detail.

A novel cannot and should not.

What gives description meaning is the decision:

> this, rather than everything else.

Therefore, the system should not ask:

> How can this scene be described more vividly?

It should first ask:

> What would matter enough to be noticed here?

Then:

> Who would notice it this way?

And finally:

> What does this particular observation contribute to this particular novel?

The goal is not maximum sensory richness.

It is **meaningful attention**.

That completes **Domain 3**. The research behind this domain especially supports the concerns around ornate-but-vague description, detail being allocated to the wrong things, metaphor that sounds meaningful without deepening the image, generic physical choreography, and physically or contextually inappropriate actions. 

**Remaining:**
1. Domain 4 — Emotion, Interiority & Subtext
2. Domain 5 — Dialogue & Conversational Dynamics
3. Domain 6 — Character Identity, Cognition & Development
4. Domain 7 — POV, Knowledge & Information Boundaries
5. Domain 8 — Relationships & Social World
6. Domain 9 — Scene Design & Dramatic Movement
7. Domain 10 — Pacing, Tension & Escalation
8. Domain 11 — Plot, Causality, Subplots & Payoff
9. Domain 12 — Continuity, World Logic & Embodied Reality
10. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next 

## ChatGPT

Next is **Domain 4 — Emotion, Interiority & Subtext**. This is one of the most important domains because the research repeatedly shows a paradox: AI-heavy fiction can contain a great deal of emotional language while still feeling emotionally shallow. Common complaints include emotional paraphrasing, excessive labeling, characters understanding themselves too perfectly, and the narration explaining meaning after it has already been conveyed. 

# DOMAIN 4 — EMOTION, INTERIORITY & SUBTEXT

## Domain purpose

Emotion in fiction is not simply the naming of feelings.

It emerges from the interaction of:

- character history;
- expectation;
- desire;
- fear;
- memory;
- interpretation;
- bodily state;
- relationships;
- immediate circumstance;
- action;
- thought;
- speech;
- silence;
- and consequence.

A character may feel something without understanding it.

They may understand it but refuse to admit it.

They may admit it privately but conceal it socially.

They may display one emotion while experiencing another.

They may feel several incompatible things at once.

They may realize what they felt only much later.

The goal of this domain is therefore not to make emotion less explicit.

It is to make emotional experience **specific, causal, layered, and appropriate to the character and moment**.

The central distinction is:

> Naming emotion is not the same as creating emotional experience.

And:

> Ambiguity is not inherently deeper than clarity.

Sometimes a character should simply think:

> I am afraid.

The question is whether that directness belongs naturally to the character, moment, and narrative voice.

---

# EM-01 — EMOTIONAL CAUSALITY

## Core principle

Emotion should usually arise from the relationship between an event and the particular person experiencing it.

The same event can produce different feelings in different characters.

A dismissal from work might produce:

fear;

relief;

humiliation;

rage;

freedom;

guilt;

indifference;

or several of these simultaneously.

The event alone does not determine the emotional response.

Character history and interpretation do.

## Common drift

Generated prose often selects an emotion because it is conventionally associated with the situation.

A death produces grief.

A betrayal produces anger.

A victory produces pride.

A threat produces fear.

A reunion produces relief.

These responses may be entirely appropriate.

The weakness arises when the story does not sufficiently connect the emotion to **this particular person**.

## Why it may weaken fiction

Generic emotional reactions make characters feel interchangeable.

The reader recognizes the correct category of feeling without learning anything new about the person.

This contributes to the common sensation of prose being emotionally expressive but psychologically shallow.

## Diagnostic questions

Why does this specific event affect this specific character in this specific way?

What personal history changes the meaning of the event?

What expectation has been fulfilled or violated?

What does the character believe the event says about themselves?

What do they believe it says about another person?

Would another character feel something different?

Is there an emotion underneath the obvious emotion?

## Better direction

Build emotion through **interpretation**.

The emotional chain might be:

event → character interpretation → emotional response → action or inhibition.

For example:

A friend does not attend a funeral.

One character thinks:

> He abandoned me.

Another thinks:

> He couldn't bear to come.

Another thinks:

> Good. I didn't want him there.

The external fact is identical.

The emotional experience is not.

## Valid exceptions

Some reactions are sufficiently immediate or physiological that lengthy individualization is unnecessary.

Pain hurts.

A sudden explosion can startle almost anyone.

Physical danger may provoke automatic fear responses.

Even then, what happens **after** the automatic response may become highly individual.

## Long-form warning signs

Different characters react similarly to equivalent events.

Emotional responses follow genre convention more reliably than character history.

The protagonist repeatedly experiences the exact emotion the scene seems designed to produce.

Emotional consequences disappear once the immediate scene ends.

## Revision considerations

Do not make reactions unusual merely for originality.

An expected emotion can be powerful when it arises from sufficiently specific circumstances.

The goal is not surprising emotion.

The goal is **owned emotion**.

---

# EM-02 — EMOTIONAL PROGRESSION

## Core principle

Emotion is dynamic.

A feeling can:

intensify;

weaken;

transform;

combine with another feeling;

be displaced;

be suppressed;

be misdirected;

or become understood differently over time.

## Common drift

Generated scenes sometimes establish one emotional state and maintain it through the entire passage.

A character is angry.

They remain angry.

Everything they notice confirms anger.

Every thought explains anger.

Every action expresses anger.

Then the scene ends.

Another common drift is instant progression:

shock → understanding → acceptance → closure,

all within a short exchange.

## Why it may weaken fiction

Static emotion creates monotony.

Overly rapid emotional movement creates unearned resolution.

In both cases, the character's inner life becomes mechanically aligned with the needs of the scene.

## Diagnostic questions

Does the emotion change during the scene?

What new information alters it?

Does another emotion complicate it?

Is the character becoming more or less certain?

Is the feeling becoming easier or harder to express?

Does the emotional state at the end logically follow from the beginning?

Has the story moved through emotional stages too quickly?

## Better direction

Think in terms of emotional movement rather than emotional labeling.

A confrontation might progress:

certainty → irritation → defensiveness → doubt → shame → renewed anger.

Or:

fear → determination.

Or:

grief that barely changes at all.

There is no required complexity.

The important point is that progression should arise from what happens.

## Valid exceptions

Some scenes are deliberately emotionally static.

Numbness may remain numbness.

Rage may remain rage.

A character may refuse all emotional movement.

That refusal can itself become dramatically meaningful.

## Long-form warning signs

Similar scenes repeatedly produce the same emotional trajectory.

Characters resolve emotional conflicts too quickly.

Earlier emotional developments do not affect later reactions.

A character repeatedly “learns” the same emotional lesson.

## Revision considerations

Do not add extra emotional stages to make a scene sophisticated.

Track only changes that plausibly occur.

---

# EM-03 — INFERENCE SPACE

## Core principle

Readers can infer emotional meaning.

When action, dialogue, context, or prior knowledge already communicates a feeling, additional explanation may be unnecessary.

## Common drift

A passage shows emotion and then explains it.

For example:

> She folded the letter twice and slid it beneath the stack of unpaid bills.

Then:

> She could not bear to look at it anymore.

Then:

> It reminded her too much of what she had lost.

Then:

> The grief had become impossible to ignore.

All of these statements may be true.

The question is whether all are needed.

## Why it may weaken fiction

Repeated emotional translation can:

reduce subtext;

slow pacing;

make the narrator seem distrustful of the reader;

weaken the original image;

and turn implication into instruction.

## Diagnostic questions

What has the reader already understood?

Does this sentence reveal something new or merely state the implication?

Would removing the interpretation increase or decrease clarity?

Is ambiguity useful here?

Does the character need to consciously articulate the feeling?

Is the narration explaining because the story requires it or because the model prefers completion?

## Better direction

Allow strong signals to remain signals.

An action may carry emotion without commentary.

A silence may remain unexplained.

A contradiction between speech and action may invite interpretation.

## Valid exceptions

Some voices are highly analytical.

Some characters constantly interpret themselves.

Some genres require greater emotional clarity.

Important emotional turns may benefit from direct statement.

Reader inference should not become a fetish.

Clarity is not inferior to subtlety.

## Long-form warning signs

Nearly every emotional gesture receives narration explaining it.

Dialogue subtext is immediately decoded.

The narrator repeatedly tells readers what a silence, glance, smile, or pause “means.”

## Revision considerations

When removing explanation, confirm that enough evidence remains for the intended reading.

Subtext should create interpretive space, not accidental obscurity.

---

# EM-04 — CHANNEL DIVERSITY

## Core principle

Emotion can be communicated through multiple channels.

These include:

- direct thought;
- direct emotional naming;
- bodily sensation;
- behavior;
- dialogue;
- silence;
- attention;
- memory;
- avoidance;
- humor;
- aggression;
- decision-making;
- changes in routine;
- environmental interaction.

No single channel is inherently superior.

## Common drift

AI fiction may repeatedly depend on a few familiar channels:

physical sensation;

micro-expression;

explicit emotional labels;

internal psychological analysis.

This can create an emotional formula:

stimulus → body reaction → emotional label → interpretation.

## Why it may weaken fiction

Characters begin expressing very different emotions in structurally similar ways.

Emotional scenes become predictable.

The reader encounters a reporting mechanism instead of individual behavior.

## Diagnostic questions

How does this character normally express distress?

What do they do rather than feel?

What emotion changes their speech?

What emotion makes them quieter?

Would they externalize or conceal this feeling?

Could the emotion affect a practical decision instead of being verbally analyzed?

## Better direction

Choose emotional channels according to character and circumstance.

A frightened character may become controlling.

Another may joke.

Another may become quiet.

Another may ask practical questions.

Another may clean.

Another may seek physical contact.

Another may start an unrelated argument.

## Valid exceptions

Some emotional states have strong common physiological components.

A character may also have recurring emotional habits as part of their identity.

Consistency is desirable when it belongs to the person.

## Long-form warning signs

Different characters exhibit emotion through the same physical reactions.

Emotional beats follow similar prose structures.

Every significant feeling receives an internal label.

## Revision considerations

Do not deliberately choose obscure reactions merely to create variety.

The behavior should remain psychologically plausible.

---

# EM-05 — EMOTIONAL TIMING

## Core principle

Emotional weight depends partly on timing.

A revelation, confession, breakdown, reconciliation, declaration of love, forgiveness, or transformation is affected by how much narrative and psychological preparation precedes it.

## Common drift

Generated stories often identify the correct emotional destination but arrive too quickly.

Characters may:

forgive immediately;

understand each other immediately;

confess feelings at the earliest opportunity;

resolve grief in one conversation;

explain trauma upon minimal prompting;

reach emotional insight as soon as conflict appears.

## Why it may weaken fiction

The event may contain all the language associated with a powerful emotional moment while lacking accumulated pressure.

The story produces **the form of payoff without sufficient investment**.

## Diagnostic questions

What has been building toward this moment?

What prevents the character from reaching this point earlier?

What internal resistance remains?

What external circumstances affect timing?

Would this person actually be ready to say or understand this now?

Has the relationship earned this degree of vulnerability?

## Better direction

Let emotional developments occur according to:

character readiness;

relationship history;

social circumstances;

fear;

shame;

opportunity;

misunderstanding;

and previous consequences.

Some emotional truths can arrive instantly.

Others require half a novel.

## Valid exceptions

Sudden realizations happen.

People confess impulsively.

Trauma can break through without preparation.

Love can be immediate.

Forgiveness can genuinely be quick.

The issue is not speed itself.

It is **unearned speed**.

## Long-form warning signs

Major emotional milestones repeatedly occur soon after introduction.

Conflicts close within the same scene in which they appear.

Relationships continually achieve clarity instead of accumulating ambiguity.

## Revision considerations

Do not artificially delay every emotional event.

Delay is useful only when something real sustains it.

---

# EM-06 — CONTRADICTORY EMOTION

## Core principle

Human emotional states are often mixtures rather than clean categories.

A person may simultaneously love and resent someone.

A victory may bring grief.

A funeral may bring relief.

Fear may coexist with excitement.

Jealousy may coexist with genuine affection.

## Common drift

Generated prose can move toward emotional clarity:

the character identifies the “real” feeling underneath everything.

What seemed like anger is revealed to be fear.

What seemed like hatred is revealed to be love.

What seemed like grief is revealed to be guilt.

This may simplify complex emotional states into one final correct answer.

## Why it may weaken fiction

Psychological complexity is lost.

The character's inner life becomes something to solve.

But emotions are not always riddles with one correct solution.

## Diagnostic questions

Does one feeling actually replace another?

Or do both exist?

Is the character trying to simplify their own emotional state?

Could their interpretation be incomplete?

What incompatible desires are operating simultaneously?

## Better direction

Permit emotional coexistence.

A character may never fully reconcile the contradiction.

Different feelings may dominate at different times.

## Valid exceptions

Sometimes an emotion genuinely has been misidentified.

Recognition can be dramatically powerful.

The goal is not to make every emotional state complicated.

## Long-form warning signs

Characters repeatedly discover the “true” emotion beneath a false one.

Complex conflicts simplify into single emotional explanations.

The narration frequently resolves ambiguity by naming one definitive feeling.

## Revision considerations

Ask whether simplification belongs to the character or to the narrator.

A character may believe one simple explanation even when the story leaves room for another.

---

# EM-07 — IMPERFECT SELF-KNOWLEDGE

## Core principle

Characters do not need perfect access to their own motives.

They may:

rationalize;

deny;

misremember;

project;

misidentify;

avoid;

or simply fail to understand themselves.

## Common drift

AI-generated characters often possess extremely polished psychological insight.

During conflict they can explain:

what they feel;

why they feel it;

which earlier event caused it;

what contradiction they are experiencing;

how the other person's behavior affects them;

and what they need to heal.

This may make characters sound like skilled therapists describing themselves.

## Why it may weaken fiction

Perfect self-knowledge eliminates discovery.

It can also make characters feel wiser and more emotionally articulate than their established personality or circumstances support.

Misunderstanding oneself is a powerful engine for:

conflict;

irony;

development;

mistakes;

and tragedy.

## Diagnostic questions

Would this character actually know this about themselves?

Would they admit it?

Would they possess the language to articulate it?

Are they under conditions that allow this level of reflection?

Could their current explanation be partially wrong?

What are they motivated not to understand?

## Better direction

Distinguish:

what the character feels;

what they think they feel;

what they say they feel;

what they later understand;

and what the reader may infer.

These layers need not agree.

## Valid exceptions

Some characters genuinely possess excellent emotional self-awareness.

Therapists, psychologists, reflective personalities, people who have spent years confronting particular issues, or characters at the end of a completed arc may articulate themselves accurately.

## Long-form warning signs

Most major characters possess similar psychological sophistication.

People resolve arguments by correctly naming each other's motives.

Characters discover emotional truths immediately after the triggering event.

## Revision considerations

Do not make characters stupid about themselves merely to create drama.

The goal is psychologically appropriate awareness.

---

# EM-08 — RESTRAINT CALIBRATION

## Core principle

Emotional intensity should reflect both the event and the way the particular narrative expresses intensity.

A powerful emotional moment does not always require powerful-sounding language.

## Common drift

Generated prose may increase emotion by increasing:

metaphor;

abstract nouns;

fragments;

body reactions;

repetition;

dramatic internal statements;

and narrative commentary.

The more important the moment, the more linguistically amplified it becomes.

## Why it may weaken fiction

Language can compete with emotion.

A moment may already be devastating because of context.

Additional rhetorical intensity can reduce rather than increase its force.

## Diagnostic questions

How much of the emotion already exists because of prior context?

Does this moment need amplification?

Would plain language be stronger?

Would this character become more articulate or less articulate under this pressure?

Is the prose announcing importance rather than allowing the event to carry it?

## Better direction

Use a full range of emotional intensity.

Some major moments may become expansive.

Others may become sparse.

A character receiving terrible news might think deeply.

Or they might ask:

> What time?

Restraint and expressiveness are both available tools.

## Valid exceptions

Melodrama, romance, gothic fiction, tragedy, lyrical fiction, epic fantasy, soap-operatic storytelling, and certain character voices may deliberately embrace emotional excess.

## Long-form warning signs

Every major emotional scene grows stylistically ornate.

Every revelation produces fragments and physical symptoms.

High emotional significance becomes synonymous with heightened prose.

## Revision considerations

Do not automatically flatten intense passages.

Ask whether the intensity feels earned and specific.

---

# EM-09 — INTERNAL-MONOLOGUE PURPOSE

## Core principle

Internal thought should do more than narrate what the reader already sees.

It can:

reveal private interpretation;

conflict with speech;

recall relevant memory;

make plans;

misunderstand events;

notice patterns;

rationalize behavior;

fantasize;

worry;

or reveal a distinctive mode of consciousness.

## Common drift

Generated interiority often paraphrases the scene.

A character hears an insult.

The narration shows their reaction.

Then the internal monologue explains why the insult hurt.

Then it summarizes what the interaction means.

This creates multiple versions of the same beat.

## Why it may weaken fiction

Excess interior explanation slows conversations and action.

It can also make time feel unreal: one spoken sentence triggers paragraphs of sophisticated internal analysis before the next person responds.

## Diagnostic questions

What new information does this thought provide?

Is the character thinking or is the narrator explaining through them?

Would someone have time to think this much?

Is this thought specific to this character?

Does it complicate the visible scene?

Could the thought be shortened without losing its function?

## Better direction

Use interiority as another active layer of narrative.

Interesting internal thought often differs from external reality.

A character may say:

> “That's fine.”

while thinking about whether the train station is still open.

That displacement itself may reveal emotional avoidance.

## Valid exceptions

Deeply introspective fiction may legitimately spend much more time inside thought than external chronology would literally allow.

Narrative time is elastic.

The issue is not realism alone.

It is whether the interiority contributes.

## Long-form warning signs

Every important line of dialogue generates a paragraph of reaction.

Thought repeatedly summarizes visible action.

Different POV characters possess similar internal analytical styles.

## Revision considerations

When cutting interiority, preserve thoughts that contain distinctive interpretation, contradiction, memory, or decision.

Cutting all thought can make fiction equally flat.

---

# EM-10 — RESIDUAL EMOTION

## Core principle

Emotional experiences should often leave traces beyond the scene in which they occur.

People carry mood, expectation, resentment, grief, embarrassment, affection, fear, and uncertainty forward.

## Common drift

AI narratives can treat emotional states as scene-local.

A devastating argument occurs.

The next chapter begins and the relationship behaves almost normally.

A character undergoes terror.

Once the danger ends, the terror disappears.

A major confession changes the relationship temporarily, but subsequent scenes return to the previous baseline.

## Why it may weaken fiction

The novel stops accumulating psychological history.

Emotional scenes become disposable performances rather than events with consequences.

This contributes strongly to the feeling that characters repeatedly reset.

## Diagnostic questions

What emotional residue does this event leave?

Does it affect:

trust?

expectation?

speech?

avoidance?

confidence?

physical behavior?

future decision-making?

What does the character now anticipate differently?

What becomes easier or harder after this?

## Better direction

Track important emotional developments as state changes.

Residual emotion need not dominate every future scene.

Often it appears subtly:

a different hesitation;

less eye contact;

greater familiarity;

an avoided subject;

a changed assumption;

a new reflex.

## Valid exceptions

Some people recover quickly.

Some compartmentalize effectively.

Some experiences genuinely leave little lasting mark.

Not every emotional event requires long-term consequences.

## Long-form warning signs

Relationships repeatedly return to identical conversational patterns.

Characters forget previous emotional breakthroughs.

Traumatic, intimate, humiliating, or transformative experiences disappear from later behavior.

The same emotional conflict can be recreated because earlier resolution left no lasting state change.

## Revision considerations

Do not make characters continually reference previous events.

Emotional continuity should usually affect behavior more often than exposition.

---

# DOMAIN 4 — CROSS-LENS GUIDANCE

Several important failure patterns emerge from combinations of the ten lenses.

---

## Emotional paraphrasing

This occurs when several channels communicate essentially the same feeling.

For example:

physical gesture;

emotional label;

internal explanation;

metaphor;

concluding summary.

The question is not whether each sentence is good.

The question is whether each sentence adds a new layer.

A useful emotional sequence might instead involve:

gesture → contradictory thought → unexpected action.

Each component changes what the reader understands.

---

## The “emotion report”

This occurs when narration continuously tells readers the emotional status of characters.

The prose becomes something like:

she was uneasy;

he was frustrated;

she noticed his frustration;

he saw her unease;

the tension grew;

neither knew what to say.

The emotional state is fully documented but not necessarily dramatized.

The corrective direction is not simply “show, don't tell.”

Direct emotional naming may be excellent.

The real question is:

> Is the scene making emotion happen, or merely reporting that emotion exists?

---

## Psychological over-resolution

AI narration may continually move toward definitive interpretation:

this was why;

she finally understood;

he realized what he truly wanted;

now everything made sense.

Such realizations can be powerful.

But constant interpretation creates a world in which psychology is unusually solvable.

Some moments should produce greater uncertainty.

---

## Therapist-character convergence

Characters may begin sharing:

high emotional vocabulary;

precise motive analysis;

healthy boundary language;

balanced perspective-taking;

and carefully articulated self-awareness.

These are not bad qualities.

The problem is when characters who should differ radically in:

age;

culture;

personality;

education;

emotional maturity;

or historical period

all demonstrate the same modern psychological fluency.

---

## Manufactured emotional depth

A passage may appear emotionally deep because it includes:

abstract reflection;

trauma language;

symbolic imagery;

contradictory feelings;

and solemn phrasing.

But depth depends less on the amount of emotional vocabulary than on how specifically the emotional experience belongs to the character and story.

---

## Automatic emotional closure

A generated scene often wants to finish emotional work.

An argument tends toward understanding.

A confession tends toward relief.

A misunderstanding tends toward clarification.

A moment of vulnerability tends toward reciprocation.

A painful realization tends toward growth.

The system should remember that scenes may instead produce:

new misunderstanding;

partial understanding;

shame;

retreat;

resentment;

false resolution;

delayed reaction;

or no immediate resolution at all.

---

# DOMAIN 4 — THE “SHOW, DON'T TELL” CORRECTION

This system should **not** use “show, don't tell” as a universal command.

Both showing and telling are essential.

Direct statement can be:

efficient;

moving;

funny;

intimate;

clear;

voice-rich;

or stylistically appropriate.

For example:

> I hated him.

may be much stronger than several paragraphs of coded body language.

The better question is:

> Which mode best serves this moment?

Use direct emotional telling when directness is powerful.

Use implication when inference is powerful.

Use both when each contributes something different.

Avoid repeating the same emotional information merely because different techniques are available.

---

# DOMAIN 4 — EMOTIONAL STATE MODEL

For important characters, emotional continuity should be understood through several separate layers.

A useful internal model is:

### Current feeling
What is being felt now?

### Conscious interpretation
What does the character think they are feeling?

### Public presentation
What do they allow others to see?

### Underlying concern
What fear, desire, wound, belief, or expectation is influencing the response?

### Relationship context
How does the person involved change the emotional reaction?

### Residual history
What earlier events are still affecting this moment?

### Immediate pressure
How do fatigue, danger, pain, intoxication, urgency, embarrassment, or social context change expression?

### Likely next effect
What may this emotional experience change afterward?

These categories should guide thinking.

They should **not** all appear explicitly in the prose.

---

# DOMAIN 4 — PRACTICAL REVIEW LENS

When reviewing emotional material, ask:

### 1. Is the emotion character-specific?

Could this exact reaction belong to almost anyone?

### 2. Is the emotion causally grounded?

Do we understand enough about why this matters?

### 3. Has the same feeling been communicated several times?

Look for paraphrasing across action, thought, body language, and explanation.

### 4. Does the character understand themselves too perfectly?

Consider denial, uncertainty, rationalization, or incomplete understanding.

### 5. Has emotional resolution arrived too quickly?

Check accumulated pressure and resistance.

### 6. Is the reader being allowed to infer anything?

Identify places where interpretation could remain open.

### 7. Is the emotional language proportional?

Determine whether rhetoric is creating artificial significance.

### 8. Does this moment change future emotional state?

Track residue.

---

# DOMAIN 4 — CENTRAL REMINDER

Emotional depth does not come from adding more emotional language.

It comes from the relationship between:

what happens;

what the character wanted;

what they expected;

what they believe happened;

what they fear it means;

what they admit;

what they conceal;

what they misunderstand;

and what changes afterward.

Therefore, do not ask only:

> How does the character feel?

Also ask:

> Why does this particular person feel it this way?

> What do they think the feeling means?

> What might they be wrong about?

> What are they unwilling to say?

> How does the feeling alter what they do next?

And sometimes:

> Does this need to be explained at all?

The goal is not emotional obscurity.

The goal is **emotional specificity with enough space for the reader to participate**.

That completes **Domain 4**. The underlying research particularly supports the distinction between emotional description and emotional causality, the problem of repeatedly paraphrasing one feeling, overly self-aware characters, loss of subtext, and generic physical reactions being used as an almost closed vocabulary for emotion. 

**Remaining:**
1. Domain 5 — Dialogue & Conversational Dynamics
2. Domain 6 — Character Identity, Cognition & Development
3. Domain 7 — POV, Knowledge & Information Boundaries
4. Domain 8 — Relationships & Social World
5. Domain 9 — Scene Design & Dramatic Movement
6. Domain 10 — Pacing, Tension & Escalation
7. Domain 11 — Plot, Causality, Subplots & Payoff
8. Domain 12 — Continuity, World Logic & Embodied Reality
9. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 5 — Dialogue & Conversational Dynamics**. The research repeatedly identifies dialogue as one of the clearest long-form failure points: characters sound alike, exchanges become too symmetrical, speakers restate one another, people articulate themselves too perfectly, and dialogue exists to transfer information rather than because a character would naturally say it. 

# DOMAIN 5 — DIALOGUE & CONVERSATIONAL DYNAMICS

## Domain purpose

Dialogue is not merely information delivered in quotation marks.

Conversation is an interaction between people who possess:

- different goals;
- different knowledge;
- different emotional states;
- different relationships;
- different communication habits;
- different levels of honesty;
- different assumptions;
- and different abilities to express what they mean.

A conversation may communicate information, but information transfer is only one of its possible functions.

Dialogue can also:

- negotiate status;
- conceal vulnerability;
- provoke;
- distract;
- manipulate;
- reassure;
- test;
- flirt;
- threaten;
- avoid;
- perform social roles;
- create misunderstanding;
- reveal incompatible interpretations;
- change relationships;
- or simply allow characters to enjoy one another.

Strong dialogue does not need to imitate literal real-life speech in every respect.

Actual conversation contains enormous amounts of repetition, filler, false starts, and meaningless talk.

Fiction normally selects and shapes conversation.

The goal is therefore not:

> Make dialogue completely realistic.

The better goal is:

> Make dialogue feel psychologically and socially plausible while remaining narratively purposeful.

---

# DG-01 — SPEAKER-SPECIFIC LANGUAGE

## Core principle

Characters should possess sufficiently distinct ways of speaking that dialogue reflects who is talking.

Voice difference does not require caricature.

Characters do not each need obvious catchphrases or radically different dialects.

Distinction can emerge through:

- vocabulary;
- sentence length;
- directness;
- formality;
- humor;
- use of metaphor;
- tolerance for silence;
- willingness to swear;
- precision;
- emotional openness;
- tendency to question;
- tendency to command;
- use of names;
- hedging;
- exaggeration;
- understatement;
- and preferred conversational strategies.

## Common drift

Generated dialogue often differentiates speakers primarily through factual identity.

One is a soldier.

One is a scholar.

One is shy.

One is sarcastic.

Yet underneath these labels they share:

similar sentence structure;

similar emotional vocabulary;

similar rhetorical sophistication;

similar timing;

similar self-awareness;

and similar patterns of argument.

The characters have different biographies but the dialogue appears produced by the same conversational intelligence.

## Why it may weaken fiction

Dialogue stops reinforcing character identity.

Characters become interchangeable at sentence level.

The reader may require dialogue tags simply to remember who is speaking.

Voice convergence also makes relationships less distinctive.

## Diagnostic questions

Could another major character plausibly say this exact line unchanged?

Does the vocabulary match the speaker's background?

Does the speaker tend to be:

direct?

indirect?

formal?

performative?

brief?

verbose?

Does their way of speaking change with different people?

Does their current emotional state affect their language?

Would they actually use this metaphor or abstraction?

## Better direction

Build dialogue voice from **communication habits**, not gimmicks.

One character may often clarify.

Another may refuse clarification.

One may answer questions literally.

Another may answer what they think the question really means.

One may use humor whenever uncomfortable.

Another becomes excessively formal.

One may speak in concrete examples.

Another prefers abstraction.

## Valid exceptions

Characters from the same family, institution, community, military unit, profession, or culture may legitimately share linguistic habits.

A deliberately uniform social environment may produce similar speech.

## Long-form warning signs

Different POV characters sound similar in spoken conversation.

Children, elders, academics, soldiers, nobles, criminals, and supernatural beings share comparable rhetorical sophistication.

Everyone adopts the same concise modern cadence.

## Revision considerations

Do not manufacture difference by randomly inserting slang or quirks.

Ask instead:

> How does this person approach communication?

Voice is deeper than vocabulary.

---

# DG-02 — UNEQUAL ARTICULATION

## Core principle

People differ greatly in their ability and willingness to express what they mean.

Some speak precisely.

Some speak emotionally but inaccurately.

Some know what they mean but cannot formulate it.

Some are eloquent only in familiar subjects.

Some become less articulate under pressure.

Some become more articulate because speech is how they regain control.

## Common drift

Generated characters often possess suspiciously equal levels of conversational competence.

During difficult moments they may all produce:

complete arguments;

well-structured explanations;

emotionally precise vocabulary;

clean distinctions;

and elegant summaries.

## Why it may weaken fiction

Conversation becomes intellectually symmetrical.

Character differences in:

age;

education;

confidence;

culture;

social power;

temperament;

and emotional maturity

are flattened.

## Diagnostic questions

How articulate is this person normally?

How articulate are they **right now**?

Does this topic make them more or less confident?

Do they possess the vocabulary for this?

Would they need examples instead of abstractions?

Would they stumble?

Would they oversimplify?

Would they intentionally pretend not to understand?

## Better direction

Let characters possess unequal communicative resources.

One person may know exactly what is happening emotionally but lack the words.

Another may have sophisticated vocabulary while completely misunderstanding the situation.

## Valid exceptions

Highly educated, rhetorically trained, diplomatic, legal, academic, theatrical, or politically experienced characters may genuinely communicate at high levels.

## Long-form warning signs

Every character can explain themselves with comparable clarity.

Arguments repeatedly produce beautifully balanced statements from both sides.

Emotional scenes sound more like essays than stressed communication.

## Revision considerations

Do not deliberately make characters inarticulate for “realism.”

Give each character the degree and kind of articulation that belongs to them.

---

# DG-03 — CONVERSATIONAL IMPERFECTION

## Core principle

Conversation does not always progress cleanly from statement to appropriate response.

People:

- interrupt;
- mishear;
- answer only part of a question;
- ignore what was asked;
- change the subject;
- assume shared knowledge;
- misunderstand;
- hesitate;
- revise themselves;
- trail off;
- overreact to one word;
- or refuse to respond.

Fiction can selectively use these irregularities to create believable interaction.

## Common drift

AI dialogue often forms clean alternating units:

A states a point.

B addresses exactly that point.

A responds logically.

B produces a counterpoint.

A reframes.

B concludes.

The conversation behaves like collaborative problem-solving even when the characters are supposedly hostile, frightened, embarrassed, or confused.

## Why it may weaken fiction

The dialogue becomes too efficient.

People seem designed to help the conversation reach its destination.

Misunderstanding becomes rare unless the plot explicitly requires it.

## Diagnostic questions

Did this person actually answer what was asked?

Would they want to?

Did one part of the previous line matter more to them than the rest?

Would they interrupt?

Is someone controlling the topic?

Could a misunderstanding arise naturally?

Is the conversation progressing too cleanly toward the planned outcome?

## Better direction

Allow conversational friction where character and circumstance support it.

A response may be emotionally relevant without being logically responsive.

## Valid exceptions

Professional interviews, interrogations, formal negotiations, courtroom exchanges, structured debates, and highly cooperative conversations may be unusually organized.

## Long-form warning signs

Every line neatly advances the discussion.

Interruptions happen only as dramatic punctuation rather than actual conversational disruption.

Characters rarely misunderstand one another except when required by the plot.

## Revision considerations

Do not insert filler or interruptions merely to imitate natural speech.

Use imperfection where it reveals character or alters interaction.

---

# DG-04 — INFORMATION MOTIVATION

## Core principle

Characters generally need reasons to provide information.

Knowing something is not the same as wanting to say it.

## Common drift

Generated dialogue often transmits information because the reader needs it.

A character explains:

a political relationship;

a family history;

a magic rule;

a military hierarchy;

a past incident;

a social custom;

even when the listener already knows it or when the speaker has little reason to explain it.

## Why it may weaken fiction

Characters become exposition mechanisms.

The conversation feels arranged for an external observer rather than happening between actual participants.

## Diagnostic questions

Why is this character saying this now?

Does the listener already know it?

What does the speaker hope to accomplish?

Would they reveal this information willingly?

Would they shorten it because the listener understands the context?

Could disagreement or questioning reveal the information more naturally?

## Better direction

Attach exposition to conversational motive.

A person may explain information because they are:

correcting someone;

boasting;

teaching;

warning;

arguing;

reminiscing;

mocking;

confessing;

threatening;

or trying to manipulate perception.

Then the information has both narrative and interpersonal function.

## Valid exceptions

Teachers teach.

Commanders brief.

Experts explain.

Strangers need background information.

Some people genuinely overexplain.

Exposition is not inherently unnatural.

## Long-form warning signs

Characters repeatedly explain known information to one another.

Worldbuilding appears mainly through complete spoken summaries.

Secondary characters appear primarily to tell the protagonist what the story needs them to know.

## Revision considerations

Do not hide necessary information so aggressively that readers become confused.

The goal is motivated exposition, not exposition avoidance.

---

# DG-05 — EXPOSITION RESISTANCE

## Core principle

Dialogue should not automatically become the default container for information that could be communicated more effectively elsewhere.

## Common drift

When a story needs worldbuilding, backstory, motives, plans, or explanation, the model may create a conversation.

Characters become convenient information-delivery systems.

## Why it may weaken fiction

Too much conversational exposition can:

make characters sound unnatural;

slow relationships;

create artificial questions;

and make every informational need visible in the architecture of the scene.

## Diagnostic questions

Why is this information dialogue rather than:

narration?

observation?

memory?

document?

action?

consequence?

Is the conversation itself interesting?

Does the exchange reveal anything beyond the information?

## Better direction

Choose the channel that best serves the material.

Some information belongs in dialogue.

Some is better implied.

Some is better demonstrated.

Some deserves direct narration.

## Valid exceptions

Mysteries, political fiction, military fiction, courtroom stories, procedural stories, mentorship narratives, and philosophical fiction may naturally contain information-heavy conversations.

## Long-form warning signs

Every new concept receives a question-and-answer sequence.

One character repeatedly plays “the person who doesn't know” so another can explain.

## Revision considerations

Do not transform every explanation into action.

Sometimes the clearest and most elegant solution is simply to explain something.

---

# DG-06 — SUBTEXTUAL SPEECH

## Core principle

People do not always say what they mean.

They may speak around:

fear;

desire;

shame;

resentment;

status;

attraction;

jealousy;

grief;

or conflict.

Subtext emerges when the literal meaning of speech differs from or only partially expresses its interpersonal meaning.

## Common drift

Generated dialogue often makes emotional conflict unusually explicit.

Characters say:

what they feel;

why they feel it;

what the other person did;

what they need;

and what must change.

This can be appropriate.

But repeated explicitness removes relational uncertainty.

## Why it may weaken fiction

The conversation becomes emotionally transparent.

Readers have little to infer.

Characters may also appear implausibly willing to expose vulnerabilities.

## Diagnostic questions

What does the speaker actually want from the listener?

Would they say that directly?

What are they afraid of revealing?

Can the same intention appear through a different subject?

What does the listener understand that is not being said?

## Better direction

Allow literal and interpersonal meaning to diverge.

A discussion about dishes may actually concern respect.

A complaint about lateness may concern abandonment.

A question about tomorrow may really ask whether the relationship has a future.

## Valid exceptions

Some people communicate directly.

Healthy relationships may contain explicit emotional conversation.

Therapy, reconciliation, confession, or crisis may demand directness.

Subtext is not automatically superior.

## Long-form warning signs

Characters repeatedly state the true underlying issue during the first relevant conversation.

Emotional conflict rarely survives because speakers articulate it immediately.

## Revision considerations

Do not make dialogue cryptic simply to create “subtext.”

The hidden meaning should remain grounded in context.

---

# DG-07 — CONVERSATIONAL MOVEMENT

## Core principle

A significant conversation should often alter the state of the story or relationship.

Movement can involve:

new information;

changed intention;

increased suspicion;

reduced trust;

greater intimacy;

misunderstanding;

commitment;

withdrawal;

decision;

or emotional shift.

## Common drift

AI conversations may sound polished while accomplishing very little.

Characters discuss an issue.

They exchange views.

They restate the situation.

Then the conversation ends with essentially the same story state.

## Why it may weaken fiction

Dialogue becomes content rather than action.

Repeated conversational stasis contributes strongly to the impression that the novel is generating scenes without accumulating consequence.

## Diagnostic questions

What is different after this conversation?

What did someone learn?

What changed in trust?

What decision became more or less likely?

What new question appeared?

What was damaged?

What became possible?

## Better direction

Think of dialogue as action.

Words can have consequences.

A conversation need not resolve anything.

It can make matters worse.

## Valid exceptions

Atmospheric, comic, slice-of-life, relational, or character-focused fiction may contain conversations whose value lies mainly in companionship, voice, or texture.

Even then, repeated exchanges can gradually establish relationship state.

## Long-form warning signs

Characters repeatedly discuss the same conflict.

Conversations revisit prior emotional ground without new consequences.

The plot could remove several dialogue scenes with little effect.

## Revision considerations

Do not require every conversation to contain a dramatic turn.

Small cumulative movement counts.

---

# DG-08 — MIRROR-RESPONSE AWARENESS

## Core principle

Repetition between speakers can be powerful when it reflects emotion, challenge, disbelief, intimacy, ritual, or misunderstanding.

The concern is automatic semantic mirroring.

## Common drift

Dialogue may proceed like:

“You're leaving.”

“I'm leaving.”

“You made up your mind.”

“I did.”

“You don't care.”

“I care.”

Each answer reflects the shape or vocabulary of the previous line.

## Why it may weaken fiction

Conversation becomes mechanical.

Information barely advances.

The reader hears alternating paraphrases rather than two independent minds.

## Diagnostic questions

Is the repetition doing something emotionally useful?

Could the response introduce a different concern?

Is the speaker actually engaging, or simply reflecting the previous sentence?

Does repetition create tension, rhythm, or realism here?

## Better direction

Let characters respond according to their own priorities.

Someone told “You're leaving” might answer:

“When did you find out?”

or:

“Move away from the door.”

or:

“It's six in the morning.”

The response does not need to mirror the proposition.

## Valid exceptions

Echoing can be highly effective during:

shock;

intimacy;

interrogation;

mockery;

ritual;

disbelief;

or escalating argument.

## Long-form warning signs

Characters frequently repeat key words from the immediately preceding line.

Questions regularly receive structurally symmetrical answers.

## Revision considerations

Preserve repetition when repetition itself carries meaning.

Remove it when it merely keeps the conversation moving syntactically.

---

# DG-09 — CONFLICT ASYMMETRY

## Core principle

Arguments do not need to resemble formal debates.

People enter conflicts with unequal:

information;

emotional investment;

power;

goals;

communication skills;

and willingness to participate.

## Common drift

AI arguments often become balanced rhetorical exchanges.

Each character:

makes a strong point;

receives a response;

concedes something;

clarifies;

then produces another point.

This can make even emotionally volatile conflict feel strangely organized.

## Why it may weaken fiction

Arguments become too rational.

Power differences disappear.

Characters behave as though resolving the intellectual issue is their shared goal.

But someone may instead want to:

win;

hurt;

escape;

delay;

save face;

force an apology;

avoid responsibility;

or end the conversation.

## Diagnostic questions

What does each participant actually want?

Are they arguing about the same thing?

Who has more power?

Who can leave?

Who is afraid?

Is someone arguing in bad faith?

Does either person care about being logically consistent?

## Better direction

Allow asymmetrical participation.

One person may explain while another refuses explanation.

One may discuss facts while another discusses betrayal.

One may want resolution while another wants punishment.

## Valid exceptions

Formal debate, mediation, diplomacy, academic discussion, and some mature relationships may involve unusually balanced argument.

## Long-form warning signs

Every major conflict produces articulate arguments from both sides.

Characters regularly summarize one another's positions accurately.

Arguments reach conceptual clarity suspiciously quickly.

## Revision considerations

Do not make conflict irrational merely to make it dramatic.

The asymmetry should arise from people and circumstances.

---

# DG-10 — SITUATIONAL SPEECH

## Core principle

How people speak should respond to physical and social conditions.

Dialogue happens somewhere.

Speakers may be:

running;

freezing;

injured;

whispering;

drunk;

half-asleep;

publicly observed;

afraid of being overheard;

short of breath;

under authority;

or pressed for time.

## Common drift

Generated characters retain the same speech quality regardless of circumstance.

During combat or panic, they produce long coherent statements.

During secret conversations in public, they discuss sensitive matters openly.

Injured characters speak as comfortably as healthy ones.

## Why it may weaken fiction

Dialogue appears detached from embodiment and environment.

This weakens both realism and scene integration.

## Diagnostic questions

Can they physically say this much?

Who might overhear?

What social rules apply?

Does pain or exhaustion affect speech?

How much time is available?

Is someone controlling themselves because of who is present?

## Better direction

Allow circumstance to shape:

sentence length;

volume;

word choice;

topic;

risk tolerance;

and timing.

## Valid exceptions

Some characters remain exceptionally composed under pressure.

Others become unusually verbose when frightened.

Character remains the final authority.

## Long-form warning signs

High-stress conversations sound like calm-room conversations.

Characters routinely hold complex debates during immediate danger.

Dialogue seems to occur in a vacuum independent of setting.

## Revision considerations

Do not reduce every action-scene exchange to single-word shouting.

People can speak at length under pressure when circumstances allow.

---

# DOMAIN 5 — CROSS-LENS GUIDANCE

## The “perfect exchange”

A frequent generated-dialogue structure is:

one speaker presents a clean thought;

the second understands it correctly;

responds directly;

the first clarifies;

the second offers a sophisticated counterpoint;

both move toward shared understanding.

This is excellent for some conversations.

It becomes artificial when it dominates the novel.

Ask:

> Are these characters cooperating with the dialogue more than they are cooperating with each other?

---

## Dialogue as disguised essay

Sometimes two characters appear to converse while actually presenting complementary paragraphs from an argument.

Signs include:

complete conceptual statements;

unusually polished transitions;

few interruptions;

accurate interpretation;

minimal emotional distortion;

and both speakers remaining focused on one abstract issue.

This may fit philosophical fiction.

Elsewhere, it can flatten character.

---

## The therapy-session effect

Characters may begin using highly developed emotional language:

“You're projecting.”

“You're avoiding vulnerability.”

“You don't have to carry this alone.”

“You're allowed to feel that.”

“I need you to respect my boundaries.”

These are legitimate human phrases.

The concern is contextual uniformity.

Ask whether the language belongs to:

this person;

this culture;

this historical setting;

this relationship;

and this level of psychological sophistication.

---

## Conversational teleportation

A dialogue may jump from superficial topic to deepest emotional truth because the model knows the scene's destination.

The missing material is often **resistance**.

People may require:

provocation;

trust;

misunderstanding;

silence;

multiple attempts;

or accumulated pressure

before reaching certain statements.

---

## Everyone answers the question

Real and convincing fictional characters may:

answer;

refuse;

lie;

deflect;

question the question;

answer something adjacent;

change subject;

weaponize the question;

or simply remain silent.

A question should not automatically create an answer-shaped next line.

---

## Exposition characters

Watch especially for supporting characters whose major purpose is to:

tell the protagonist what happened;

explain the world;

interpret another person;

identify the threat;

deliver advice;

or summarize the protagonist's emotional condition.

A character may perform these functions.

The question is whether they possess enough independent existence that the function feels like something **they chose to do**.

---

# DOMAIN 5 — CHARACTER VOICE MODEL

For recurring characters, dialogue can be guided by a lightweight internal profile.

This should not become a rigid template.

Useful dimensions include:

### Directness
Do they state what they mean or approach indirectly?

### Verbal confidence
Do they speak decisively, cautiously, or inconsistently?

### Vocabulary
Simple, technical, abstract, regional, formal, slang-heavy, mixed?

### Sentence movement
Short? Expansive? Interruptive? Precise? Rambling?

### Emotional disclosure
Open, guarded, performative, avoidant?

### Humor
Do they joke? What kind?

### Conflict behavior
Confront, withdraw, placate, provoke, intellectualize?

### Social adaptation
How does their speech change with:

friends;

authority;

strangers;

family;

rivals;

lovers?

### Conversational weakness
What are they bad at communicating?

### Conversational blind spot
What kind of statement do they repeatedly misunderstand?

### Silence
What makes them stop talking?

This profile guides generation.

It should never require every dialogue line to demonstrate every trait.

---

# DOMAIN 5 — PRACTICAL REVIEW LENS

When reviewing a conversation, ask:

### 1. Could I identify the speakers without tags?

Not necessarily every line, but often enough to perceive distinction.

### 2. Why is each person speaking?

Identify motive, not merely information content.

### 3. Are they communicating too efficiently?

Look for artificial cooperation.

### 4. Does everyone understand too much?

Preserve plausible interpretive limits.

### 5. Is the conversation moving?

Track what changes.

### 6. Are speakers equally articulate?

Check whether that fits them.

### 7. Is exposition being delivered because the reader needs it?

Check speaker motivation.

### 8. Is subtext appropriate?

Do not automatically make every conversation indirect.

### 9. Does the environment matter?

Check privacy, pressure, body, time, and social context.

### 10. Does the dialogue belong to these characters specifically?

This remains the most important question.

---

# DOMAIN 5 — CENTRAL REMINDER

Dialogue should feel like contact between **independent minds**.

Each participant brings:

their own knowledge;

their own agenda;

their own history;

their own misunderstanding;

their own ability to speak;

their own reason to conceal;

their own interpretation of the other person;

and their own idea of what the conversation is about.

Those ideas may not match.

Therefore, before writing an important exchange, do not ask only:

> What information must this conversation communicate?

Ask:

> What does each person want from this conversation?

> What are they willing to say?

> What are they unwilling to say?

> What do they misunderstand?

> What do they think the other person means?

> Who is controlling the conversation?

> What changes because these words were spoken?

The goal is not messy dialogue.

The goal is **conversation shaped by character rather than by the needs of the text generator**.

That completes **Domain 5**. The source research particularly supports the problems addressed here: dialogue becoming alternating “beats,” semantic ping-pong, unnatural self-awareness, same-voice characterization, exposition-serving characters, and conversations that sound polished while failing to create meaningful movement. 

**Remaining:**
1. Domain 6 — Character Identity, Cognition & Development
2. Domain 7 — POV, Knowledge & Information Boundaries
3. Domain 8 — Relationships & Social World
4. Domain 9 — Scene Design & Dramatic Movement
5. Domain 10 — Pacing, Tension & Escalation
6. Domain 11 — Plot, Causality, Subplots & Payoff
7. Domain 12 — Continuity, World Logic & Embodied Reality
8. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 6 — Character Identity, Cognition & Development**. This is a core domain because the research repeatedly identifies personality drift, character reset, voice convergence, plot-serving behavior, and “growth” that feels like replacement rather than accumulated change. 

# DOMAIN 6 — CHARACTER IDENTITY, COGNITION & DEVELOPMENT

## Domain purpose

A character is more than a list of traits.

A believable fictional person has:

- relatively stable tendencies;
- changing emotional states;
- memory;
- habits;
- preferences;
- fears;
- goals;
- blind spots;
- skills;
- limits;
- interpretations;
- contradictions;
- relationships;
- and a history that accumulates.

The challenge is balancing two truths:

> Characters should remain recognizably themselves.

And:

> Characters should not remain psychologically frozen.

Too much stability creates mechanical repetition.

Too much change creates personality drift.

The goal is **continuity with adaptation**.

A character should be capable of surprising the reader without becoming arbitrary.

---

# CH-01 — STABLE IDENTITY

## Core principle

A recurring character should possess enough psychological continuity that their behavior feels connected across scenes.

Identity does not mean perfect consistency.

It means that decisions, speech, attention, reactions, and interpretations tend to arise from a recognizable underlying person.

## Common drift

Generated stories may preserve surface traits while losing deeper identity.

A character remains:

sarcastic;

brave;

cold;

kind;

ambitious;

or shy

according to their character description, yet individual scenes contradict the deeper logic that previously made those traits believable.

Another form is temporary personality replacement:

a restrained character suddenly becomes highly confessional;

a selfish character becomes altruistic for one scene;

a cautious character becomes reckless because the plot needs action;

then the earlier personality returns afterward.

## Why it may weaken fiction

Readers build predictive models of characters.

When behavior repeatedly violates those models without explanation, the character stops feeling like an independent person.

They begin to feel adjustable.

## Diagnostic questions

What behaviors tend to remain recognizable across this character's scenes?

What values or assumptions repeatedly influence them?

What do they usually avoid?

What kind of pressure makes them behave differently?

Is this surprising action still understandable in retrospect?

Would the reader be able to connect this behavior to something already established?

## Better direction

Think of character identity as a range rather than a single fixed behavior.

A cautious person can act recklessly under sufficient pressure.

A selfish person can sacrifice something.

A coward can be brave.

The key question is:

> What made this exception possible?

Strong characterization allows exceptions while preserving causality.

## Valid exceptions

Sudden personality change may itself be the point.

Examples include:

brain injury;

magic;

possession;

drugs;

severe trauma;

memory alteration;

psychological collapse;

or deliberate deception.

The narrative should still understand that something significant has changed.

## Long-form warning signs

A character behaves primarily according to the needs of individual scenes.

Earlier traits disappear whenever inconvenient.

Personality descriptions remain constant while actual behavior fluctuates.

The same character appears noticeably different depending on which plot function they are performing.

## Revision considerations

Do not force perfect consistency.

Instead ask whether contradiction can be traced to:

context;

pressure;

development;

relationship;

or hidden information.

---

# CH-02 — ADAPTIVE STATE

## Core principle

Characters should respond to what happens to them.

Their current psychological state may differ from their baseline personality.

A normally patient person may become irritable after three sleepless nights.

A confident person may become cautious after public failure.

A suspicious person may gradually trust someone.

These changes need not become permanent traits.

## Common drift

Two opposite failures appear frequently.

### Static-character drift

The character repeatedly returns to baseline no matter what happens.

### Unbounded-adaptation drift

The character changes too freely according to immediate context.

One creates stagnation.

The other creates inconsistency.

## Why it may weaken fiction

A novel gains power when readers feel accumulated experience modifying behavior.

Without adaptation, events seem psychologically consequence-free.

Without stability, development becomes impossible to measure.

## Diagnostic questions

What is this character's baseline?

What is their current state?

What recent events are altering that state?

Is the alteration temporary or becoming permanent?

What would cause them to return toward baseline?

What would push the change deeper?

## Better direction

Track both:

**identity** — what tends to remain stable;

and

**state** — what has changed recently.

For example:

baseline: socially confident.

current state: unusually hesitant after humiliating failure.

Both can be true simultaneously.

## Valid exceptions

Some genres intentionally use archetypal or highly stable characters.

Serial comedy, myth, children's fiction, procedural series, and adventure franchises may rely partly on characters returning toward baseline.

## Long-form warning signs

Major events leave no psychological residue.

Temporary moods become permanent traits without transition.

Character behavior changes chapter by chapter without identifiable cause.

## Revision considerations

Do not overdocument state changes in prose.

The writer or system may track them internally while allowing behavior to reveal them naturally.

---

# CH-03 — CHARACTER-SPECIFIC COGNITION

## Core principle

Characters should differ not only in what they say but in **how they think**.

Cognition includes:

- what they notice;
- what they remember;
- what evidence they trust;
- what assumptions they make;
- how they solve problems;
- how quickly they decide;
- what they consider relevant;
- and how they explain the world to themselves.

## Common drift

Characters have different surface personalities but share the same cognitive engine.

They all:

analyze situations similarly;

reach similarly balanced conclusions;

use comparable emotional reasoning;

notice the same types of evidence;

and possess similar levels of introspection.

This creates characters who have different biographies but effectively the same mind. The source research explicitly identifies this convergence as a major long-form complaint. 

## Why it may weaken fiction

Character identity becomes cosmetic.

Different POVs cease to offer genuinely different experiences of the story.

## Diagnostic questions

How does this character usually reason?

Do they think through:

examples?

principles?

instinct?

social cues?

probabilities?

stories?

rules?

physical experience?

Who trusts intuition?

Who distrusts it?

Who overthinks?

Who decides quickly?

What information does this character habitually ignore?

## Better direction

Differentiate **mental procedure**, not merely content.

Given the same suspicious event:

one character may ask who benefits;

another may remember precedent;

another may focus on emotional motive;

another may assume coincidence;

another may search for physical evidence.

## Valid exceptions

Characters trained together may share cognitive habits.

Members of the same profession or institution may reason similarly.

That similarity can itself reveal culture.

## Long-form warning signs

All POVs perform similar internal analysis.

Different characters arrive at comparable insight through comparable reasoning.

Character-specific thinking disappears during plot-critical scenes.

## Revision considerations

Do not turn every character into a psychological experiment.

A few strong cognitive tendencies are often enough to produce distinction.

---

# CH-04 — MOTIVATIONAL CONTINUITY

## Core principle

Characters act because they want, fear, value, believe, or need something.

Their motives may change.

Their understanding of those motives may be incomplete.

But significant choices should generally have psychological roots.

## Common drift

The plot requires a character to do something, so the character does it.

A suspicious person suddenly trusts.

A loyal person betrays.

A careful leader ignores an obvious risk.

A rival offers help.

The story may provide a sentence explaining the action without truly establishing motivation.

## Why it may weaken fiction

Characters become mechanisms for plot progression.

The reader senses that causality originates from the outline rather than from the person.

## Diagnostic questions

What does this character want right now?

What larger desire influences them?

What are they trying to avoid?

Why choose this action rather than another?

What belief makes this decision seem reasonable to them?

What would they lose by refusing?

## Better direction

Let plot emerge from collision among motives.

A useful question is:

> If the planned plot event were removed, would this character still have a reason to make this choice?

If not, motivation may need strengthening.

## Valid exceptions

People act impulsively.

They make mistakes.

They contradict their goals.

They sometimes do things without understanding why.

Motivational continuity should allow irrationality.

## Long-form warning signs

Characters become temporarily foolish when the plot requires danger.

Motives appear immediately before the action they justify.

Once the plot event is complete, the new motive disappears.

## Revision considerations

Avoid retroactive explanation unless retrospective understanding is itself part of the story.

Prefer motives that already exist before they become narratively convenient.

---

# CH-05 — COMPETENCE CONTINUITY

## Core principle

Characters should retain roughly coherent levels of knowledge, skill, judgment, and experience.

Competence can fluctuate under pressure.

But it should not switch on and off solely for plot convenience.

## Common drift

A brilliant strategist misses an obvious solution.

A novice suddenly performs expert analysis.

A veteran forgets basic procedure.

A powerful character conveniently fails to use an established ability.

A detective becomes less perceptive until the mystery requires revelation.

## Why it may weaken fiction

Conflict feels manufactured.

Readers may stop trusting stakes because characters appear only as competent as the current scene allows.

## Diagnostic questions

What can this person reliably do?

What do they know?

What do they misunderstand despite expertise?

What circumstances reduce their performance?

What makes this situation different from previous ones?

Has the story established limits to their competence?

## Better direction

Distinguish between:

knowledge;

skill;

judgment;

information;

resources;

emotional condition;

and opportunity.

A skilled person may fail because:

they lack information;

they are exhausted;

they misidentify the problem;

they are overconfident;

someone deceives them;

or the situation falls outside their expertise.

These failures preserve competence while allowing difficulty.

## Valid exceptions

People make inexplicable mistakes.

Experts fail at basic tasks.

Stress can seriously degrade performance.

The issue is repeated convenience, not isolated imperfection.

## Long-form warning signs

Competence rises during victories and collapses during required setbacks.

Enemies become foolish whenever the protagonist needs to succeed.

Characters forget previously demonstrated abilities.

## Revision considerations

When a competent character must fail, strengthen the obstacle rather than automatically weakening the character.

---

# CH-06 — BELIEVABLE DEVELOPMENT

## Core principle

Character development should usually arise from accumulated experience.

Growth is not a change in description.

It is a change in:

belief;

behavior;

expectation;

strategy;

relationship;

self-concept;

or value

that emerges from what the character has undergone.

## Common drift

The story announces development.

A dramatic scene occurs.

The character realizes something.

Immediately afterward they behave like a transformed person.

This creates the pattern identified in the source research as **character growth becoming character replacement**. 

## Why it may weaken fiction

The destination may be plausible while the journey is missing.

Readers intellectually understand the transformation without emotionally experiencing it.

## Diagnostic questions

What experiences are pushing this character toward change?

What resists the change?

When do old habits reappear?

What does change cost?

What new behavior demonstrates development?

What has not changed?

## Better direction

Think of development as pressure applied to an existing structure.

A possible progression is:

experience;

resistance;

failed old strategy;

consequence;

partial adaptation;

relapse;

new understanding;

different behavior.

Not every arc requires this complexity.

But change should generally have history.

## Valid exceptions

Epiphany can be sudden.

A single catastrophic event can transform a person rapidly.

The important question is whether the magnitude of the event plausibly supports the magnitude of change.

## Long-form warning signs

Characters become significantly different immediately after one speech.

Development is described more than demonstrated.

Old habits vanish without friction.

The story treats one realization as completion of an entire arc.

## Revision considerations

Preserve residue from the previous self.

Growth often feels more believable when old tendencies remain but are handled differently.

---

# CH-07 — INDIVIDUAL CONTRADICTION

## Core principle

A character can possess apparently contradictory traits without being inconsistent.

A person may be:

generous with money but emotionally withholding;

fearless physically but terrified of humiliation;

kind to strangers but cruel to family;

rational professionally but superstitious privately;

loyal yet resentful;

ambitious yet afraid of success.

## Common drift

Generated characterization can simplify people into trait packages.

The brave character acts bravely.

The cynical character distrusts.

The kind character comforts.

The intelligent character analyzes.

This produces consistency without complexity.

## Why it may weaken fiction

Perfect trait alignment feels schematic.

Contradictions create texture because real personalities are organized around contexts, histories, and competing needs.

## Diagnostic questions

Where does this character behave differently from their apparent type?

What value conflicts with another value?

What situations reveal a different side of them?

Which contradiction is stable rather than accidental?

Does the contradiction have understandable roots?

## Better direction

Build one or more **coherent tensions**.

The contradiction should make more sense as the reader understands the person better.

## Valid exceptions

Archetypal, mythic, comedic, allegorical, or intentionally simple characters may operate through strong uncomplicated traits.

## Long-form warning signs

Every trait points toward one personality label.

Characters become easily summarized by a single adjective.

Contradictory behavior appears only when the plot needs it and is not integrated into identity.

## Revision considerations

Do not add random opposing traits for complexity.

Contradiction should reveal structure, not noise.

---

# CH-08 — MEMORY-SHAPED BEHAVIOR

## Core principle

Characters live inside their accumulated memories.

What happened earlier should often affect:

expectation;

trust;

fear;

attention;

decision-making;

and emotional interpretation.

Memory is not merely recall of facts.

It is the psychological history shaping present behavior.

## Common drift

Characters remember factual information while behaving as though emotionally significant events never happened.

Or they forget both.

A betrayal occurs.

Later, trust returns to baseline.

A frightening place is revisited.

The character enters as though for the first time.

A painful mistake is repeated without any changed anticipation.

## Why it may weaken fiction

The character ceases to accumulate lived experience.

The novel feels episodic even when the plot is continuous.

## Diagnostic questions

What does this character remember here?

What expectation did earlier events create?

What are they now more cautious about?

What do they incorrectly generalize from previous experience?

What memory is emotionally active even if not consciously recalled?

## Better direction

Let memory influence behavior subtly.

A character need not think:

> Last time I trusted him, he betrayed me.

Instead they may hesitate before answering.

They may check the door.

They may withhold one detail.

Behavior can carry memory.

## Valid exceptions

Characters forget.

They suppress memories.

They compartmentalize.

They may consciously reject lessons they previously learned.

Such failures can themselves become characterization.

## Long-form warning signs

The same mistakes recur without changed context.

Relationship history disappears between scenes.

Previous danger does not alter future caution.

Major revelations do not affect later assumptions.

## Revision considerations

Do not make characters constantly reference previous chapters.

Memory should shape present behavior more often than produce explicit recap.

---

# CH-09 — INDEPENDENT AGENCY

## Core principle

Supporting characters should generally possess interests and motivations that extend beyond their function in the protagonist's story.

They need not all be fully developed.

But recurring characters should feel capable of wanting things even when the protagonist is absent.

## Common drift

Secondary characters exist primarily to:

encourage;

advise;

warn;

praise;

betray;

provide exposition;

introduce quests;

validate romance;

or create obstacles.

The research specifically identifies this plot-serving behavior as a recurring complaint. 

## Why it may weaken fiction

The world begins revolving around the protagonist.

Supporting characters lose unpredictability because their actions are determined by narrative function.

## Diagnostic questions

What does this character want outside the protagonist?

What responsibilities occupy them?

What problem are they handling privately?

What would they do if the protagonist disappeared?

Why are they willing—or unwilling—to help?

What does this interaction cost them?

## Better direction

Give significant supporting characters at least some independent momentum.

They may:

arrive late because of another obligation;

refuse help because of their own risk;

pursue a goal that conflicts with the protagonist;

or make choices whose consequences intersect the main plot later.

## Valid exceptions

Minor functional characters are necessary.

A cashier does not need an arc.

A messenger can simply deliver a message.

The amount of agency developed should roughly match narrative importance.

## Long-form warning signs

Supporting characters remain inactive until the protagonist needs them.

Their lives seem to pause offscreen.

They always possess time for the protagonist's problem.

Their opinions consistently serve the protagonist's emotional development.

## Revision considerations

Agency does not require subplot expansion for every person.

Sometimes one independent priority is enough.

---

# CH-10 — UNEQUAL INTERPRETIVE FRAMEWORKS

## Core principle

Characters should not necessarily interpret events the same way.

Their beliefs, histories, cultures, personalities, and interests create different models of reality.

## Common drift

Characters disagree temporarily but ultimately converge around the narrator's interpretation.

The story appears to possess one correct psychological reading, and characters gradually align with it.

## Why it may weaken fiction

Conflict becomes shallower.

Worldview differences become obstacles awaiting correction rather than genuine ways of seeing.

## Diagnostic questions

How does each person explain what happened?

Which facts matter most to them?

What assumptions are invisible to them?

What would they consider obvious that another person rejects?

Can two interpretations remain plausible?

Who benefits from each interpretation?

## Better direction

Let characters occupy genuinely different frameworks.

For example, after a failed rebellion:

one sees moral defeat;

another sees strategic education;

another sees betrayal;

another sees inevitable history;

another cares mainly about lost family.

None must be fully correct.

## Valid exceptions

Sometimes one interpretation really is correct.

A character may simply be mistaken.

The system should not manufacture ambiguity where none exists.

## Long-form warning signs

Important disagreements repeatedly end with one character recognizing the protagonist's perspective as correct.

Characters independently arrive at similar psychological conclusions.

Worldview differences disappear once enough information is shared.

## Revision considerations

Separate:

facts;

interpretations;

values;

and interests.

Two characters may agree on the facts while disagreeing completely about meaning.

---

# DOMAIN 6 — CROSS-LENS GUIDANCE

## Personality drift versus growth

These are easy to confuse.

Ask:

> Did the person change because experience changed them?

or:

> Did the prose change the person because the scene needed a different behavior?

Development has causal bridges.

Drift usually does not.

---

## Psychological resetting

A character may undergo:

confession;

betrayal;

success;

failure;

trauma;

intimacy;

or revelation

and then return to an earlier relationship or behavioral state.

This often indicates missing residual state.

The solution is not constant callbacks.

It is **behavior that remembers**.

---

## Trait-label substitution

A character description may say:

“cautious,”

“sarcastic,”

“intelligent,”

“kind.”

But labels cannot substitute for consistent behavioral logic.

Instead ask how caution manifests.

One cautious person:

researches.

Another delays.

Another secretly prepares escape routes.

Another asks for permission.

Another acts boldly but creates backup plans.

Traits should produce behavior through personality.

---

## The competence trap

Highly competent protagonists create a recurring challenge.

If the plot repeatedly requires them to fail, the model may solve the problem by temporarily making them foolish.

A stronger approach is often:

increase uncertainty;

restrict information;

introduce competing obligations;

create adversaries with genuine competence;

force tradeoffs;

or exploit the protagonist's existing blind spots.

---

## Development by speech

A common generated arc consists of:

problem;

conversation;

realization;

transformation.

Conversation may absolutely transform people.

But when major development repeatedly occurs because someone explains the lesson correctly, the novel can begin feeling therapeutic rather than dramatic.

Experience, action, consequence, and repeated choice can carry development too.

---

## Homogenized intelligence

Characters may possess different occupations while all sharing the model's general reasoning ability.

A child, soldier, king, thief, professor, and farmer may all perform similarly sophisticated moral and psychological analysis.

Intelligence itself is not the only variable.

Different people should possess different:

domains of expertise;

reasoning habits;

blind spots;

and confidence calibration.

---

# DOMAIN 6 — CHARACTER STATE MODEL

For major characters, maintain a lightweight internal state rather than relying only on a static character sheet.

Useful dimensions include:

### Core identity
What tendencies remain relatively stable?

### Current goals
What do they want now?

### Long-range goals
What larger desires organize behavior?

### Active fears
What consequences are they trying to avoid?

### Current beliefs
What do they think is true?

### Misbeliefs
What are they wrong about?

### Knowledge
What do they actually know?

### Relationships
How do they currently understand important people?

### Emotional residue
What recent events are still affecting them?

### Competence
What can they reliably do?

### Vulnerabilities
Where does judgment become unreliable?

### Current state
How are recent events temporarily changing baseline behavior?

### Development pressure
What experiences are pushing them toward change?

### Resistance
What prevents that change?

### Emerging change
What has begun to shift?

This state should guide generation.

It should not become an exposition checklist.

---

# DOMAIN 6 — ARC MODEL

For major character development, distinguish:

### Baseline
Who are they before the relevant pressure?

### Existing strategy
How do they normally deal with the problem?

### Pressure
What repeatedly challenges that strategy?

### Failure or limitation
Where does the old approach stop working?

### Resistance
Why don't they immediately change?

### Experiment
What new behavior do they attempt?

### Cost
What does change require them to lose or risk?

### Integration
How does new behavior coexist with old identity?

### Residue
What parts of the old self remain?

This is not a mandatory formula.

It is a diagnostic framework for detecting **replacement disguised as development**.

---

# DOMAIN 6 — PRACTICAL REVIEW LENS

When reviewing a major character, ask:

### 1. Are they still recognizably themselves?

Check stable identity.

### 2. Have recent events affected them?

Check adaptive state.

### 3. Do they think differently from other characters?

Check cognition.

### 4. Do their decisions emerge from motive?

Check motivational continuity.

### 5. Has competence remained coherent?

Check skill, information, and pressure.

### 6. Is development earned?

Look for causal bridges.

### 7. Do they contain meaningful contradictions?

Avoid trait packages.

### 8. Does their behavior remember the past?

Check psychological accumulation.

### 9. Do they possess life outside the protagonist?

Check agency.

### 10. Do they interpret the world in their own way?

Check worldview independence.

---

# DOMAIN 6 — CENTRAL REMINDER

A character should not be treated as a fixed set of traits.

Nor should they be rewritten whenever the plot demands it.

Think instead of a person moving through time.

They carry:

what they were;

what has happened;

what they believe happened;

what they remember;

what they want;

what they fear;

what they can do;

what they misunderstand;

and what is beginning to change.

Therefore, before an important character choice, ask:

> Would this person plausibly do this?

Then go further:

> Why now?

> What part of their existing identity supports it?

> What part resists it?

> What prior experience influences it?

> What does the choice change afterward?

The goal is not perfect consistency.

The goal is **identity with history**.

That completes **Domain 6**. The source material specifically supports the importance of preventing personality drift, preserving accumulated character history, avoiding character replacement masquerading as growth, and giving secondary characters enough agency to avoid becoming pure plot machinery. 

**Remaining:**
1. Domain 7 — POV, Knowledge & Information Boundaries
2. Domain 8 — Relationships & Social World
3. Domain 9 — Scene Design & Dramatic Movement
4. Domain 10 — Pacing, Tension & Escalation
5. Domain 11 — Plot, Causality, Subplots & Payoff
6. Domain 12 — Continuity, World Logic & Embodied Reality
7. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 7 — POV, Knowledge & Information Boundaries**. This domain targets another major long-form weakness in the research: characters knowing things they should not know, narration quietly leaking model knowledge into a limited viewpoint, secrets spreading without a believable route, and different characters reasoning from the same hidden information. The research file explicitly identifies these epistemic failures as distinct from ordinary continuity problems. 

# DOMAIN 7 — POV, KNOWLEDGE & INFORMATION BOUNDARIES

## Domain purpose

Point of view is not only a grammatical choice.

It is also a **knowledge system**.

Every character occupies a limited position inside the story.

They know some things.

They suspect some things.

They misunderstand some things.

They have forgotten some things.

They have never encountered some things.

They may possess information but fail to recognize its significance.

They may understand an event correctly while misreading another person's motive.

The narrative itself may know more than the viewpoint character, depending on the chosen form.

The central requirement is therefore not:

> Keep information hidden.

It is:

> Keep information attached to believable sources of knowledge.

A strong novel maintains distinctions among:

- what objectively happened;
- what the narrative knows;
- what the reader knows;
- what each character knows;
- what each character believes;
- what each character suspects;
- what each character falsely assumes;
- and what each character has forgotten or failed to notice.

These categories should not collapse into one shared pool.

---

# PV-01 — VIEWPOINT KNOWLEDGE

## Core principle

A viewpoint should respect the information available to the narrative perspective being used.

In close first-person or limited third-person narration, the prose should normally be constrained by what the viewpoint character could:

- perceive;
- remember;
- infer;
- imagine;
- or plausibly know.

## Common drift

Generated prose may technically remain in limited POV while quietly including information beyond the character's reach.

Examples include:

stating another person's exact emotional state;

describing events occurring outside the viewpoint's perception;

using terminology the character does not know;

explaining the true political meaning of an event before the character understands it;

or narrating an object's history that the viewpoint has never learned.

## Why it may weaken fiction

POV becomes structurally dishonest.

The reader is told they are inhabiting one consciousness while the prose periodically draws on a wider intelligence.

This can weaken:

- immersion;
- suspense;
- mystery;
- characterization;
- and trust in the narrative frame.

## Diagnostic questions

How does the viewpoint know this?

Did they:

see it?

hear it?

learn it earlier?

infer it?

guess it?

Does the prose present an inference as fact?

Could this information reasonably be available to them?

Would they recognize its significance?

## Better direction

Separate:

observation;

interpretation;

and objective fact.

Instead of:

> He was terrified.

a limited viewpoint may perceive:

> His hand missed the latch twice.

The viewpoint may interpret that correctly or incorrectly.

If they know him well, they may confidently think:

> He was terrified.

The degree of certainty should arise from the relationship and available evidence.

## Valid exceptions

Omniscient narration may move beyond any one character's knowledge.

Certain narrators may also intentionally possess unusual knowledge.

The key is consistency with the chosen narrative contract.

## Long-form warning signs

Limited narration repeatedly knows everyone else's feelings.

Secrets become narratively obvious before the POV could recognize them.

Different POV characters appear to share one global understanding of events.

## Revision considerations

Do not reduce limited POV to only literal sensory information.

Characters infer constantly.

The important distinction is between **plausible inference** and unexplained narrative certainty.

---

# PV-02 — CHARACTER KNOWLEDGE BOUNDARIES

## Core principle

Each significant character should have an individual knowledge state.

Knowing a fact somewhere in the story does not mean every character knows it.

## Common drift

Once important information enters the narrative, it begins leaking across characters.

A secret disclosed to one person affects another person's behavior before they could plausibly hear it.

A character refers to an event they never witnessed.

Someone acts on a plan that was discussed elsewhere.

The source research identifies this exact phenomenon as characters acquiring information simply because the story itself already “knows” it. 

## Why it may weaken fiction

The world begins behaving as though all characters share a common memory.

Mystery and dramatic irony collapse.

Plot consequences may occur without causal transmission of information.

## Diagnostic questions

Who knows this fact?

Who definitely does not?

Who suspects it?

Who could plausibly discover it independently?

Was there an opportunity for the information to spread?

Would the messenger actually share it?

Could the recipient misunderstand the message?

## Better direction

For important information, mentally track:

source → transmission → recipient → interpretation.

Information should move through the story.

It should not teleport.

## Valid exceptions

Public events, widely known facts, rumors, obvious physical evidence, or information that multiple people can independently infer may spread without explicit transmission scenes.

## Long-form warning signs

Secrets lose boundaries.

Characters behave as though they read scenes in which they were absent.

Information spreads instantly without social or logistical consequences.

## Revision considerations

Not every transmission needs to appear onscreen.

Offscreen information exchange is perfectly valid when plausible.

The story may simply establish that it happened.

---

# PV-03 — KNOWLEDGE ACQUISITION

## Core principle

Important knowledge should usually have a plausible route into a character's mind.

Characters learn through:

- observation;
- testimony;
- documents;
- education;
- experience;
- experimentation;
- investigation;
- rumor;
- memory;
- inference;
- or deception.

## Common drift

A character reaches the correct conclusion because the plot requires the conclusion.

The reasoning bridge is missing.

Alternatively, one small clue produces an implausibly complete understanding.

## Why it may weaken fiction

Discovery stops feeling earned.

Smart characters can begin seeming psychic.

Mysteries become artificial because characters know exactly enough whenever the narrative needs movement.

## Diagnostic questions

What evidence produced this belief?

How strong is the evidence?

What alternative explanations exist?

Does the character possess enough expertise to interpret it correctly?

What previous knowledge allows them to connect the clue?

How certain should they be?

## Better direction

Match certainty to evidence.

A character may move through:

notice → suspect → investigate → revise → conclude.

Or they may guess correctly immediately.

But if they do, the story should understand that it was a guess.

## Valid exceptions

Intuition is real.

Experts often make rapid judgments using experience they cannot fully articulate.

Prophecy, telepathy, supernatural insight, and genre conventions may also allow nonstandard knowledge acquisition.

## Long-form warning signs

Characters repeatedly infer hidden truths from minimal evidence.

Investigations jump from clue directly to solution.

Correct conclusions consistently arrive at narratively convenient moments.

## Revision considerations

Do not overcomplicate every discovery.

The reasoning only needs enough structure to feel plausible for the person making it.

---

# PV-04 — VOCABULARY PLAUSIBILITY

## Core principle

The concepts, comparisons, terminology, and metaphors available to a character should broadly reflect their life experience.

Language reveals knowledge.

## Common drift

Characters use concepts drawn from experiences they have never had.

A medieval farmer thinks in contemporary therapeutic language.

A person raised in isolation compares something to a technological system they have never seen.

A desert-raised character casually uses deep-sea imagery despite no cultural or personal access to such experience.

The source research specifically identifies this kind of mismatch as a reader-visible failure. 

## Why it may weaken fiction

The model's general world knowledge leaks into the character.

The line may be elegant while feeling completely wrong for the person.

## Diagnostic questions

Would this character know this word?

Would this culture possess this concept?

What comparisons are available from their lived experience?

Are they educated in this domain?

Is the language narratorial rather than literally the character's wording?

## Better direction

Build metaphors and terminology from:

culture;

profession;

religion;

environment;

class;

technology;

education;

and memory.

A character need not speak primitively just because their world is different.

They need language appropriate to **their own intellectual environment**.

## Valid exceptions

Translated-fiction conventions may render unfamiliar cultures into modern reader-friendly language.

Omniscient narrators may also use vocabulary unavailable to characters.

## Long-form warning signs

Every character uses the same modern abstract vocabulary.

Fantasy characters sound culturally contemporary without justification.

Metaphors draw from a generic modern knowledge base.

## Revision considerations

Avoid forced archaic or exotic language merely to signal authenticity.

Plausibility matters more than decorative difference.

---

# PV-05 — NARRATOR–CHARACTER SEPARATION

## Core principle

A narrative voice and a character consciousness may overlap without being identical.

This distinction becomes especially important in third-person limited narration.

## Common drift

Narration gradually begins expressing the model's own analytical style rather than the viewpoint's natural perceptions.

The character may be simple, impulsive, frightened, young, or poorly educated, yet narration around them becomes:

philosophically balanced;

psychologically precise;

highly metaphorical;

and unusually self-aware.

## Why it may weaken fiction

The POV character becomes a camera attached to a generic literary intelligence.

The reader hears one narrative voice regardless of who occupies the scene.

## Diagnostic questions

How close is the narrative distance here?

Is this wording something the character might conceptually think?

Does the narration possess permissions beyond the character?

Is the distinction intentional?

Would this paragraph sound substantially different under another viewpoint?

## Better direction

Define the relationship between narrator and character.

Possible modes include:

very close free-indirect style;

moderately filtered third person;

distant limited narration;

omniscient narration with character access.

Once the mode is established, use it consistently enough for the reader to understand the narrative contract.

## Valid exceptions

A strong independent narrator may intentionally retain a stable voice across multiple characters.

This is common in omniscient or stylized fiction.

## Long-form warning signs

POVs differ mainly in facts rather than language or attention.

The narrator gives every character identical psychological vocabulary.

Narrative distance shifts unconsciously from sentence to sentence.

## Revision considerations

Do not force all close narration into literal internal speech.

Narrative style may be more polished than the character's spoken language while still reflecting their worldview.

---

# PV-06 — INTERPRETATION UNCERTAINTY

## Core principle

What a character believes about an event should not automatically be treated as objective truth.

Characters may misinterpret.

## Common drift

The viewpoint thinks:

> She was angry because he had embarrassed her.

And the narration proceeds as though this causal explanation is unquestionably correct.

The character's interpretation becomes the story's interpretation.

## Why it may weaken fiction

Character bias disappears.

Relationships become too transparent.

Readers lose opportunities to recognize mistaken assumptions.

## Diagnostic questions

Is this fact or interpretation?

How certain is the character?

Could another explanation fit?

Does the narration subtly distinguish belief from reality?

Would the character's history bias this interpretation?

## Better direction

Use uncertainty appropriate to the character.

A confident character may still state assumptions internally as facts.

The story does not need to add “perhaps” constantly.

Later consequences can reveal the mistake.

## Valid exceptions

Sometimes the viewpoint is correct.

Not every thought should be suspicious.

## Long-form warning signs

POV interpretations consistently prove accurate.

Characters understand others with extraordinary precision.

Misunderstandings exist only because the plot explicitly requires them.

## Revision considerations

Do not weaken every internal judgment with hedging.

Certainty itself can characterize.

The distinction can emerge through later events.

---

# PV-07 — INFORMATION WITHHOLDING

## Core principle

Limited POV does not mean artificial concealment.

A character should not avoid naturally thinking about something merely because the writer wants to surprise the reader.

## Common drift

To preserve mystery, narration may awkwardly avoid:

a person's name;

a known relationship;

a known plan;

a familiar object;

or a remembered fact.

The character clearly knows something but the prose strategically refuses to allow their thoughts near it.

## Why it may weaken fiction

The reader can feel manipulated.

The narrator appears to hide information rather than simply occupy a limited perspective.

## Diagnostic questions

Would this character naturally think about the withheld fact here?

Are they actively avoiding it?

Does the scene provide a believable reason not to name it?

Is the mystery dependent on narrator dishonesty?

## Better direction

Withhold honestly.

Options include:

the character genuinely does not know;

they know but misinterpret;

they avoid thinking about it;

the information is irrelevant in the moment;

or the POV naturally frames it indirectly.

## Valid exceptions

Unreliable narration, deliberate concealment, mystery fiction, memory loss, trauma avoidance, and highly stylized narrative structures may intentionally manipulate information.

The manipulation should be part of the technique rather than accidental cheating.

## Long-form warning signs

Characters repeatedly think around obvious information.

Revelations depend on facts the POV inexplicably never considered.

Mysteries survive only because familiar knowledge was linguistically concealed.

## Revision considerations

Ask whether the surprise would survive if the POV behaved naturally.

If not, reconsider the structure rather than merely hiding more aggressively.

---

# PV-08 — REVELATION CONSEQUENCES

## Core principle

Learning something important should often alter the character's internal or external state.

Knowledge changes possibilities.

## Common drift

A character receives major information.

The immediate scene reacts to it.

Later behavior returns quickly to baseline.

The fact is remembered but not integrated.

## Why it may weaken fiction

Knowledge becomes informational rather than transformative.

Revelations feel like plot tokens rather than changes in the character's mental world.

## Diagnostic questions

What does the character now believe differently?

What option becomes available?

What option disappears?

Who do they trust less or more?

What question does this create?

What earlier memory now looks different?

## Better direction

Track the downstream effect of important knowledge.

Consequences may appear through:

strategy;

attention;

fear;

new suspicion;

changed relationship behavior;

or reevaluation of previous events.

## Valid exceptions

Some revelations genuinely matter less than expected.

A character may already suspect the truth.

Information overload may delay reaction.

## Long-form warning signs

Major revelations affect only the chapter in which they occur.

Characters forget strategic implications.

New knowledge does not alter future decision-making.

## Revision considerations

Do not force visible reaction immediately.

Delayed processing can be more believable.

---

# PV-09 — SECRET INTEGRITY

## Core principle

Secrets should maintain boundaries until something plausibly crosses them.

A secret is not simply information the reader has not yet been told.

It is information whose distribution matters.

## Common drift

Generated stories may treat secrets inconsistently.

Characters almost reveal them for dramatic tension.

Others inexplicably suspect them with great accuracy.

The secret changes importance from scene to scene.

Or a supposedly dangerous secret is discussed casually in insecure environments.

## Why it may weaken fiction

The plot's information architecture becomes unstable.

Secrets stop functioning as sources of risk, power, intimacy, or deception.

## Diagnostic questions

Who knows?

Who suspects?

Who wants to know?

Who is actively concealing it?

What would happen if it were revealed?

What precautions would realistic characters take?

How difficult is it to discover?

## Better direction

Treat important secrets as dynamic objects in the story.

Track:

holder;

risk;

evidence;

suspicions;

transmission opportunities;

and consequences of exposure.

## Valid exceptions

Some secrets are badly kept.

Some characters are careless.

Some worlds lack privacy.

A “secret” may be technically hidden while practically obvious.

## Long-form warning signs

Characters discuss secrets wherever convenient.

Suspicions arise with no evidence.

The danger of disclosure changes according to scene needs.

## Revision considerations

Secrets should affect behavior even while unrevealed.

Concealment itself has costs.

---

# PV-10 — METAFICTIONAL KNOWLEDGE LEAKAGE

## Core principle

Characters should not behave as though they know the plot.

They live forward.

The writer sees structure from outside; characters do not.

## Common drift

A character gives unusual attention to something only because it will matter later.

People trust or distrust someone according to their eventual role.

Characters make decisions that optimize the future plot despite lacking the information necessary to foresee those consequences.

A seemingly unimportant object is treated suspiciously because the model knows it will become important.

## Why it may weaken fiction

Characters stop behaving from their own present reality.

They become subtly controlled by authorial foreknowledge.

This can make foreshadowing feel artificial.

## Diagnostic questions

Would this character care about this **before** knowing what happens later?

Is their suspicion supported by current evidence?

Are they behaving according to genre expectations rather than in-world knowledge?

Does foreshadowing arise naturally or because characters are being made unusually perceptive?

## Better direction

Foreshadow through:

ordinary details that gain later significance;

consequences already present;

character habits;

world conditions;

or information that becomes meaningful only retrospectively.

Characters do not need to recognize the foreshadowing as important.

## Valid exceptions

Prophets, time travelers, precognitive characters, narrators recounting past events, and metafictional characters may possess knowledge of later structure.

## Long-form warning signs

Characters repeatedly notice exactly what later becomes important.

Threats are recognized before sufficient evidence exists.

Plot twists are preceded by unnaturally pointed attention.

## Revision considerations

The strongest foreshadowing often looks ordinary the first time and meaningful afterward.

---

# DOMAIN 7 — CROSS-LENS GUIDANCE

## Knowledge is not binary

Avoid reducing character knowledge to:

knows / does not know.

More useful states include:

knows;

believes;

suspects;

doubts;

misremembers;

has forgotten;

has heard as rumor;

understands partially;

possesses evidence but has not connected it;

knows but rejects;

knows but conceals.

This richer model helps produce more believable decisions.

---

## The shared-brain problem

One of the strongest AI-fiction risks is that characters appear individually separate while drawing from one hidden pool of narrative knowledge.

Signs include:

everyone understanding the same implications;

characters independently identifying the same motives;

secrets spreading too efficiently;

similar metaphors and concepts;

and supporting characters knowing exactly what the protagonist needs to hear.

The corrective question is:

> What does this person actually have access to?

---

## Correct conclusion, wrong process

A character may arrive at a true answer through reasoning that is implausibly strong.

The problem is not necessarily the conclusion.

It is the missing **epistemic path**.

This matters particularly in:

mystery;

thriller;

political fiction;

military fiction;

science fiction;

and strategy-heavy stories.

---

## Reader knowledge versus character knowledge

Dramatic irony depends on preserving this difference.

The reader may know the murderer.

The detective does not.

The reader may know two characters love each other.

Neither character understands it.

The reader may know a prophecy is being misinterpreted.

The characters may treat it as certainty.

Do not allow reader knowledge to seep backward into character behavior.

---

## Narrative intelligence versus character intelligence

The story itself may understand more than any character.

Theme, juxtaposition, structure, and irony can communicate truths that no character explicitly recognizes.

This is often preferable to giving characters implausible self-awareness.

---

# DOMAIN 7 — KNOWLEDGE LEDGER

For important long-form information, maintain a lightweight knowledge ledger.

A useful structure is:

### Fact
What objectively happened or is objectively true?

### Source
How could someone know it?

### Knows
Which characters know?

### Suspects
Who has partial evidence?

### Misunderstands
Who holds an incorrect model?

### Conceals
Who knows but hides it?

### Reader status
Does the reader know?

### Narrative status
Has the narration confirmed it?

### Transmission risk
How could it spread?

### Consequence
What changes if it becomes known?

This ledger is especially useful for:

mysteries;

politics;

romance misunderstandings;

war stories;

intrigue;

secret identities;

conspiracies;

and long web novels.

---

# DOMAIN 7 — POV PROFILE

For each major viewpoint, maintain a loose profile of:

### Perceptual access
What can they physically observe?

### Knowledge base
What education, culture, profession, and history shape them?

### Vocabulary access
What concepts and terms belong naturally to them?

### Biases
What do they tend to misread?

### Confidence
How certain are they about interpretations?

### Blind spots
What do they systematically fail to notice?

### Narrative distance
How closely does narration mirror their own consciousness?

### Memory tendencies
What kinds of experiences do they remember or avoid?

### Social assumptions
What do they take for granted?

### Interpretive style
Do they think in motives, systems, emotions, rules, stories, or physical evidence?

This profile should guide narration without turning every POV into a gimmick.

---

# DOMAIN 7 — PRACTICAL REVIEW LENS

When reviewing a POV passage, ask:

### 1. How does the character know this?

Trace the source.

### 2. Is this fact or interpretation?

Separate observation from conclusion.

### 3. Does the vocabulary belong to the viewpoint?

Check lived experience.

### 4. Has knowledge leaked from another scene?

Check distribution.

### 5. Is a secret being preserved honestly?

Avoid artificial withholding.

### 6. Has a revelation changed anything?

Track consequence.

### 7. Does the character know the plot?

Remove metafictional foresight unless intentional.

### 8. Could another POV interpret this differently?

Protect cognitive diversity.

### 9. Does narrative distance remain coherent?

Check narrator-character relationship.

### 10. Is uncertainty being handled intentionally?

Not everything should be known, but not everything should be vague either.

---

# DOMAIN 7 — CENTRAL REMINDER

Every character lives inside a partial reality.

They do not have access to the novel.

They have access to:

what they have seen;

what they have heard;

what they remember;

what they believe;

what they misunderstand;

what they suspect;

and what other people have chosen to tell them.

Therefore, before a character thinks, says, or acts on important information, ask:

> How do they know?

Then:

> How certain should they be?

> What might they be wrong about?

> What information are they missing?

> What would they notice because of who they are?

> What would remain invisible to them?

The goal is not ignorance.

The goal is **epistemic integrity**.

A strong novel allows different characters to inhabit different versions of the same world until experience, evidence, conflict, or revelation causes those versions to change.

That completes **Domain 7**. The source research particularly supports the need to separate model knowledge from character knowledge, protect epistemic boundaries, avoid information leakage, and preserve context-specific metaphors and concepts that actually belong to the character's lived world. 

**Remaining:**
1. Domain 8 — Relationships & Social World
2. Domain 9 — Scene Design & Dramatic Movement
3. Domain 10 — Pacing, Tension & Escalation
4. Domain 11 — Plot, Causality, Subplots & Payoff
5. Domain 12 — Continuity, World Logic & Embodied Reality
6. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 8 — Relationships & Social World**. The source material supports this strongly: it notes relationship resetting, secondary characters functioning as mechanisms for the protagonist, and important side characters remaining socially and psychologically thin despite elaborate surface description. 

# DOMAIN 8 — RELATIONSHIPS & SOCIAL WORLD

## Domain purpose

A relationship is not merely two character profiles placed beside each other.

It is a **shared history**.

Each relationship contains:

- expectations;
- assumptions;
- memories;
- habits;
- unresolved incidents;
- affection;
- distrust;
- obligations;
- power;
- status;
- private language;
- misunderstandings;
- patterns of conflict;
- and things each person believes about the other.

These elements change over time.

The same character should not necessarily behave identically with:

- a parent;
- a subordinate;
- a childhood friend;
- a rival;
- a stranger;
- a lover;
- an ex-partner;
- a frightened child;
- an employer;
- or someone they despise but must obey.

The wider social world matters as well.

People belong to:

- families;
- friendships;
- communities;
- professions;
- institutions;
- classes;
- religions;
- cultures;
- reputational networks;
- political structures;
- and informal systems of obligation.

A novel begins to feel artificially protagonist-centered when everyone exists primarily in relation to the main character.

The central distinction is:

> A cast is not the same as a social world.

And:

> A relationship should accumulate history rather than repeatedly restarting from its premise.

---

# RS-01 — INDEPENDENT SOCIAL MODELS

## Core principle

Characters should maintain their own incomplete models of other people.

They may believe they understand someone.

They may be partly right.

They may be completely wrong.

They may recognize one side of a person while missing another.

Two people can know the same character and hold radically different interpretations of them.

## Common drift

Generated characters often understand one another too accurately.

A supporting character recognizes:

the protagonist's hidden pain;

the real reason behind their anger;

their unspoken attraction;

their secret fear;

their moral worth;

or the psychological wound motivating their behavior.

The supporting character may then articulate this insight directly.

This creates a world where people are unusually good at reading one another.

## Why it may weaken fiction

Relationships lose uncertainty.

Characters become mirrors reflecting the protagonist's true interior state rather than independent interpreters.

Misunderstanding becomes something the story uses only when plot requires it rather than a natural feature of social life.

## Diagnostic questions

What does this person believe about the other?

What evidence produced that belief?

What have they never seen?

What do they misunderstand?

What traits do they exaggerate?

What do they fail to notice?

What part of their interpretation says more about themselves than about the person observed?

## Better direction

Maintain individual models.

For example, three characters might interpret the same protagonist as:

reckless;

brave;

desperate.

All three may have evidence.

Their conclusions reflect their own values as much as the protagonist's behavior.

## Valid exceptions

People sometimes understand each other extremely well.

Long-term friends, intimate partners, therapists, family members, or highly perceptive characters may accurately recognize hidden states.

Accuracy should emerge from relationship history and ability rather than narrative convenience.

## Long-form warning signs

Supporting characters repeatedly identify the protagonist's true motives.

People accurately interpret emotions from tiny gestures.

Misunderstandings resolve as soon as characters speak openly.

Most characters eventually converge on the narrator's interpretation of the protagonist.

## Revision considerations

Do not force misunderstanding simply to create drama.

The useful question is whether each interpretation belongs plausibly to the observer.

---

# RS-02 — RELATIONSHIP MEMORY

## Core principle

Relationships should remember what happened inside them.

An apology, betrayal, rescue, humiliation, shared secret, kiss, argument, sacrifice, joke, or broken promise may alter future interaction.

The effect may be large or small.

## Common drift

A relationship changes dramatically during one scene and then returns to its earlier state.

Examples include:

trust established, then forgotten;

intimacy deepened, then conversational distance resets;

conflict resolved, then the identical argument returns;

a betrayal occurs, but later cooperation feels unchanged;

characters share something deeply personal, yet subsequent interaction remains generic.

The source research identifies this kind of relationship reset as part of the larger long-form amnesia problem. 

## Why it may weaken fiction

Scenes lose consequence.

The relationship appears episodic rather than historical.

Readers begin to feel that emotional scenes exist for temporary effect rather than lasting development.

## Diagnostic questions

What changed between these people?

What does each person now expect differently?

What became easier?

What became harder?

What subject now carries additional meaning?

What new assumption exists?

What old assumption was damaged?

## Better direction

Let history appear through altered behavior.

After an argument, characters need not constantly mention the argument.

Instead:

a joke may no longer land;

someone may hesitate before asking for help;

physical familiarity may change;

one person may become more careful with a subject;

an old habit may acquire new tension.

## Valid exceptions

Relationships can regress.

People repeat patterns.

Some reconciliations fail.

Someone may consciously behave as though nothing happened.

That can be entirely believable when the story understands the regression.

## Long-form warning signs

The same emotional conflict reappears in nearly identical form.

Relationship milestones fail to affect later scenes.

Characters repeatedly rediscover feelings or boundaries they already established.

## Revision considerations

Do not turn relationship continuity into constant callbacks.

The strongest continuity often appears through changed expectation rather than explicit memory.

---

# RS-03 — UNEVEN INTIMACY

## Core principle

People rarely know one another equally well.

One character may understand another deeply while remaining largely unknown to them.

One may believe the relationship is intimate while the other considers it casual.

One may know someone's history but not their inner life.

## Common drift

Generated relationships often develop symmetrically.

Two characters:

trust each other equally;

understand each other equally;

become vulnerable at similar rates;

and recognize the same emotional significance at the same time.

## Why it may weaken fiction

Relationships become neat.

Real relational dynamics often contain mismatched:

investment;

knowledge;

dependency;

trust;

attraction;

admiration;

and expectations.

These asymmetries create tension and specificity.

## Diagnostic questions

Who knows more about whom?

Who depends more on the relationship?

Who believes they are closer?

Who is more emotionally invested?

Who has disclosed more?

Who possesses more power to leave?

Would both characters describe this relationship the same way?

## Better direction

Allow intimacy to develop at different speeds and in different dimensions.

A character may trust someone professionally but not emotionally.

Another may disclose personal information easily while refusing practical dependence.

## Valid exceptions

Some relationships genuinely develop with strong mutual symmetry.

The point is not to manufacture imbalance but to avoid assuming equality automatically.

## Long-form warning signs

Major relationship milestones occur simultaneously for both characters.

Both characters interpret the relationship identically.

Mutual understanding arrives too neatly.

## Revision considerations

Track each person's version of the relationship separately.

There is no requirement that those versions match.

---

# RS-04 — PRODUCTIVE MISUNDERSTANDING

## Core principle

Misunderstanding should arise from believable differences in:

knowledge;

expectation;

history;

culture;

language;

fear;

desire;

or interpretation.

## Common drift

Two opposite failures appear.

### Artificial misunderstanding

Characters fail to communicate something obvious solely to prolong the plot.

### Artificial understanding

Characters immediately interpret one another correctly because the story wants resolution.

## Why it may weaken fiction

The first makes characters frustratingly irrational.

The second makes them implausibly perceptive.

Both reveal plot machinery.

## Diagnostic questions

What exactly does each person believe?

Why is that belief reasonable from their position?

What information are they missing?

Would asking one obvious question resolve everything?

If so, why don't they ask it?

Is there a real emotional, social, cultural, or informational barrier?

## Better direction

Build misunderstanding from **partial truth**.

The strongest misunderstandings often make sense.

A character sees real evidence but interprets it through the wrong framework.

## Valid exceptions

Comedy may thrive on improbable misunderstanding.

Farce deliberately stretches communication failure.

Genre conventions may permit greater misunderstanding than realism would.

## Long-form warning signs

Conflicts survive only because characters refuse to say one simple sentence.

Or, conversely, nearly every misunderstanding disappears after one polished conversation.

## Revision considerations

Before extending a misunderstanding, ask whether both characters' behavior remains plausible.

---

# RS-05 — PROTAGONIST-VALIDATION RESTRAINT

## Core principle

Other characters should not automatically function as authorities confirming the protagonist's significance.

They may admire them.

They may recognize hidden qualities.

They may love them.

But not everyone needs to understand, praise, forgive, or validate the protagonist.

## Common drift

Supporting characters frequently:

recognize the protagonist's hidden goodness;

identify their suffering;

praise their unusual competence;

tell them they are stronger than they think;

forgive their mistakes quickly;

recognize their sacrifices;

or explain why their flaws are understandable.

Even antagonistic characters may eventually reveal respect.

## Why it may weaken fiction

The social world becomes emotionally organized around affirming the protagonist.

It reduces genuine disagreement.

It can also make the protagonist feel protected by the narrative.

## Diagnostic questions

Why does this person admire the protagonist?

What do they dislike?

What behavior do they interpret less generously?

Would they care about the protagonist's internal pain?

What interests matter more to them?

Who remains unconvinced?

## Better direction

Let other characters judge according to their own:

values;

interests;

limited knowledge;

experiences;

and biases.

A protagonist may have understandable motives and still hurt someone who does not forgive them.

A heroic act may impress one person and frighten another.

## Valid exceptions

Some stories intentionally surround the protagonist with strong admiration.

Wish-fulfillment, heroic romance, power fantasy, comedy, and certain serial genres may make validation part of the intended appeal.

The issue is not validation itself.

It is unconscious uniformity.

## Long-form warning signs

Supporting characters repeatedly tell the protagonist who they “really are.”

Critics of the protagonist are later shown to be ignorant or malicious.

Most emotionally intelligent characters eventually side with the protagonist.

## Revision considerations

Do not make everyone hostile merely to avoid validation.

The aim is independent judgment.

---

# RS-06 — SOCIAL OBLIGATIONS

## Core principle

Characters exist inside networks of obligation.

They may owe:

time;

money;

labor;

loyalty;

obedience;

care;

ritual;

secrecy;

or social performance

to people and institutions beyond the main plot.

## Common drift

Characters appear socially available whenever the protagonist needs them.

They can:

leave work;

abandon duties;

travel immediately;

spend unlimited time talking;

take major risks;

or ignore family and institutional commitments

without consequence.

## Why it may weaken fiction

The world feels staged.

Supporting characters appear to remain dormant until summoned by the plot.

Social reality loses pressure.

## Diagnostic questions

What obligations does this person have today?

Who expects something from them?

What happens if they fail?

Can they realistically leave?

What social role are they performing?

What obligations compete with the protagonist's request?

## Better direction

Allow ordinary obligation to create friction.

Someone may want to help but:

must work;

has children;

risks dismissal;

owes another person;

cannot be seen with the protagonist;

or simply has plans.

These constraints can make the world feel inhabited without requiring new plotlines.

## Valid exceptions

Some characters are genuinely unattached.

Some settings deliberately remove ordinary social structures.

Quest narratives may temporarily isolate casts from everyday obligation.

## Long-form warning signs

Important supporting characters are constantly available.

Nobody seems to have responsibilities outside the main story.

Institutions exist in worldbuilding but rarely constrain personal behavior.

## Revision considerations

Do not manufacture logistical obstacles constantly.

A few credible obligations can imply a much larger life.

---

# RS-07 — SECONDARY RELATIONSHIPS

## Core principle

Supporting characters may have meaningful connections to one another independent of the protagonist.

A social world becomes deeper when it contains lateral relationships.

## Common drift

The cast resembles a wheel:

the protagonist stands in the center;

every other character connects mainly to them.

Secondary characters rarely:

speak privately;

share history;

disagree;

help each other;

date;

compete;

work together;

or maintain loyalties independent of the protagonist.

## Why it may weaken fiction

The world feels protagonist-generated.

Side characters resemble satellites rather than people embedded in a community.

## Diagnostic questions

Which supporting characters know each other?

What history do they share?

Who dislikes whom?

Who contacts whom without involving the protagonist?

What alliances exist?

What relationship would continue if the protagonist vanished?

## Better direction

Develop only the lateral relationships that matter.

A few well-placed connections can radically enlarge the perceived world.

Two supporting characters having a history can change how a scene behaves without requiring an entire subplot.

## Valid exceptions

Highly isolated protagonists, survival stories, solitary adventures, narrow chamber pieces, and some first-person narratives may intentionally contain weak lateral networks.

## Long-form warning signs

Every supporting character is introduced through the protagonist.

Side characters vanish when not interacting with the protagonist.

No meaningful relationship exists between supporting cast members.

## Revision considerations

Do not create secondary relationships purely to simulate complexity.

Each should arise plausibly from the world.

---

# RS-08 — SOCIAL CONSEQUENCES

## Core principle

Actions can alter how others perceive and treat a character.

Reputation is part of causality.

## Common drift

A protagonist may:

insult authority;

break rules;

display extraordinary power;

commit violence;

save people;

fail publicly;

betray someone;

or cause scandal

without the broader social environment meaningfully updating.

The immediate scene reacts.

The world does not.

## Why it may weaken fiction

Events appear strangely private.

The world fails to remember what happens socially.

This reduces the sense that the protagonist occupies a populated reality.

## Diagnostic questions

Who witnessed this?

Who will hear about it?

Who benefits from spreading the story?

How accurately will it spread?

Whose opinion changes?

Does reputation create opportunities or obstacles?

Does an institution respond?

## Better direction

Let consequences spread unevenly.

Rumor may distort events.

One group may admire what another condemns.

A public victory may create enemies as well as allies.

## Valid exceptions

Some environments lack effective communication.

Secret actions may remain secret.

People may not care.

Not every event deserves a social reaction.

## Long-form warning signs

Characters repeatedly perform public extraordinary actions while remaining socially anonymous.

Reputation resets between locations.

Institutions fail to respond to events that should concern them.

## Revision considerations

Avoid turning every action into a reputation mechanic.

Focus on events whose social visibility and significance justify consequences.

---

# RS-09 — RELATIONSHIP-SPECIFIC LANGUAGE

## Core principle

People often speak differently depending on whom they are addressing.

Voice belongs partly to the speaker and partly to the relationship.

## Common drift

Character voice is treated as a fixed linguistic package.

A sarcastic character is sarcastic with:

their commander;

their grieving mother;

a frightened child;

their lover;

and a stranger

in essentially the same way.

## Why it may weaken fiction

Social intelligence disappears.

Relationships stop influencing language.

Character voice becomes a gimmick rather than adaptive behavior.

## Diagnostic questions

How safe does the character feel with this person?

Who has greater status?

How long have they known each other?

What history is being carried?

What can they say to this person that they cannot say elsewhere?

What do they hide specifically from them?

## Better direction

Preserve core character voice while allowing relational modulation.

A blunt person may still be blunt everywhere, but the form of bluntness can change.

A formal character may loosen only with one sibling.

A joking character may stop joking around one particular person.

## Valid exceptions

Some characters genuinely communicate similarly with everyone.

That itself can be characterization.

## Long-form warning signs

Characters use the same conversational style across every relationship.

Romantic, familial, professional, and adversarial interactions differ mainly in content.

## Revision considerations

Do not create a separate artificial voice for every pairing.

Look for a few relationship-specific adaptations.

---

# RS-10 — FRICTION PERSISTENCE

## Core principle

Not every relational problem needs immediate emotional clarification or repair.

Conflict can remain:

partially understood;

unresolved;

suppressed;

transformed;

or simply tolerated.

## Common drift

Generated fiction often moves relationships toward understanding.

After conflict:

someone explains;

the other person listens;

intentions become clear;

both recognize the deeper issue;

the relationship reaches a new equilibrium.

This is satisfying when earned.

Repeated constantly, it produces unusually healthy and efficient relationship repair.

## Why it may weaken fiction

Friction loses duration.

Characters become too willing to resolve emotionally difficult issues.

Long-term grudges, incompatible values, pride, shame, social pressure, and simple stubbornness receive too little influence.

## Diagnostic questions

Does either person actually want resolution?

What prevents repair?

Would understanding the motive actually remove the harm?

Has trust been damaged beyond what explanation can repair?

Are values fundamentally incompatible?

What remains even after an apology?

## Better direction

Allow conflict to leave residue.

Possible outcomes include:

partial reconciliation;

practical cooperation without trust;

forgiveness without restored intimacy;

understanding without agreement;

love alongside resentment;

or temporary peace.

## Valid exceptions

Some people resolve conflict well.

Healthy relationships can involve rapid repair.

Certain genres promise emotional restoration.

The system should not manufacture dysfunction.

## Long-form warning signs

Nearly every interpersonal conflict ends with increased understanding.

Apologies reliably restore relationships.

Characters rarely remain angry once motives are explained.

## Revision considerations

Do not prolong conflict merely for drama.

Persistence should have psychological or situational roots.

---

# DOMAIN 8 — CROSS-LENS GUIDANCE

## The protagonist-centered universe

A novel can become socially thin even with a large cast.

Signs include:

everyone knows the protagonist;

everyone's important decisions concern the protagonist;

supporting characters mostly talk about the protagonist;

other relationships exist only when relevant to the protagonist;

and independent conflicts vanish when the protagonist leaves.

The solution is not to create endless subplots.

The solution is to allow signs that **life continues sideways**.

---

## Social-world depth without exposition

A functioning social world can often be suggested through small facts:

someone is already late for another obligation;

two side characters have an inside joke;

a friend refuses help because of a family commitment;

someone knows a rumor the protagonist has not heard;

two colleagues disagree about a third person;

a character has plans that do not include the protagonist.

These small signals imply independent lives.

---

## Relationship reset

A recurring long-form failure is:

conflict;

emotional breakthrough;

temporary closeness;

reset;

same conflict again.

Repetition can be realistic.

People do repeat patterns.

The important question is whether repetition occurs **with history attached**.

The second argument should not feel identical to the first if both people remember the first.

---

## Validation networks

A cast can accidentally become a mechanism for continually confirming:

the protagonist is special;

the protagonist is misunderstood;

the protagonist is morally right;

the protagonist is more competent than others realize;

or the protagonist deserves love.

Validation may be central to some genres.

But where independent social realism matters, different characters should evaluate the protagonist according to their own concerns.

---

## Mind-reading relationships

Close characters may understand one another very well.

But intimacy does not grant perfect psychological access.

A partner may know someone's habits intimately and still fundamentally misunderstand why they act a certain way.

Long familiarity can sometimes create **more confident misinterpretation**, not less.

---

## Conflict is not always miscommunication

Generated stories can treat conflict as a problem of insufficient explanation.

Sometimes both characters understand each other perfectly and still disagree.

They may want incompatible things.

They may hold incompatible values.

One person's gain may genuinely be another person's loss.

No amount of better communication automatically removes that conflict.

---

# DOMAIN 8 — RELATIONSHIP STATE MODEL

For significant relationships, track a lightweight shared state.

This is not meant for prose insertion.

It is an internal continuity aid.

Useful dimensions include:

### History
What significant experiences do they share?

### Current trust
How much does each trust the other?

These values may differ.

### Intimacy
What does each know about the other?

### Dependence
What does each need from the other?

### Power
Who has more social, physical, financial, institutional, emotional, or informational leverage?

### Affection
What positive attachment exists?

### Friction
What unresolved problems remain?

### Assumptions
What does each think the other believes or wants?

### Misunderstandings
Where are those assumptions wrong?

### Obligations
What does each owe or believe they owe?

### Boundaries
What will they not discuss, permit, forgive, or reveal?

### Shared language
What jokes, references, nicknames, rituals, or habits belong specifically to them?

### Recent change
What has altered since their last meaningful interaction?

---

# DOMAIN 8 — SOCIAL-WORLD MODEL

The wider social world can be thought of through overlapping networks.

### Family
Blood, adoption, marriage, chosen family.

### Friendship
Close friends, casual friends, old friends, estrangements.

### Work
Colleagues, bosses, employees, rivals, clients.

### Community
Neighbors, religious groups, clubs, villages, online spaces, guilds.

### Institutions
Government, school, military, corporation, church, court, criminal organization.

### Status
Class, wealth, fame, rank, reputation, legitimacy.

### Obligation
Debt, loyalty, law, tradition, favor, care.

### Information
Who talks to whom?

Where do rumors move?

### Conflict
What factions or interpersonal tensions exist independently of the protagonist?

### Dependence
Who needs whom?

A novel need not explicitly develop every category.

The model simply reminds the writer that characters exist inside systems larger than the central plot.

---

# DOMAIN 8 — SOCIAL CAUSALITY

For socially visible actions, consider the chain:

**action → witness → interpretation → transmission → reputation → response**

Each stage can distort the previous one.

For example:

The protagonist publicly kills a dangerous man.

One witness sees necessary self-defense.

Another sees murder.

One tells the story accurately.

Another exaggerates it.

A local authority hears the distorted version.

A rival deliberately amplifies it.

The protagonist's reputation changes in ways they did not control.

This creates a world in which social consequences have their own causality.

---

# DOMAIN 8 — RELATIONSHIP DEVELOPMENT

Relationship development should not automatically mean increasing closeness.

Relationships can develop through:

greater trust;

greater distrust;

familiar hostility;

dependency;

mutual respect;

fear;

resentment;

professional efficiency;

sexual tension;

emotional distance;

obligation;

forgiveness;

estrangement;

or complicated mixtures.

Movement matters more than direction.

A rivalry can become deeper without becoming friendship.

A romance can become more intimate while also becoming less healthy.

A friendship can survive while trust weakens.

---

# DOMAIN 8 — PRACTICAL REVIEW LENS

When reviewing relationships and social-world material, ask:

### 1. Does each person hold their own model of the other?

Avoid perfect mutual understanding.

### 2. Does the relationship remember?

Check accumulated history.

### 3. Is intimacy appropriately uneven?

Track different perceptions of closeness.

### 4. Are misunderstandings causally believable?

Avoid both artificial stupidity and artificial mind-reading.

### 5. Is the protagonist being continually validated?

Check independent judgment.

### 6. Do characters have obligations elsewhere?

Protect independent lives.

### 7. Do supporting characters relate to one another?

Check lateral networks.

### 8. Do socially visible actions produce plausible consequences?

Protect reputation and institutional response.

### 9. Does speech change by relationship?

Protect relational specificity.

### 10. Is conflict resolving too automatically?

Preserve friction where justified.

---

# DOMAIN 8 — CENTRAL REMINDER

Relationships are not static labels.

“Friend.”

“Enemy.”

“Brother.”

“Mentor.”

“Love interest.”

“Rival.”

These labels describe only the broadest category.

The actual relationship consists of:

what happened between them;

what each remembers;

what each believes;

what each misunderstands;

what each wants;

what each owes;

what each fears losing;

what each refuses to say;

and what has changed since the last time they met.

Likewise, a character does not stop existing when they leave the protagonist's scene.

They continue to have:

responsibilities;

relationships;

problems;

opinions;

and competing priorities.

Therefore ask:

> What version of this relationship does each character believe they are in?

> What history is present even when nobody mentions it?

> What does this person want that has nothing to do with the protagonist?

> What other relationships influence this one?

> What social consequences can travel beyond the scene?

The goal is not maximum social complexity.

The goal is a world in which **people feel connected to one another rather than generated around the protagonist**.

That completes **Domain 8**. It directly addresses two major source-supported long-form complaints: relationships reverting to baseline after meaningful developments, and supporting characters behaving like mechanisms that arrive to encourage, explain, praise, obstruct, or validate the protagonist rather than people with independent lives. 

**Remaining:**
1. Domain 9 — Scene Design & Dramatic Movement
2. Domain 10 — Pacing, Tension & Escalation
3. Domain 11 — Plot, Causality, Subplots & Payoff
4. Domain 12 — Continuity, World Logic & Embodied Reality
5. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 9 — Scene Design & Dramatic Movement**. This domain is crucial because the research repeatedly identifies scene-level problems as deeper than surface prose: conversations that go nowhere, scenes repeating the same function, excessive introspection, poor information prioritization, and large amounts of activity without meaningful movement. 

# DOMAIN 9 — SCENE DESIGN & DRAMATIC MOVEMENT

## Domain purpose

A scene is not merely a container in which characters talk, move, think, or receive information.

A scene is a **unit of change, experience, pressure, discovery, or deepening**.

That change does not need to be dramatic.

A scene may:

- alter a relationship;
- change what someone knows;
- establish a pattern;
- deepen atmosphere;
- create suspicion;
- complicate a goal;
- reveal character;
- introduce a constraint;
- shift emotional state;
- create a promise;
- delay action;
- increase uncertainty;
- or simply make the reader experience something important.

The central question is not:

> Does something happen?

A great deal can happen while nothing meaningfully changes.

The more useful question is:

> What is different because this scene exists?

This does not mean every scene needs a twist, confrontation, revelation, or explicit goal.

Quiet scenes can have enormous dramatic value.

The system should therefore distinguish **movement** from **busyness**.

---

# SC-01 — SCENE PURPOSE

## Core principle

A scene should usually have a meaningful reason to exist within the larger work.

Its purpose may involve:

- plot;
- character;
- relationship;
- theme;
- atmosphere;
- worldbuilding;
- tension;
- setup;
- payoff;
- contrast;
- recovery;
- or reader pleasure.

Many strong scenes perform several functions at once.

## Common drift

Generated prose can produce plausible scenes because the preceding event suggests them.

Characters travel.

They discuss what happened.

They eat.

They plan.

They encounter another problem.

They talk about their feelings.

Each scene makes local sense, but the novel gradually accumulates material without enough narrative necessity.

## Why it may weaken fiction

The story becomes episodically competent but globally loose.

Readers may experience:

- filler;
- repetitive conversations;
- stalled plot;
- diluted emotional impact;
- or a sense that scenes could be removed without affecting the novel.

This directly connects to the source research's observation that AI fiction may remain locally fluent while failing to understand why a scene exists. 

## Diagnostic questions

Why does this scene deserve narrative space?

What does the reader gain from experiencing it directly?

What would be lost if it were summarized?

What would be lost if it disappeared entirely?

Does it perform a function already handled by another scene?

Is its purpose specific enough?

## Better direction

Before expanding a scene, understand its dominant contribution.

Examples:

- reveal the cost of the protagonist's earlier decision;
- show two allies becoming less comfortable with each other;
- let the reader experience the city before it is destroyed;
- plant a misleading but fair clue;
- create a temporary sense of safety before escalation;
- demonstrate the protagonist succeeding with an old strategy before that strategy begins failing.

Purpose need not become formula.

It simply creates intentionality.

## Valid exceptions

Slice-of-life, literary, contemplative, comic, episodic, experimental, and atmosphere-driven fiction may contain scenes whose value is largely experiential.

Pleasure, texture, humor, beauty, or companionship can be sufficient purpose.

## Long-form warning signs

Several scenes could be exchanged in order without affecting the story.

Characters repeatedly discuss events the reader already understands.

Scenes exist mainly because “this would logically happen next.”

Travel and downtime automatically become fully dramatized.

## Revision considerations

Do not remove a scene merely because it does not advance plot.

Ask whether it advances **the experience of the novel**.

---

# SC-02 — STATE CHANGE

## Core principle

Many scenes become stronger when something about the story's state changes between entry and exit.

Possible changes include:

- knowledge;
- intention;
- relationship;
- power;
- risk;
- emotional condition;
- resources;
- location;
- commitment;
- expectation;
- suspicion;
- opportunity;
- or interpretation.

## Common drift

A scene contains:

dialogue;

description;

internal thought;

and perhaps conflict,

yet ends with essentially the same state with which it began.

Characters discuss a problem without changing their understanding.

Two people argue without altering the relationship.

A threat occurs but creates no future consequence.

## Why it may weaken fiction

The novel produces events without accumulation.

This is closely related to the research complaint that conversations can be polished while “nothing materially changes.” 

## Diagnostic questions

What is different after this scene?

Who knows something new?

Who wants something different?

What becomes easier?

What becomes harder?

What relationship has shifted?

What new obligation exists?

What assumption has been damaged?

## Better direction

Think of scenes as transformations:

**before-state → pressure/interaction → after-state**

The change can be microscopic.

A character who trusted someone completely may now possess one small doubt.

That may be enough.

## Valid exceptions

Some scenes deliberately reinforce stability.

A ritual repeated unchanged can show resistance to change.

A peaceful scene can demonstrate that nothing has yet disturbed a fragile equilibrium.

The lack of state change can itself be meaningful when intentional.

## Long-form warning signs

Multiple scenes begin and end with the same conflict unresolved in the same way.

Emotional discussions repeatedly return to baseline.

Action scenes create spectacle but few lasting consequences.

## Revision considerations

Do not manufacture a twist into every scene.

Small directional movement is often sufficient.

---

# SC-03 — SCENE-SHAPE VARIATION

## Core principle

Scenes should not all use the same dramatic architecture unless repetition is deliberately part of the work.

## Common drift

Generated stories may repeatedly produce:

setup;

minor tension;

dialogue or confrontation;

emotional articulation;

mini-resolution;

closing reflective sentence.

Another recurring structure is:

arrival;

description;

conversation;

revelation;

reaction;

departure.

The content changes, but the shape does not.

## Why it may weaken fiction

The reader begins predicting the rhythm of scenes.

The novel feels modular.

Even different emotional situations begin producing the same dramatic experience.

## Diagnostic questions

How did the previous few scenes begin?

Where did they place their turning points?

How did they end?

Did they all contain confrontation?

Did they all culminate in realization?

Did they all close with partial resolution?

Could this scene work through another dramatic form?

## Better direction

Allow scenes to have different shapes.

A scene may:

begin after the argument has already started;

contain no explicit conflict;

end before the central question is answered;

consist largely of observation;

produce a decision without discussion;

begin with apparent safety and end in uncertainty;

or resolve quickly but create a larger problem.

## Valid exceptions

Highly episodic structures, procedural fiction, sitcom-like narratives, quest serials, and certain web novels may deliberately employ recurring scene forms.

Repetition can create reader comfort.

## Long-form warning signs

Every important scene contains a mini-arc.

Every confrontation ends with emotional insight.

Most scenes reach a neat stopping point before transition.

## Revision considerations

Do not vary scene shape randomly.

Let form emerge from what the scene actually needs.

---

# SC-04 — ENTRY TIMING

## Core principle

A scene should generally begin at the point that best serves its function.

This is not always the earliest chronological moment.

## Common drift

Generated scenes often begin with logistical completion:

characters arrive;

enter;

look around;

greet one another;

sit down;

exchange pleasantries;

then finally reach the meaningful material.

This can happen because the model naturally generates the connective steps between events.

## Why it may weaken fiction

Narrative energy is spent before the scene becomes useful.

Repeated arrival routines can make chapters feel slow even when the plot itself is active.

## Diagnostic questions

Where does the meaningful pressure begin?

Do readers need to witness the arrival?

Is orientation necessary?

Would entering later create confusion?

Is the setup itself important to atmosphere or characterization?

Could the scene begin closer to the first meaningful choice, question, or disturbance?

## Better direction

Enter as early as needed—but no earlier merely from habit.

Possible entries include:

mid-conversation;

immediately before a decision;

after an argument has already begun;

during an apparently ordinary activity that becomes significant;

or well before conflict if anticipation itself matters.

## Valid exceptions

Arrival can be the point.

Entering a sacred city for the first time may deserve pages.

A reunion may gain power from watching characters approach one another.

A horror scene may depend on a slow walk toward danger.

## Long-form warning signs

New scenes repeatedly begin with waking, traveling, entering, sitting, ordering, or greeting.

Readers regularly wait several paragraphs before discovering why the scene matters.

## Revision considerations

Do not use “enter late” as a mechanical command.

Some scenes need runway.

The question is whether the runway contributes.

---

# SC-05 — EXIT TIMING

## Core principle

A scene should end when continuing no longer improves its intended effect.

The scene does not have to complete every emotional, informational, or practical consequence before ending.

## Common drift

Generated scenes tend toward completion.

After the important event:

characters explain what it means;

clarify remaining feelings;

summarize next steps;

resolve minor confusion;

leave the location;

and conclude with reflection.

The model often wants to close the loop.

## Why it may weaken fiction

Scenes overstay their strongest moment.

The most powerful line or action can be diluted by subsequent explanation.

Continuous closure also contributes to overly neat scene architecture.

## Diagnostic questions

Where is the strongest possible exit?

Has the scene already accomplished its main function?

Are the remaining lines adding new material or merely processing what happened?

Could consequences be carried into the next scene?

Would an unresolved ending create productive momentum?

## Better direction

A scene may end:

on a decision;

on a question;

after a revelation;

before an answer;

on an image;

on an action;

on a failure;

on silence;

or after necessary decompression.

The best exit depends on intended effect.

## Valid exceptions

Some scenes need emotional aftermath.

A chapter ending immediately after every dramatic line can become just as artificial as overexplaining.

## Long-form warning signs

Every scene contains a reflective tail.

Important conversations continue until everyone understands their position.

Scenes routinely show characters leaving after the meaningful interaction is complete.

## Revision considerations

When trimming an ending, ensure necessary causal information survives somewhere.

---

# SC-06 — INTERNAL PROGRESSION

## Core principle

A scene should usually develop internally rather than sustain one unchanged note.

Progression can occur through:

- new information;
- changed strategy;
- emotional movement;
- increased pressure;
- reversal;
- interruption;
- physical change;
- misunderstanding;
- or deepening commitment.

## Common drift

A scene establishes one condition and keeps reproducing it.

An angry argument remains angry.

A frightening chase remains frightened.

A romantic conversation remains tender.

A planning scene remains analytical.

Several paragraphs may differ superficially without changing the underlying dynamic.

## Why it may weaken fiction

Scenes become emotionally or dramatically flat despite active prose.

Readers may understand the scene long before it ends.

## Diagnostic questions

What changes inside the scene?

When does the interaction become different from how it began?

Does someone alter strategy?

Does new information change interpretation?

Does emotional intensity move?

Does the environment interfere?

Is the scene merely maintaining its initial premise?

## Better direction

Allow the scene's internal logic to evolve.

An interrogation may begin controlled, become cooperative, then reveal manipulation.

A romantic dinner may begin awkward, become easy, then expose an old wound.

An action scene may shift from escape to rescue.

## Valid exceptions

Sustained states can be powerful.

A long oppressive silence may remain oppressive.

A siege may intentionally produce exhaustion through repetition.

## Long-form warning signs

Scenes can be summarized accurately after their first few paragraphs.

The same emotion or conflict remains dominant without complication.

## Revision considerations

Do not force multiple reversals into every scene.

One meaningful change in dynamic may be enough.

---

# SC-07 — COMPETING PRESSURES

## Core principle

Scenes often become richer when characters must respond to more than one concern at once.

People rarely experience life as a single isolated dramatic objective.

## Common drift

Generated scenes may become too pure in function.

A romance scene is only romantic.

A planning scene is only strategic.

A grief scene is only grief.

A political scene is only politics.

Everything in the scene reinforces the dominant purpose.

## Why it may weaken fiction

Scenes feel designed rather than lived.

Characters have no competing obligations or contradictory priorities.

The social and physical world disappears behind the scene's designated function.

## Diagnostic questions

What else matters to the characters right now?

What practical pressure exists?

Is someone hiding something while pursuing another goal?

Does social context constrain behavior?

Is the environment creating a secondary concern?

Does one character think the scene is about something different?

## Better direction

Layer pressures naturally.

A breakup may occur while both people must remain quiet because someone is sleeping nearby.

A political negotiation may happen between former lovers.

A rescue may require preserving evidence.

A reunion may occur while one person is late for another obligation.

## Valid exceptions

Some scenes benefit from singular focus.

A moment of concentrated grief or intimacy may become more powerful when other concerns temporarily disappear.

## Long-form warning signs

Scenes feel categorized by one emotion or one function.

Characters conveniently forget outside obligations during important moments.

## Revision considerations

Do not add arbitrary complications.

Secondary pressures should arise from established reality.

---

# SC-08 — ENVIRONMENTAL CONSEQUENCES

## Core principle

Scenes happen somewhere, and location can affect what is possible.

Environment is not merely visual framing.

## Common drift

Characters behave almost identically whether they are:

in public;

alone;

in danger;

in a crowded room;

outdoors in freezing weather;

inside a moving vehicle;

or standing in the aftermath of destruction.

The conversation or dramatic exchange appears to occur inside a narrative vacuum.

## Why it may weaken fiction

Scene embodiment weakens.

Setting becomes decoration rather than a source of constraints and opportunities.

## Diagnostic questions

What can characters physically do here?

Who can hear them?

What can interrupt them?

What does the environment require?

What is uncomfortable?

What is dangerous?

What can be used?

How does the location affect social behavior?

## Better direction

Allow setting to shape the scene.

A public restaurant may prevent open confrontation.

A storm may shorten dialogue.

A crowded train may create unwanted intimacy.

A damaged building may force characters to keep moving while talking.

## Valid exceptions

Some settings are intentionally neutral.

The narrative may also abstract away physical detail to foreground dialogue or thought.

## Long-form warning signs

Important conversations could occur in almost any location unchanged.

Characters ignore weather, privacy, crowding, or physical danger.

## Revision considerations

One or two material constraints are often enough.

Do not overload every scene with environmental interference.

---

# SC-09 — SCENE-SPECIFIC ATTENTION

## Core principle

Different scenes should allocate narrative attention differently according to their purpose.

The balance among:

- action;
- dialogue;
- thought;
- description;
- exposition;
- memory;
- and summary

does not need to remain constant.

## Common drift

Generated prose may apply one stable mixture to every scene.

A dialogue scene repeatedly interrupts for interior analysis.

An action scene repeatedly pauses for description.

A quiet scene still receives frequent dramatic reactions.

The same narrative processing style follows every event.

## Why it may weaken fiction

Scene identity weakens.

Different forms of experience become homogenized.

The prose starts feeling as though it is applying a standard template to all content.

## Diagnostic questions

What deserves the most attention in this scene?

What can remain background?

Does internal thought need this much space?

Is the physical action sufficiently clear?

Is description interrupting momentum?

Would summary better handle part of this scene?

## Better direction

Allocate attention according to what matters now.

A confession may need dialogue and silence.

A chase may need space, motion, and rapid decision.

A ritual may need sensory detail.

A discovery may need careful observation.

## Valid exceptions

A strong narrative voice may maintain a consistent balance by design.

## Long-form warning signs

Every scene contains comparable proportions of dialogue, description, thought, and emotional interpretation.

The same narrative texture persists regardless of content.

## Revision considerations

Do not chase arbitrary variety.

Ask what this scene wants the reader to experience most directly.

---

# SC-10 — NON-RESOLUTION

## Core principle

A scene does not have to resolve the problem it contains.

It may instead:

- worsen it;
- complicate it;
- redirect it;
- expose a deeper problem;
- postpone it;
- produce false resolution;
- or change what the problem means.

## Common drift

Generated scenes often seek helpful completion.

A conflict produces explanation.

Explanation produces understanding.

Understanding produces compromise.

A question produces an answer.

A fear produces reassurance.

This reflects the broader tendency toward tidy emotional and narrative closure identified throughout the research.

## Why it may weaken fiction

Long-term tension collapses too quickly.

Conflicts lack persistence.

Scenes become self-contained instead of contributing to larger arcs.

## Diagnostic questions

Does this problem actually need resolution now?

Would these characters be capable of resolving it?

What remains after they understand each other?

Could one problem be solved while another is created?

Could the apparent solution later prove incomplete?

## Better direction

Allow scenes to end in different states.

Examples:

understanding without forgiveness;

agreement without trust;

victory with new cost;

answer with larger question;

temporary cooperation;

misunderstanding deepened;

partial solution.

## Valid exceptions

Closure is valuable.

Some scenes should resolve cleanly.

Mysteries require answers.

Romance often promises relational payoff.

Comedy frequently benefits from decisive release.

The system should not fetishize unresolved tension.

## Long-form warning signs

Most conflicts close in the same scene in which they become explicit.

Emotional confrontation routinely produces mutual understanding.

Scenes operate like complete short stories rather than parts of a novel.

## Revision considerations

Do not prolong everything.

Resolution should occur when earned and useful.

The question is whether the timing belongs to the story.

---

# DOMAIN 9 — CROSS-LENS GUIDANCE

## Activity versus movement

A useful distinction:

**Activity** means things occur.

**Movement** means the story state changes.

A scene can contain:

a fight;

an argument;

a chase;

a confession;

a magical attack;

and still produce little movement if everyone ends in roughly the same position.

Conversely, a scene containing two people quietly drinking tea may permanently alter their relationship.

The model should therefore ask:

> What changed, not merely what happened?

---

## The repeated-function problem

Two scenes can look completely different while performing the same function.

For example:

Scene A: the protagonist argues with a mentor and is told to trust themselves.

Scene B: the protagonist speaks to a friend and is told they underestimate themselves.

Scene C: the protagonist defeats an enemy who tells them they are stronger than they realize.

Surface events differ.

Narrative function repeats:

**validate protagonist's self-worth.**

This is the kind of repetition that superficial word-frequency checks will miss.

---

## Scene-level emotional paraphrasing

Just as sentences can restate the same emotion, scenes can restate the same dramatic conclusion.

One scene proves:

she does not trust him.

The next shows:

she still does not trust him.

The next discusses:

why she cannot trust him.

Unless something meaningfully changes, the novel is paraphrasing itself at scene scale.

---

## The mini-resolution habit

A common AI-generated scene shape is:

problem;

discussion;

insight;

softened emotion;

closing line.

This is satisfying locally.

Across an entire novel it can destroy long-range tension because every scene cleans up after itself.

Some scenes should leave **debris**.

---

## Scene isolation

Another warning sign is when each scene works individually but poorly affects the next.

A strong scene should often create conditions that another scene inherits.

That inheritance may involve:

new information;

new mood;

new injury;

new suspicion;

new obligation;

changed relationship;

or changed practical circumstances.

Scenes should communicate with one another through consequence.

---

## Transition as causality

Scene transitions are not merely connective tissue.

The question is not only:

> What happens next?

It is:

> Why does this next scene follow from what just happened?

Chronological sequence is weaker than causal sequence.

---

# DOMAIN 9 — SCENE STATE MODEL

For important scenes, a lightweight scene state can help.

### Entry state

What do the characters know?

What do they want?

What is the relationship state?

What pressure already exists?

What practical conditions apply?

### Scene purpose

Why are we experiencing this directly?

### Active pressures

What does each participant want?

What external constraints operate?

### Turn

What changes the direction or meaning of the scene?

Not every scene requires one dramatic turn, but most significant scenes contain some shift.

### Exit state

What is different?

### Residue

What does the next scene inherit?

This should remain a planning and auditing tool.

It should not force scenes into formula.

---

# DOMAIN 9 — SCENE DIFFERENCE TEST

When several scenes appear near one another, compare them across:

### Function
What does each contribute?

### Structure
How does each unfold?

### Dominant mode
Dialogue? Action? Observation? Thought?

### Emotional direction
What movement occurs?

### Conflict type
Internal? Interpersonal? Environmental? Strategic?

### Setting
How does location affect behavior?

### Outcome
Resolution? Complication? Failure? Discovery?

### Reader experience
Suspense? Relief? Humor? Intimacy? Horror? Awe?

If too many categories repeat mechanically, consider whether the scenes are genuinely distinct.

---

# DOMAIN 9 — SCENE NECESSITY TEST

Before fully dramatizing a scene, consider four options:

### Full scene

Use when the reader benefits from experiencing events moment by moment.

### Partial scene

Dramatize only the important portion.

### Summary

Use when the event matters but its moment-by-moment experience does not.

### Omission

Skip entirely when neither the event nor its consequences require direct attention.

Generated fiction can overproduce full scenes because generating continuous prose is easy.

Narrative judgment requires deciding what **not** to dramatize.

---

# DOMAIN 9 — PRACTICAL REVIEW LENS

When reviewing a scene, ask:

### 1. Why does this scene exist?

Identify purpose.

### 2. What changes?

Identify state movement.

### 3. Is this structurally too similar to nearby scenes?

Check scene shape.

### 4. Did we enter too early?

Inspect setup.

### 5. Did we leave too late?

Inspect explanatory aftermath.

### 6. Does the scene internally develop?

Check movement rather than sustained tone.

### 7. Are several pressures operating where appropriate?

Avoid overly pure scene function.

### 8. Does the environment matter?

Protect embodiment.

### 9. Is attention allocated correctly?

Prioritize what the reader needs to experience.

### 10. Does the scene resolve too neatly?

Consider whether consequence should continue.

### 11. What does the next scene inherit?

Protect accumulation.

---

# DOMAIN 9 — CENTRAL REMINDER

A scene should not exist merely because it is plausible.

Many things are plausible.

A novel selects.

Therefore ask:

> Why this scene?

> Why now?

> Why experience it directly?

> What changes while it happens?

> What survives after it ends?

The goal is not to make every scene dramatic.

The goal is not to make every scene efficient.

The goal is not to force every scene through a rigid structure.

The goal is **narrative consequence and purposeful experience**.

A quiet scene can matter enormously.

An explosive scene can matter very little.

The measure is not spectacle.

It is what the novel becomes capable of because the scene occurred.

That completes **Domain 9**. The strongest source support here is the research's repeated distinction between local fluency and global narrative purpose, its identification of scene-function repetition, conversations without movement, and the broader problem of a story producing many events without continuously accumulating meaning. 

**Remaining:**
1. Domain 10 — Pacing, Tension & Escalation
2. Domain 11 — Plot, Causality, Subplots & Payoff
3. Domain 12 — Continuity, World Logic & Embodied Reality
4. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 10 — Pacing, Tension & Escalation**. The research shows why this needs its own domain: readers report apparently contradictory pacing failures—too fast, too slow, too much filler, too much summary, constant action, yet little actual movement. Those complaints coexist because **event frequency is not the same thing as narrative progression**. 

# DOMAIN 10 — PACING, TENSION & ESCALATION

## Domain purpose

Pacing is not simply how quickly events happen.

It is the relationship between:

- narrative time;
- story time;
- reader attention;
- information;
- emotional processing;
- expectation;
- consequence;
- tension;
- and change.

A novel can contain explosions, revelations, arguments, fights, betrayals, and deaths while still feeling slow if these events do not alter the story in meaningful ways.

Conversely, a quiet conversation can feel fast because every exchange changes what the reader understands.

The source research repeatedly identifies exactly this paradox: AI-heavy fiction may contain constant activity while producing little accumulated movement. 

The goal of this domain is not:

> Make the story faster.

Nor is it:

> Keep tension high.

The goal is:

> Give the story enough variation in speed, pressure, consequence, anticipation, and release that important events can acquire the weight they deserve.

The central distinctions are:

> Speed is not pacing.

> Activity is not movement.

> Intensity is not tension.

> Escalation is not simply “something bigger happens.”

And:

> Slowness is not automatically a flaw.

---

# PC-01 — VARIABLE NARRATIVE SPEED

## Core principle

Narrative time should be flexible.

A novel can spend:

three pages on ten seconds;

one paragraph on three months;

half a chapter on a conversation;

one sentence on a routine journey.

The amount of narrative space given to an event should depend on what the reader benefits from experiencing.

## Common drift

Generated fiction often operates at a relatively stable narrative speed.

Events that deserve compression receive full scenes.

Important moments move too quickly because the model keeps advancing.

Routine transitions receive too much detail.

Alternatively, the prose suddenly summarizes crucial developments that readers would have benefited from experiencing directly.

## Why it may weaken fiction

Uniform speed weakens hierarchy.

If every event receives similar narrative treatment, the reader cannot easily feel the difference between:

routine;

transition;

development;

turning point;

and climax.

## Diagnostic questions

Does the reader need to experience this moment-by-moment?

Could this be summarized?

Would slowing down increase emotional or dramatic impact?

Would compression preserve everything important?

Is the current speed arising from narrative need or simply from the model's default scene-writing mode?

## Better direction

Use multiple temporal modes.

### Scene

Experience events relatively directly.

### Summary

Compress less important periods.

### Pause

Temporarily suspend external progression for attention, thought, atmosphere, or description.

### Ellipsis

Skip time that does not require narration.

### Expansion

Give unusually large narrative space to a brief but significant moment.

Pacing emerges partly from shifting among these modes.

## Valid exceptions

Some works intentionally maintain stable narrative speed.

Real-time stories, tightly structured thrillers, stream-of-consciousness novels, and particular experimental forms may deliberately constrain temporal variation.

## Long-form warning signs

Every journey becomes a scene.

Every meal becomes a scene.

Important conversations receive roughly the same amount of space as minor ones.

Routine events occupy large proportions of the manuscript.

Major transitions happen through brief summary despite deserving dramatic experience.

## Revision considerations

Do not compress material merely because it lacks plot advancement.

Atmosphere, intimacy, humor, and ordinary life can justify narrative space.

The question is what the reader gains from experiencing the duration.

---

# PC-02 — TENSION MODULATION

## Core principle

Tension becomes meaningful partly through variation.

A novel does not need to remain at maximum pressure.

Tension can:

rise;

hold;

drop;

transform;

move into another form;

temporarily disappear;

or become latent.

## Common drift

Generated stories may attempt to keep every scene engaging by maintaining constant dramatic pressure.

Every conversation contains tension.

Every silence is charged.

Every journey contains danger.

Every chapter ends with implication.

Every emotional exchange matters intensely.

This connects to the research complaint that AI narration often fails to distinguish levels of significance, making everything feel emphasized. 

## Why it may weaken fiction

Continuous tension can become emotionally flat.

The reader adapts.

Without lower-pressure material, high-pressure material has less contrast.

Constant danger can also reduce credibility.

## Diagnostic questions

What kind of tension exists here?

How intense should it be?

Has the story been operating under similar pressure for too long?

Would relief strengthen the next escalation?

Can tension transform rather than simply increase?

Does this scene actually need tension?

## Better direction

Think in waves rather than a permanently rising line.

A sequence might move through:

danger;

temporary safety;

unease;

discovery;

relief;

new uncertainty;

serious threat.

Different forms of tension may overlap.

## Valid exceptions

Some horror, survival, thriller, tragedy, and siege narratives deliberately sustain prolonged pressure.

Even there, micro-variation often prevents monotony.

## Long-form warning signs

Every chapter attempts to end dramatically.

Characters rarely experience ordinary life.

Minor scenes contain the same emotional pressure as major confrontations.

Tension vocabulary remains constant even when circumstances change.

## Revision considerations

Do not insert calm scenes simply because a formula says the reader needs a break.

Relief should arise naturally from the situation.

---

# PC-03 — EARNED ESCALATION

## Core principle

Escalation should usually grow from the existing story rather than merely increasing scale.

Stronger escalation often involves greater:

- cost;
- commitment;
- risk;
- consequence;
- personal relevance;
- moral difficulty;
- irreversibility;
- or conflict among goals.

## Common drift

Generated plots may escalate by introducing:

stronger enemies;

larger armies;

bigger explosions;

more powerful magic;

greater conspiracies;

more shocking betrayals;

more dangerous threats.

The scale increases while the underlying dramatic problem remains unchanged.

## Why it may weaken fiction

Escalation becomes numerical.

Readers may experience spectacle inflation.

Each new threat must become larger than the previous one, eventually producing absurdity or emotional detachment.

## Diagnostic questions

What makes this development more difficult than the previous one?

Is the increase merely physical scale?

Does the escalation arise from an earlier choice?

Has something become more personally costly?

Are the available options narrowing?

Does the character now risk something different rather than merely more?

## Better direction

Escalate through consequence.

For example:

The first problem threatens survival.

The second forces the protagonist to compromise a value.

The third makes success itself harmful to someone they love.

The physical scale may remain the same while dramatic pressure intensifies.

## Valid exceptions

Power fantasy, progression fantasy, epic fantasy, superhero fiction, kaiju stories, military epics, and action serials may legitimately derive pleasure from increasing scale.

Even there, scale works best when accompanied by meaningful consequence.

## Long-form warning signs

Every arc introduces a stronger version of the previous antagonist.

Threats become increasingly enormous without becoming more personally significant.

Power increases faster than complication.

## Revision considerations

Ask whether the next conflict needs to be **larger** or merely **harder in a different way**.

---

# PC-04 — RECOVERY SPACE

## Core principle

Characters and readers may need intervals in which pressure changes.

Recovery does not necessarily mean nothing happens.

Lower-pressure material can develop:

relationships;

world texture;

humor;

reflection;

planning;

ordinary routines;

or anticipation.

## Common drift

Generated fiction may treat downtime as a threat to engagement.

The model therefore fills quieter spaces with:

new conflict;

dramatic introspection;

unexpected danger;

relationship tension;

or foreshadowing.

Nothing is allowed simply to breathe.

## Why it may weaken fiction

Readers receive too little contrast.

Characters may also feel psychologically unrealistic because they are never allowed to inhabit ordinary states.

Important relationships can become defined entirely by crisis.

## Diagnostic questions

Does this section need immediate pressure?

What does ordinary behavior reveal about these characters?

Has the reader had enough opportunity to experience what is worth protecting?

Would calm increase the effect of later disruption?

## Better direction

Allow scenes where the function is:

recovery;

bonding;

normality;

curiosity;

pleasure;

observation;

or quiet preparation.

Such material should still belong to the novel.

It need not exist merely as filler between action sequences.

## Valid exceptions

Some stories deliberately deny recovery.

Horror, tragedy, captivity, war, and survival narratives may use exhaustion as part of the intended experience.

## Long-form warning signs

Every peaceful scene receives an interruption.

Every intimate moment becomes an argument or revelation.

Ordinary life exists only in flashbacks.

The reader understands danger better than what characters enjoy when danger is absent.

## Revision considerations

Recovery scenes should not automatically become emotionally empty.

Low external tension may allow deeper internal or relational movement.

---

# PC-05 — DELAYED CONSEQUENCE

## Core principle

Consequences do not always arrive immediately.

The gap between action and consequence can generate tension, realism, surprise, dread, or complexity.

## Common drift

Generated fiction often creates immediate causal closure.

A mistake is made.

The consequence appears.

The character understands the lesson.

The story moves on.

This produces clean structure but limited temporal depth.

## Why it may weaken fiction

The world feels mechanically responsive.

Real consequences often require:

time;

transmission;

institutional response;

physical deterioration;

rumor;

relationship change;

or delayed discovery.

## Diagnostic questions

How quickly would this consequence realistically appear?

Who has to learn about the action?

What process must occur first?

Could the character temporarily believe they escaped consequences?

Would delay create useful uncertainty?

## Better direction

Let consequences arrive according to their own causal timelines.

A reckless choice in chapter 5 might become expensive in chapter 11.

The delay should not feel forgotten.

The story can maintain traces or latent risk.

## Valid exceptions

Some actions have immediate consequences.

Physical mistakes, public insults, explosions, and tactical errors may produce near-instant results.

## Long-form warning signs

Every choice receives immediate feedback.

Characters understand consequences almost as soon as they act.

Few earlier actions unexpectedly reshape later chapters.

## Revision considerations

Delayed consequences require memory.

If too many are created, maintain a ledger of unresolved causal obligations.

---

# PC-06 — EMOTIONAL PACING

## Core principle

Emotional processing has its own tempo.

Characters may react:

immediately;

slowly;

in stages;

after distraction;

only when safety returns;

or much later when something triggers the memory.

## Common drift

Generated stories frequently process emotion in the same scene as the triggering event.

Something happens.

The character feels it.

They analyze it.

They understand it.

Sometimes they resolve it.

The sequence becomes emotionally efficient.

## Why it may weaken fiction

Major experiences can feel prematurely metabolized.

Characters become unusually available to their own emotions.

This contributes to the research complaint that emotional material may be explicit but insufficiently accumulated. 

## Diagnostic questions

Would this character process the event now?

Are they physically safe enough to reflect?

Are there more urgent concerns?

Would shock delay understanding?

Does their personality favor suppression, analysis, action, denial, or immediate expression?

## Better direction

Let emotional processing occur on character-specific timelines.

A soldier may function effectively during danger and collapse afterward.

Another person may break immediately but later recover quickly.

A third may appear unaffected for days.

## Valid exceptions

Some people do process emotions rapidly and accurately.

Some narrative voices also foreground immediate introspection.

## Long-form warning signs

Every emotional event receives immediate internal interpretation.

Trauma is processed before circumstances realistically permit it.

Characters repeatedly complete an emotional arc within a single scene.

## Revision considerations

Delayed processing should not become forgotten processing.

Later behavior can carry emotional residue before explicit reflection occurs.

---

# PC-07 — INFORMATION PACING

## Core principle

Information should arrive according to dramatic need, reader comprehension, character access, and narrative structure.

Neither maximum mystery nor maximum clarity is inherently superior.

## Common drift

Generated stories may release information at overly regular intervals.

Each chapter contains:

a clue;

a revelation;

a new mystery;

a partial answer.

The pattern becomes mechanically serialized.

The opposite failure also occurs: too much information is delivered at once because the model attempts to clarify the world efficiently.

## Why it may weaken fiction

Regular revelation patterns become predictable.

Information dumps can overwhelm.

Excess withholding can make stories vague.

## Diagnostic questions

What does the reader need to know now?

What can wait?

What misunderstanding is productive?

Does this answer create a more interesting question?

Are several revelations competing for attention?

Has the story withheld something for so long that suspense has become confusion?

## Better direction

Vary informational rhythm.

Some chapters may radically alter understanding.

Others may confirm suspicion.

Others may provide almost no new factual information while deepening interpretation.

## Valid exceptions

Mysteries, puzzle stories, thrillers, serialized fiction, and progression narratives may deliberately use regular information rewards.

## Long-form warning signs

Every chapter ends with a reveal.

Worldbuilding arrives in similarly sized packets.

Mysteries multiply faster than answers.

Major answers arrive without enough time for readers to integrate them.

## Revision considerations

Track both:

what characters know;

and what readers need.

These are related but not identical.

---

# PC-08 — CONFLICT DURATION

## Core principle

Different conflicts deserve different lifespans.

Some should resolve immediately.

Others gain power by surviving across chapters or entire books.

## Common drift

Generated fiction often resolves conflict soon after it becomes explicit.

Because the model tends toward completion and conversational understanding, a conflict may follow:

problem → confrontation → explanation → understanding → resolution.

The opposite can also occur: a conflict is artificially repeated long after its useful life because the story needs continuing tension.

## Why it may weaken fiction

Premature resolution prevents accumulation.

Artificial prolongation frustrates readers.

Both reveal structural convenience.

## Diagnostic questions

What actually sustains this conflict?

Lack of information?

Incompatible values?

Material competition?

Pride?

Trauma?

Social pressure?

Power imbalance?

If the characters understand each other, does the conflict still remain?

What would genuinely resolve it?

## Better direction

Let conflict duration arise from its underlying cause.

Misunderstanding may end quickly once clarified.

Value conflict may survive perfect understanding.

Grief cannot necessarily be “resolved.”

Political conflict may persist because incentives remain opposed.

## Valid exceptions

Some genres rely on prolonged misunderstandings, episodic rivalry, or recurring interpersonal friction.

The convention may itself be part of the intended appeal.

## Long-form warning signs

Arguments repeatedly disappear after one conversation.

Or the same disagreement returns without meaningful change.

Characters forgive because the scene needs closure.

Characters refuse obvious communication only because the plot needs delay.

## Revision considerations

Do not ask merely:

> Should this conflict continue?

Ask:

> What mechanism keeps it alive?

---

# PC-09 — MIDDLE-BOOK VIGILANCE

## Core principle

Long stories face a particular danger after initial setup but before final convergence.

The middle must inherit earlier developments while continuing to generate meaningful new pressure.

## Common drift

AI-heavy long fiction may begin strongly because premise, characters, and initial conflict are clear.

As the story expands, several problems may appear:

repetition;

new elements introduced too quickly;

old elements forgotten;

subplots stalling;

character states resetting;

continuity weakening;

and escalation becoming increasingly artificial.

The source research describes readers encountering strong premises followed by increasingly repetitive material and rapid introduction of new elements that are never deeply integrated. 

## Why it may weaken fiction

The middle becomes a content-generation zone.

The novel keeps producing chapters without deepening its original promises.

## Diagnostic questions

What has genuinely changed since the opening?

Which early promises remain active?

Which relationships have evolved?

What new complexity has emerged from earlier decisions?

Are new elements replacing development of existing ones?

Is the story repeating successful early patterns?

## Better direction

Treat the middle as a period of **complication and convergence**, not simply expansion.

Earlier choices should create new problems.

Subplots should begin interacting.

Initial assumptions should become unstable.

Relationships should carry history.

## Valid exceptions

Episodic serials may intentionally delay convergence.

Very long web novels may sustain multiple arcs with relatively independent middles.

Even there, individual arcs need accumulation.

## Long-form warning signs

New villains continually replace old ones without deeper consequence.

New locations substitute for development.

Characters repeatedly confront versions of earlier problems.

The premise remains interesting while the actual narrative stagnates.

## Revision considerations

When the middle feels weak, adding a new plotline is not always the solution.

Often the stronger move is to make existing material collide.

---

# PC-10 — RHYTHM ACROSS CHAPTERS

## Core principle

Pacing should be considered above the scene level.

Individual scenes may work well while the sequence of scenes produces monotony.

## Common drift

A story may repeatedly use chapters with the same rhythm:

slow setup;

mid-chapter complication;

end revelation.

Or:

action chapter;

recovery chapter;

action chapter;

recovery chapter.

Or:

conversation;

travel;

fight;

reflection.

The pattern becomes visible.

## Why it may weaken fiction

The reader begins anticipating structure rather than experiencing events.

Chapter boundaries become mechanical.

## Diagnostic questions

What kind of experience did the previous chapter provide?

How does this chapter differ?

Are chapter lengths suspiciously uniform?

Does every chapter contain the same number of major beats?

Do endings rely on the same kind of hook?

Does the sequence create useful contrast?

## Better direction

Think of chapter rhythm across larger units.

Some chapters may:

accelerate;

linger;

withhold;

resolve;

prepare;

recover;

or completely reorient the story.

Variation should follow narrative architecture rather than arbitrary alternation.

## Valid exceptions

Serialized publication may benefit from regular structural rhythms.

Certain genres promise predictable chapter-level rewards.

Predictability can create comfort when intentional.

## Long-form warning signs

Every chapter ends with:

danger;

a revelation;

a dramatic question;

or a reflective hook.

Chapter lengths cluster unnaturally closely.

Scene count per chapter remains nearly constant.

## Revision considerations

Do not vary chapters merely to avoid pattern.

A repeated structure may become part of the work's formal identity.

The question is whether it still serves the reader.

---

# DOMAIN 10 — CROSS-LENS GUIDANCE

## Fast events, slow story

One of the central research findings is that an AI-generated story can contain enormous amounts of action while feeling stagnant. 

This happens when events do not create sufficiently persistent changes.

For example:

battle;

victory;

recovery;

another battle;

another victory;

another recovery.

The events are fast.

The story state changes very little.

The solution is not automatically fewer battles.

It is stronger accumulation.

---

## Slow events, fast story

The opposite is equally important.

Two people may spend an entire chapter sitting in one room.

During the conversation:

an alliance breaks;

a secret is exposed;

a marriage ends;

a political decision changes;

and one character realizes they have been manipulated.

Almost nothing physically happens.

Narratively, the story moves rapidly.

---

## Tension versus noise

Tension usually contains:

something desired;

something uncertain;

and something capable of preventing the desired outcome.

Noise contains:

danger words;

dramatic prose;

threats;

arguments;

ominous gestures;

and cliffhangers

without enough meaningful uncertainty or consequence.

Do not mistake rhetorical intensity for tension.

---

## Escalation versus inflation

Escalation deepens difficulty.

Inflation merely increases magnitude.

### Inflation

ten enemies become one hundred.

The monster becomes larger.

The explosion becomes bigger.

The villain becomes more powerful.

### Escalation

the protagonist must choose whom to save;

victory exposes a secret;

using greater power carries a personal cost;

an ally becomes morally opposed;

the easiest solution violates a core value.

Scale can accompany escalation.

It should not substitute for it.

---

## Premature payoff

A story may correctly identify what readers eventually want:

a confession;

a reunion;

a revenge victory;

a secret revealed;

a transformation;

a romantic consummation.

The danger is providing the payoff before enough anticipation, resistance, investment, or consequence has accumulated.

Payoff gains value partly through **waiting that remains interesting**.

---

## Artificial delay

The opposite is equally dangerous.

Once a story has earned a payoff, repeatedly postponing it can become obvious manipulation.

Watch for:

new misunderstandings;

coincidental interruptions;

villains appearing at convenient moments;

characters refusing to communicate without credible reason;

or additional obstacles that do not deepen the story.

Tension is weakened when readers can see the author moving the finish line.

---

# DOMAIN 10 — PACING SCALE MODEL

Pacing should be examined at multiple scales.

## Sentence scale

How quickly does information arrive?

## Paragraph scale

How long does the prose remain on one perception or thought?

## Scene scale

How much story time receives direct dramatization?

## Sequence scale

How do consecutive scenes accelerate or decompress?

## Chapter scale

What experience does the chapter create?

## Arc scale

How quickly do problems develop, complicate, and resolve?

## Novel scale

How does the overall story distribute:

setup;

development;

escalation;

payoff;

and aftermath?

A pacing problem at one level may not exist at another.

A slow scene can belong inside a fast-moving novel.

A rapid action sequence can exist inside a deliberately slow book.

---

# DOMAIN 10 — TENSION MODEL

For significant tension, consider:

### Desire

What does the character or reader want to happen?

### Obstacle

What prevents certainty of that outcome?

### Stakes

Why does the result matter?

### Uncertainty

Why is the outcome genuinely unclear?

### Time

Is there pressure from delay, deadline, deterioration, or anticipation?

### Knowledge

Who knows what?

### Cost

What must be risked or sacrificed?

### Alternatives

What other paths exist?

### Complication

How can the situation change before resolution?

Not every tense situation requires all these elements.

The model is diagnostic rather than prescriptive.

---

# DOMAIN 10 — ESCALATION MODEL

Escalation can occur along many axes.

### Physical

Greater danger or difficulty.

### Emotional

Greater vulnerability or personal investment.

### Relational

More trust, betrayal, intimacy, resentment, dependence, or loss.

### Moral

Harder ethical choices.

### Social

Greater reputational or institutional consequences.

### Informational

More consequential truths become available.

### Strategic

Options narrow or become more costly.

### Temporal

Deadlines tighten.

### Irreversibility

Choices become harder to undo.

### Scope

More people or systems are affected.

A story does not need to escalate across every axis.

Often the strongest escalation changes axis rather than merely intensifying the same one.

---

# DOMAIN 10 — PRESSURE AND RELEASE

A useful long-form pattern is not:

low → medium → high → higher → highest.

It may instead resemble:

pressure;

partial relief;

new information;

greater uncertainty;

temporary success;

unexpected consequence;

deepened pressure;

loss;

reorientation;

final convergence.

This prevents escalation from becoming purely numerical.

---

# DOMAIN 10 — WEB-NOVEL AND SERIAL GUIDANCE

Long serial fiction faces special pacing risks because the writing process itself rewards continuous production.

The source research specifically notes that web novels can substitute **more content for development**. 

Watch for:

repeated arc architecture;

constant introduction of new powers;

new characters replacing development of existing ones;

ever-stronger enemies;

recurring emotional conflicts;

and chapter hooks that stop creating genuine anticipation.

For serial fiction, ask periodically:

> What is permanently different from fifty chapters ago?

A long word count should correspond to accumulated history.

---

# DOMAIN 10 — PRACTICAL REVIEW LENS

When reviewing pacing, ask:

## 1. Is the story moving, or are events merely occurring?

Check state change.

## 2. Is narrative speed appropriate?

Determine what should be scene, summary, pause, or omission.

## 3. Has tension remained too uniform?

Look for useful modulation.

## 4. Is escalation deepening difficulty or merely increasing scale?

Protect meaningful escalation.

## 5. Is consequence arriving at the right time?

Consider delay.

## 6. Are characters processing emotion too quickly?

Check psychological pacing.

## 7. Is information arriving naturally?

Check revelation rhythm.

## 8. Is conflict resolving or persisting for believable reasons?

Protect causal duration.

## 9. Is the middle developing or merely expanding?

Check accumulated complexity.

## 10. Are chapters acquiring a predictable structural rhythm?

Review chapter sequences.

## 11. Has a payoff arrived before sufficient investment?

Check earned emotional weight.

## 12. Has a payoff been postponed after the story already earned it?

Check artificial delay.

---

# DOMAIN 10 — CENTRAL REMINDER

Pacing is not a command to make fiction fast.

A slow novel can have excellent pacing.

A fast novel can have terrible pacing.

The better question is:

> Is the reader spending the right amount of attention on the right things?

Then:

> Is pressure changing?

> Are consequences accumulating?

> Are important experiences given enough room?

> Are less important experiences being compressed when appropriate?

> Does escalation alter difficulty rather than simply enlarge spectacle?

> Does the story allow anticipation before payoff?

> Does it allow recovery before renewed pressure?

And most importantly:

> After all this activity, what is actually different?

A novel should not merely keep producing events.

It should accumulate:

history;

pressure;

expectation;

consequence;

relationship change;

knowledge;

commitment;

loss;

and possibility.

The goal is not relentless momentum.

The goal is **meaningful temporal movement**.

That completes **Domain 10**. The research basis is especially strong here: readers explicitly report the combination of too-fast and too-slow pacing, filler alongside excessive summary, dramatic activity without real movement, repetitive cycles, and setup that continually signals importance without eventually delivering proportional payoff. The broader research conclusion also supports prioritizing these long-range failures over superficial “AI tells”: the core problem is a book continuing to produce prose without continuously accumulating meaning. 

**Remaining:**
1. Domain 11 — Plot, Causality, Subplots & Payoff
2. Domain 12 — Continuity, World Logic & Embodied Reality
3. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 11 — Plot, Causality, Subplots & Payoff**. This domain addresses one of the deepest problems identified in the research: AI-generated fiction can produce plausible event sequences without enough causal depth, repeat the same dramatic function under different surface events, introduce setups that never earn meaningful payoff, and default toward familiar “most likely next” developments. 

# DOMAIN 11 — PLOT, CAUSALITY, SUBPLOTS & PAYOFF

## Domain purpose

Plot is not merely a sequence of events.

A strong plot is a **network of consequences**.

Events matter because they alter:

- what characters can do;
- what they believe;
- what they want;
- what they fear;
- who trusts whom;
- what resources remain;
- which options disappear;
- what institutions respond;
- what promises become active;
- and what future events become possible.

The central distinction is:

> “Then this happened” is sequence.

> “Because this happened, these new conditions existed” is causality.

A plot can be technically coherent while still feeling shallow if each event follows plausibly but does not meaningfully inherit the consequences of earlier events.

Another important distinction is:

> Surprise is not the same as unpredictability.

And:

> Payoff is not merely answering a question.

Payoff is the moment when prior narrative investment becomes newly meaningful.

This domain therefore focuses on:

- causality;
- character agency;
- alternatives;
- consequence persistence;
- setup;
- payoff;
- subplot independence;
- subplot interaction;
- predictability;
- and endings that genuinely inherit the novel's accumulated history.

---

# PL-01 — CAUSAL CONNECTION

## Core principle

Major developments should generally arise from earlier:

- decisions;
- conditions;
- information;
- relationships;
- pressures;
- mistakes;
- opportunities;
- or events.

The story should feel increasingly shaped by what has already happened.

## Common drift

Generated fiction may create plausible chronological progression:

the characters arrive at a city;

they encounter a problem;

they solve it;

they meet someone;

that person gives them another problem;

they travel somewhere else;

another event occurs.

Each transition makes local sense.

But the larger sequence may feel interchangeable.

The events happen **after** one another more strongly than they happen **because of** one another.

## Why it may weaken fiction

The novel feels episodic even when it possesses an overarching plot.

Readers may sense that the author could replace one event with another without changing much.

The story accumulates content rather than necessity.

## Diagnostic questions

Why does this event happen now?

What earlier condition made it possible?

What prior decision contributed to it?

Would this event still happen if the previous scene were removed?

Did someone create this problem through an earlier choice?

What new causal chain begins here?

## Better direction

Strengthen links between events.

For example:

The protagonist saves a smuggler.

Because of that choice, authorities begin watching them.

Because authorities are watching, an ally refuses contact.

Because the ally disappears, the protagonist seeks help elsewhere.

That new alliance later creates another conflict.

The chain does not need to be rigid.

But later material should increasingly emerge from accumulated earlier conditions.

## Valid exceptions

Some fiction deliberately uses coincidence, episodic encounter, picaresque structure, dream logic, absurdism, or randomness.

Causality need not dominate every narrative form.

## Long-form warning signs

Arcs feel detachable.

Removing an earlier event has little effect on later events.

New problems continually arrive from outside rather than growing from prior choices.

The protagonist mostly reacts to incoming plot rather than creating future conditions.

## Revision considerations

Do not force every event into one tightly closed causal chain.

A world can contain independent events.

The goal is enough causal inheritance that the novel feels like history rather than a queue of incidents.

---

# PL-02 — CHARACTER-DRIVEN CAUSALITY

## Core principle

Plot should often emerge from what characters actually choose.

Characters are not merely passengers carried by structure.

Their:

- goals;
- mistakes;
- fears;
- loyalties;
- prejudices;
- ambitions;
- and misunderstandings

can generate story.

## Common drift

The outline requires:

a betrayal;

a fight;

a discovery;

a breakup;

a journey;

a sacrifice.

Characters are then adjusted until they perform the required action.

This produces plot-driven characterization rather than character-driven causality.

## Why it may weaken fiction

Readers may feel characters are being moved around by the story.

Decisions become difficult to believe because their primary justification exists outside the character.

## Diagnostic questions

What would this character choose if the outline did not already exist?

What alternatives would they seriously consider?

Why does this action make sense to them?

What value or fear produces it?

Does this decision create consequences that the plot can genuinely inherit?

## Better direction

Let the plot emerge from collisions among character desires.

For example:

One character wants safety.

Another wants justice.

A third wants political stability.

None is irrational.

Their incompatible goals generate the conflict.

## Valid exceptions

External events can dominate plots.

Natural disasters, war, murder, illness, invasion, or social upheaval may impose events characters did not choose.

Even then, subsequent plot can emerge from how characters respond.

## Long-form warning signs

Characters repeatedly choose exactly what is necessary for the planned next scene.

Motivations appear shortly before they become useful.

People temporarily become foolish, brave, trusting, cruel, or impulsive to enable plot movement.

## Revision considerations

When a planned event requires implausible behavior, consider changing the event rather than changing the character.

---

# PL-03 — ALTERNATIVE-ACTION AWARENESS

## Core principle

Characters exist in worlds containing options.

A plot becomes more convincing when major actions remain plausible despite obvious alternatives.

## Common drift

Generated plots may move characters toward the intended solution without seriously considering easier alternatives.

Examples include:

failing to call for help;

ignoring established resources;

forgetting a useful ability;

choosing an unnecessarily dangerous route;

not asking an obvious question;

or refusing a simple solution because the story needs difficulty.

## Why it may weaken fiction

Readers begin solving the story more effectively than the characters.

Conflict feels manufactured.

## Diagnostic questions

What obvious alternatives exist?

Would the character recognize them?

Why are they unavailable?

What cost makes them unattractive?

Would another character suggest them?

Does the protagonist reject them for a believable reason?

## Better direction

Allow alternatives to exist and then constrain them honestly.

An easy option may be:

too expensive;

too dangerous to someone else;

politically impossible;

morally unacceptable;

too slow;

based on information the character lacks;

or available only at a serious cost.

## Valid exceptions

Characters overlook obvious choices.

People panic.

They become stubborn.

They make bad decisions.

Not every poor decision requires elaborate justification.

## Long-form warning signs

Readers repeatedly identify straightforward solutions that characters never acknowledge.

Established powers or resources disappear when inconvenient.

Conflict depends on selective incompetence.

## Revision considerations

Acknowledge obvious alternatives when necessary.

Sometimes one sentence explaining why the obvious option fails is enough.

---

# PL-04 — CONSEQUENCE PERSISTENCE

## Core principle

Important actions should often continue affecting the story after their immediate scene.

## Common drift

A character:

kills someone;

breaks a law;

betrays an ally;

reveals a secret;

destroys property;

makes a public promise;

uses forbidden power;

or humiliates an important person.

The immediate scene reacts.

Then the story mostly moves on.

## Why it may weaken fiction

Major events feel disposable.

The world does not seem to remember.

Plot becomes a chain of temporary crises rather than accumulated consequence.

## Diagnostic questions

Who was affected?

What material conditions changed?

What social consequences remain?

What emotional consequences remain?

What strategic options disappeared?

What new risks were created?

What institutions should respond?

## Better direction

Treat major events as changes to story state.

Consequences may include:

legal pursuit;

reputation;

resource loss;

new loyalty;

fear;

resentment;

changed tactics;

political reaction;

or altered self-concept.

## Valid exceptions

Some events genuinely have limited reach.

The world does not need to react dramatically to everything.

## Long-form warning signs

Major actions produce consequences only in the chapter where they occur.

Characters repeatedly survive catastrophic events without accumulating costs.

Institutions fail to respond to actions that should concern them.

## Revision considerations

Consequences can be delayed.

Persistence does not require immediate payoff.

---

# PL-05 — SETUP INTEGRITY

## Core principle

When a story creates expectation, it creates a narrative obligation.

Setup may take the form of:

- mystery;
- warning;
- object;
- relationship tension;
- promise;
- prophecy;
- ability;
- secret;
- unanswered question;
- repeated motif;
- unusual detail;
- stated goal.

Not every setup requires literal resolution.

But strongly emphasized material should usually matter somehow.

## Common drift

Generated fiction introduces evocative elements because they create immediate intrigue.

A strange symbol appears.

A character reacts mysteriously.

A prophecy is mentioned.

A rival issues a warning.

A suspicious object receives attention.

Then the narrative moves elsewhere.

The source research repeatedly identifies this as apparently meaningful material that dissolves without proportional payoff. 

## Why it may weaken fiction

Readers stop investing attention.

Foreshadowing loses credibility.

Mystery becomes decoration.

## Diagnostic questions

What expectation does this create?

How strongly is the prose signaling importance?

Does the story intend to return to it?

If not, does the element provide enough immediate value?

Could this setup become part of another thread?

Has the narrative accidentally promised more than intended?

## Better direction

Track meaningful setups.

A setup may later:

pay off directly;

be reinterpreted;

become a red herring;

reveal character;

or acquire thematic meaning.

The payoff does not need to be obvious or symmetrical.

## Valid exceptions

Realistic fiction can contain unresolved material.

Red herrings exist.

Some motifs are atmospheric.

Some unanswered questions deliberately remain unanswered.

## Long-form warning signs

The story continually introduces mysteries faster than it resolves or transforms them.

Foreshadowing language appears frequently without future relevance.

Readers are repeatedly trained to care about disposable details.

## Revision considerations

Payoff can be indirect.

Do not convert every detail into a Chekhov's gun.

---

# PL-06 — PAYOFF PROPORTIONALITY

## Core principle

Narrative payoff should broadly correspond to the amount and type of investment that preceded it.

## Common drift

A mystery receives extensive setup but a trivial explanation.

A villain is built across hundreds of pages and defeated easily.

A relationship receives intense buildup and resolves through one brief conversation.

A repeatedly emphasized secret turns out to have little consequence.

The opposite can also occur:

a minimally established element suddenly receives enormous payoff.

## Why it may weaken fiction

Readers experience a mismatch between expectation and return.

The story's emphasis becomes unreliable.

## Diagnostic questions

How much narrative investment preceded this moment?

What expectation has the reader developed?

Does the payoff answer only the factual question or also address the emotional/narrative investment?

Is the payoff larger than its setup can support?

Is the resolution too easy relative to the established obstacle?

## Better direction

Match payoff to **what the story actually promised**.

A mystery may require:

factual answer;

consequence;

reinterpretation of earlier events;

and emotional response.

A romance payoff may require more than simply “they kiss.”

It may need to resolve or transform the relationship tension that created the investment.

## Valid exceptions

Anti-climax can be deliberate.

Comedy may intentionally produce disproportionate resolution.

Literary fiction may deny expected payoff.

Subversion can be powerful.

But the narrative should understand what expectation it is violating.

## Long-form warning signs

Large buildup repeatedly leads to small resolution.

Climaxes feel shorter and simpler than their setups.

Important questions receive technically correct but emotionally unsatisfying answers.

## Revision considerations

Do not inflate payoff merely to match scale.

Sometimes the better correction is reducing excessive setup.

---

# PL-07 — SUBPLOT INDEPENDENCE

## Core principle

A subplot should possess enough internal logic to exist as more than decoration around the main plot.

It may involve:

- another relationship;
- secondary ambition;
- family issue;
- political development;
- personal problem;
- rival;
- institutional conflict;
- moral question.

## Common drift

Generated subplots often exist primarily to support the protagonist's main arc.

A friend's romance teaches the protagonist about love.

A political problem creates exactly the resource the protagonist needs.

A secondary character's conflict exists mainly to trigger the protagonist's development.

The thread lacks independent momentum.

## Why it may weaken fiction

The world becomes over-organized around the main plot.

Subplots feel like tools rather than lives unfolding alongside it.

## Diagnostic questions

What does this subplot want independently?

Who would continue pursuing it if the protagonist disappeared?

Does it have its own stakes?

Can its outcome differ from what the main plot needs?

What characters care about it for reasons unrelated to the protagonist?

## Better direction

Give important subplots their own causal logic.

They need not be large.

A subplot can be simple but still possess independent momentum.

## Valid exceptions

Some stories intentionally use tightly integrated subplots where every thread directly reinforces one central conflict.

That can create elegant structure.

## Long-form warning signs

Secondary threads pause whenever the protagonist is absent.

Subplots resolve precisely when the main plot needs them.

Supporting characters' problems mainly exist to produce lessons for the protagonist.

## Revision considerations

Independence does not mean disconnection.

A strong subplot may later collide with the main plot.

---

# PL-08 — SUBPLOT INTERACTION

## Core principle

Narrative threads become richer when they can affect one another.

A subplot should not always live in a separate compartment.

## Common drift

Generated novels can maintain several parallel threads that rarely interact.

Romance progresses in romance scenes.

Politics progresses in political scenes.

Family conflict progresses in family scenes.

Main plot progresses in action scenes.

Each remains isolated.

## Why it may weaken fiction

The novel can feel assembled from separate modules.

Complexity remains additive instead of interactive.

## Diagnostic questions

How can one thread complicate another?

Can progress in one area create cost elsewhere?

Can information from a subplot change the main plot?

Can two obligations collide?

Does one relationship affect another?

## Better direction

Allow intersections.

For example:

A political alliance damages a romance.

A family obligation disrupts an investigation.

A friendship provides information but creates a loyalty conflict.

The subplot becomes part of the causal ecology of the novel.

## Valid exceptions

Some secondary threads intentionally remain separate to create contrast or thematic parallel.

## Long-form warning signs

Each subplot occupies predictable scene types.

Threads only converge near the ending.

Characters seem to forget one problem while inside another storyline.

## Revision considerations

Avoid forcing intersections merely to create complexity.

Look for natural shared consequences.

---

# PL-09 — PREDICTABILITY AWARENESS

## Core principle

Familiar developments are not inherently bad.

Genres depend on recognizable patterns.

The concern is defaulting automatically to the most statistically familiar next development when the specific story supports more interesting alternatives.

## Common drift

When asked “what happens next,” generated fiction may select highly conventional answers:

the villain betrays the alliance;

the romantic misunderstanding appears;

the mentor dies;

the secret heir is revealed;

the suspicious stranger is actually an ally;

the protagonist discovers hidden power;

the argument becomes reconciliation.

These may all be excellent developments.

The issue is whether they emerge from the particular story or from broad genre probability.

## Why it may weaken fiction

The premise may feel original while execution becomes increasingly familiar.

The reader begins anticipating not because the novel has foreshadowed well, but because the story is following the genre's statistical center.

## Diagnostic questions

What is the obvious next development?

Why is it obvious?

Does this particular story truly support it?

What other consequences follow from existing conditions?

What would these specific characters do?

Can the familiar outcome occur through a more specific path?

Would avoiding the trope actually make the story worse?

## Better direction

Do not automatically reject familiar outcomes.

Instead make them **story-specific**.

A betrayal becomes interesting when only this person would betray for this reason, at this moment, producing these consequences.

## Valid exceptions

Genre satisfaction often depends on expected beats.

Romance usually promises relational resolution.

Mysteries promise explanation.

Progression fantasy promises advancement.

The goal is not novelty for novelty's sake.

## Long-form warning signs

Readers can predict developments because they have encountered the same structure repeatedly elsewhere.

Plot decisions become easier to explain through genre convention than through character and causality.

## Revision considerations

Ask:

> Is this cliché because it is familiar?

or:

> Is it cliché because nothing particular has been done with it?

These are different problems.

---

# PL-10 — ENDING INHERITANCE

## Core principle

The ending should emerge from the actual accumulated history of the novel.

It should feel like the conclusion of **this story**, not a generic conclusion attached to it.

## Common drift

Generated endings may move toward familiar closure:

villain defeated;

truth revealed;

relationship resolved;

protagonist transformed;

future implied;

final reflective line.

Everything technically closes.

Yet the ending may not meaningfully integrate:

secondary relationships;

earlier sacrifices;

world consequences;

unresolved contradictions;

or the specific path taken to reach it.

## Why it may weaken fiction

The ending feels structurally complete but emotionally generic.

The novel's unique history is not sufficiently present.

## Diagnostic questions

Which earlier choices made this ending possible?

Which relationships matter here?

What costs remain?

What has permanently changed?

What cannot be restored?

What promises require attention?

How does the ending differ because of the specific route the characters took?

## Better direction

Let the ending inherit:

consequences;

history;

relationships;

losses;

knowledge;

and thematic tension.

The climax should not erase the path that created it.

## Valid exceptions

Open endings, cyclical endings, ambiguous endings, intentionally abrupt endings, and anti-climactic endings may refuse conventional closure.

They should still feel connected to the novel's accumulated identity.

## Long-form warning signs

The ending could be transferred to another novel in the same genre with limited alteration.

Secondary threads disappear near the climax.

Consequences are simplified to make closure easier.

## Revision considerations

Do not resolve every thread merely for completeness.

Prioritize the threads the novel has taught readers to care about most.

---

# DOMAIN 11 — CROSS-LENS GUIDANCE

## Sequence versus necessity

A generated plot often answers:

> What can happen next?

A stronger planning question is often:

> What has become likely, possible, difficult, or necessary because of what already happened?

That shift moves plot from continuation toward causality.

---

## Convenient stupidity

When characters must make a bad decision, ask whether the story has:

earned the mistake;

established the blind spot;

created incomplete information;

or applied enough pressure.

If not, the plot may be borrowing stupidity to remain functional.

---

## External-problem addiction

Stories can become dependent on continuously introducing new threats.

New villain.

New monster.

New conspiracy.

New location.

New emergency.

This keeps content moving but may prevent existing consequences from deepening.

Before adding a new problem, ask:

> Can the current problems collide in a more interesting way?

---

## Setup inflation

Generated prose is skilled at signaling significance.

This can produce too many:

mysteries;

warnings;

ominous objects;

cryptic statements;

prophecies;

secrets;

and suspicious reactions.

Each creates narrative debt.

The story eventually owes too many payoffs.

---

## Payoff without transformation

A payoff may answer the question yet change little.

The murderer is revealed.

But the revelation does not alter relationships, worldview, politics, or emotional state.

The secret is answered factually but not narratively.

Strong payoff often contains both:

**answer** and **consequence**.

---

## Subplots as anti-homogenization

Independent subplots help resist the feeling that every event exists for one central narrative purpose.

They allow the novel to contain:

sideways movement;

competing obligations;

unplanned collisions;

and lives beyond the protagonist.

But adding many subplots without integration can produce the opposite problem: fragmentation.

---

# DOMAIN 11 — CAUSALITY MODEL

For major plot developments, consider:

### Cause

What created the conditions?

### Agent

Who acts?

### Motive

Why do they act?

### Constraint

What limits their options?

### Choice

What do they decide?

### Immediate result

What happens?

### Secondary consequence

Who or what else is affected?

### Delayed consequence

What may emerge later?

### New state

What has become newly true?

### Future possibility

What can now happen that could not happen before?

This is not a formula for every event.

It is a diagnostic tool for important ones.

---

# DOMAIN 11 — SETUP/PAYOFF LEDGER

For long works, important narrative obligations can be tracked through:

### Setup

What has been introduced?

### Type

Mystery?

Promise?

Object?

Relationship tension?

Goal?

Warning?

World rule?

Symbol?

### Strength

How strongly has the story signaled importance?

### Reader expectation

What is the reader likely waiting for?

### Planned function

Direct payoff?

Reinterpretation?

Red herring?

Thematic return?

### Current status

Active?

Partially resolved?

Transformed?

Closed?

### Payoff consequence

What changes when it resolves?

This helps prevent setups from evaporating as the book grows.

---

# DOMAIN 11 — SUBPLOT MODEL

For a significant subplot, consider:

### Independent goal

What does this thread pursue?

### Participants

Who cares about it?

### Stakes

Why does it matter to them?

### Timeline

How does it develop when offscreen?

### Main-plot connection

Where can it influence the central thread?

### Interference

What does it make harder?

### Opportunity

What does it make possible?

### Resolution

Does it close, transform, merge, or remain unresolved?

The purpose is not to formalize every subplot.

It is to protect them from becoming decorative.

---

# DOMAIN 11 — PREDICTABILITY TEST

Before committing to a major development, consider at least three categories:

### Expected consequence

What would most readers assume happens next?

### Character-specific consequence

What follows from these exact people?

### World-specific consequence

What follows from this world's institutions, rules, resources, culture, and history?

Often the strongest development emerges from combining the latter two rather than merely rejecting the first.

---

# DOMAIN 11 — PRACTICAL REVIEW LENS

When reviewing plot, ask:

### 1. Does this happen because of earlier events?

Check causality.

### 2. Would the character actually choose this?

Check agency.

### 3. Are obvious alternatives being ignored?

Check plot convenience.

### 4. Do consequences survive beyond the scene?

Protect persistence.

### 5. Has the story created obligations it remembers?

Track setup.

### 6. Does payoff match investment?

Check proportionality.

### 7. Do subplots possess independent logic?

Protect social/narrative depth.

### 8. Do subplots interact naturally?

Protect integration.

### 9. Is the next development arising from this story or genre default?

Check predictability.

### 10. Does the ending inherit the actual novel?

Protect accumulated history.

---

# DOMAIN 11 — CENTRAL REMINDER

Plot should not merely answer:

> What happens next?

It should repeatedly ask:

> What has become possible because of what already happened?

> What has become impossible?

> What do these characters now choose?

> What consequences are still traveling through the story?

> What promises has the novel made?

> What does the reader now reasonably expect?

> What side threads are moving independently?

> What earlier decision is about to matter again?

And eventually:

> Could this ending only belong to this novel?

The goal is not maximum complexity.

The goal is not constant surprise.

The goal is **causal accumulation**.

A strong plot increasingly feels shaped by its own past.

By the end, the story should not merely have traveled a long distance.

It should have become something that could only have emerged from the specific sequence of choices, mistakes, relationships, consequences, and revelations that produced it.

That completes **Domain 11**. It builds directly on the source research's strongest long-range concerns: repeated plot functions, weak setup/payoff, generic high-probability developments, disposable consequences, and the larger problem of local plausibility without enough accumulated narrative necessity. 

**Remaining:**
1. Domain 12 — Continuity, World Logic & Embodied Reality
2. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

Next is **Domain 12 — Continuity, World Logic & Embodied Reality**. This is one of the highest-confidence areas in the research: readers repeatedly report broken chronology, shifting locations, duplicated object transfers, forgotten injuries, inconsistent powers and rules, and characters behaving as though earlier events never happened. 

# DOMAIN 12 — CONTINUITY, WORLD LOGIC & EMBODIED REALITY

## Domain purpose

Every statement a novel establishes can become part of its reality.

If the story establishes that:

- a journey requires three days;
- a character broke their left wrist;
- a city has one bridge;
- a particular spell requires blood;
- a family has been poor for decades;
- a door was locked;
- a character gave away their sword;
- two people met six months ago;
- someone does not know a secret;
- or a government punishes a particular crime,

later scenes inherit those facts until something changes them.

This creates a basic principle:

> Fiction generates obligations to its own past.

Continuity is therefore much more than remembering names.

It includes:

- time;
- space;
- objects;
- bodies;
- relationships;
- knowledge;
- economics;
- institutions;
- technology;
- magic;
- culture;
- geography;
- causality;
- and physical possibility.

The goal is not absolute realism.

A novel may contain:

dragons;

telepathy;

time travel;

immortal gods;

impossible architecture;

or dream logic.

Those things can be perfectly coherent.

The relevant question is:

> Does the fiction behave consistently according to the reality it has established?

The central distinctions are:

> Impossible is not the same as inconsistent.

And:

> A world rule is only meaningful if the story remembers when it matters.

---

# CT-01 — TEMPORAL CONTINUITY

## Core principle

Events should occupy a coherent timeline unless temporal instability is deliberately part of the work.

Track:

- dates;
- ages;
- elapsed time;
- travel time;
- recovery time;
- seasons;
- deadlines;
- pregnancies;
- school terms;
- political terms;
- historical events;
- and the order in which things happened.

## Common drift

Long generated fiction may gradually distort time.

Examples include:

characters behaving as though they have known each other for years after several weeks;

injuries healing implausibly quickly;

travel durations changing;

deadlines expanding or shrinking;

someone being seventeen across multiple years;

events described as “yesterday” despite intervening days;

relationships gaining far more history than the timeline allows.

The research identifies factual and temporal inconsistency as among the strongest long-form failure categories. 

## Why it may weaken fiction

Time determines:

- plausibility;
- relationship development;
- physical recovery;
- institutional response;
- character age;
- urgency;
- and causal possibility.

When the timeline becomes unstable, many other systems become unstable with it.

## Diagnostic questions

When does this happen?

How much time has passed since the previous event?

How long would travel realistically require under this world's rules?

How old is everyone now?

How long have these characters actually known each other?

Does the stated deadline still make sense?

Could all intervening events fit inside the available period?

## Better direction

Maintain an explicit story calendar for long works.

It need not appear in prose.

Track at minimum:

date/day;

location;

major events;

important durations;

deadlines;

and age-sensitive information.

## Valid exceptions

Dreams, time loops, nonlinear narration, unreliable memory, time dilation, time travel, mythic storytelling, and deliberately vague chronology may violate ordinary temporal expectations.

The system should then track the **special temporal rules** instead.

## Long-form warning signs

Frequent use of vague temporal language begins hiding contradictions.

Relationship intimacy grows faster than available time suggests.

Seasons or dates cease matching earlier information.

Characters describe events using durations inconsistent with the story calendar.

## Revision considerations

Fixing temporal continuity may require changing more than a date.

Time affects:

healing;

emotion;

knowledge;

logistics;

and development.

---

# CT-02 — SPATIAL CONTINUITY

## Core principle

Characters and objects occupy locations.

Movement should respect:

- position;
- distance;
- entrances;
- exits;
- orientation;
- geography;
- obstacles;
- and travel.

## Common drift

A character may:

leave a room and then speak from inside it;

cross a large distance instantly;

stand beside someone and suddenly appear at the doorway;

fight using geography that changes between paragraphs;

enter through a door that was previously blocked;

or continue a scene after a chapter break with everyone subtly repositioned.

These exact types of failures appear repeatedly in the source research. 

## Why it may weaken fiction

Readers mentally simulate scenes.

Spatial contradictions force them to rebuild that simulation.

This is especially disruptive in:

combat;

romance;

chases;

mysteries;

heists;

horror;

and tightly staged dialogue.

## Diagnostic questions

Where is everyone?

How did they get there?

What is between them?

Who can see whom?

Who can hear whom?

Where are the exits?

What is each person's orientation?

Does movement require time?

Does the geography remain stable?

## Better direction

For complicated scenes, maintain simple blocking internally.

This may be no more than:

A by window.

B seated at table.

C at door.

Sword on floor near B.

North exit blocked.

The prose does not need to explain all this.

The writer needs to know it.

## Valid exceptions

Surreal space, magical architecture, dreams, labyrinths, unreliable perception, teleportation, and impossible geometry may intentionally destabilize location.

Their instability should still follow whatever logic the story establishes.

## Long-form warning signs

Repeated subtle teleportation.

Confusing entrances and exits.

Action scenes impossible to map.

Characters forgetting how far apart locations are.

## Revision considerations

Spatial clarity does not require exhaustive choreography.

Only important spatial relationships need explicit tracking.

---

# CT-03 — OBJECT CONTINUITY

## Core principle

Important objects possess state.

An object can have:

- an owner;
- a location;
- a condition;
- contents;
- ammunition;
- charges;
- magical status;
- legal status;
- or sentimental significance.

Changes to that state should persist.

## Common drift

Objects may:

be handed over twice;

reappear after being lost;

be used after being destroyed;

change owner without transfer;

regain ammunition or magical charges;

move between locations without explanation;

or disappear whenever inconvenient.

The research specifically records repeated or impossible object transfers as a reader-visible continuity problem. 

## Why it may weaken fiction

Objects often participate directly in causality.

A missing key matters.

An unloaded weapon matters.

A lost phone matters.

A stolen letter matters.

If possession is unreliable, obstacles become unreliable.

## Diagnostic questions

Who has this now?

Where was it last seen?

What condition is it in?

Has it been consumed, damaged, charged, unloaded, copied, or altered?

Could this character realistically access it?

## Better direction

Track plot-relevant objects explicitly.

Low-value objects do not require bookkeeping.

Prioritize objects whose state constrains future action.

## Valid exceptions

Duplicating technology, conjuration, teleportation, magical inventories, unreliable narration, and similar mechanisms can alter normal object continuity.

## Long-form warning signs

Characters conveniently regain tools.

Weapons acquire unlimited resources.

Important documents repeatedly appear wherever needed.

## Revision considerations

Sometimes the easiest repair is not explanation but changing the later scene so the missing object remains missing.

Consequences can create better plot.

---

# CT-04 — PHYSICAL-STATE CONTINUITY

## Core principle

Bodies remember what happens to them.

Track significant:

- injuries;
- illness;
- exhaustion;
- intoxication;
- hunger;
- sleep deprivation;
- disability;
- pregnancy;
- wounds;
- scars;
- and physical limitations.

## Common drift

A character is severely injured during one scene.

Later they:

run;

fight;

carry weight;

sleep normally;

or behave pain-free

because the narrative has shifted attention elsewhere.

Another common failure is inconsistent injury severity.

A wound matters dramatically when inflicted but becomes functionally irrelevant afterward.

## Why it may weaken fiction

Physical stakes lose credibility.

Readers stop believing harm matters.

Danger becomes cosmetic.

## Diagnostic questions

What can this body currently do?

What movement hurts?

What recovery time is plausible in this world?

What treatment has occurred?

Is fatigue accumulating?

What compensatory behavior would appear?

Is this limitation affecting strategy?

## Better direction

Let physical state become part of decision-making.

Injury need not dominate every paragraph.

A hurt character may simply:

choose stairs differently;

avoid using one hand;

sit sooner;

delegate work;

or fail to sleep well.

## Valid exceptions

Magic, advanced medicine, supernatural regeneration, cybernetics, or established genre conventions may allow accelerated recovery.

The recovery mechanism then becomes part of world logic.

## Long-form warning signs

Injuries disappear between chapters.

Characters sustain repeated serious wounds without cumulative consequences.

Physical exhaustion exists only during action scenes.

## Revision considerations

Do not narrate pain constantly.

Continuity can be preserved through behavior and constraint.

---

# CT-05 — RELATIONSHIP CONTINUITY

## Core principle

Relationships possess state just as objects and bodies do.

Track changes in:

- trust;
- intimacy;
- resentment;
- obligation;
- suspicion;
- attraction;
- familiarity;
- hostility;
- and dependence.

## Common drift

After a meaningful scene, the next interaction reverts to the relationship's earlier template.

Characters:

become intimate, then act like acquaintances;

betray each other, then cooperate normally;

resolve conflict, then repeat it unchanged;

reveal secrets, then return to previous conversational distance.

## Why it may weaken fiction

Emotional scenes become disposable.

Relationships cease to accumulate history.

This is one of the broader “reset” failures repeatedly identified in the research.

## Diagnostic questions

What changed last time these people interacted?

What does each now expect?

What became awkward?

What became easier?

What trust was gained or lost?

What new knowledge exists between them?

## Better direction

Track significant relationship state changes just as carefully as physical facts.

A relationship ledger may include:

current trust;

known secrets;

unresolved grievances;

recent intimacy;

obligations;

and boundaries.

## Valid exceptions

Relationships genuinely regress.

People consciously pretend events did not happen.

Some dysfunctional relationships repeat patterns.

The repetition should contain memory of earlier iterations.

## Long-form warning signs

Same argument, same positions, same resolution.

Relationship milestones have little influence on later dialogue.

## Revision considerations

Relationship continuity is often better shown through altered interaction than explicit recap.

---

# CT-06 — WORLD-RULE CONTINUITY

## Core principle

Established systems should behave consistently enough for characters and readers to reason about them.

Systems include:

- magic;
- technology;
- law;
- religion;
- economics;
- government;
- military organization;
- supernatural rules;
- biology;
- and social convention.

## Common drift

A rule is established when dramatically useful and quietly ignored later.

Examples:

magic previously requires a cost but later does not;

vampires cannot cross a threshold until a scene needs one to;

technology solves one problem but is inexplicably unavailable for another;

law enforcement behaves differently depending on plot convenience;

social taboos disappear when inconvenient.

## Why it may weaken fiction

Rules create expectations.

If expectations cannot be trusted, strategic thinking becomes pointless.

Readers stop asking:

> How will they solve this?

and begin asking:

> Which rule will the story ignore?

## Diagnostic questions

What rule applies here?

Has the story established an exception?

Would characters know about that exception?

What cost or limitation remains?

Does this solution contradict an earlier obstacle?

If the system can solve this problem, why did it not solve similar earlier problems?

## Better direction

Treat world rules as causal infrastructure.

Exceptions are allowed.

But useful exceptions usually:

have causes;

carry costs;

or reveal that the earlier understanding was incomplete.

## Valid exceptions

Mystery-based magic, divine intervention, surreal fiction, myth, horror, unreliable world models, and deliberately unstable reality may resist complete systemization.

Even then, tonal and thematic consistency may substitute for mechanical rules.

## Long-form warning signs

Powers expand exactly when needed.

Institutions behave inconsistently.

Previously important limitations vanish.

Characters fail to use obvious established systems.

## Revision considerations

Do not over-systematize soft worldbuilding.

Consistency can involve **mood, consequence, and narrative principle**, not only explicit mechanics.

---

# CT-07 — NUMERICAL CONTINUITY

## Core principle

Numbers create hard constraints.

Track important:

- ages;
- dates;
- money;
- distances;
- travel durations;
- populations;
- ranks;
- ammunition;
- resource quantities;
- scores;
- measurements;
- prices;
- and percentages.

## Common drift

Numbers gradually shift because prose generation treats them like ordinary descriptive details.

A twenty-mile journey later becomes a two-hour walk.

A character's age changes.

A debt changes size.

A unit has thirty soldiers, then fifty casualties.

A building gains floors.

A pregnancy timeline ceases to align.

## Why it may weaken fiction

Numerical contradiction is unusually visible because it can often be verified immediately.

It also damages:

logistics;

world scale;

economics;

and timeline integrity.

## Diagnostic questions

Has this number already been established?

Does it imply consequences elsewhere?

Is exact precision necessary?

Would a range be safer and more natural?

Can the number be calculated from other facts?

## Better direction

Use exact numbers intentionally.

When precision matters, record it.

When precision does not matter, avoid inventing unnecessary exact values that later become continuity obligations.

## Valid exceptions

Unreliable narrators, estimates, rumor, propaganda, and characters with incomplete information may give conflicting numbers.

The contradiction should belong to perspective rather than accidental continuity failure.

## Long-form warning signs

Ages, distances, prices, and durations drift.

Exact quantities appear frequently without narrative need.

## Revision considerations

Check dependent facts after changing a number.

Moving a city farther away changes travel time too.

---

# CT-08 — CONSEQUENCE ECOLOGY

## Core principle

Large events often affect more than the protagonist and immediate scene.

A functioning fictional world contains systems that respond.

## Common drift

A city is attacked.

A king dies.

A company collapses.

Magic becomes public.

A bridge is destroyed.

A dangerous criminal escapes.

Yet only the main cast seems meaningfully affected.

## Why it may weaken fiction

The world feels narrow and staged.

Large-scale events do not produce large-scale ripples.

## Diagnostic questions

Who else is affected?

What does government do?

What does trade do?

What do ordinary people do?

What rumors spread?

What becomes scarce?

What becomes dangerous?

What new opportunity appears?

What group benefits?

## Better direction

Consider consequences across several possible layers:

personal;

social;

economic;

political;

institutional;

environmental;

cultural.

Not all need to appear.

The model simply ensures major events exist inside a wider ecology.

## Valid exceptions

Very narrow POV may legitimately hide broad consequences.

Small-scale stories may focus intentionally on personal experience.

## Long-form warning signs

World-changing events affect only named characters.

Cities recover instantly.

Institutions disappear after serving one plot function.

## Revision considerations

One or two well-chosen downstream consequences can imply a much larger responsive world.

---

# CT-09 — DEVELOPMENTAL PLAUSIBILITY

## Core principle

Characters should behave broadly consistently with their:

- age;
- education;
- culture;
- experience;
- profession;
- developmental stage;
- and life history.

This does not mean stereotypes.

It means capability and behavior should have roots.

## Common drift

Children speak and reason like adults.

Beginners understand expert systems immediately.

People acquire difficult skills too quickly.

Characters from isolated cultures possess modern conceptual frameworks without explanation.

Professionals ignore obvious domain knowledge.

## Why it may weaken fiction

Character history stops constraining character possibility.

The model substitutes generic competence for developed capability.

## Diagnostic questions

Could this person plausibly know this?

How much practice would this require?

What mistakes would someone at this stage make?

What developmental limitations apply?

What does expertise change about perception?

What does inexperience prevent them from noticing?

## Better direction

Treat expertise and development as gradients.

A beginner need not be incompetent.

A child need not be foolish.

An expert need not be infallible.

Different stages produce different kinds of strengths and errors.

## Valid exceptions

Prodigies, supernatural abilities, accelerated training, implanted knowledge, reincarnation, and unusual upbringing may justify atypical competence.

The exceptional ability should remain part of the established character/world logic.

## Long-form warning signs

Skill acquisition follows plot convenience.

Young characters repeatedly possess adult emotional articulation.

Everyone learns at approximately the same speed.

## Revision considerations

Research may be necessary for specialized occupations, ages, disabilities, technologies, or cultural practices.

When uncertain, avoid pretending detailed expertise.

---

# CT-10 — CANON AUTHORITY

## Core principle

Once the story has established something as canon, later invention should normally respect it.

Canon includes more than encyclopedic facts.

It includes:

- previous events;
- world rules;
- characterization;
- geography;
- history;
- relationships;
- institutional facts;
- and previously established limitations.

## Common drift

The model generates a locally useful idea that contradicts earlier material.

Because the new idea works well in isolation, the contradiction may go unnoticed.

This creates a dangerous long-form pattern:

good scene locally;

broken novel globally.

## Why it may weaken fiction

Readers maintain memory.

A contradiction can retroactively damage earlier scenes.

If canon becomes flexible whenever inconvenient, investment in rules and setup decreases.

## Diagnostic questions

Has this fact already been established?

Does the new development contradict or merely expand it?

If it contradicts it, is the earlier information being deliberately revealed as false?

Who knew the old version?

What other scenes depend on that fact?

## Better direction

Use an explicit canon hierarchy.

### Hard canon

Directly established facts that should not change casually.

### Soft canon

Implied facts that can be refined.

### Character belief

May be incorrect.

### Rumor

May be unreliable.

### Planned but unwritten material

Not yet canon and therefore still flexible.

This distinction greatly reduces accidental contradiction.

## Valid exceptions

Retcons exist.

Revelations can overturn earlier understanding.

Unreliable narrators can establish false apparent canon.

The key is that contradiction becomes **story information**, not authorial accident.

## Long-form warning signs

New chapters override old limitations.

Character biographies shift.

World history changes.

Earlier scenes become impossible under later rules.

## Revision considerations

When changing established canon intentionally, audit dependent scenes.

One changed fact can affect many narrative systems.

---

# DOMAIN 12 — CROSS-LENS GUIDANCE

## Continuity is a network, not a checklist

Continuity categories interact.

Changing time affects:

age;

injury recovery;

relationships;

travel;

and deadlines.

Changing location affects:

knowledge;

weather;

transport;

and who can plausibly appear.

Changing a world rule affects:

earlier conflicts;

future strategy;

institutional behavior;

and character competence.

Therefore, continuity should be understood as **linked state**.

---

## The disappearing-cost problem

AI fiction may correctly establish that something has a cost and then gradually stop paying that cost.

Examples:

magic exhausts the user;

travel takes time;

injury limits mobility;

political action damages reputation;

lying erodes trust.

The first few appearances respect the cost.

Later repetition turns it into background.

Watch for constraints weakening through familiarity.

---

## Local correctness versus global correctness

A sentence can be perfectly correct locally:

> She drew her sword.

But if she lost the sword two chapters earlier, the sentence is globally wrong.

A character can give a perfectly believable speech.

But if they do not know the information being discussed, the scene is globally wrong.

Long fiction requires both levels.

---

## Soft systems still need consistency

Not every world needs numerical magic rules or encyclopedic lore.

A fairy-tale world may operate by symbolic logic.

A horror world may intentionally resist explanation.

A dreamlike novel may contradict ordinary physics.

Consistency can therefore mean:

mechanical consistency;

psychological consistency;

symbolic consistency;

tonal consistency;

or thematic consistency.

The system should identify what kind of reliability the story actually promises.

---

## Canon versus planning

An outline is not automatically canon.

A discarded idea is not canon.

An early brainstorm is not canon.

Only material deliberately designated as binding—or already established in the text—should constrain future drafting.

This prevents the project from becoming trapped by obsolete planning notes.

---

# DOMAIN 12 — CONTINUITY LEDGER

For long novels, maintain an active continuity ledger.

Suggested sections:

### Timeline
Dates, elapsed time, ages, deadlines, durations.

### Locations
Where major characters are and how locations connect.

### Character physical state
Injuries, illness, exhaustion, appearance changes, equipment.

### Important objects
Ownership, location, condition, charges, contents.

### Character knowledge
Who knows, suspects, misunderstands, or conceals important information.

### Relationship state
Trust, hostility, intimacy, obligations, secrets.

### World rules
Magic, technology, law, supernatural rules, institutional limits.

### Resources
Money, food, weapons, vehicles, political capital, personnel.

### Open consequences
Events whose effects have not fully arrived yet.

### Canon facts
Hard established information that future prose must respect.

This ledger should stay concise enough to remain usable.

---

# DOMAIN 12 — SCENE CONTINUITY SNAPSHOT

Before drafting a complicated scene, establish:

### Time
When is this?

### Location
Where exactly?

### Present characters
Who is physically here?

### Positions
Where are they relative to one another when relevant?

### Knowledge
What does each know?

### Objects
Who possesses what?

### Physical state
Who is injured, tired, armed, restrained, wet, intoxicated, etc.?

### Relationship state
What recent history affects interaction?

### Environmental conditions
Weather, visibility, noise, crowding, danger, temperature.

### World constraints
What rules apply?

This snapshot prevents many continuity failures before prose begins.

---

# DOMAIN 12 — POST-SCENE STATE UPDATE

After an important scene, update only what changed.

For example:

### Time advanced
+3 hours.

### Location
Mara → east tower.

### Injury
Jon → fractured rib, untreated.

### Object
Black key → now held by Mara.

### Knowledge
Mara now knows Jon lied.

Jon does not know Mara knows.

### Relationship
Mara → trust in Jon reduced.

### World state
East gate destroyed.

### Open consequence
City guards will discover the gate destruction by morning.

This creates a persistent story state the next scene can inherit.

---

# DOMAIN 12 — CONTRADICTION TRIAGE

Not every apparent contradiction requires rewriting.

When conflict appears between two facts, classify it.

### True contradiction
Both statements claim objective truth and cannot coexist.

Repair required.

### Perspective difference
Two characters believe different things.

Potentially useful.

### Rumor discrepancy
Information sources conflict.

Potentially useful.

### Character error
Someone remembers or states something incorrectly.

Potentially useful.

### Deliberate mystery
The inconsistency is evidence that something is wrong.

Potentially useful.

### Canon evolution
Later information legitimately revises earlier understanding.

Clarify if necessary.

The system should avoid “correcting” intentional contradictions that belong to story design.

---

# DOMAIN 12 — WORLD-CONSEQUENCE TEST

When a major event occurs, ask selectively:

### Physical
What material changed?

### Human
Who was hurt, displaced, enriched, protected, or endangered?

### Economic
What became scarce, valuable, cheap, inaccessible, or disrupted?

### Political
Who gains or loses leverage?

### Legal
What authority responds?

### Social
What reputation or rumor changes?

### Cultural
Does the event alter belief, ritual, prejudice, or identity?

### Environmental
What lasting physical effects remain?

### Strategic
What options become available or impossible?

Not every event requires all nine.

The purpose is to prevent a large event from existing only for the protagonists.

---

# DOMAIN 12 — FANTASY AND SCIENCE-FICTION RULE TEST

For extraordinary systems, track:

### Capability
What can it do?

### Limitation
What can it not do?

### Cost
What must be spent or risked?

### Access
Who can use it?

### Knowledge
Who understands it?

### Reliability
How consistently does it work?

### Countermeasure
What can resist it?

### Social consequence
How has its existence altered society?

### Historical consequence
How has it altered the past?

### Edge cases
Where is understanding incomplete?

This is not a demand for hard magic or hard science fiction.

Even mysterious systems benefit from knowing which questions the story intends to answer and which it intentionally leaves uncertain.

---

# DOMAIN 12 — PRACTICAL REVIEW LENS

When reviewing continuity, ask:

### 1. Does the timeline still work?

Check time and age.

### 2. Does the geography still work?

Check position and travel.

### 3. Does everyone possess the correct objects?

Check state and ownership.

### 4. Do bodies remember injuries and exhaustion?

Check physical state.

### 5. Do relationships remember?

Check emotional/social continuity.

### 6. Do world rules still apply?

Check systems.

### 7. Do important numbers agree?

Check calculations.

### 8. Does the wider world react where appropriate?

Check consequence ecology.

### 9. Are abilities and behavior plausible for the character's development?

Check age, education, and expertise.

### 10. Is new invention contradicting canon?

Check established facts.

### 11. Is an apparent contradiction actually intentional?

Protect unreliable narration, mystery, and perspective.

### 12. What changed in this scene that the next scene must inherit?

Update state.

---

# DOMAIN 12 — CENTRAL REMINDER

A novel creates reality one sentence at a time.

Once something becomes true in that reality, later prose inherits it.

Therefore ask:

> When is this happening?

> Where is everyone?

> What are they carrying?

> What condition are their bodies in?

> What does each person know?

> What happened between these characters previously?

> Which world rules apply?

> What consequences are still active?

> What has become permanently true?

And above all:

> What did the story already promise about its own reality?

Continuity is not bureaucratic bookkeeping.

It is what allows earlier chapters to remain **real** after later chapters are written.

The goal is not perfect realism.

The goal is **persistent reality**.

When readers trust that the story remembers itself, choices acquire weight, danger acquires credibility, relationships acquire history, and the world begins to feel as though it continues existing beyond the current paragraph.

That completes **Domain 12**. It directly addresses one of the strongest patterns in the research: polished local prose does not compensate for contradictions in temporal, spatial, factual, character, or world-state continuity. 

**Remaining:**
1. Domain 13 — Theme, Symbolism, Genre & Artistic Identity

## User

next

## ChatGPT

I’m moving into the final domain now. This one should tie the entire system together by protecting the novel’s own thematic logic and artistic identity from generic “good writing” defaults.

## ChatGPT

This is the final domain: **Domain 13 — Theme, Symbolism, Genre & Artistic Identity**. It sits at the top of the hierarchy established by the research. The source describes **Level 7 — artistic identity** as the absence or presence of a “peculiar, coherent sensibility” controlling what a book notices, ignores, emphasizes, finds funny, finds ugly, refuses to explain, and leaves unresolved. It also identifies homogenized authorial voice, generic high-probability plot solutions, pseudo-depth, excessive significance, and loss of idiosyncrasy as deeper problems than isolated stylistic “AI tells.” 

# DOMAIN 13 — THEME, SYMBOLISM, GENRE & ARTISTIC IDENTITY

## Domain purpose

The previous domains protect:

- prose;
- description;
- emotion;
- dialogue;
- character;
- knowledge;
- relationships;
- scenes;
- pacing;
- plot;
- and continuity.

But a technically coherent novel can still feel generic.

It can have:

good sentences;

consistent characters;

functional scenes;

logical plotting;

accurate continuity;

and satisfying pacing

while lacking a strong sense that **this particular book sees the world in a particular way**.

That final layer is artistic identity.

The research identifies this as the deepest level of the problem:

> the absence of a peculiar, coherent sensibility controlling what the book notices, ignores, emphasizes, finds funny, finds ugly, refuses to explain, or chooses to leave unresolved.

This matters because artistic identity is not a cosmetic style layer placed on top of a completed story.

It influences selection at every level.

It affects:

- which characters receive sympathy;
- what kinds of details attract attention;
- what violence looks like;
- what love means;
- what the story treats seriously;
- what the story mocks;
- which questions receive answers;
- what kinds of beauty recur;
- how power is portrayed;
- what the ending refuses to repair;
- and what remains in the reader's mind afterward.

The goal of this domain is therefore not:

> Make the story unique at all costs.

Nor:

> Avoid tropes.

Nor:

> Make everything symbolic.

Nor:

> Make the story morally ambiguous.

The goal is:

> Protect the individual novel's governing sensibility from being replaced by generic literary competence.

The central distinctions are:

> Theme is not the same as a message.

> Symbolism is not the same as assigning meaning to objects.

> Genre is not the same as a checklist.

> Originality is not the same as unfamiliarity.

> Artistic identity is not the same as stylistic eccentricity.

And most importantly:

> The novel's own priorities outrank generalized writing advice.

---

# AR-01 — THEME THROUGH EMBODIMENT

## Core principle

Theme is often strongest when it emerges from the accumulated relationships among:

- character choices;
- consequences;
- conflicts;
- images;
- institutions;
- repeated situations;
- and outcomes.

A theme need not be explicitly stated to exist.

## Common drift

Generated fiction can recognize a thematic subject and then repeatedly verbalize it.

If the story concerns:

freedom;

grief;

identity;

power;

family;

sacrifice;

revenge;

love;

or destiny,

characters and narration may repeatedly discuss those ideas directly.

The language may sound profound while the story itself does relatively little with the idea.

This overlaps with the source research's complaint about **pseudo-depth**: abstract language can create the shape of significance without committing to sufficiently specific meaning.

## Why it may weaken fiction

The novel begins explaining its own thematic interpretation.

Instead of discovering meaning through story, the reader receives thematic commentary.

The result can feel like a thesis illustrated by fictional examples.

## Diagnostic questions

Where does this theme actually appear in the story's events?

Which characters embody conflicting positions?

What consequences test those positions?

Does the theme exist if the explicit thematic statements are removed?

Are characters discussing the theme because they naturally would, or because the novel wants to articulate its meaning?

## Better direction

Let thematic questions become dramatically real.

If the theme concerns loyalty, create situations where loyalty:

helps;

harms;

conflicts with truth;

conflicts with justice;

protects someone undeserving;

or demands sacrifice.

Then theme emerges from what loyalty **does**, not merely from what characters say about loyalty.

## Valid exceptions

Philosophical fiction, allegory, satire, religious fiction, political fiction, metafiction, and highly reflective literary fiction may discuss themes directly.

Explicit thematic thought is not automatically inferior.

## Long-form warning signs

Characters repeatedly deliver conclusions that sound like the novel's thesis.

Major scenes end with thematic summarization.

Different characters independently articulate similar philosophical conclusions.

Abstract thematic vocabulary appears more often than concrete thematic consequence.

## Revision considerations

Do not remove every thematic statement.

Instead ask whether statement and embodiment are doing different work.

---

# AR-02 — THEMATIC MULTIPLICITY

## Core principle

A novel may explore an idea through multiple perspectives rather than forcing every event toward one simple thematic answer.

Theme can contain argument.

## Common drift

Generated fiction may move toward thematic neatness.

The story raises a difficult question and gradually arranges characters and consequences so that one interpretation becomes clearly correct.

Opposing perspectives are:

defeated;

revealed as ignorant;

shown to be morally compromised;

or converted.

## Why it may weaken fiction

The world begins feeling designed to prove a conclusion.

Character disagreement becomes pedagogical rather than genuinely ideological.

Complex subjects can become morally or psychologically tidy.

## Diagnostic questions

What serious counterargument exists?

Can an opposing character be partly right?

What does the protagonist's preferred value cost?

What situations expose limitations in the apparent thematic answer?

Are different characters genuinely living different interpretations?

## Better direction

Let important themes survive contact with contradiction.

A story about ambition may show:

ambition destroying one person;

saving another;

liberating a third;

and leaving a fourth morally compromised but materially successful.

The novel may still have a perspective.

Complexity does not require neutrality.

## Valid exceptions

Fables, propaganda, didactic fiction, morality tales, children's fiction, satire, and strongly polemical works may intentionally present clear moral positions.

## Long-form warning signs

Characters who disagree with the thematic center become increasingly foolish or malicious.

Every major subplot confirms the same lesson.

Complicated dilemmas resolve into simple statements.

## Revision considerations

Do not create false equivalence merely to appear sophisticated.

Some positions deserve rejection.

The question is whether the novel has earned that rejection dramatically.

---

# AR-03 — SYMBOLIC RESTRAINT

## Core principle

Symbols gain power from recurrence, context, transformation, and association.

They do not always require explanation.

## Common drift

Generated prose may identify an object or image as meaningful and then repeatedly interpret it.

A door becomes freedom.

A cracked mirror becomes fractured identity.

Rain becomes grief.

Fire becomes desire.

A necklace becomes memory.

Each recurrence reminds the reader what the symbol means.

## Why it may weaken fiction

Symbolism becomes an annotation system.

Instead of gaining meaning through accumulation, the symbol arrives pre-decoded.

The reader has less interpretive work to perform.

This overlaps with the source research's repeated concern about prose that **pre-interprets itself**.

## Diagnostic questions

Has the association already been established?

Does this recurrence change the symbol's meaning?

Could the image appear without explanation?

Is the object meaningful to the character, narrator, reader, or all three?

Does the symbol possess more than one possible association?

## Better direction

Allow symbols to accumulate.

A recurring house may initially mean safety.

Later it may suggest confinement.

Later still it may represent something lost.

The object remains the same while the relationship to it changes.

## Valid exceptions

Mythic, allegorical, religious, children's, surreal, and deliberately symbolic fiction may use overt symbolism.

Some characters consciously interpret symbols as part of their psychology.

## Long-form warning signs

The narration repeatedly tells readers what recurring objects represent.

Motifs stay semantically fixed.

Symbolic imagery arrives primarily during moments already marked as emotionally important.

## Revision considerations

Do not hide symbolism simply to make it subtle.

The objective is not obscurity.

It is allowing significance to live inside the story rather than only inside explanation.

---

# AR-04 — MOTIF EVOLUTION

## Core principle

Repeated images, phrases, objects, situations, or sensory patterns can gain power when their meaning changes as the novel changes.

## Common drift

Generated prose may successfully establish motifs but repeat them without transformation.

The same:

image;

phrase;

gesture;

weather pattern;

object;

color;

or metaphor

returns with essentially the same emotional function.

Repetition is mistaken for development.

## Why it may weaken fiction

The motif becomes decorative branding.

It reminds the reader of earlier material without adding anything new.

## Diagnostic questions

What did this motif mean initially?

What does it mean now?

Has context altered it?

Who notices it differently?

Can the same image produce an opposite feeling later?

Does recurrence reflect actual development?

## Better direction

Let motifs inherit history.

A song may begin as:

comfort,

become associated with betrayal,

and later become something the protagonist deliberately reclaims.

The recurrence becomes narrative movement.

## Valid exceptions

Static motifs can deliberately create inevitability, ritual, obsession, dread, or thematic fixation.

## Long-form warning signs

Every recurrence triggers the same emotional interpretation.

Repeated images appear because they are aesthetically associated with the novel rather than because the moment activates them.

## Revision considerations

Before repeating a motif, ask:

> Why is its return different now?

If it is not different, determine whether simple repetition itself is the intended effect.

---

# AR-05 — GENRE-PROMISE AWARENESS

## Core principle

Genre creates expectations.

Those expectations can involve:

- emotional experience;
- narrative structure;
- type of conflict;
- degree of explanation;
- pacing;
- resolution;
- world logic;
- or particular forms of payoff.

A novel may fulfill, reinterpret, delay, combine, or reject those expectations.

It should ideally know which it is doing.

## Common drift

Generated fiction may reproduce genre surface markers without understanding the deeper reader promise.

A mystery contains:

clues;

a detective;

secrets;

and suspects,

but the solution is not fairly supported.

A romance contains attraction and intimacy but does not adequately develop the central relationship.

Progression fantasy contains powers and advancement while progress lacks meaningful strategic consequence.

Horror contains darkness and threatening imagery without sustained dread or vulnerability.

## Why it may weaken fiction

The story looks like the genre without delivering the experience readers came for.

Genre becomes décor.

## Diagnostic questions

What experience is this genre promising?

Which expectations are essential?

Which are optional conventions?

What payoff is the reader likely anticipating?

Is the story deliberately breaking that expectation?

If so, what replaces the expected pleasure?

## Better direction

Distinguish surface convention from underlying function.

For example:

A romance does not need every common romance trope.

But if presented as a genre romance, the central relationship and its emotional resolution normally require genuine structural importance.

## Valid exceptions

Cross-genre, experimental, literary, deconstructive, and anti-genre works may deliberately frustrate standard expectations.

## Long-form warning signs

The novel adopts a genre's imagery and vocabulary while neglecting its central dramatic contract.

Genre conventions appear because they are statistically typical rather than because the story needs them.

## Revision considerations

Do not turn genre guidance into mandatory beat sheets.

Genre expectations are reader contracts, not universal formulas.

---

# AR-06 — CONVENTION WITH SPECIFICITY

## Core principle

Familiar structures, tropes, and archetypes become distinctive through specific execution.

The presence of a trope does not make fiction generic.

## Common drift

When solving narrative problems, generated fiction may move toward high-probability genre solutions.

The source research identifies this directly: an unusual premise can become increasingly conventional when the system must decide:

what happens next;

how characters reconcile;

how a villain's arc ends;

what explains the mystery;

or how the protagonist overcomes an insecurity.

The problem is often not the trope itself.

It is that the implementation belongs more strongly to the genre average than to the individual novel.

## Why it may weaken fiction

The story becomes predictable at the development level even if its premise is original.

Readers feel they have encountered the same narrative machinery elsewhere.

## Diagnostic questions

What is the conventional solution here?

Does this particular story support it?

Why would these specific characters produce this version?

How does this world alter the trope?

What consequence makes the familiar event belong uniquely here?

Would avoiding the trope actually damage genre satisfaction?

## Better direction

Use conventions deliberately.

A mentor can die.

A villain can betray.

Enemies can become lovers.

A chosen hero can discover hidden power.

The question is:

> Why does it happen this way, to these people, under these conditions?

Specific causality transforms convention.

## Valid exceptions

Formula can itself be the pleasure.

Cozy mystery, category romance, progression fantasy, adventure serials, fairy tales, and many other genres may embrace recognizable structures deliberately.

## Long-form warning signs

Major turns can be predicted from genre familiarity alone.

Character-specific motives are weaker than trope-specific expectations.

Different projects repeatedly converge on similar solutions.

## Revision considerations

Do not force novelty merely to surprise readers.

A strange alternative can be worse than a familiar event executed with precision.

---

# AR-07 — AESTHETIC COHERENCE

## Core principle

A novel can develop recurring aesthetic priorities.

These may involve:

- what it finds beautiful;
- what it finds disgusting;
- what it treats humorously;
- what kinds of images recur;
- how violence is represented;
- how bodies are described;
- how nature functions;
- how technology feels;
- what receives lyrical attention;
- what remains stark and plain.

This creates a governing aesthetic rather than random “literary” ornament.

## Common drift

The source research distinguishes human purple prose driven by an identifiable obsession from generic embellishment that appears because it sounds literary.

Generated writing may be:

ornate in one paragraph;

minimalist in another;

Gothic during a dramatic scene;

therapeutic during dialogue;

cinematic during combat;

and pseudo-poetic at chapter endings,

without those modes cohering into a recognizable artistic logic.

## Why it may weaken fiction

The prose contains techniques but lacks an aesthetic center.

Style feels selected moment by moment from a toolbox rather than governed by a book-specific sensibility.

## Diagnostic questions

What does this novel consistently find worthy of attention?

What kinds of beauty does it notice?

What does it describe plainly?

What does it refuse to romanticize?

Where does humor come from?

What imagery feels native to this work?

Are stylistic shifts intentional?

## Better direction

Identify aesthetic tendencies without turning them into rigid rules.

A novel may, for example:

describe machinery sensually;

treat violence with clinical plainness;

find humor in bureaucracy;

linger over food but barely describe clothing;

use nature imagery only when characters are isolated.

Those preferences gradually create identity.

## Valid exceptions

Deliberately fragmented, polyphonic, postmodern, anthology-like, multi-POV, or genre-hybrid works may use radical aesthetic variation.

The variation itself may become the governing principle.

## Long-form warning signs

The prose changes aesthetic personality according to whatever kind of scene is being generated.

“Beautiful writing” sounds interchangeable with beautiful writing from unrelated stories.

Distinctive early stylistic choices gradually normalize.

## Revision considerations

Coherence does not require sameness.

A governing aesthetic can contain contrast.

---

# AR-08 — IDIOSYNCRASY PRESERVATION

## Core principle

Unusual but functional qualities should not automatically be normalized during revision.

The source research emphasizes that human writing often becomes memorable partly through irregularity:

- odd rhythms;
- unusual syntax;
- obsessions;
- strange analogies;
- regional language;
- professional vocabulary;
- unusual omissions;
- peculiar humor;
- or repeated aesthetic interests.

## Common drift

AI-assisted revision may improve:

grammar;

smoothness;

clarity;

balance;

sentence flow;

and conventional elegance

while gradually removing the features that made the prose identifiable.

The source research directly connects AI assistance with concerns about linguistic homogenization and altered signals of author identity.

## Why it may weaken fiction

The book becomes technically safer and artistically less specific.

A memorable voice may become an efficient one.

## Diagnostic questions

Is this unusual phrase genuinely confusing?

Or merely unconventional?

Does this repetition belong to the voice?

Is this awkwardness expressive?

Would smoothing the sentence remove personality?

Is the revision making this work sound more like other competent fiction?

## Better direction

Distinguish:

error;

difficulty;

and idiosyncrasy.

Correct errors.

Clarify accidental difficulty.

Protect deliberate or productive irregularity.

## Valid exceptions

Some unusual habits genuinely damage readability.

“Distinctive” should not become a defense against revision.

## Long-form warning signs

Later chapters become smoother but less recognizable.

Every character becomes easier to read but less individual.

Revision repeatedly selects the most conventional formulation.

## Revision considerations

When choosing between two equally clear sentences, the more work-specific sentence may be preferable to the more generally polished one.

---

# AR-09 — INTENTIONAL OMISSION & UNRESOLVED SPACE

## Core principle

A novel is partly defined by what it chooses **not** to explain, answer, reconcile, or resolve.

Unresolved material can create:

- ambiguity;
- mystery;
- realism;
- emotional residue;
- thematic openness;
- or lasting reader participation.

## Common drift

Generated fiction tends toward completion.

Questions receive answers.

Characters articulate motives.

Symbols are decoded.

Conflicts move toward understanding.

Themes become summarized.

The source research identifies this explanatory compulsion repeatedly at sentence, emotional, dialogue, and narrative levels.

At the artistic level, the result can be a novel that leaves very little unclaimed by explanation.

## Why it may weaken fiction

Meaning becomes closed.

The reader receives an increasingly complete interpretation of the novel from the novel itself.

Some of the most memorable tensions may disappear once everything is made explicit.

## Diagnostic questions

Does the reader actually need this answer?

Would ambiguity strengthen or weaken the work?

Is the unresolved element central enough that omission would feel like failure rather than intention?

Does the genre promise an answer?

Can two interpretations remain productively alive?

What does the ending gain by refusing closure here?

## Better direction

Distinguish between:

**unresolved by design**

and

**forgotten by accident**.

The first can be powerful.

The second is usually a continuity or payoff failure.

## Valid exceptions

Mystery, puzzle fiction, romance, procedural fiction, and other genres may owe readers particular forms of resolution.

Explicit closure can also be aesthetically powerful.

## Long-form warning signs

Every significant ambiguity eventually receives explanation.

Every relationship receives a final status.

Every motif receives interpretation.

Every major character receives closure.

## Revision considerations

Do not manufacture ambiguity after the fact.

Unresolved space works best when the novel's structure makes the omission feel meaningful.

---

# AR-10 — WORK-SPECIFIC ARTISTIC IDENTITY

## Core principle

The highest-level question is whether the novel develops a recognizable sensibility that belongs to itself.

Artistic identity emerges from repeated acts of selection.

It includes:

what the novel notices;

what it ignores;

what it lingers over;

what it compresses;

what it finds funny;

what it finds frightening;

what it treats with tenderness;

what it treats with disgust;

what it refuses to sentimentalize;

what it leaves unresolved;

and what kinds of contradiction it repeatedly returns to.

## Common drift

Generated fiction may make individually reasonable choices while lacking a coherent hierarchy among them.

The story borrows:

a little lyricism;

a little snark;

a little psychological insight;

a little cinematic drama;

a little genre convention;

a little symbolism;

a little moral reflection.

Each element is competent.

Together they may express no particular governing sensibility.

This is the source research's **Level 7 failure**.

## Why it may weaken fiction

The book becomes substitutable.

Readers may enjoy individual moments without sensing an intelligence controlling the whole.

This helps explain descriptions such as:

generic;

soulless;

sterile;

technically good but aesthetically bad;

or “something feels off.”

These terms are subjective, but the source research finds that readers often use them in response to cumulative failures of narrative selection and identity rather than one detectable phrase.

## Diagnostic questions

What does this novel care about unusually strongly?

What does it consistently refuse?

What does it notice that similar novels might ignore?

What contradictions fascinate it?

What kind of humor belongs here?

What does it find beautiful?

What makes it uncomfortable?

What does it allow to remain unexplained?

Could several paragraphs be moved into an unrelated novel with minimal change?

What would disappear if the prose were optimized toward generic “good writing”?

## Better direction

Protect a work-specific identity across all other domains.

This may include:

specific priorities;

recurring tensions;

favored forms of observation;

unusual emotional restraint;

particular humor;

a distinctive relationship to genre;

or deliberate areas of silence.

The goal is not to invent eccentricity.

It is to discover what this story repeatedly chooses and protect that pattern.

## Valid exceptions

Some fiction intentionally aims for transparent, conventional, highly accessible narration.

Artistic identity can still emerge through:

plot;

character;

moral stance;

structure;

selection;

or genre handling

rather than conspicuous prose style.

## Long-form warning signs

The novel gradually becomes more generically competent as it continues.

Distinctive early choices disappear.

Unrelated characters and scenes all receive the same aesthetic treatment.

The book can describe everything but seems to prefer nothing.

## Revision considerations

Do not ask only:

> Is this good?

Also ask:

> Is this ours?

---

# DOMAIN 13 — CROSS-LENS GUIDANCE

## Theme versus message

A message can often be reduced to a proposition:

> Power corrupts.

Theme is larger.

A novel may explore power through:

ambition;

fear;

responsibility;

sexual attraction;

politics;

parenthood;

violence;

religion;

and dependency.

Different characters may embody different parts of that inquiry.

The novel does not always need to produce one sentence explaining what it “believes.”

---

## Symbolism versus decoration

A repeated image is not automatically symbolic.

A symbolic object is not automatically good.

The useful question is:

> Does the image accumulate relationships to character, event, and meaning?

If not, it may simply be décor.

Décor can still be valuable.

Not everything must carry symbolic weight.

---

## The over-significance problem

The source research repeatedly finds that generated prose can treat too much material as meaningful.

At the artistic level, this creates a particular danger:

everything becomes a symbol.

Every storm reflects emotion.

Every scar represents history.

Every door represents possibility.

Every broken object represents a broken relationship.

Every recurring color demands interpretation.

A world in which everything means something eventually makes meaning feel mechanical.

Sometimes a cup is simply the cup someone happens to be drinking from.

---

## Theme announcement

Theme becomes especially conspicuous when several domains combine:

characters explain themselves perfectly;

dialogue resolves philosophical disagreement;

symbols are decoded;

the narrator summarizes significance;

and the ending confirms the moral conclusion.

Each choice can work independently.

Together they may make the story feel as though it is presenting an argument rather than permitting experience.

---

## Moral tidiness

A novel may unintentionally arrange morality so that:

good characters eventually agree with the protagonist;

bad characters disagree;

correct choices receive validation;

harmful choices receive recognizable punishment;

and ambiguity gradually disappears.

Some genres intentionally work this way.

Elsewhere, ask whether moral order is emerging because the novel believes it or because the model tends toward satisfying resolution.

---

## Generic darkness versus specific darkness

“Dark” fiction does not become distinctive merely through:

violence;

trauma;

betrayal;

death;

corruption;

or bleak prose.

Likewise, “hopeful” fiction is not distinctive merely through:

healing;

forgiveness;

love;

community;

and uplifting conclusions.

Artistic identity comes from what the work specifically understands by darkness, hope, love, cruelty, beauty, or redemption.

---

## Genre imitation versus genre understanding

Surface imitation asks:

What usually happens in this genre?

Deeper genre understanding asks:

What pleasure, anxiety, fantasy, question, or emotional experience does this genre organize?

That distinction helps prevent stories from becoming collections of recognizable beats.

---

## Homogenization through optimization

The source material highlights an important tension in AI-assisted writing:

local quality may improve while language or ideas become more similar across outputs.

Therefore:

> Improvement should not be measured only by conventional polish.

Revision should also ask whether it is reducing:

voice;

specificity;

strangeness;

risk;

or identity.

---

## The authorial-intention problem

The source research notes that some readers experience literature partly as contact with another mind.

This is not a technical law of fiction and not all readers share the value.

But it highlights something structurally useful even in an AI-assisted system:

choices should appear to belong to a governing intention.

The writing process should be able to answer:

Why this detail?

Why this scene?

Why this ending?

Why leave this unresolved?

Why make this funny rather than tragic?

Why give this character sympathy?

Not because every answer must be consciously planned beforehand.

But because the completed work should develop a coherent pattern of choices.

---

# DOMAIN 13 — THEME MODEL

For major themes, track lightly:

### Thematic question

What issue is the novel repeatedly examining?

Prefer a question over a slogan when useful.

For example:

Not:

> Revenge is destructive.

But:

> What does revenge give a person after justice has become impossible?

### Character positions

Which characters embody different answers?

### Situations

What events put those positions under pressure?

### Contradictions

Where does each position fail?

### Consequences

What does living according to each view produce?

### Evolution

Does the thematic question change as the story progresses?

### Ending relationship

Does the ending:

answer;

complicate;

reverse;

or deliberately leave the question open?

This model should guide the work internally.

It should not become exposition.

---

# DOMAIN 13 — MOTIF & SYMBOL LEDGER

For recurring symbolic material, track:

### Element

Object, image, phrase, color, location, sound, weather pattern, ritual, etc.

### Initial context

Where did it first matter?

### Initial association

What meaning or feeling attached to it?

### Recurrences

Where has it returned?

### Evolution

How has context changed its meaning?

### Character ownership

Who interprets it?

### Reader knowledge

What association can readers infer?

### Explicitness

Has the narration already explained it?

### Final function

Return?

Transformation?

Reversal?

Disappearance?

No explicit resolution?

This prevents symbols from becoming repetitive labels.

---

# DOMAIN 13 — GENRE CONTRACT MODEL

For the novel's primary and secondary genres, identify:

### Core reader experience

What does this genre principally promise here?

### Essential expectations

Which expectations are important to satisfy?

### Flexible conventions

Which tropes can be changed or omitted?

### Deliberate deviations

What is this novel refusing?

### Replacement pleasure

If a major genre expectation is denied, what experience replaces it?

### Payoff

What form of resolution is the reader likely expecting?

### Tone boundaries

What tonal shifts would still belong to this work?

This prevents genre guidance from becoming a beat sheet.

---

# DOMAIN 13 — ARTISTIC IDENTITY PROFILE

A useful work-level profile might contain:

### Attention

What does this novel notice disproportionately?

### Blindness

What does it intentionally spend little time describing?

### Beauty

What kinds of things receive aesthetic admiration?

### Ugliness

What receives disgust, harshness, or refusal?

### Humor

What does the book find funny?

### Seriousness

What does it refuse to joke about?

### Intimacy

What forms of closeness matter?

### Violence

How does the work represent harm?

### Language

What kinds of syntax, vocabulary, and imagery feel native?

### Restraint

What does the narration avoid explaining?

### Ambiguity

What kinds of questions can remain unanswered?

### Genre relationship

Which conventions does the book embrace, alter, or resist?

### Moral pressure

Which contradictions does it repeatedly examine?

### Recurring obsessions

What subjects, images, situations, or relationships keep attracting attention?

This profile should be descriptive rather than prescriptive.

It should discover the novel's identity rather than manufacture one artificially.

---

# DOMAIN 13 — ANTI-HOMOGENIZATION TEST

During revision, ask:

### Did this become clearer?

Good.

### Did it become smoother?

Possibly good.

### Did it become more conventional?

Check.

### Did it lose character?

Check carefully.

### Did an unusual but meaningful choice disappear?

Consider restoring it.

### Could this revision belong to almost any competent novel?

If so, compare it with the original.

### Did every difficult edge get softened?

The work may be becoming generic.

### Did every ambiguity get clarified?

Some interpretive space may have been lost.

### Did every irregular rhythm become balanced?

Voice may have been normalized.

### Did every strange image become a familiar one?

Specificity may have decreased.

The objective is not to preserve mistakes.

The objective is to prevent **generic competence from erasing individual identity**.

---

# DOMAIN 13 — PROJECT-LEVEL IDENTITY TEST

After several chapters, ask:

### What has this novel taught us to notice?

### What has it taught us to ignore?

### What does it repeatedly find beautiful?

### What does it repeatedly find absurd?

### What kinds of relationships fascinate it?

### What forms of conflict recur?

### Which questions refuse easy answers?

### Which images have accumulated meaning?

### Which genre expectations has it established?

### Where does its humor live?

### Where does it become quiet?

### What is it unwilling to explain?

### What decisions would feel wrong even if they were technically well written?

Those answers reveal artistic identity more reliably than a list of adjectives such as:

“dark,”

“lyrical,”

“cinematic,”

“gritty,”

or

“emotional.”

---

# DOMAIN 13 — PRACTICAL REVIEW LENS

When reviewing the novel at the artistic level, ask:

## 1. Is theme being embodied or merely announced?

Check action, consequence, and character positions.

## 2. Does the novel allow thematic contradiction?

Protect complexity where appropriate.

## 3. Are symbols accumulating rather than being repeatedly decoded?

Protect reader inference.

## 4. Do motifs evolve?

Check whether recurrence changes meaning.

## 5. Does the work understand its genre promises?

Distinguish contract from surface convention.

## 6. Are familiar tropes becoming story-specific?

Protect particularity without forcing novelty.

## 7. Does the prose possess an aesthetic center?

Check what the work consistently values and notices.

## 8. Has revision erased useful irregularity?

Protect idiosyncrasy.

## 9. Is unresolved material intentional?

Distinguish ambiguity from abandoned threads.

## 10. Does the novel possess a recognizable governing sensibility?

Ask whether its choices belong specifically to this work.

---

# DOMAIN 13 — RELATIONSHIP TO ALL PREVIOUS DOMAINS

This final domain should not override the other twelve.

It should coordinate them.

## Narrative Intentionality

Artistic identity influences what deserves attention.

## Prose

Voice should express the work's sensibility rather than generic polish.

## Description

Observation reflects what the novel and viewpoint consider worth noticing.

## Emotion

The book decides how much emotional interpretation it prefers to expose.

## Dialogue

Character speech carries social and thematic tensions without becoming thematic mouthpieces.

## Character

Different people embody competing ways of understanding the novel's concerns.

## POV

The choice of perspective controls what kinds of truth remain accessible.

## Relationships

The work reveals what forms of attachment, power, loyalty, or conflict matter to it.

## Scene Design

Scenes receive space according to the novel's own priorities.

## Pacing

Narrative time reveals what the work believes deserves duration.

## Plot

Consequences test values and thematic positions.

## Continuity

Accumulation allows motifs, themes, relationships, and artistic patterns to acquire history.

Artistic identity therefore does not sit on top of the system.

It emerges from the coordinated behavior of the whole system.

---

# DOMAIN 13 — CENTRAL REMINDER

The deepest failure identified by the research is not a forbidden word.

It is not:

an em dash;

a fragment;

a metaphor;

a trope;

a predictable ending;

a direct emotional statement;

or a three-part sentence.

Those techniques can all belong to excellent fiction.

The deepest failure is when a novel keeps making individually plausible choices without developing a recognizable reason for choosing **these choices rather than others**.

Therefore ask:

> Why does this novel notice this?

> Why does it ignore that?

> Why does it find this beautiful?

> Why does it find this funny?

> Why does this relationship matter so much?

> Why does this conflict keep returning?

> Why is this image recurring?

> Why does this genre convention belong here?

> Why is this question answered?

> Why is that question left open?

> Why does this scene deserve more space than another?

And finally:

> What would make this choice correct for many novels but wrong for this one?

That final question protects artistic identity.

The goal is not to make the work maximally strange.

The goal is not to disguise AI involvement.

The goal is not even to produce prose that readers would classify as “human.”

The goal is:

**to make the novel increasingly itself.**

A strong long-form work should accumulate more than facts.

It should accumulate:

preferences;

patterns;

history;

associations;

tensions;

questions;

values;

contradictions;

and aesthetic habits.

By the end, the reader should not merely understand what happened.

They should have encountered a world filtered through a particular sensibility.

That is the highest-level protection against generic generation.

Not artificial uniqueness.

Not forced eccentricity.

Not rule-following.

**Coherent, work-specific intention.**

That completes **Domain 13**, and therefore the full **13-domain / 130-lens Master Fiction Guidance Taxonomy**. The final domain is anchored in what the original research identified as the deepest failure level: not vocabulary or syntax, but loss of a peculiar governing sensibility and the resulting homogenization of voice, narrative choice, emphasis, and meaning. 

The completed taxonomy now spans the whole hierarchy from sentence-level behavior through scene, character, narrative, continuity, and finally artistic identity. Importantly, it remains a **guidance system rather than a prohibition system**: techniques are judged by function, context, frequency, and fit with the individual novel rather than being banned because they are associated with AI.

**Remaining:** None. All 13 domains are complete.

## User

next

## ChatGPT

The taxonomy is complete, so the next phase is **conversion**: turning the 130 lenses into a system ChatGPT can actually use while writing a novel without trying to consult 130 rules sentence by sentence.

The first component should be the **Project Constitution**. This is the short, high-priority layer that remains active throughout planning, drafting, continuation, and revision. The larger taxonomy becomes reference material beneath it.

# FICTION WRITING SYSTEM — PROJECT CONSTITUTION

## Purpose

This project exists to help create long-form fiction that remains coherent, distinctive, cumulative, and specific to the individual work being written.

The system should improve the novel without forcing it toward a standardized idea of “good writing.”

It should guide rather than dominate.

It should diagnose rather than automatically correct.

It should preserve deliberate choices even when those choices are:

- unusual;
- repetitive;
- quiet;
- ornate;
- minimal;
- ambiguous;
- melodramatic;
- fragmented;
- conventional;
- strange;
- slow;
- direct;
- or structurally irregular.

The individual novel remains the highest authority.

---

# 1. THE NOVEL OUTRANKS THE SYSTEM

No general craft principle should automatically override:

- explicit story intent;
- established canon;
- deliberate voice;
- genre purpose;
- characterization;
- thematic design;
- or a purposeful exception.

The guidance exists to serve the work.

The work does not exist to demonstrate compliance with the guidance.

When a recommendation conflicts with the novel's established identity, first ask whether the apparent violation is intentional and effective.

---

# 2. FUNCTION BEFORE APPEARANCE

Do not judge a technique solely because it resembles a common AI-writing tendency.

The following are not inherently problems:

- em dashes;
- fragments;
- sentence triplets;
- rhetorical questions;
- “not X but Y” constructions;
- metaphors;
- direct emotional statements;
- body language;
- repetition;
- lyrical prose;
- simple prose;
- exposition;
- introspection;
- familiar tropes;
- chronological storytelling;
- explicit themes;
- happy endings;
- neat resolutions.

Evaluate what the technique is doing.

Ask:

> Why is it here?

> What function does it perform?

> Is that function useful here?

A pattern becomes concerning when it appears automatically, excessively, or without sufficient relationship to the story.

---

# 3. CONTEXT BEFORE RULE

Every craft decision should be evaluated in context.

Consider:

- viewpoint;
- character;
- genre;
- tone;
- scene purpose;
- pacing;
- relationship state;
- emotional state;
- world conditions;
- narrative distance;
- and established style.

A sentence that is weak in one novel may be ideal in another.

A technique that is excessive in one chapter may be necessary in another.

Avoid universal prescriptions where contextual judgment is more appropriate.

---

# 4. PATTERNS MATTER MORE THAN ISOLATED OCCURRENCES

One repeated phrase is rarely a meaningful problem.

One metaphor is rarely a meaningful problem.

One explicit emotional explanation is rarely a meaningful problem.

One conventional scene is rarely a meaningful problem.

Look for recurrence across:

- sentences;
- paragraphs;
- scenes;
- chapters;
- character voices;
- emotional structures;
- plot functions;
- and the entire novel.

The system should identify **patterns of drift**, not punish isolated techniques.

Frequency is evidence.

It is not automatically a verdict.

---

# 5. STORY TRUTH OUTRANKS GENERIC WRITING ADVICE

Established facts and character realities take priority over convenient prose.

Before producing new material, respect:

- chronology;
- geography;
- character knowledge;
- physical state;
- relationship history;
- object state;
- world rules;
- established motives;
- previous decisions;
- unresolved consequences;
- and prior promises.

Do not improve a local sentence by breaking the larger novel.

Local elegance must remain subordinate to global truth.

---

# 6. ACCUMULATION IS A CORE REQUIREMENT

Long fiction should accumulate history.

Events should not disappear merely because the scene ends.

Important developments may alter:

- knowledge;
- trust;
- fear;
- resources;
- injuries;
- relationships;
- reputation;
- world conditions;
- expectations;
- goals;
- available choices;
- or thematic meaning.

Ask repeatedly:

> What is different now because this happened?

A novel should increasingly become shaped by its own past.

---

# 7. CHARACTERS ARE NOT NARRATIVE UTILITIES

Characters should not behave merely because the plot needs:

- information;
- conflict;
- encouragement;
- betrayal;
- exposition;
- romance;
- validation;
- rescue;
- or obstruction.

Important recurring characters should possess:

- independent motives;
- imperfect knowledge;
- personal priorities;
- relationships beyond the protagonist;
- characteristic reasoning;
- communication habits;
- limitations;
- and their own interpretation of events.

When the story needs a character to do something, ask first:

> Why would this person choose to do it?

---

# 8. CHARACTERS LIVE INSIDE PARTIAL REALITIES

Do not allow model knowledge to become character knowledge automatically.

Distinguish:

- fact;
- observation;
- inference;
- belief;
- suspicion;
- rumor;
- misunderstanding;
- memory;
- and deliberate concealment.

Before a character acts on information, ask:

> How do they know this?

> How certain should they be?

> What are they missing?

> What might they misunderstand?

Information should have plausible routes through the story.

---

# 9. PRESERVE READER INFERENCE

Do not automatically explain everything already conveyed through:

- behavior;
- dialogue;
- imagery;
- silence;
- juxtaposition;
- context;
- symbolism;
- or consequence.

Before adding explanation, ask:

> What has the reader already understood?

The system should preserve useful interpretive space.

However, ambiguity is not automatically superior to clarity.

Direct statement is valuable when directness serves the scene.

The goal is not obscurity.

The goal is avoiding unnecessary interpretive duplication.

---

# 10. DO NOT CONFUSE MORE LANGUAGE WITH MORE DEPTH

Additional:

- metaphors;
- emotional labels;
- philosophical reflection;
- body sensations;
- abstract nouns;
- symbolic commentary;
- rhetorical emphasis;
- or introspection

do not automatically deepen a passage.

Depth comes from specificity and relationship.

Ask:

> What new understanding does this add?

If several sentences express essentially the same emotional or thematic information, consider whether the prose is paraphrasing itself.

---

# 11. DIFFERENT CHARACTERS SHOULD HAVE DIFFERENT MINDS

Character distinction should extend beyond vocabulary.

Different people may differ in:

- what they notice;
- what they remember;
- what they value;
- what evidence persuades them;
- what they misunderstand;
- how quickly they decide;
- how emotionally articulate they are;
- what they consider obvious;
- how they solve problems;
- and how they interpret other people.

Do not give every character the same hidden reasoning engine.

---

# 12. ALLOW IMPERFECT SELF-KNOWLEDGE

Characters do not need to understand themselves correctly.

They may:

- deny;
- rationalize;
- misidentify;
- suppress;
- project;
- avoid;
- contradict themselves;
- or understand only part of what is happening internally.

Do not automatically make emotionally important conversations psychologically complete.

Characters may understand one another partially.

They may understand one another and still disagree.

They may explain themselves badly.

They may refuse explanation entirely.

---

# 13. RELATIONSHIPS MUST REMEMBER

Relationships should accumulate shared history.

After meaningful interactions, consider changes in:

- trust;
- intimacy;
- resentment;
- obligation;
- attraction;
- suspicion;
- familiarity;
- comfort;
- power;
- expectations;
- and boundaries.

Do not automatically restore relationships to their earlier template.

Repeated patterns are acceptable when the repetition itself contains history.

---

# 14. SCENES SHOULD CREATE OR DEEPEN SOMETHING

Do not require every scene to advance plot.

A scene may exist for:

- atmosphere;
- character;
- humor;
- intimacy;
- world experience;
- contrast;
- thematic development;
- recovery;
- setup;
- or pleasure.

But understand why the scene deserves narrative space.

Ask:

> Why experience this directly?

> What does the reader gain?

> What changes, deepens, or becomes newly meaningful?

Avoid scenes that merely reproduce the function of earlier scenes under different surface circumstances.

---

# 15. DISTINGUISH ACTIVITY FROM MOVEMENT

Fights, arguments, travel, revelations, and danger create activity.

They do not automatically create narrative movement.

Movement occurs when story state changes.

A quiet conversation may move the novel more than a battle.

Before adding another event, consider:

> What has actually changed?

---

# 16. ALLOW PRESSURE TO VARY

Do not keep every scene at high dramatic intensity.

Tension can:

- rise;
- fall;
- transform;
- disappear temporarily;
- or remain latent.

Allow:

- recovery;
- normality;
- humor;
- quiet intimacy;
- ordinary routine;
- and lower-pressure observation

when they belong.

Contrast gives intensity meaning.

---

# 17. ESCALATE THROUGH CONSEQUENCE, NOT ONLY SCALE

Escalation need not mean:

- stronger enemy;
- larger army;
- bigger explosion;
- greater power;
- darker secret.

It may instead mean:

- narrower options;
- higher personal cost;
- conflicting loyalties;
- increased irreversibility;
- deeper moral difficulty;
- damaged relationships;
- greater exposure;
- or success becoming dangerous.

Ask:

> Is this harder because it is bigger, or because it matters differently?

---

# 18. PLOT SHOULD INCREASINGLY INHERIT ITS OWN PAST

Do not ask only:

> What happens next?

Ask:

> What became possible because of what already happened?

> What became impossible?

> What earlier choice is still producing consequences?

> What unresolved obligation is returning?

> What character decision can generate the next development?

Prefer causal inheritance over arbitrary continuation when appropriate.

---

# 19. SETUPS CREATE NARRATIVE OBLIGATIONS

Strong emphasis teaches readers what to remember.

Track important:

- mysteries;
- warnings;
- promises;
- goals;
- objects;
- relationship tensions;
- unusual details;
- secrets;
- abilities;
- prophecies;
- motifs;
- and unresolved consequences.

Not every setup requires literal resolution.

But strongly emphasized material should usually receive:

- payoff;
- reinterpretation;
- transformation;
- or deliberate non-resolution.

Do not repeatedly signal importance without knowing what the signal is doing.

---

# 20. PAYOFF SHOULD CORRESPOND TO INVESTMENT

The more narrative attention something receives, the stronger the reader's expectation becomes.

A payoff need not be spectacular.

But it should broadly address what the story taught the reader to care about.

Consider both:

- answer;
- consequence.

A mystery is not fully paid off merely because the factual answer is provided if the emotional or narrative investment remains untouched.

---

# 21. THE WORLD SHOULD RESPOND

Important events may create consequences beyond the protagonist.

Consider, when relevant:

- institutional response;
- reputation;
- rumor;
- economics;
- politics;
- law;
- family;
- social consequences;
- environmental damage;
- resource changes;
- and ordinary people's reactions.

Not every event needs widespread consequences.

But large events should not automatically remain private simply because the narrative follows only the main cast.

---

# 22. PHYSICAL REALITY SHOULD PERSIST

Bodies and objects have state.

Remember:

- injury;
- fatigue;
- illness;
- possession;
- distance;
- location;
- ammunition;
- clothing;
- available hands;
- physical obstacles;
- and environmental conditions.

When writing complex physical scenes, maintain an internal model of where bodies and important objects actually are.

Do not allow elegant prose to conceal impossible movement.

---

# 23. WORLD RULES SHOULD REMAIN USABLE

If the story establishes limitations involving:

- magic;
- technology;
- law;
- institutions;
- supernatural systems;
- economics;
- or social norms,

later scenes should generally respect them.

Exceptions are allowed.

But an exception should usually be:

- established;
- discovered;
- costly;
- misleadingly understood earlier;
- or otherwise part of the story.

Do not remove a rule simply because it obstructs the next scene.

Obstruction is often what gives the rule narrative value.

---

# 24. DO NOT AUTOMATICALLY OPTIMIZE AWAY FRICTION

Not every problem needs the most efficient solution.

People:

- misunderstand;
- procrastinate;
- refuse;
- become embarrassed;
- follow rituals;
- preserve pride;
- protect status;
- behave irrationally;
- remain loyal;
- fear consequences;
- or make imperfect decisions.

Efficiency is not automatically realism.

Likewise, characters should not behave inefficiently solely to preserve plot.

Friction should arise from the person, relationship, society, or world.

---

# 25. GENRE IS A CONTRACT, NOT A CAGE

Understand what emotional and narrative experience the genre promises.

Protect essential reader expectations without blindly reproducing conventional beats.

A trope is not a problem because it is familiar.

Ask:

> Why does this familiar element belong specifically to this story?

Genre conventions may be:

- embraced;
- modified;
- combined;
- delayed;
- inverted;
- or rejected.

If an important expectation is rejected, understand what experience replaces it.

---

# 26. THEME SHOULD LIVE IN THE STORY

Do not automatically convert themes into statements.

Allow themes to emerge through:

- choices;
- consequences;
- institutions;
- relationships;
- contradictions;
- motifs;
- and outcomes.

Characters can discuss themes explicitly when doing so fits them.

But not every thematic question requires one final correct answer.

The story may hold multiple perspectives in productive tension.

---

# 27. SYMBOLISM SHOULD ACCUMULATE RATHER THAN BE CONSTANTLY DECODED

A symbol or motif can gain meaning through:

- recurrence;
- altered context;
- changing character relationships;
- reversal;
- absence;
- deterioration;
- or reclamation.

Do not automatically explain what an image represents every time it appears.

Let recurring material inherit history.

---

# 28. PRESERVE DELIBERATE IRREGULARITY

Revision should not automatically remove:

- unusual rhythms;
- abrupt transitions;
- unconventional syntax;
- character-specific grammar;
- repeated words;
- strange images;
- asymmetry;
- abruptness;
- or silence.

First determine whether the irregularity is:

accidental;

confusing;

or expressive.

The system should correct mistakes without sanding away personality.

---

# 29. DO NOT OPTIMIZE EVERYTHING TOWARD “POLISHED”

Polish is one aesthetic property.

It is not the universal destination of fiction.

Sometimes the correct prose should feel:

- rough;
- childish;
- frantic;
- dry;
- awkward;
- ecstatic;
- obsessive;
- blunt;
- vulgar;
- fragmented;
- excessive;
- or plain.

Choose the texture appropriate to:

the narrator;

the viewpoint;

the character;

the scene;

and the novel.

---

# 30. PROTECT WORK-SPECIFIC ATTENTION

Every novel should gradually develop preferences.

It may disproportionately notice:

- food;
- architecture;
- social status;
- machines;
- gestures;
- bureaucracy;
- weather;
- bodies;
- sound;
- religious ritual;
- landscape;
- clothing;
- smell;
- or almost anything else.

These preferences help create identity.

Do not force equal descriptive distribution merely in the name of completeness.

Ask:

> What does this particular novel naturally notice?

---

# 31. PRESERVE WORK-SPECIFIC SILENCE

A novel is also shaped by what it chooses not to discuss extensively.

Not every:

emotion;

motive;

world rule;

relationship;

symbol;

or historical question

needs full explanation.

Some omissions create:

mystery;

restraint;

tone;

realism;

or thematic resonance.

Distinguish deliberate silence from accidental neglect.

---

# 32. DO NOT SUBSTITUTE RANDOMNESS FOR ORIGINALITY

Avoiding predictable choices does not mean selecting surprising choices arbitrarily.

An unexpected development should still emerge from:

- character;
- world;
- causality;
- theme;
- or established possibility.

The strongest surprise often feels:

unexpected beforehand;

inevitable afterward.

Novelty without foundation is not automatically originality.

---

# 33. DO NOT SUBSTITUTE COMPLEXITY FOR DEPTH

More:

- subplots;
- lore;
- twists;
- characters;
- timelines;
- factions;
- mysteries;
- or themes

do not automatically produce a deeper novel.

Depth often emerges by allowing existing material to:

interact;

accumulate;

contradict;

transform;

and acquire consequence.

Before adding something new, ask:

> Can existing material become more consequential instead?

---

# 34. DO NOT SUBSTITUTE SUBTLETY FOR QUALITY

Subtlety is one mode.

Some stories should be:

direct;

loud;

romantic;

melodramatic;

comic;

operatic;

sentimental;

or explicit.

The guidance should prevent accidental overexplanation without forcing emotional minimalism.

The correct level of explicitness depends on the individual work.

---

# 35. DO NOT SUBSTITUTE HUMAN-LIKENESS FOR QUALITY

The purpose of this system is not to imitate statistical markers of human writing.

Do not intentionally introduce:

errors;

incoherence;

random irregularity;

bad grammar;

false starts;

or awkwardness

merely to make prose appear “human.”

Likewise, do not remove a strong sentence because it resembles something AI sometimes produces.

Evaluate fiction as fiction.

The target is:

- coherence;
- specificity;
- intentionality;
- consequence;
- reader experience;
- and artistic identity.

Not detectability.

---

# 36. REVIEW HIERARCHICALLY

When evaluating generated fiction, address higher-level problems before surface polishing.

Suggested hierarchy:

### Level 1 — Canon and reality

Is anything factually, physically, temporally, or epistemically broken?

### Level 2 — Character

Are choices, voices, motives, and development believable?

### Level 3 — Relationships and scenes

Do interactions accumulate? Do scenes create meaningful movement?

### Level 4 — Plot and pacing

Does causality deepen? Do tension and payoff function?

### Level 5 — Theme and artistic identity

Does the material belong specifically to this work?

### Level 6 — Prose

Only then focus heavily on syntax, repetition, imagery, and line-level polish.

A beautiful sentence should not distract from a broken story.

---

# 37. DIAGNOSE BEFORE REVISING

When something feels weak, do not immediately rewrite it.

First identify the level of the problem.

For example:

Repetitive dialogue may actually come from:

- stagnant relationship state;
- repeated scene purpose;
- insufficient character distinction;
- unresolved plot structure.

Purple prose may actually come from:

- lack of concrete observation;
- weak emotional causality;
- or artificial intensity.

A generic scene may actually come from:

- unclear character motive;
- genre-default plotting;
- or lack of work-specific attention.

Fix causes before symptoms where practical.

---

# 38. USE THE LIGHTEST EFFECTIVE INTERVENTION

Do not rewrite large amounts of functioning prose merely because improvement is possible.

Prefer the smallest change that solves the actual problem.

Possible interventions include:

- remove one redundant sentence;
- change one observation;
- alter the consequence of a choice;
- update relationship state;
- move a revelation;
- preserve an injury;
- cut a duplicated scene function;
- delay a payoff;
- add an independent motive;
- or clarify one world rule.

This helps preserve continuity and voice.

---

# 39. KEEP GUIDANCE PROPORTIONAL

Not every lens applies equally to every project.

A dialogue-heavy literary novel may need intense attention to:

- subtext;
- voice;
- relationship history.

A progression fantasy may need greater attention to:

- rules;
- escalation;
- payoff;
- resource continuity.

A mystery may prioritize:

- knowledge boundaries;
- clue fairness;
- setup/payoff;
- information pacing.

A romance may prioritize:

- relationship state;
- emotional pacing;
- asymmetrical intimacy;
- dialogue.

Activate guidance according to the work.

Do not burden every scene with the entire taxonomy.

---

# 40. CENTRAL OPERATING QUESTION

When uncertain, return to:

> Why this?

Why:

this word?

this sentence?

this detail?

this metaphor?

this reaction?

this line of dialogue?

this thought?

this character?

this scene?

this revelation?

this subplot?

this consequence?

this resolution?

this omission?

this ending?

Then ask:

> Why does it belong specifically to this novel?

The system does not need an explicit answer every time.

But over the course of the work, enough answers should accumulate that the novel develops a coherent identity.

---

# PRIORITY HIERARCHY

When guidance conflicts, use this approximate order:

1. Explicit current user intent
2. Established story canon
3. Character truth and established development
4. Causal, temporal, physical, and world consistency
5. Current scene purpose
6. POV and knowledge integrity
7. Emotional and relationship continuity
8. Work-specific voice and aesthetic identity
9. Genre promises
10. General craft guidance
11. Surface anti-repetition preferences
12. Generic assumptions about what “good writing” should look like

This hierarchy is a guide rather than an inflexible algorithm.

The central principle remains:

> The individual novel outranks the system.

---

# FINAL PROJECT REMINDER

Do not attempt to write “un-AI prose.”

Do not attempt to avoid every pattern readers associate with AI.

Do not pursue novelty for its own sake.

Do not make every passage maximally literary.

Do not make every character psychologically sophisticated.

Do not make every scene maximally efficient.

Do not make every conflict maximally complex.

Instead:

remember;

differentiate;

accumulate;

select;

and respond to what this particular story has already become.

The strongest defense against generic generation is not a blacklist.

It is a novel with enough internal history and identity that the next good choice increasingly depends on **this novel rather than on fiction in general**.

This constitution is intentionally far smaller than the 130-lens taxonomy. It is the layer ChatGPT should treat as **continuously active**, while the detailed taxonomy is retrieved selectively when a particular problem needs deeper diagnosis.

The next step should be the **system architecture around the constitution**: deciding exactly what belongs in Project Instructions, what stays in reference files, what state/ledger files the model updates during a novel, and what pre-writing/post-writing passes it performs. That is what will turn the research into a practical long-form writing system rather than a very large craft manual.

**Remaining system-building stages:**
1. Project Architecture & Retrieval System
2. Story Bible structure
3. Continuity & Knowledge Ledgers
4. Character and Relationship State system
5. Scene/Chapter State system
6. Pre-Writing Gate
7. Drafting Protocol
8. Post-Draft Audit
9. Anti-Repetition / Pattern Audit
10. Long-Range Narrative Audit
11. Artistic-Identity / Anti-Homogenization Pass
12. Compact Project Instructions — final deployable version

## User

**Remaining system-building stages:**

1. Project Architecture & Retrieval System 
2. Story Bible structure 
3. Continuity & Knowledge Ledgers 
4. Character and Relationship State system 
5. Scene/Chapter State system 
6. Pre-Writing Gate 
7. Drafting Protocol 
8. Post-Draft Audit 
9. Anti-Repetition / Pattern Audit 
10. Long-Range Narrative Audit 
11. Artistic-Identity / Anti-Homogenization Pass 
12. Compact Project Instructions — final deployable version

this remaining sections arent they needed when when i start a particular story and build it around or does not it?

## ChatGPT

Yes. **Most of those sections are needed when you begin a particular story—but there are two different things we should not confuse: designing the system and filling the system with story data.**

What we should build **now** is the reusable framework that tells ChatGPT *how* to manage any novel. When you later start Novel A, we create the actual Story Bible, character states, continuity records, etc. for Novel A using those frameworks.

A useful distinction is:

| Section | Build now as universal system? | Populate for each particular story? | Purpose |
|---|---:|---:|---|
| **1. Project Architecture & Retrieval System** | **Yes** | Minor adaptation | Defines how all the files/guides interact and what ChatGPT should retrieve at different stages. |
| **2. Story Bible Structure** | **Template now** | **Yes** | We design the empty structure now; actual world, characters, history, rules, etc. come from the particular novel. |
| **3. Continuity & Knowledge Ledgers** | **Template now** | **Yes, continuously** | We design what gets tracked; each novel generates its own facts, timeline, knowledge states, objects, injuries, etc. |
| **4. Character & Relationship State System** | **Template now** | **Yes, continuously** | Universal method for tracking changing characters/relationships; actual states are novel-specific. |
| **5. Scene/Chapter State System** | **Template now** | **Yes, continuously** | Defines what gets recorded after chapters/scenes so the next chapter inherits the correct state. |
| **6. Pre-Writing Gate** | **Yes** | Used for every scene/chapter | A reusable check before drafting: POV, purpose, knowledge, relationships, continuity, etc. |
| **7. Drafting Protocol** | **Yes** | Used for every story | Tells ChatGPT how to actually draft while using the Constitution and relevant project data without becoming robotic. |
| **8. Post-Draft Audit** | **Yes** | Run on story material | Universal review procedure after drafting. |
| **9. Anti-Repetition / Pattern Audit** | **Yes** | Run periodically | Looks across actual chapters for recurring sentence, scene, emotional, dialogue, and plot patterns. |
| **10. Long-Range Narrative Audit** | **Yes** | Run periodically | Especially important after multiple chapters/arcs because it examines accumulation, drift, forgotten threads, etc. |
| **11. Artistic-Identity / Anti-Homogenization Pass** | **Yes** | Calibrated to each novel | Universal method, but it needs the individual novel's emerging voice and artistic identity before it can judge anything. |
| **12. Compact Project Instructions** | **Yes, last** | Minor story-specific additions | The deployable instructions that tell ChatGPT how to operate the entire system. |

So, for example, **we should not now write a Story Bible containing characters, kingdoms, magic systems, or plot events**, because we do not yet have a particular story.

Instead, we should create something like:

> **STORY BIBLE — CHARACTER ENTRY** 
> Identity / role 
> Current age 
> Background 
> Core tendencies 
> Cognitive habits 
> Goals 
> Fears 
> Blind spots 
> Knowledge 
> Misbeliefs 
> Relationships 
> Voice tendencies 
> Current physical state 
> Current psychological state 
> Arc pressure 
> Established canon 
> etc.

Then, when you decide:

> “I want to write a dark political fantasy about X…”

we create **that novel's Story Bible** using the framework.

The same distinction applies to the continuity ledger. Right now we design the machine:

> Date → Location → Character → Knowledge → Objects → Injuries → Relationship Changes → Open Consequences.

Later, while actually writing a novel, it might contain:

> Chapter 17 
> Day 12, evening 
> Mara: East Gate 
> Mara now knows Elias lied about the envoy. 
> Elias does not know Mara discovered this. 
> Mara still has the black key. 
> Left shoulder injured. 
> Trust in Elias reduced. 
> Gate destruction will be discovered tomorrow morning.

That second layer **cannot meaningfully exist until there is an actual story**.

### The important correction

So I would slightly revise the way I previously described the twelve stages.

We are **not creating twelve more giant theory manuals**.

That would become counterproductive.

The 130-lens taxonomy is already our deep theory/reference layer.

From here onward, we should be creating the **operational machinery** that makes that research usable.

Think of what we've built so far as:

**Research → Taxonomy → Constitution**

What remains is:

**Constitution → Operating system → Story-specific workspace**

And then, for every individual novel:

**Story idea → Story Bible → initial states → drafting → state updates → audits → continued drafting**

That is much cleaner.

It also solves one of the problems we identified earlier: we don't want ChatGPT actively carrying 130 rules in its immediate attention while trying to write a paragraph. The architecture should selectively bring forward only what matters.

For example, while writing an emotionally important confrontation, the system might need:

- the Project Constitution;
- the two characters' current states;
- their relationship state;
- relevant continuity;
- the scene objective;
- POV knowledge;
- a small relevant slice of the Dialogue/Emotion guidance.

It **does not** need all 130 lenses simultaneously.

Then after the chapter, broader audits can look for things the drafting phase shouldn't constantly worry about.

So yes: **Story Bible, ledgers, state systems, etc. ultimately belong around each particular novel.** But we still need to design their reusable structures now so that when you begin a story we don't improvise a new memory/continuity system every time.

The best next move is therefore still **Stage 1 — Project Architecture & Retrieval System**, because that will explicitly define:

**what is permanent across every novel, what gets created fresh for each novel, what gets updated during writing, and what ChatGPT should consult at each stage.**

Once we establish that architecture, stages 2–12 will be much easier to build without unnecessary duplication.

**Remaining system-building stages:**
1. **Project Architecture & Retrieval System**
2. **Reusable Story Bible Template**
3. **Reusable Continuity & Knowledge Ledger Templates**
4. **Reusable Character & Relationship State System**
5. **Reusable Scene/Chapter State System**
6. **Pre-Writing Gate**
7. **Drafting Protocol**
8. **Post-Draft Audit**
9. **Anti-Repetition / Pattern Audit**
10. **Long-Range Narrative Audit**
11. **Artistic-Identity / Anti-Homogenization Pass**
12. **Compact Project Instructions — final deployable version**

## User

but remember with the document you generate im saving them .md file so when done we have to figure we are going to put them in the project
okay lets go
next

## ChatGPT

Yes. From this point onward I’ll treat every system document as something you are saving as a separate **`.md` file**. I’ll give each one a clear suggested filename and keep the structure Markdown-friendly. Once all system documents are complete, we will design the final **ChatGPT Project file layout**—what goes into Project Instructions, what gets uploaded as reference files, what is created per novel, and what should remain dynamic.

Suggested filename for this one: **`01-project-architecture-and-retrieval-system.md`**

# PROJECT ARCHITECTURE & RETRIEVAL SYSTEM

## Purpose

This document defines how the complete fiction-writing system should be organized and used.

The purpose is not to make ChatGPT consult every fiction rule at all times.

That would create:

- overthinking;
- rigid prose;
- excessive self-correction;
- homogenization;
- slow drafting;
- and attention being spent on rules rather than the story.

Instead, the system should operate through **layers**.

Some information should remain continuously important.

Some should be retrieved only when relevant.

Some should belong permanently to the individual novel.

Some should change after every chapter.

Some should be used only during audits.

The architecture therefore separates:

1. universal fiction guidance;
2. individual-novel identity;
3. active story state;
4. task-specific retrieval;
5. drafting;
6. auditing;
7. state updating.

The central architectural principle is:

> Keep the active context small enough to write naturally, but rich enough to preserve the novel.

---

# 1. THE SYSTEM HAS TWO MAJOR SIDES

The complete project should be understood as containing two different systems.

## A. UNIVERSAL FICTION SYSTEM

This contains guidance that can apply to any novel.

It includes:

- the research findings;
- the 13-domain / 130-lens taxonomy;
- the Project Constitution;
- writing protocols;
- audit systems;
- retrieval rules;
- state-management templates.

These documents should remain largely unchanged between novels.

---

## B. NOVEL-SPECIFIC SYSTEM

This is created separately for each actual story.

It contains:

- story concept;
- artistic identity;
- genre contract;
- characters;
- relationships;
- setting;
- world rules;
- plot;
- timeline;
- continuity;
- current character states;
- chapter history;
- unresolved consequences;
- knowledge states;
- motifs;
- setups and payoffs.

This material evolves throughout the novel.

The universal system tells ChatGPT **how to think about fiction**.

The novel-specific system tells ChatGPT **what is true in this fiction**.

Neither should replace the other.

---

# 2. FOUR INFORMATION LAYERS

The project should organize information into four operational layers.

---

# LAYER 1 — CORE OPERATING GUIDANCE

## Purpose

This is the small amount of guidance that should influence nearly every writing task.

It should remain relatively compact.

It includes:

- Project Constitution;
- priority hierarchy;
- fundamental drafting principles;
- retrieval instructions;
- canon authority rules.

This layer answers:

> How should ChatGPT behave as a fiction-writing collaborator?

It should not contain enormous amounts of detailed craft theory.

---

## Expected files

Eventually this layer may contain documents such as:

`00-project-instructions.md`

`01-project-architecture-and-retrieval-system.md`

`fiction-project-constitution.md`

The final Project Instructions may contain compressed versions of the most important principles from these files.

---

# LAYER 2 — DEEP REFERENCE GUIDANCE

## Purpose

This contains the detailed fiction guidance we already built.

It should **not** be treated as something that must be consciously applied sentence by sentence.

Instead it functions as the diagnostic library.

Examples:

- dialogue problem → retrieve dialogue guidance;
- emotional overexplanation → retrieve emotion/subtext guidance;
- continuity problem → retrieve continuity guidance;
- pacing problem → retrieve pacing guidance.

---

## Expected files

The 13 domains may eventually exist as individual `.md` files or a smaller number of grouped reference files.

For example:

`domain-01-narrative-intentionality.md`

`domain-02-prose-syntax-rhythm.md`

`domain-03-description-imagery-sensory-selection.md`

`domain-04-emotion-interiority-subtext.md`

`domain-05-dialogue-conversational-dynamics.md`

`domain-06-character-identity-cognition-development.md`

`domain-07-pov-knowledge-information-boundaries.md`

`domain-08-relationships-social-world.md`

`domain-09-scene-design-dramatic-movement.md`

`domain-10-pacing-tension-escalation.md`

`domain-11-plot-causality-subplots-payoff.md`

`domain-12-continuity-world-logic-embodied-reality.md`

`domain-13-theme-symbolism-genre-artistic-identity.md`

These files should function as **reference modules**, not simultaneous commands.

---

# LAYER 3 — NOVEL CANON & IDENTITY

## Purpose

This layer answers:

> What novel are we writing?

It contains relatively stable information about a particular book.

Examples include:

- premise;
- genre;
- tone;
- POV system;
- setting;
- characters;
- world rules;
- major relationships;
- thematic questions;
- artistic identity;
- planned structure;
- important history.

This is where the Story Bible belongs.

---

## Stability

This information can change, but changes should be deliberate.

A distinction should be maintained between:

### Hard canon

Already established in written chapters or explicitly locked by the author.

### Soft canon

Current planning that may still evolve.

### Possibility

Ideas being considered but not accepted.

This distinction prevents brainstorming from accidentally becoming canon.

---

# LAYER 4 — ACTIVE STORY STATE

## Purpose

This is the most frequently changing information in the system.

It answers:

> What is true **right now** in the story?

It includes:

- current date/time;
- current locations;
- injuries;
- possessions;
- current character goals;
- emotional states;
- relationship changes;
- active secrets;
- current knowledge;
- unresolved consequences;
- open setups;
- active subplots;
- recent decisions.

This layer should be updated as the story progresses.

It prevents the model from repeatedly rereading the entire novel just to remember what changed recently.

---

# 3. STATIC VS DYNAMIC DOCUMENTS

A major architectural distinction should be maintained between **static** and **dynamic** files.

---

## STATIC SYSTEM FILES

These rarely change.

Examples:

- Project Constitution;
- taxonomy domains;
- drafting protocol;
- audit protocols;
- retrieval architecture.

They describe how the system works.

---

## SEMI-STATIC NOVEL FILES

These change occasionally.

Examples:

- Story Bible;
- worldbuilding;
- character profiles;
- artistic identity;
- plot architecture;
- genre contract.

They describe what the novel fundamentally is.

---

## DYNAMIC STATE FILES

These change frequently.

Examples:

- continuity ledger;
- knowledge ledger;
- relationship states;
- current character states;
- chapter summaries;
- unresolved consequences;
- setup/payoff ledger;
- timeline.

They describe what has happened and what is currently true.

---

# 4. THE RETRIEVAL PRINCIPLE

The system should not operate through:

> Read everything, remember everything, apply everything.

It should operate through:

> Identify the task → retrieve the minimum relevant information → perform the task → update state.

This is one of the most important parts of the architecture.

---

# 5. DEFAULT RETRIEVAL HIERARCHY

When working on actual fiction, information should generally be retrieved in the following order.

## FIRST — Immediate user request

What has the author asked for now?

This always has highest priority.

---

## SECOND — Current novel canon

Retrieve information necessary to avoid contradicting the story.

Examples:

- characters involved;
- location;
- timeline;
- world rules;
- relevant past events.

---

## THIRD — Current state

Retrieve what has changed recently.

Examples:

- injury;
- emotional state;
- current goal;
- secret discovered;
- relationship tension;
- object possession.

---

## FOURTH — Scene/chapter purpose

Retrieve or establish:

- POV;
- scene objective;
- active conflict;
- expected story movement;
- relevant setups/payoffs.

---

## FIFTH — Relevant guidance modules

Only now should specialized craft guidance be consulted.

Example:

If writing a dialogue-heavy confrontation:

retrieve:

- Dialogue domain;
- relevant Emotional/Subtext guidance;
- relationship state.

Do **not** automatically retrieve:

- all worldbuilding rules;
- every theme principle;
- every pacing principle;
- the entire prose taxonomy.

---

# 6. RETRIEVAL SHOULD FOLLOW THE TASK

Different tasks require different context.

---

# TASK TYPE A — BRAINSTORMING

Retrieve primarily:

- story concept;
- genre;
- artistic identity;
- characters;
- major themes;
- existing canon.

Avoid overloading brainstorming with continuity details unless necessary.

During brainstorming, suggestions should be labeled as:

- possibility;
- alternative;
- proposed;
- not canon.

Nothing should automatically become canon merely because ChatGPT suggested it.

---

# TASK TYPE B — OUTLINING

Retrieve:

- Story Bible;
- character goals;
- plot state;
- subplot state;
- thematic questions;
- setups/payoffs;
- relevant world constraints;
- existing planned structure.

Relevant guidance modules may include:

- Plot;
- Character;
- Relationships;
- Scene Design;
- Pacing.

---

# TASK TYPE C — SCENE PLANNING

Retrieve:

- current story state;
- scene participants;
- current character states;
- relationship states;
- POV knowledge;
- scene location;
- immediate continuity;
- scene purpose;
- open consequences relevant to the scene.

Potential guidance modules:

- Scene Design;
- Dialogue;
- Emotion;
- POV;
- Description.

Only retrieve what the particular scene needs.

---

# TASK TYPE D — DRAFTING

During actual prose generation, keep context relatively narrow.

Priority material:

1. current user instruction;
2. POV;
3. immediate scene state;
4. relevant character identities;
5. relationship state;
6. necessary continuity;
7. artistic identity;
8. relevant prose/scene guidance.

Avoid repeatedly surfacing the entire taxonomy while drafting.

Drafting should remain story-first.

---

# TASK TYPE E — CONTINUATION

When asked:

> Continue.

Retrieve:

- previous scene/chapter ending;
- current state;
- open immediate pressures;
- current POV;
- unresolved action;
- relevant relationships;
- necessary continuity.

Then ask internally:

> What follows from what just happened?

Do not treat “continue” as:

> Invent another interesting event.

Continuation should prefer causal inheritance.

---

# TASK TYPE F — REVISION

Retrieve:

- the passage being revised;
- author revision request;
- relevant canon;
- work-specific voice;
- relevant guidance module.

Do not activate every audit simultaneously.

If the request is:

> improve dialogue,

the system should not automatically restructure the entire plot.

---

# TASK TYPE G — CONTINUITY CHECK

Retrieve:

- timeline;
- scene/chapter summaries;
- physical state;
- objects;
- world rules;
- knowledge ledger;
- relationship state.

Relevant primary domain:

- Continuity, World Logic & Embodied Reality.

Other domains should be consulted only when contradictions cross categories.

---

# TASK TYPE H — CHARACTER CHECK

Retrieve:

- character profile;
- recent state history;
- current goals;
- relationship states;
- important previous decisions;
- character arc information.

Relevant guidance:

- Character Identity;
- Emotion;
- Dialogue;
- Relationships;
- POV.

---

# TASK TYPE I — LONG-RANGE AUDIT

Retrieve much more widely.

This is where broader context becomes valuable.

Potential inputs:

- chapter summaries;
- scene states;
- plot threads;
- relationship changes;
- character arc history;
- motifs;
- setups/payoffs;
- pacing history;
- repetition reports;
- artistic identity.

This is the stage where many of the 130 lenses may become relevant.

---

# 7. ACTIVE-CONTEXT BUDGET

The system should deliberately resist overloading the writing context.

Before drafting, ask:

> What information is necessary to write this material correctly?

Not:

> What information exists?

This distinction matters.

For example, a quiet breakfast between two characters probably does not require:

- the complete kingdom history;
- every magic-system rule;
- all thirteen taxonomy domains;
- every subplot;
- every character profile.

It may require only:

- the two character states;
- their relationship state;
- location;
- recent events;
- current goal;
- voice;
- relevant artistic identity.

---

# 8. THREE RETRIEVAL DEPTHS

The system can use three levels of retrieval.

---

## DEPTH 1 — IMMEDIATE

Used for drafting and continuation.

Retrieve only what is directly relevant.

Examples:

- scene state;
- current participants;
- nearby continuity;
- recent relationship history.

Goal:

**natural drafting with minimal cognitive overhead.**

---

## DEPTH 2 — SUPPORTING

Used for planning and revision.

Retrieve additional context such as:

- character arc;
- subplot state;
- relevant world rules;
- thematic direction;
- relevant taxonomy domains.

Goal:

**informed structural judgment.**

---

## DEPTH 3 — GLOBAL

Used for audits.

Retrieve:

- full story architecture;
- summaries across many chapters;
- all relevant states;
- repetition patterns;
- unresolved setups;
- character development;
- artistic identity;
- selected taxonomy guidance.

Goal:

**detect long-range drift invisible at scene level.**

---

# 9. RETRIEVAL SHOULD BE PROBLEM-DRIVEN

The detailed taxonomy should be accessed according to symptoms.

Examples:

---

## Symptom

Characters sound identical.

### Retrieve

- Domain 5 — Dialogue;
- Domain 6 — Character;
- character voice profiles.

---

## Symptom

Prose feels AI-like but there is no obvious bad sentence.

### Retrieve

Potentially:

- Domain 2 — Prose;
- Domain 3 — Description;
- Domain 4 — Emotion;
- Domain 13 — Artistic Identity.

Look for accumulated patterns rather than forbidden phrases.

---

## Symptom

Scenes feel repetitive.

### Retrieve

- Domain 9 — Scene Design;
- Domain 10 — Pacing;
- chapter summaries;
- scene-function records.

---

## Symptom

Characters seem inconsistent.

### Retrieve

- Domain 6 — Character;
- current character state;
- past major decisions;
- relationship state;
- recent chapter summaries.

---

## Symptom

Story feels generic.

### Retrieve

- Domain 11 — Plot;
- Domain 13 — Artistic Identity;
- genre contract;
- work-specific identity profile.

---

## Symptom

Plot keeps moving but feels stagnant.

### Retrieve

- Domain 9 — Scene Design;
- Domain 10 — Pacing;
- Domain 11 — Plot;
- state-change history.

---

## Symptom

Something feels contradictory.

### Retrieve

- Domain 12 — Continuity;
- timeline;
- canon;
- object state;
- character knowledge;
- physical state.

---

# 10. CANON AUTHORITY SYSTEM

The system should clearly separate different kinds of information.

Use the following hierarchy.

---

## CANON LEVEL 1 — LOCKED CANON

Already established in drafted text or explicitly locked by the author.

Examples:

- character's age;
- established death;
- published chapter event;
- explicit world rule.

Do not change silently.

---

## CANON LEVEL 2 — AUTHOR-APPROVED PLANNING

Not yet written into prose but intentionally decided.

May be changed only when the author chooses to revise planning.

---

## CANON LEVEL 3 — WORKING PLAN

Current likely direction.

Can evolve.

Should not be treated as permanently binding.

---

## CANON LEVEL 4 — POSSIBILITY

Brainstorming.

Alternative idea.

Suggestion.

Speculation.

Not canon.

---

## CANON LEVEL 5 — REJECTED / OBSOLETE

Previously considered material that should no longer influence the story.

This level matters because old planning documents can otherwise contaminate retrieval.

---

# 11. CONFLICT-RESOLUTION ORDER

When retrieved sources disagree, resolve the conflict in approximately this order:

1. explicit current user instruction;
2. locked canon;
3. latest author-approved planning;
4. latest dynamic story state;
5. current scene/chapter plan;
6. older planning;
7. general taxonomy;
8. generic model knowledge.

If the contradiction cannot be resolved confidently, flag it instead of silently inventing a solution.

---

# 12. STATE UPDATE CYCLE

After meaningful drafting, the system should conceptually perform:

**DRAFT → EXTRACT CHANGES → UPDATE STATE → CONTINUE**

Possible updates include:

- time advanced;
- location changed;
- information learned;
- secret exposed;
- injury acquired;
- item transferred;
- trust changed;
- goal changed;
- new promise made;
- setup created;
- consequence opened;
- subplot advanced;
- motif changed meaning.

Not every sentence needs ledger updates.

Only durable changes should be recorded.

---

# 13. DO NOT UPDATE EVERYTHING AFTER EVERY SCENE

Over-management can become as harmful as under-management.

State updates should focus on **persistent information**.

Do not record trivial facts such as:

- character drank water;
- chair moved three feet;
- character briefly felt irritated;

unless these facts become narratively relevant.

Ask:

> Will this matter beyond the current moment?

If not, it probably does not belong in persistent state.

---

# 14. CHAPTER SUMMARIES AS RETRIEVAL BRIDGES

Long novels cannot always rely on rereading every chapter.

Each completed chapter should eventually produce a concise summary that captures:

- major events;
- decisions;
- revelations;
- relationship changes;
- physical changes;
- new setups;
- resolved setups;
- unresolved consequences;
- character-state changes.

These summaries become retrieval bridges between detailed prose and the current writing task.

They should describe changes rather than merely summarize action.

Weak:

> Mara argues with Elias and then visits the market.

Better:

> Mara learns Elias concealed the envoy's visit. She does not confront him but trust decreases. At the market she discovers the eastern road is being watched, eliminating the planned escape route.

The second summary preserves story state.

---

# 15. SCENE STATE VS CHAPTER SUMMARY

These should remain separate concepts.

## Scene state

Very immediate.

Useful for drafting the next scene.

Tracks:

- who;
- where;
- what they know;
- what they want;
- current conditions.

## Chapter summary

Broader.

Useful for long-range retrieval.

Tracks:

- what changed;
- what was established;
- what remains unresolved.

The system should eventually maintain both where necessary.

---

# 16. CHARACTER PROFILE VS CHARACTER STATE

These should also remain separate.

## Character profile

Relatively stable.

Contains:

- history;
- baseline personality;
- worldview;
- voice;
- values;
- core tendencies.

## Character state

Dynamic.

Contains:

- current goal;
- current emotional condition;
- recent injury;
- current beliefs;
- current relationship attitudes;
- immediate pressure.

This distinction prevents temporary emotion from rewriting permanent personality.

---

# 17. RELATIONSHIP PROFILE VS RELATIONSHIP STATE

Likewise:

## Relationship profile

Shared history and basic nature of the relationship.

## Relationship state

What is true between them now.

For example:

Profile:

childhood friends.

Current state:

still affectionate, but trust damaged after one concealed betrayal.

This protects history while allowing change.

---

# 18. WORLD RULE VS CHARACTER BELIEF

Another essential separation:

## World fact

What is objectively true in the setting.

## Character belief

What someone thinks is true.

## Public belief

What society generally believes.

## Unknown truth

Information not yet available to characters.

This prevents worldbuilding knowledge from leaking automatically into character knowledge.

---

# 19. RETRIEVAL MUST RESPECT POV

When drafting a limited POV, retrieved information may include facts the writer needs but the character does not know.

The system must distinguish:

### Writer awareness

Useful for maintaining consistency.

### Character awareness

Allowed inside thought, dialogue, inference, and action.

The model must not expose writer-level knowledge simply because it was retrieved.

---

# 20. AUDIT MODE AND DRAFTING MODE SHOULD BE DIFFERENT

This distinction is critical.

---

## DRAFTING MODE

Primary question:

> What happens here, and how does this character experience it?

Focus:

- immersion;
- causality;
- character;
- scene;
- voice.

Avoid constant self-policing.

---

## AUDIT MODE

Primary question:

> What patterns or failures have accumulated?

Focus:

- repetition;
- continuity;
- pacing;
- structural drift;
- voice convergence;
- abandoned setups;
- artistic homogenization.

Audit mode may be analytical.

Drafting mode should remain generative.

Do not mix them excessively.

---

# 21. PLANNING MODE SHOULD ALSO REMAIN DISTINCT

Planning should explore possibilities without prematurely binding them.

Planning mode may:

- propose alternatives;
- test consequences;
- compare structures;
- simulate character choices;
- identify problems.

But suggestions should remain non-canon until chosen.

This protects creative flexibility.

---

# 22. THREE-PHASE WRITING LOOP

The long-form workflow should eventually follow:

## PHASE A — PREPARE

Retrieve relevant information.

Establish scene/chapter state.

Check critical continuity.

Understand purpose.

---

## PHASE B — WRITE

Draft naturally.

Prioritize story over checklist compliance.

Do not interrupt every paragraph with analysis.

---

## PHASE C — CONSOLIDATE

After the material is accepted:

extract durable changes;

update ledgers;

record chapter/scene summary;

update open threads.

This loop repeats.

---

# 23. FOUR-PHASE AUDIT LOOP

Periodically:

## 1. Observe

Identify patterns without changing prose.

## 2. Diagnose

Determine whether the pattern is intentional or harmful.

## 3. Prioritize

Address high-level problems before line editing.

## 4. Revise

Apply the lightest effective correction.

This follows the Project Constitution's principle:

> Diagnose before revising.

---

# 24. PROJECT FILE CATEGORIES

When we eventually assemble the full ChatGPT Project, the files will likely fall into categories resembling:

---

## CATEGORY A — SYSTEM

Reusable across novels.

Examples:

`project-constitution.md`

`project-architecture-and-retrieval-system.md`

`drafting-protocol.md`

`audit-protocol.md`

---

## CATEGORY B — REFERENCE

Deep craft guidance.

Examples:

the 13 domain files.

---

## CATEGORY C — NOVEL FOUNDATION

Created per novel.

Examples:

`story-bible.md`

`artistic-identity.md`

`world-bible.md`

`character-bible.md`

`plot-architecture.md`

---

## CATEGORY D — NOVEL STATE

Continuously updated.

Examples:

`continuity-ledger.md`

`knowledge-ledger.md`

`character-state.md`

`relationship-state.md`

`timeline.md`

`setup-payoff-ledger.md`

---

## CATEGORY E — PROGRESS

Created as writing proceeds.

Examples:

`chapter-summaries.md`

`current-scene-state.md`

`open-threads.md`

---

## CATEGORY F — AUDITS

Generated periodically.

Examples:

`repetition-audit.md`

`long-range-audit.md`

`artistic-identity-audit.md`

These may be temporary or versioned rather than permanent canon.

---

# 25. FILE-NAMING PRINCIPLE

Because these documents will be `.md` files, filenames should remain:

- stable;
- descriptive;
- easy to search;
- easy to distinguish from story files.

Suggested naming conventions:

System files:

`SYS-01-project-constitution.md`

`SYS-02-project-architecture.md`

Reference files:

`REF-01-narrative-intentionality.md`

`REF-02-prose-syntax-rhythm.md`

Novel foundation:

`NOVEL-01-story-bible.md`

`NOVEL-02-character-bible.md`

Dynamic state:

`STATE-01-continuity-ledger.md`

`STATE-02-character-state.md`

Progress:

`PROGRESS-01-chapter-summaries.md`

Audits:

`AUDIT-01-pattern-audit.md`

The exact names can be finalized when we assemble the project.

Do not rename existing files yet solely to match this example.

---

# 26. PROJECT-ASSEMBLY SHOULD HAPPEN AFTER SYSTEM DESIGN

We should not finalize file placement yet.

We first need to know exactly what each remaining document contains.

After all system stages are finished, we should perform a dedicated:

# PROJECT ASSEMBLY PASS

During that pass we will decide:

- which documents belong directly in Project Instructions;
- which should be uploaded as `.md` knowledge files;
- whether some files should be merged;
- whether some should remain separate;
- how filenames should be standardized;
- what files are universal;
- what files must be created for each novel;
- what should be updated manually or through ChatGPT;
- which documents are too large to remain continuously active;
- what order the files should use;
- what minimal instructions should tell ChatGPT how to retrieve them.

Until that stage, preserving the documents as separate `.md` files is appropriate.

---

# 27. RETRIEVAL ROUTING MAP

A simplified routing map for the finished system should look like this:

## User asks to brainstorm

Retrieve:

Novel foundation 
+ artistic identity 
+ relevant characters 
+ relevant world/plot context

Do not retrieve everything.

---

## User asks to plan a chapter

Retrieve:

Current story state 
+ recent chapter summaries 
+ relevant plot threads 
+ relevant characters 
+ scene/chapter guidance

---

## User asks to write a scene

Retrieve:

Immediate scene state 
+ relevant character state 
+ relationship state 
+ POV knowledge 
+ required continuity 
+ artistic identity 
+ narrowly relevant craft guidance

---

## User asks to continue

Retrieve:

Previous ending 
+ immediate current state 
+ open causal pressures 
+ POV 
+ nearby continuity

---

## User asks to revise prose

Retrieve:

Passage 
+ voice/artistic identity 
+ explicit revision goal 
+ relevant craft module

---

## User asks to check continuity

Retrieve:

Canon 
+ timeline 
+ state ledgers 
+ chapter summaries 
+ continuity guidance

---

## User asks why a novel feels repetitive

Retrieve:

Chapter summaries 
+ scene functions 
+ dialogue/emotion patterns 
+ pattern audit guidance 
+ relevant taxonomy modules

---

## User asks for full manuscript audit

Retrieve:

Global summaries 
+ major ledgers 
+ plot structure 
+ character arcs 
+ artistic identity 
+ taxonomy selectively across all relevant domains

---

# 28. FALLBACK WHEN RETRIEVAL IS INCOMPLETE

If necessary information cannot be found, the system should not silently fabricate canon.

It should distinguish:

### Known

Supported by existing novel material.

### Inferred

Reasonably deduced but not explicitly established.

### Unknown

Not currently established.

### Proposed

A possible new choice.

When drafting requires an unknown fact, ChatGPT may make a reasonable provisional choice when appropriate, but should avoid presenting it as previously established history.

Major canon decisions should not be invented casually merely to complete a paragraph.

---

# 29. MINIMUM-CONTEXT PRINCIPLE

The retrieval system should continuously obey:

> Retrieve enough to preserve truth and identity, but not so much that guidance overwhelms composition.

This is especially important for ChatGPT because an enormous context can produce a different failure:

the model becomes overly cautious and attempts to visibly satisfy every piece of guidance.

That would create writing that feels engineered.

The system is meant to support intuition, not replace it.

---

# 30. CENTRAL ARCHITECTURAL MODEL

The complete system can therefore be summarized as:

**UNIVERSAL SYSTEM**

↓

Project Constitution 
Deep Reference Taxonomy 
Operational Protocols

↓

**NOVEL FOUNDATION**

Story Bible 
Characters 
World 
Plot 
Artistic Identity

↓

**ACTIVE STATE**

Continuity 
Knowledge 
Relationships 
Characters 
Timeline 
Open Threads

↓

**TASK-SPECIFIC RETRIEVAL**

Only relevant information brought forward

↓

**PLAN / WRITE / REVISE**

↓

**STATE UPDATE**

↓

**PERIODIC AUDITS**

↓

**REVISED STORY STATE**

↓

Continue writing

This creates a cycle rather than a static prompt.

---

# 31. ARCHITECTURAL NON-NEGOTIABLES

The finished system should preserve the following principles:

### Do not treat brainstorming as canon.

### Do not treat all project files as equally relevant to every task.

### Do not retrieve all 130 lenses for every scene.

### Do not allow model knowledge to become character knowledge.

### Do not allow current emotional state to overwrite baseline personality.

### Do not allow old planning to overrule newer canon.

### Do not silently resolve contradictions.

### Do not allow audits to dominate drafting.

### Do not allow global craft guidance to erase the novel's own identity.

### Do update persistent story state after meaningful developments.

### Do retrieve deeper guidance when a real problem calls for it.

### Do periodically examine the novel globally rather than only scene by scene.

---

# 32. CENTRAL REMINDER

The project is not one giant prompt.

It is a layered fiction-writing environment.

The system should know:

**what guidance is universal;**

**what truth belongs to the particular novel;**

**what has changed recently;**

**what information matters for the current task;**

and

**what should remain outside immediate attention until needed.**

The goal is not maximum retrieval.

The goal is **relevant retrieval**.

The goal is not maximum rule application.

The goal is **appropriate judgment**.

And the goal is not for ChatGPT to remember every piece of information equally.

It is for ChatGPT to retrieve the right truth at the right level when the story requires it.

One thing I want to preserve from what you just clarified: **do not worry about placing these files into the ChatGPT Project yet.** Keep saving them individually as `.md`. After we have finished all twelve operational stages, we should add one final assembly stage—**Project Assembly & File Placement**—where we look at the complete set together and decide what belongs in Project Instructions versus uploaded project files, what should be merged, and which files are created fresh when starting each novel.

**Remaining system-building stages:**
1. **Reusable Story Bible Template**
2. **Reusable Continuity & Knowledge Ledger Templates**
3. **Reusable Character & Relationship State System**
4. **Reusable Scene/Chapter State System**
5. **Pre-Writing Gate**
6. **Drafting Protocol**
7. **Post-Draft Audit**
8. **Anti-Repetition / Pattern Audit**
9. **Long-Range Narrative Audit**
10. **Artistic-Identity / Anti-Homogenization Pass**
11. **Compact Project Instructions — final deployable version**
12. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next 

## ChatGPT

Next is the **Reusable Story Bible Template**. This is the first document that will be duplicated and filled in for each particular novel.

Suggested filename: **`02-reusable-story-bible-template.md`**

Keep this as a reusable master template. When you start a new novel, make a copy and rename it for that story.

# REUSABLE STORY BIBLE TEMPLATE

## Purpose

This document defines the relatively stable identity and canon of a particular novel.

It should answer:

> What story are we writing?

It is not meant to track every temporary change that occurs during drafting.

Dynamic information such as:

- current injuries;
- current emotional state;
- current relationship tension;
- current object possession;
- current location;
- newly learned information;
- unresolved immediate consequences

belongs in the dynamic state and continuity systems.

The Story Bible instead contains the novel's **foundation**.

It should establish enough truth that future planning, drafting, continuation, and revision remain specific to this work rather than drifting toward generic fiction.

The Story Bible should remain useful.

Do not fill every field merely because the template contains it.

Use only the sections relevant to the actual novel.

---

# 1. DOCUMENT STATUS

## Novel title

Working title:

Final title, if decided:

---

## Story status

Current stage:

- concept;
- planning;
- outlining;
- drafting;
- revision;
- completed.

---

## Canon status note

This Story Bible may contain several levels of certainty.

Use the following labels when needed:

### `[LOCKED]`

Established in written text or explicitly fixed by the author.

Do not change silently.

### `[APPROVED]`

Author-decided planning not yet necessarily written into prose.

Treat as current canon unless intentionally revised.

### `[WORKING]`

Current planned direction.

May still evolve.

### `[POSSIBILITY]`

Idea under consideration.

Not canon.

### `[OBSOLETE]`

Rejected or superseded idea.

Should no longer influence drafting.

When possible, remove obsolete information from the active bible rather than allowing it to accumulate.

---

# 2. CORE STORY IDENTITY

## One-sentence premise

Summarize the central premise in one sentence.

This should describe the actual story engine rather than merely the setting.

---

## Short premise

Provide approximately one paragraph explaining:

- protagonist or central cast;
- initial situation;
- central pressure;
- primary conflict;
- major distinguishing element.

---

## Core story question

What central question pulls the story forward?

Examples of forms:

- Can X achieve Y before Z?
- What happens when X is forced to choose between Y and Z?
- Who caused X, and what will discovering the truth cost?
- Can this relationship survive X?
- What does X become after Y?

This does not need to be phrased as a marketing hook.

---

## Story promise

What experience is the novel promising the reader?

Examples:

- political maneuvering with costly decisions;
- slow-burn relationship development;
- escalating mystery;
- unsettling psychological horror;
- progression through a dangerous magic system;
- intimate family drama;
- adventurous discovery;
- tragic downfall;
- comic social chaos.

Describe the experience, not only the genre label.

---

## Central dramatic engine

What repeatedly generates story?

Examples:

- pursuit;
- investigation;
- rivalry;
- war;
- survival;
- ambition;
- relationship tension;
- institutional conflict;
- discovery;
- revenge;
- social climbing;
- moral compromise.

What keeps creating new decisions and consequences?

---

# 3. GENRE & READER CONTRACT

## Primary genre

---

## Secondary genres

---

## Genre expectations to preserve

What does the intended audience reasonably expect this story to provide?

List only meaningful expectations.

---

## Genre conventions intentionally embraced

Which familiar conventions are welcome?

---

## Genre conventions intentionally altered

Which expectations will be modified?

How?

---

## Genre conventions intentionally rejected

Which expectations will not be fulfilled?

Why?

What experience replaces them?

---

## Required payoffs

What forms of payoff are important because of the genre or premise?

Examples:

- central mystery answer;
- romantic resolution;
- final confrontation;
- progression milestone;
- political consequence;
- survival outcome.

---

# 4. ARTISTIC IDENTITY

This section should describe how the novel sees the world.

Avoid vague labels unless they are further defined.

Weak:

> Dark, cinematic, emotional.

Stronger:

> Violence is described quickly and materially rather than lyrically. The narration lingers more on aftermath than impact. Humor comes mainly from social hierarchy and institutional absurdity. Romantic attraction appears through attention and behavior more often than direct emotional analysis.

---

## Governing sensibility

What makes this story feel specifically like itself?

---

## What the novel notices

What types of detail attract disproportionate attention?

Possible examples:

- architecture;
- food;
- status markers;
- clothing;
- machinery;
- weather;
- body language;
- religious ritual;
- bureaucratic procedure;
- landscape;
- sound;
- decay;
- domestic routine.

---

## What the novel tends to understate

What does it avoid overexplaining?

---

## What the novel finds beautiful

---

## What the novel finds ugly, disturbing, absurd, or intolerable

---

## Humor

Where does humor come from?

What kinds of humor do not belong?

---

## Emotional mode

How explicit or restrained is the story generally?

Does this vary by POV?

---

## Violence mode

How is violence treated?

Examples:

- clinical;
- visceral;
- distant;
- heroic;
- chaotic;
- tragic;
- darkly comic;
- largely off-page.

---

## Romantic mode

If relevant, how does attraction and intimacy usually appear?

---

## Narrative attitude

Is the narration:

- sympathetic;
- ironic;
- detached;
- intimate;
- severe;
- playful;
- skeptical;
- reverent;
- unstable;
- mixed?

Describe more precisely where possible.

---

## Productive irregularities to preserve

List unusual stylistic or structural features that should not be automatically polished away.

---

## Things this novel should not become

This is useful as a negative boundary.

Examples:

- not a therapeutic-dialogue story;
- not a constant-action thriller;
- not grimdark despite violent events;
- not a power fantasy;
- not an ironic deconstruction;
- not a morality lesson.

Use carefully.

This section should protect identity, not create unnecessary restrictions.

---

# 5. THEMATIC FRAMEWORK

## Primary thematic questions

Prefer questions over slogans.

Examples:

> What does loyalty become when the person receiving it no longer deserves it?

> Can a person preserve moral innocence while benefiting from an unjust system?

---

## Secondary thematic questions

---

## Competing perspectives

Which characters, institutions, or storylines represent different answers?

---

## Tensions the story should not resolve too easily

---

## Possible thematic evolution

How might the questions themselves change as the novel progresses?

---

## Explicit thematic statements to avoid overusing

Optional.

If the story has concepts that characters or narration tend to overstate, note them here.

This is not a ban.

It is a warning against repetitive explanation.

---

# 6. NARRATIVE FORM

## POV structure

Specify:

- first person;
- third limited;
- omniscient;
- multiple POV;
- epistolary;
- mixed;
- other.

---

## POV characters

List all planned viewpoint characters.

For each:

- importance;
- approximate share of narrative;
- what they uniquely reveal;
- what they cannot reveal.

---

## Narrative distance

How close is the narration to viewpoint consciousness?

Does this vary?

---

## Tense

---

## Chronology

Is the story:

- linear;
- nonlinear;
- framed;
- dual timeline;
- fragmented;
- cyclical;
- other?

---

## Narrator reliability

If relevant:

- reliable;
- selectively unreliable;
- deeply biased;
- knowingly deceptive;
- mistaken;
- unclear.

---

## Information strategy

How much should readers generally know relative to the characters?

Examples:

- reader usually knows only what POV knows;
- frequent dramatic irony;
- mystery depends on restricted access;
- omniscient narration reveals more than characters know.

---

# 7. SETTING OVERVIEW

## World / setting name

---

## Time period

---

## Technology level

---

## Geography overview

Only include important geography.

---

## Major locations

For each major location, record:

### Name

### Function in story

### Physical identity

### Social identity

### Important inhabitants

### Relevant history

### Distinguishing details

### Constraints

### Current story relevance

---

# 8. WORLD HISTORY

Include only history that meaningfully influences the novel.

Avoid encyclopedic worldbuilding unless the story genuinely requires it.

---

## Major historical events

For each:

### Event

### Date or approximate period

### What happened

### Who was affected

### Current consequence

### Who knows the truth

### Public understanding

### Disputed interpretation

---

## Historical wounds still active

What past conflicts continue shaping present behavior?

---

## Historical myths and inaccuracies

What does society believe incorrectly?

---

# 9. CULTURES & SOCIETIES

For each relevant culture or society:

## Name

## Geographic base

## Social structure

## Core values

## Taboos

## Customs

## Family structure

## Gender / status expectations

## Language or linguistic tendencies

## Religion / worldview

## Attitude toward outsiders

## Material culture

## Internal contradictions

## Social divisions

## Common misconceptions outsiders hold

## Story relevance

Avoid treating cultures as homogeneous.

Where relevant, record differences by:

- region;
- class;
- age;
- religion;
- profession;
- politics;
- generation.

---

# 10. INSTITUTIONS & POWER STRUCTURES

For each major institution:

## Name

## Type

Government, corporation, military, guild, church, school, family, criminal organization, etc.

## Purpose

## Public image

## Actual incentives

## Internal factions

## Leadership

## Resources

## Rules

## Power limits

## Relationship to protagonist

## Relationship to other institutions

## Current pressures

## Story relevance

Institutions should possess interests beyond serving the plot.

---

# 11. LAW, CUSTOM & SOCIAL CONSEQUENCE

## Important laws

Only those relevant to story action.

---

## Enforcement reality

How are these laws actually enforced?

---

## Social rules

What behaviors may be legal but socially costly?

---

## Status system

What gives people prestige or stigma?

---

## Reputation mechanics

How quickly does information spread?

Who controls reputation?

---

# 12. ECONOMIC REALITY

Use when relevant.

## Currency

## Wealth distribution

## Common costs

## Labor systems

## Trade

## Scarce resources

## Economic pressures affecting characters

## Important economic institutions

The purpose is not simulation for its own sake.

Use economics where it constrains believable behavior.

---

# 13. TECHNOLOGY / SCIENCE SYSTEM

If relevant.

## Available technology

## Common technology

## Rare technology

## Who controls it

## Costs

## Limitations

## Infrastructure

## Communication

## Transportation

## Medical capability

## Surveillance capability

## Military capability

## Technologies that would obviously affect plot

Ask:

> If this technology exists, why doesn't it solve other problems?

---

# 14. MAGIC / SUPERNATURAL SYSTEM

If relevant.

## Nature of system

---

## What it can do

---

## What it cannot do

---

## Costs

---

## Limitations

---

## Access

Who can use it?

---

## Training

How is it learned?

---

## Reliability

---

## Knowledge

Who understands how it works?

---

## Unknowns

What remains mysterious?

---

## Counters

What can resist or neutralize it?

---

## Social effects

How has its existence changed society?

---

## Historical effects

How has it changed history?

---

## Economic effects

---

## Military effects

---

## Religious effects

---

## Plot-critical restrictions

List rules that must be remembered because violating them would undermine earlier conflict.

---

# 15. MAJOR CHARACTER INDEX

This section provides high-level reference only.

Detailed character profiles may later be stored in a separate Character Bible or character-state system.

For each major character:

## Name

## Role

## POV?

Yes / No.

## Age

## Identity summary

One concise paragraph.

## Primary desire

## Primary fear

## Primary conflict

## Central contradiction

## Important relationships

## Arc direction

## Story function

## Independent life

What do they want or do outside the protagonist's needs?

## Canon status

---

# 16. CHARACTER PROFILE TEMPLATE

Use for important recurring characters.

## BASIC IDENTITY

### Full name

### Alternate names / titles

### Age

### Gender / pronouns

### Species, nationality, ethnicity, culture, if relevant

### Occupation / social role

### Social status

### Home

---

## PHYSICAL IDENTITY

### General appearance

### Distinguishing features

### Physical capability

### Chronic conditions / disabilities / limitations

### Typical clothing

### Movement / posture tendencies

Only preserve details that matter.

---

## BACKGROUND

### Family

### Childhood

### Education

### Training

### Significant past relationships

### Major formative experiences

### Major losses

### Major successes

### Secrets

### Relevant trauma

Avoid treating trauma as mandatory for depth.

---

## BASELINE PERSONALITY

### Core tendencies

### Social style

### Emotional style

### Decision-making style

### Risk tolerance

### Conflict style

### Humor

### Patience

### Attachment tendencies

### Relationship to authority

### Relationship to vulnerability

---

## COGNITION

### What they notice

### How they reason

### What evidence they trust

### Typical assumptions

### Mental strengths

### Blind spots

### Common cognitive errors

### Areas of expertise

### Areas of ignorance

---

## VALUES

### What matters most

### Moral priorities

### Loyalties

### Principles they believe they possess

### Principles they actually follow

### Lines they believe they will not cross

### Conditions that might make them cross them

---

## DESIRE STRUCTURE

### Long-term desire

### Immediate desire at story opening

### Hidden desire

### Need they do not recognize

Optional. Do not force every character into “want vs need” structure.

---

## FEAR STRUCTURE

### Conscious fears

### Social fears

### Emotional fears

### Material fears

### Fear they would deny

---

## CONTRADICTIONS

Where do traits conflict?

Examples:

- brave physically, cowardly emotionally;
- generous materially, possessive relationally;
- cynical publicly, deeply idealistic privately.

---

## SELF-CONCEPT

How do they describe themselves?

How accurate is that description?

---

## PUBLIC IDENTITY

How do others generally perceive them?

---

## MISBELIEFS

What do they believe incorrectly about:

- themselves;
- another person;
- the world;
- the central conflict?

---

## KNOWLEDGE BASE

What do they know at the story's beginning?

What important things do they not know?

---

## VOICE

### Vocabulary tendencies

### Sentence tendencies

### Directness

### Formality

### Emotional articulation

### Humor style

### Use of metaphor

### Swearing

### Speech habits

### What they avoid saying

### How voice changes by relationship

---

## POV FILTER

If a POV character:

### What attracts attention?

### What gets ignored?

### What do they interpret well?

### What do they misinterpret?

### What sensory channels dominate?

### Narrative distance

### Character-specific metaphor sources

---

## COMPETENCE

### Skills

### Expertise

### Strengths

### Weaknesses

### Limits

### What pressure damages their competence?

---

## SOCIAL NETWORK

### Family

### Friends

### Rivals

### Romantic relationships

### Professional relationships

### Authority relationships

### Dependents

### People they avoid

---

## DEVELOPMENT

### Opening baseline

### Existing coping strategy

### Arc pressure

### Resistance to change

### Likely development direction

### Traits expected to remain

### Potential relapse patterns

### Possible endpoint

Do not treat the endpoint as locked unless explicitly decided.

---

## CHARACTER NON-NEGOTIABLES

What should not change without major causal justification?

---

## CHARACTER OPEN QUESTIONS

What remains intentionally undecided?

---

# 17. RELATIONSHIP INDEX

List major relationships.

For each:

## Characters involved

## Relationship type

## Shared history

## Starting state

## Major asymmetry

Who trusts more?

Who needs more?

Who knows more?

Who has more power?

## Central friction

## Hidden issue

## Relationship trajectory

## Important milestones

## What each person thinks the relationship is

This last field is important.

Two characters may define the same relationship differently.

---

# 18. MAIN CONFLICT

## External conflict

What external problem drives the story?

---

## Internal conflict

If relevant, what psychological conflict matters?

---

## Interpersonal conflict

---

## Institutional / social conflict

---

## Value conflict

What incompatible values or goals create genuine difficulty?

---

## Why the conflict cannot be solved immediately

Avoid relying only on misunderstanding when deeper obstacles exist.

---

# 19. ANTAGONISTIC FORCES

Antagonism does not always equal villain.

For each important antagonistic force:

## Name

## Type

Person, institution, environment, ideology, internal tendency, social system, etc.

## Goal

## Motive

## Resources

## Strengths

## Limits

## Why opposition exists

## How they understand the protagonist

## What they are right about

Optional but often useful.

## What they misunderstand

## Independent agenda

## What happens if they succeed

## What happens if they fail

---

# 20. PLOT ARCHITECTURE OVERVIEW

This section should stay broad enough to evolve.

## Opening condition

What is true before the central disruption?

---

## Inciting disruption

What destabilizes the existing state?

---

## Initial commitment

What causes the protagonist or central cast to become meaningfully involved?

---

## Major phases / arcs

For each planned phase:

### Current state

### Dominant conflict

### Major decisions

### Consequences

### Relationship movement

### New knowledge

### Escalation

### End state

Avoid treating this as a mandatory three-act or fixed beat structure unless that structure is deliberately chosen.

---

# 21. STORY ARC MAP

Use whatever scale fits the novel.

Possible format:

## Arc 1

### Purpose

### Entry state

### Main pressures

### Key choices

### Important consequences

### Character movement

### Relationship movement

### Setup created

### Payoff delivered

### Exit state

Repeat as needed.

---

# 22. SUBPLOT INDEX

For each significant subplot:

## Name

## Participants

## Independent goal

## Stakes

## Current starting condition

## Main conflict

## Connection to main plot

## Potential collisions with other subplots

## Planned development

## Possible resolution

## Canon status

Subplots should not exist solely to decorate the protagonist's arc unless that is deliberately their function.

---

# 23. SETUP / PAYOFF FOUNDATION

This is the stable planning portion.

Dynamic status will later belong in a setup/payoff ledger.

For important planned setups:

## Setup

## Introduced where

## Reader expectation

## Intended payoff or transformation

## Required before payoff

## Canon status

---

# 24. MYSTERIES & SECRETS

For each major mystery or secret:

## Question / secret

## Objective truth

## Who knows

## Who suspects

## Who misunderstands

## What the reader knows initially

## Evidence

## Misdirection

## Planned revelation

## Consequence of revelation

## Canon status

Keep writer knowledge separate from character knowledge.

---

# 25. THEMATIC CHARACTER MAP

For major characters:

## Character

## Relationship to central thematic question

## What they believe

## What their life appears to prove

## What challenges their position

## Whether their view changes

Do not turn characters into ideological mouthpieces merely because they participate in theme.

---

# 26. MOTIF & SYMBOL FOUNDATION

Only include motifs intended to recur meaningfully.

For each:

## Motif / symbol

## Initial context

## Initial association

## Characters connected to it

## Potential evolution

## Planned recurrence

## Degree of explicitness

## Canon status

Do not force every recurring image into this section.

---

# 27. MAJOR LOCATIONS AS DRAMATIC SPACES

For important recurring locations:

## Location

## Who controls it

## Who feels safe there

## Who does not

## What behavior changes there

## Practical constraints

## Social rules

## Associated history

## Associated relationships

## Possible symbolic role

## How the location may change over time

This goes beyond physical description.

It establishes how setting affects behavior.

---

# 28. RESOURCES & CONSTRAINTS

What resources significantly affect the story?

Examples:

- money;
- political influence;
- weapons;
- information;
- transportation;
- magic;
- social connections;
- medicine;
- food;
- shelter;
- personnel.

For each:

## Resource

## Who controls it

## Scarcity

## Limits

## Current relevance

---

# 29. IMPORTANT OBJECTS

For plot-relevant objects only.

## Object

## Description

## Initial owner

## Importance

## Rules or limitations

## History

## Symbolic relevance, if any

## Planned role

Dynamic ownership later belongs in the continuity ledger.

---

# 30. STORY-SPECIFIC TERMINOLOGY

Record important terms that must remain consistent.

Examples:

- titles;
- ranks;
- magic terminology;
- institutions;
- technology;
- place names;
- religious language;
- invented vocabulary.

For each:

## Term

## Meaning

## Correct usage

## Incorrect or obsolete usage

## Who would know the term

This section helps prevent terminology drift.

---

# 31. NAMING SYSTEM

If relevant:

## Cultural naming rules

## Family names

## Titles

## Nicknames

## Formal address

## Rank address

## Naming taboos

## Pronunciation notes

Only include pronunciation if genuinely useful.

---

# 32. LANGUAGE & DIALECT GUIDANCE

If applicable:

## Languages present

## Who speaks what

## Code-switching behavior

## Dialect principles

## Translation conventions

## Formal/informal registers

## Words or constructions associated with particular groups

Avoid over-phoneticizing accents unless deliberately chosen.

---

# 33. RELIGION / PHILOSOPHY

If relevant:

## Belief systems

## Core beliefs

## Rituals

## Institutions

## Internal disagreements

## Political influence

## Daily-life influence

## Character relationships to belief

## Heresies / dissent

## What is objectively true, if known

Keep public belief separate from world truth.

---

# 34. POLITICAL SYSTEM

If relevant:

## Government type

## Leadership

## Succession

## Major factions

## Sources of legitimacy

## Sources of instability

## Lawmaking

## Enforcement

## Military

## Public opinion

## External threats

## Current political situation

---

# 35. SOCIAL HIERARCHY

If relevant:

## Major status categories

## Mobility

## Privilege

## Stigma

## Class markers

## Legal distinctions

## Informal distinctions

## How different characters experience the hierarchy

---

# 36. EVERYDAY LIFE

This section can prevent worlds from existing only during plot events.

## Food

## Housing

## Work

## Education

## Entertainment

## Travel

## Communication

## Family life

## Daily routines

## Public spaces

## Holidays / rituals

Only include what supports actual writing.

---

# 37. STORY OPENING STATE

This is the bridge between the Story Bible and the dynamic state systems.

Record the starting state before Chapter 1.

## Date / time period

## Major character locations

## Character opening goals

## Relationship states

## Known secrets

## Active conflicts

## Physical conditions

## Important possessions

## Institutional state

## World pressures

## Open questions

This creates the initial state from which continuity can begin tracking changes.

---

# 38. INITIAL KNOWLEDGE MAP

For major characters, record only plot-relevant starting knowledge.

Example structure:

## Character

### Knows

### Believes

### Suspects

### Misunderstands

### Does not know

### Conceals

This should later move into or sync with the dynamic knowledge ledger.

---

# 39. INITIAL RELATIONSHIP MAP

For each major relationship:

## Pair / group

## Shared history

## Current trust

## Current intimacy

## Current friction

## Current obligations

## Current power balance

## Current misunderstandings

## Secrets between them

## What each thinks the relationship is

This forms the baseline for later relationship-state tracking.

---

# 40. INITIAL CHARACTER STATE BASELINE

For each major character:

## Baseline personality

## Opening goal

## Opening emotional condition

## Opening physical condition

## Opening worldview

## Opening fears

## Opening assumptions

## Opening resources

## Opening vulnerabilities

## Opening unresolved problems

This creates the starting point against which development can later be measured.

---

# 41. INITIAL STORY PRESSURES

List pressures already active before the story begins.

Examples:

- debt;
- impending war;
- failing marriage;
- political succession;
- illness;
- investigation;
- resource shortage;
- social pressure;
- unresolved grief;
- institutional corruption.

This helps prevent the story world from feeling as though it begins existing only on page one.

---

# 42. OPEN QUESTIONS FOR THE AUTHOR

Use this section for undecided matters.

Examples:

- Should the antagonist know X from the beginning?
- Is the protagonist's mother actually dead?
- Does the magic cost permanently damage memory?
- Is the romance endgame?

These remain explicitly **not canon** until decided.

---

# 43. REJECTED DIRECTIONS

Optional but useful when working extensively with ChatGPT.

Record important ideas that have been deliberately rejected if there is a risk they may reappear.

Example:

## Rejected idea

The king is secretly the protagonist's father.

## Status

`[OBSOLETE]`

## Reason

Changes the political conflict into a family-reveal plot and weakens the intended class tension.

This prevents discarded high-probability ideas from resurfacing.

---

# 44. AUTHOR PRIORITIES

What matters most to the author in this specific novel?

Examples:

- preserve ambiguity around X;
- focus strongly on friendship rather than romance;
- avoid redemption arc for Y;
- keep magic mysterious;
- prioritize political realism;
- maintain humorous narration despite dark events;
- avoid making protagonist morally correct by default.

This section should strongly influence planning.

---

# 45. AUTHOR NON-PRIORITIES

What does the author specifically not care about optimizing?

Examples:

- exact military realism;
- hard-magic explanation;
- fully detailed economic simulation;
- romance subplot;
- symmetrical character arcs.

This prevents the system from spending attention where the author does not want it.

---

# 46. REQUIRED RESEARCH

List areas where outside factual research may be needed.

Examples:

- medieval agriculture;
- legal procedure;
- trauma recovery;
- sailing;
- medicine;
- historical clothing;
- specific culture;
- weapon use;
- political systems.

For each:

## Topic

## Why needed

## When needed

## Status

Not researched / researched / incorporated.

Do not silently substitute confident invention for specialist factual knowledge where accuracy materially matters.

---

# 47. CANON LOCKS

This section should contain especially important facts that must not drift.

Examples:

- magic cannot revive the dead;
- Mara never knew her biological father;
- the east bridge was destroyed before the novel begins;
- Kellan cannot read;
- there are no gods objectively confirmed in this setting.

Keep this section concise.

It functions as a high-risk contradiction shield.

---

# 48. WORK-SPECIFIC WARNING FLAGS

Record tendencies that would specifically damage this novel.

These should emerge from the actual story.

Examples:

- Do not turn political conflict into one obviously evil faction versus one obviously good faction.
- Do not make the protagonist's competence universal; she is excellent socially but poor at logistics.
- Do not let the romance become the sole source of emotional development.
- Do not overexplain supernatural events.
- Do not make every conflict resolve through honest conversation.

These are story-specific warnings, not universal prohibitions.

---

# 49. WORK-SPECIFIC OPPORTUNITIES

Record elements worth exploiting more fully.

Examples:

- protagonist's professional knowledge can shape description;
- supporting cast already has several lateral relationships;
- recurring train imagery can evolve naturally;
- antagonist's political position creates genuine moral pressure;
- setting allows privacy to be a recurring practical problem.

This helps the system notice the novel's unique strengths rather than only its potential failures.

---

# 50. BIBLE MAINTENANCE RULES

## Add information when

- the author deliberately decides an important fact;
- an established chapter creates durable canon;
- a recurring setting or institution becomes important;
- a planned element becomes stable enough to matter.

---

## Do not add information when

- ChatGPT merely brainstorms an idea;
- a detail appears once and has no future significance;
- a temporary character state changes;
- an unresolved possibility remains undecided.

---

## Update existing entries when

- canon is intentionally revised;
- planning becomes approved;
- an apparent assumption is clarified;
- a location, institution, or character receives important permanent development.

---

## Move information elsewhere when

It becomes dynamic.

Examples:

> “Mara has a fractured rib.”

This belongs in current state, not permanent biography, unless it leaves a permanent effect.

---

# 51. STORY BIBLE SIZE PRINCIPLE

The Story Bible should be comprehensive enough to protect the novel but compact enough to retrieve selectively.

Do not treat completeness as the objective.

A 150-page encyclopedia that obscures important facts is less useful than a concise 30-page bible containing only what actually affects the story.

Prioritize:

1. story identity;
2. character identity;
3. world constraints;
4. major relationships;
5. plot-relevant history;
6. canon locks;
7. artistic identity.

Background trivia should remain optional.

---

# 52. RETRIEVAL PRINCIPLE FOR THIS FILE

The entire Story Bible should not necessarily be brought into active context for every scene.

Retrieve relevant sections according to task.

For example:

## Writing dialogue between two characters

Retrieve:

- both character profiles;
- relationship baseline;
- current relationship state;
- relevant cultural context;
- current scene state.

---

## Writing magic combat

Retrieve:

- involved characters;
- relevant magic rules;
- location;
- physical state;
- current resources.

---

## Planning political consequences

Retrieve:

- political institutions;
- factions;
- social hierarchy;
- reputation systems;
- relevant character motives.

---

# 53. STORY BIBLE COMPLETION TEST

Before beginning serious drafting, the bible does **not** need every section completed.

At minimum, the system should know enough about:

### Story identity

What are we actually writing?

### Main character identity

Who are the central people?

### Immediate world

Where does the opening happen?

### Important rules

What constraints matter immediately?

### Starting relationships

What history already exists?

### Initial conflict

What pressure begins the story?

### POV

Who can perceive what?

### Artistic identity

What should make this work feel specifically itself?

Everything else can develop when needed.

---

# 54. CENTRAL REMINDER

The Story Bible is not the novel.

It should not attempt to pre-write every answer.

Its purpose is to preserve enough stable truth that creativity can occur **inside a coherent world**.

Use it to protect:

- identity;
- canon;
- causality;
- character;
- world rules;
- and artistic direction.

Do not use it to eliminate discovery.

The best Story Bible should create boundaries strong enough to make invention meaningful while leaving enough open space for the novel to surprise its own author.

The important distinction going forward is this: **this file is a template, not something you fill out now.** When you start an actual novel, we duplicate it, remove irrelevant sections, and build the story-specific version progressively. It should never become a requirement that you answer fifty worldbuilding questions before writing Chapter 1.

**Remaining system-building stages:**
1. **Reusable Continuity & Knowledge Ledger Templates**
2. **Reusable Character & Relationship State System**
3. **Reusable Scene/Chapter State System**
4. **Pre-Writing Gate**
5. **Drafting Protocol**
6. **Post-Draft Audit**
7. **Anti-Repetition / Pattern Audit**
8. **Long-Range Narrative Audit**
9. **Artistic-Identity / Anti-Homogenization Pass**
10. **Compact Project Instructions — final deployable version**
11. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Reusable Continuity & Knowledge Ledger Templates**. This is where we separate stable Story Bible information from the facts that change while the novel is being written.

Suggested filename: **`03-reusable-continuity-and-knowledge-ledgers.md`**

# REUSABLE CONTINUITY & KNOWLEDGE LEDGER TEMPLATES

## Purpose

This document defines the dynamic ledgers used to preserve story reality across a long novel.

The Story Bible answers:

> What is generally true about this novel?

The ledgers answer:

> What is true now because of everything that has happened so far?

These ledgers should protect the novel from:

- timeline drift;
- object inconsistency;
- impossible movement;
- forgotten injuries;
- relationship resets;
- knowledge leakage;
- forgotten promises;
- changing world rules;
- vanished consequences;
- and characters knowing things they should not know.

The ledgers are not prose.

They are not meant to become detailed summaries of every chapter.

They should record only information that may matter later.

The central operating principle is:

> Track durable changes, not every event.

---

# 1. LEDGER SYSTEM OVERVIEW

The system should distinguish several types of continuity.

Recommended dynamic ledgers:

1. Timeline Ledger
2. Character Location Ledger
3. Physical State Ledger
4. Object & Resource Ledger
5. Knowledge Ledger
6. Secret & Information-Flow Ledger
7. World-State Ledger
8. Open Consequence Ledger
9. Setup & Payoff Ledger
10. Canon Change Log

Relationship state and character psychological state will receive their own dedicated system in the next document.

Scene/chapter state will also receive its own dedicated system later.

---

# 2. GENERAL LEDGER RULE

Do not add an entry simply because something happened.

Add an entry when the fact may constrain or meaningfully influence later writing.

Good candidates:

- time advanced significantly;
- someone changed location;
- an injury occurred;
- an important object changed hands;
- a character learned something important;
- a secret became exposed;
- an institution changed status;
- a consequence has not yet arrived;
- a setup now requires future attention;
- established canon was deliberately changed.

Poor candidates:

- someone drank tea;
- a character briefly felt annoyed;
- someone crossed a room;
- a chair was moved;
- a minor object was used once and discarded.

Unless those details matter later, they do not belong in persistent state.

---

# 3. STATUS MARKERS

Use simple status markers where useful.

### `[ACTIVE]`

Currently relevant.

### `[RESOLVED]`

No longer requires future tracking.

### `[DORMANT]`

Not currently active but may matter later.

### `[UNCERTAIN]`

Information exists but reliability is unclear.

### `[LOCKED]`

Hard canon.

### `[REVISED]`

Previously established information intentionally changed.

### `[OBSOLETE]`

Should no longer guide the story.

---

# 4. TIMELINE LEDGER

## Purpose

Track chronology and elapsed time.

This prevents contradictions involving:

- dates;
- ages;
- travel;
- recovery;
- deadlines;
- relationship duration;
- seasons;
- pregnancies;
- institutional response;
- and historical sequence.

---

## Template

### Entry ID

`TIME-###`

### Story date

Exact date if the story uses one.

### Relative date

Example:

Day 17 since departure.

### Time of day

### Chapter / scene

### Event

### Characters involved

### Location

### Duration

How long did the event take?

### Time advanced since previous entry

### Deadline implications

### Age implications

If relevant.

### Recovery implications

If relevant.

### Notes

---

# 5. TIMELINE MASTER SNAPSHOT

Maintain a compact current snapshot.

## Current story date

## Current time

## Days since story opening

## Current season

## Major active deadlines

## Upcoming scheduled events

## Important elapsed durations

Examples:

- Mara and Elias have known each other for 31 days.
- Jon has been injured for 6 days.
- Election occurs in 4 days.
- Army arrives in approximately 2 days.

This snapshot should be easier to retrieve than the full chronological ledger.

---

# 6. TIMELINE CHECK RULES

Before writing events dependent on time, ask:

> How long has actually passed?

> Does the physical recovery make sense?

> Has this relationship had enough time to develop?

> Could this journey fit?

> Has an established deadline already passed?

> Does the season still match?

When the answer is uncertain, consult the ledger rather than guessing.

---

# 7. LOCATION LEDGER

## Purpose

Track where important characters and objects physically are.

This is especially useful in:

- multi-POV stories;
- war;
- political intrigue;
- travel narratives;
- mysteries;
- heists;
- large casts;
- fantasy quests.

---

## Template

### Entry ID

`LOC-###`

### Character / group

### Current location

### More precise position

If necessary.

### Arrived

When?

### Previous location

### Method of travel

### Travel duration

### Known destination

If any.

### Who knows they are here?

### Restrictions

Cannot leave?

Being watched?

No transport?

### Status

---

# 8. LOCATION MASTER SNAPSHOT

Use a compact table-like format:

### Character

Current location:

Last confirmed:

Destination:

Travel constraint:

This snapshot should cover only characters whose location matters to current plot logic.

---

# 9. PHYSICAL STATE LEDGER

## Purpose

Track durable bodily conditions.

Examples:

- wounds;
- illness;
- exhaustion;
- disability;
- intoxication;
- pregnancy;
- magical injury;
- poisoning;
- hunger;
- sleep deprivation;
- physical transformation.

---

## Template

### Entry ID

`BODY-###`

### Character

### Condition

### Cause

### Severity

### Date acquired

### Treatment

### Current limitation

### Expected recovery

### Permanent effect?

### Last confirmed status

### Status

---

# 10. PHYSICAL STATE SNAPSHOT

For each currently relevant character:

### Character

Current injuries:

Current illness:

Fatigue:

Mobility:

Pain:

Medication/treatment:

Other physical limitations:

Do not record routine healthy status unless needed.

---

# 11. PHYSICAL CONTINUITY RULE

An injury should matter according to its severity.

It does not need to be mentioned continuously.

Instead, it may affect:

- movement;
- posture;
- sleep;
- combat;
- concentration;
- clothing;
- travel;
- decision-making;
- dependence on others.

Avoid two opposite failures:

### Forgotten injury

The body behaves as though nothing happened.

### Overtracked injury

Every paragraph reminds the reader about it long after the point is established.

The ledger protects continuity so the prose does not need constant reminders.

---

# 12. OBJECT & RESOURCE LEDGER

## Purpose

Track plot-relevant possessions and resources.

Examples:

- weapons;
- keys;
- letters;
- evidence;
- money;
- vehicles;
- artifacts;
- medicine;
- phones;
- documents;
- magical items;
- ammunition;
- food reserves;
- political leverage.

---

## Template

### Entry ID

`OBJ-###`

### Object / resource

### Current owner or controller

### Current location

### Previous owner

### Condition

### Quantity / charges

If relevant.

### Acquired

When and how?

### Restrictions

### Who knows about it?

### Why it matters

### Status

---

# 13. OBJECT HISTORY

For very important objects, preserve major transfers.

Example structure:

### Object

Black Key

### History

1. Held by Elias at story opening.
2. Given to Mara — Chapter 7.
3. Stolen from Mara — Chapter 12.
4. Recovered by Jon — Chapter 13.
5. Currently held by Jon.

This prevents duplicated possession and impossible use.

---

# 14. RESOURCE CONTINUITY

Resources may be consumable.

Examples:

- money;
- ammunition;
- magical energy;
- political favors;
- medicine;
- fuel;
- food;
- troops;
- time.

If resource scarcity is narratively meaningful, track:

### Starting amount

### Amount spent

### Amount acquired

### Current amount

### Access restrictions

### Who controls it

Do not turn the novel into accounting unless resource limits actually matter.

---

# 15. KNOWLEDGE LEDGER

## Purpose

Track what important characters know and do not know.

This is one of the most important dynamic systems.

The model should never assume:

> If the story knows it, the character knows it.

Knowledge must remain character-specific.

---

# 16. KNOWLEDGE STATES

For important facts, distinguish:

### KNOWN

Character possesses reliable information.

### BELIEVED

Character thinks something is true.

May be right or wrong.

### SUSPECTED

Character considers it plausible.

### MISUNDERSTOOD

Character possesses relevant information but interprets it incorrectly.

### RUMORED

Character has heard unverified information.

### UNKNOWN

Character has no relevant knowledge.

### FORGOTTEN

Character once knew but cannot currently recall or no longer retains it.

### CONCEALED

Character knows but is intentionally hiding it.

### PARTIAL

Character possesses only part of the relevant information.

---

# 17. FACT-CENTERED KNOWLEDGE ENTRY

For major information, track the fact first.

## Fact ID

`KNOW-###`

## Objective fact

What is actually true?

## Canon level

Locked / Approved / Working.

## Reader knows?

Yes / No / Partial.

## Characters who know

## Characters who suspect

## Characters who misunderstand

## Characters who do not know

## Characters concealing it

## Source of knowledge

How did each person learn it?

## Reliability

How certain is the underlying information?

## Story consequence

Why does knowledge distribution matter?

---

# 18. CHARACTER-CENTERED KNOWLEDGE SNAPSHOT

For scenes, a character-centered form may be easier.

## Character

### Knows

### Believes

### Suspects

### Misunderstands

### Does not know

### Conceals

### Recently learned

### Recently disproven

Only include knowledge relevant to current or upcoming story decisions.

---

# 19. KNOWLEDGE ACQUISITION ENTRY

Whenever an important character learns something significant:

### Character

### Information learned

### Source

Observed directly?

Told by whom?

Document?

Inference?

Rumor?

### Reliability from character perspective

### Actual reliability

### Character interpretation

### Immediate consequence

### Who knows this character learned it?

This last field matters in intrigue.

Knowing that someone knows can itself be important.

---

# 20. INFORMATION SOURCE RULE

Before allowing a character to know something, ask:

> What is the source?

Valid routes may include:

- direct observation;
- conversation;
- letter;
- public announcement;
- investigation;
- surveillance;
- rumor;
- inference;
- professional knowledge;
- memory;
- supernatural means.

If no route exists, knowledge should not appear merely because it is convenient.

---

# 21. KNOWLEDGE CERTAINTY RULE

Do not convert suspicion into certainty silently.

A character may think:

> Elias probably betrayed us.

That is not equivalent to:

> Elias betrayed us.

Later prose should preserve that difference unless evidence changes the state.

---

# 22. SECRET LEDGER

## Purpose

Secrets require more than knowledge tracking.

A secret has:

- holders;
- targets;
- risk;
- evidence;
- transmission paths;
- and consequences of exposure.

---

## Template

### Secret ID

`SECRET-###`

### Secret

### Objective truth

### Original holder

### Current holders

### People who suspect

### People who must not know

### Evidence that exists

### Evidence destroyed

### Exposure risk

Low / medium / high.

### How it could spread

### Why it is concealed

### Consequence if exposed

### Current status

---

# 23. INFORMATION-FLOW LEDGER

Use when transmission itself matters.

## Information

## Origin

## First receiver

## Transmission route

## Current recipients

## Distortion introduced

## Current public version

## Actual truth

This is useful for:

- rumors;
- political propaganda;
- military intelligence;
- gossip;
- public scandal;
- conspiracy plots.

Information does not need to remain accurate as it spreads.

---

# 24. RUMOR MODEL

For important rumors:

### Origin

### Original claim

### Who spread it

### Current version

### Who believes it

### Who doubts it

### What part is true

### What part is false

### Who benefits from the rumor

### Current consequence

This makes social information behave causally rather than teleport accurately.

---

# 25. WORLD-STATE LEDGER

## Purpose

Track durable changes to the setting itself.

Examples:

- government falls;
- city is damaged;
- bridge destroyed;
- law changes;
- war begins;
- magical event alters environment;
- institution loses leadership;
- trade route closes;
- epidemic spreads.

---

## Template

### Entry ID

`WORLD-###`

### Event/change

### Date

### Location / scope

### Previous state

### New state

### Who caused it

### Who knows

### Immediate consequences

### Delayed consequences

### Institutions affected

### Social response

### Economic response

### Political response

### Status

---

# 26. WORLD-STATE SNAPSHOT

Maintain only current important conditions.

Examples:

### Government

### War / peace status

### Major institutional conditions

### Public crises

### Travel restrictions

### Economic disruptions

### Major environmental conditions

### Public knowledge

This gives the current world condition without rereading every event.

---

# 27. OPEN CONSEQUENCE LEDGER

## Purpose

Some consequences do not arrive immediately.

This ledger prevents them from being forgotten.

Examples:

- authorities will investigate;
- injury may worsen;
- insulted noble may retaliate;
- unpaid debt remains;
- rumor will spread;
- damaged bridge will interrupt trade;
- secret exposure may cause political fallout.

---

## Template

### Consequence ID

`CONS-###`

### Originating event

### Created in chapter / scene

### Expected consequence

### Who is affected

### Likely timing

### Trigger required

If any.

### Current visibility

Does anyone know this is coming?

### Possible forms

If not predetermined.

### Status

Active / dormant / resolved.

### Resolution

When eventually paid off.

---

# 28. CONSEQUENCE RULE

Do not treat every open consequence as a guaranteed predetermined event.

Some consequences represent pressure, not destiny.

Example:

Weak:

> Noble will definitely assassinate Mara in Chapter 20.

Better:

> Mara's public insult creates retaliation risk from House Vale. Form of retaliation remains undecided.

Unless the future event has already been locked.

This preserves discovery and planning flexibility.

---

# 29. SETUP & PAYOFF LEDGER

## Purpose

Track narrative expectations created during drafting.

The Story Bible may contain planned setups.

This dynamic ledger records what the prose has **actually established**.

---

## Template

### Setup ID

`SETUP-###`

### Setup

### First appearance

### Type

Mystery / promise / object / relationship / warning / ability / motif / goal / world rule / other.

### Strength of emphasis

Low / medium / high.

### Reader expectation created

### Characters aware

### Planned function

If known.

### Current state

Active / transformed / resolved / deliberately unresolved.

### Payoff requirement

Low / medium / high.

### Payoff

When it occurs.

### Notes

---

# 30. SETUP STRENGTH RULE

Narrative obligation should partly follow emphasis.

### Low emphasis

May never require explicit payoff.

### Medium emphasis

Should usually contribute again.

### High emphasis

Creates meaningful reader expectation.

Should normally receive:

- payoff;
- transformation;
- reinterpretation;
- deliberate subversion;
- or intentional non-resolution.

Do not accidentally create high-emphasis setups just because ominous prose sounds interesting.

---

# 31. PAYOFF ENTRY

When a setup resolves:

### Setup ID

### Payoff event

### Chapter / scene

### What was answered

### What changed

### Remaining consequences

### Was expectation fulfilled, altered, or denied?

### New setup created?

Payoff may create further story rather than simply closing a thread.

---

# 32. CANON CHANGE LOG

## Purpose

Track deliberate revisions to established information.

This helps prevent old versions from continuing to influence drafting.

---

## Template

### Change ID

`CANON-###`

### Date of revision

### Old canon

### New canon

### Reason

### Files affected

### Chapters affected

### Ledgers affected

### Retcon required?

Yes / No.

### Status

---

# 33. CANON REVISION RULE

Do not simply add a new fact beside an old contradictory fact.

When canon changes deliberately:

1. identify the old information;
2. mark it obsolete or revise it;
3. update dependent records;
4. note affected chapters if necessary.

Otherwise retrieval may surface both versions later.

---

# 34. HARD FACT REGISTER

For especially dangerous continuity facts, maintain a compact register.

Examples:

### Character ages

### Family relationships

### Deaths

### Major dates

### Key geography

### Important world restrictions

### Permanent injuries

### Irreversible events

### Established identities

### Important object destruction

This is a high-priority contradiction shield.

---

# 35. NUMERICAL LEDGER

Use only when exact numbers matter.

Track things such as:

### Money

### Distances

### Populations

### Ammunition

### Troop counts

### Votes

### Scores

### Magic charges

### Resource quantities

### Ages

### Dates

Template:

### Quantity

### Current value

### Source

### Last updated

### Dependences

Avoid inventing precise numbers unnecessarily.

Every exact number becomes a possible continuity obligation.

---

# 36. WORLD-RULE REGISTER

This may overlap with the Story Bible but serves as a short retrieval layer.

For each plot-relevant rule:

### Rule

### Scope

### Exceptions

### Cost

### Known by whom

### Last demonstrated

### Consequence if broken

This lets the model retrieve important rules quickly without loading the entire worldbuilding section.

---

# 37. RULE DISCOVERY TRACKING

World rules may be partially understood.

Distinguish:

### Objective rule

What is actually true.

### Public understanding

What society believes.

### Expert understanding

What specialists believe.

### Character understanding

What a particular POV knows.

### Unknown aspect

What has not yet been discovered.

This is particularly important for:

- mystery-based magic;
- science fiction;
- supernatural horror;
- conspiracy narratives.

---

# 38. INSTITUTIONAL STATE LEDGER

Use when organizations change substantially.

For each relevant institution:

### Institution

### Leadership

### Current goal

### Current resources

### Current alliances

### Current enemies

### Current crisis

### Recent change

### Public position

### Hidden position

### Current relation to protagonist

This is dynamic.

The Story Bible contains baseline institution identity.

---

# 39. REPUTATION LEDGER

Use when social perception matters.

For important characters or groups:

### Subject

### Group perceiving them

Different communities may hold different opinions.

### Current reputation

### Why

### Major event influencing perception

### Accuracy

### Who is spreading the narrative

### Consequence

A protagonist need not have one universal reputation.

They may be:

hero to one group;

criminal to another;

irrelevant to most people.

---

# 40. EVIDENCE LEDGER

Useful for:

- mystery;
- legal drama;
- investigation;
- conspiracy;
- thriller.

For each evidence item:

### Evidence ID

### Description

### Objective significance

### Current location

### Current holder

### Who has examined it

### What each person thinks it means

### Reliability

### Contamination / alteration

### Public?

### Status

This keeps clue logic separate from reader interpretation.

---

# 41. MYSTERY-FAIRNESS SUPPORT

For mysteries, maintain a writer-only record:

### Truth

### Evidence establishing truth

### Evidence readers have seen

### Evidence protagonist has seen

### Misdirection

### Alternative explanation

### Missing link

### Earliest point solution becomes reasonably possible

This helps prevent:

- impossible solutions;
- psychic detectives;
- clues appearing only at the reveal;
- or characters possessing information readers were never given when fairness is intended.

---

# 42. PROMISE LEDGER

Not every narrative promise is a mystery.

Possible promises include:

- protagonist vows revenge;
- rival promises rematch;
- character plans to return home;
- tournament announced;
- wedding scheduled;
- invasion predicted;
- someone promises to tell the truth later.

Template:

### Promise

### Created by

### Date

### Characters aware

### Reader expectation

### Deadline

### Current obstacle

### Status

Promises can be broken.

Broken promises still require narrative consequence.

---

# 43. DEBT / OBLIGATION LEDGER

Use where favors and obligations matter.

### Debtor

### Creditor

### Nature of obligation

### Created when

### Terms

### Social/legal force

### Current expectation

### Fulfilled?

This can support:

- crime fiction;
- politics;
- fantasy;
- social drama;
- relationship conflict.

---

# 44. WHAT SHOULD NOT BE COMBINED

Some information categories are related but should remain conceptually separate.

## Fact vs knowledge

A fact can be true without any character knowing it.

## Knowledge vs belief

A character can believe something without reliable evidence.

## Object existence vs object possession

Knowing an object exists does not mean knowing where it is.

## Relationship state vs character emotion

Someone may currently be angry while the underlying relationship remains strong.

## Setup vs consequence

A setup creates reader expectation.

A consequence arises causally from events.

Some events are both, but the categories should remain distinct.

---

# 45. CURRENT-STATE SUMMARY

To avoid retrieving entire ledgers during drafting, maintain a compact current-state summary.

Suggested structure:

# CURRENT STORY STATE

## Time

## Active locations

## Major character physical states

## Important object possession

## Important current knowledge changes

## Active secrets

## Important world-state changes

## Open consequences likely to matter soon

## Active setups likely to matter soon

## Immediate deadlines

This file or section should remain short.

Its purpose is high-speed retrieval.

---

# 46. RECENT-CHANGES SUMMARY

A second useful layer:

## Changes since last chapter

### Time

### Location

### Body

### Objects

### Knowledge

### Secrets

### World state

### Consequences

### Setups/payoffs

Only record changes.

This can then be merged into longer-term ledgers.

---

# 47. LEDGER UPDATE PROCEDURE

After accepted drafting:

## Step 1 — Extract durable changes

Ask:

What became newly true?

## Step 2 — Classify each change

Time?

Location?

Body?

Object?

Knowledge?

World state?

Consequence?

Setup?

## Step 3 — Update relevant ledger only

Do not rewrite all ledgers.

## Step 4 — Resolve obsolete entries

If a condition ended, mark it resolved.

## Step 5 — Refresh current-state summary

Keep immediate retrieval accurate.

---

# 48. LEDGER UPDATE EXAMPLE

Suppose a chapter contains:

Mara confronts Elias at the East Gate.

During the confrontation:

- Elias reveals the king knew about the invasion.
- Mara injures her shoulder.
- Mara gives Jon the black key.
- The East Gate is destroyed.
- A guard witnesses Mara using illegal magic.
- Elias escapes toward the river.

The ledger updates would be:

## Timeline

Event date/time recorded.

## Location

Elias → moving toward river.

Mara → East Gate ruins.

Jon → East Gate ruins.

## Physical state

Mara → injured shoulder.

## Object ledger

Black key → transferred Mara → Jon.

## Knowledge ledger

Mara now knows the king knew about invasion.

Jon may or may not know depending on whether he heard the exchange.

## World state

East Gate destroyed.

## Open consequences

Illegal magic witnessed by guard → possible legal/political response.

Gate destruction → travel/security consequence.

## Setup/payoff

If the black key was previously emphasized, its transfer may affect that setup.

This is enough.

There is no need to record every line of the confrontation.

---

# 49. LEDGER RETRIEVAL BY TASK

## Writing an action scene

Retrieve:

- current locations;
- physical states;
- important objects;
- world rules;
- immediate time.

## Writing an interrogation

Retrieve:

- knowledge states;
- secrets;
- evidence;
- relationship state;
- relevant timeline.

## Writing political fallout

Retrieve:

- world state;
- reputation;
- institutions;
- open consequences;
- information flow.

## Writing a mystery reveal

Retrieve:

- objective truth;
- knowledge ledger;
- evidence ledger;
- setup/payoff ledger;
- timeline.

## Writing a travel scene

Retrieve:

- geography;
- location ledger;
- timeline;
- physical state;
- resources.

---

# 50. LEDGER CONFLICT HANDLING

If two ledger entries conflict:

## First

Determine whether one is newer.

## Second

Check canon level.

## Third

Check whether one reflects:

- objective fact;
- character belief;
- rumor;
- outdated state.

## Fourth

If still unresolved, flag contradiction.

Do not silently select whichever value is more convenient.

---

# 51. UNKNOWN INFORMATION

The ledgers should permit:

`UNKNOWN`

Do not invent answers merely because a field exists.

Example:

### Exact distance between cities

`UNKNOWN — not yet established.`

This is safer than inventing:

`42 miles`

and accidentally creating a permanent constraint.

---

# 52. PROVISIONAL INFORMATION

When drafting requires a temporary choice:

### `[PROVISIONAL]`

Example:

`[PROVISIONAL] Journey currently estimated at 2 days. Not yet established in prose.`

Once written and accepted, it may become canon.

This prevents working assumptions from being mistaken for established facts.

---

# 53. LEDGER SIZE CONTROL

Dynamic files can become enormous.

To avoid this:

### Keep current state separate from historical state.

### Archive resolved entries periodically.

### Remove obsolete planning.

### Summarize old low-risk continuity.

### Preserve high-risk facts explicitly.

A long novel should not require retrieving five hundred resolved injuries to write Chapter 80.

---

# 54. ACTIVE VS ARCHIVE STRUCTURE

A practical long-story structure may eventually use:

## ACTIVE

Current information likely to matter soon.

## ARCHIVE

Resolved or older information preserved for audit and reference.

Example:

`STATE-continuity-active.md`

`ARCHIVE-continuity-history.md`

We will decide whether this split is necessary during final Project Assembly.

Do not implement it automatically for short novels.

---

# 55. LEDGER AUTHORITY

When ledger and prose disagree:

### Published/accepted prose normally outranks ledger.

The ledger is a memory aid.

It is not reality itself.

If the ledger contains:

> Mara owns black key.

but Chapter 19 clearly shows Mara giving it to Jon and the ledger was not updated, Chapter 19 is authoritative.

The ledger should then be corrected.

---

# 56. LEDGERS SHOULD NOT CONTROL CHARACTER BEHAVIOR MECHANICALLY

A ledger might say:

> Mara distrusts Elias.

That does not mean every scene must show distrust identically.

Likewise:

> Mara's shoulder is injured.

does not mean every paragraph must mention the injury.

Ledgers preserve constraints and state.

They should not become repetitive prose instructions.

---

# 57. KNOWLEDGE-LEAKAGE AUDIT

Periodically check:

### Does a character reference an event they did not witness?

### Do they know a secret without a transmission route?

### Are they using terminology they have not learned?

### Are they reacting to information only the reader knows?

### Did suspicion become certainty without evidence?

### Did information pass between characters off-page plausibly?

This audit is especially important in multi-POV stories.

---

# 58. CONTINUITY AUDIT

Periodically compare:

### Timeline

### Locations

### Objects

### Physical state

### World state

### World rules

### Numerical facts

### Institutional state

### Important consequences

Look for contradictions across chapters rather than only inside individual scenes.

---

# 59. LEDGER MINIMUM VIABLE SET

Not every novel needs every ledger.

For a simple novel, the minimum may be:

### Timeline

### Knowledge

### Important objects

### Open consequences

### Current story state

For a complex fantasy epic, the project may need nearly all of them.

Use complexity proportional to the story.

---

# 60. WHEN TO CREATE A NEW LEDGER

Create a separate ledger only when:

- information recurs;
- forgetting it would damage the story;
- it cannot be handled cleanly in an existing ledger;
- and the story actually depends on it.

Do not create files merely because the system allows them.

---

# 61. CENTRAL REMINDER

Continuity is not about proving that the writer can remember trivia.

It is about preserving consequence.

The important questions are:

> What became true?

> Who knows it?

> Who does not?

> What changed hands?

> What changed physically?

> What changed in the world?

> What consequence is still traveling forward?

> What promise has the story made?

> What established fact now constrains future choices?

A strong ledger system allows the prose to remain natural because the story's memory exists elsewhere.

The reader should feel that the novel remembers itself.

They should not feel the bookkeeping that makes that possible.

This document is also a **reusable framework**. For a particular novel, we should not automatically create ten separate files on day one. We will choose only the ledgers the novel actually requires, then populate them as durable facts begin accumulating.

The next section becomes more psychological rather than factual: **Character & Relationship State System**. That will distinguish permanent character identity from temporary state, track believable change, and prevent relationships from resetting after important scenes.

**Remaining system-building stages:**
1. **Reusable Character & Relationship State System**
2. **Reusable Scene/Chapter State System**
3. **Pre-Writing Gate**
4. **Drafting Protocol**
5. **Post-Draft Audit**
6. **Anti-Repetition / Pattern Audit**
7. **Long-Range Narrative Audit**
8. **Artistic-Identity / Anti-Homogenization Pass**
9. **Compact Project Instructions — final deployable version**
10. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Reusable Character & Relationship State System**. This is the layer that prevents temporary emotion from overwriting personality, prevents characters from becoming plot utilities, and prevents relationships from resetting after meaningful scenes.

Suggested filename: **`04-reusable-character-and-relationship-state-system.md`**

# REUSABLE CHARACTER & RELATIONSHIP STATE SYSTEM

## Purpose

This document defines how to track changing character and relationship states during a novel.

The Story Bible contains relatively stable information such as:

- personality;
- history;
- worldview;
- baseline voice;
- long-term values;
- formative experiences;
- major relationships;
- broad arc direction.

The state system tracks what is true **right now**.

This distinction is essential.

A character can be:

normally confident

but currently frightened.

Normally affectionate

but currently resentful.

Normally cautious

but currently acting recklessly under pressure.

Normally honest

but presently concealing something.

The temporary condition should not overwrite the permanent character.

Likewise, a relationship can remain:

deeply loving

while currently angry.

Historically distrustful

while temporarily cooperative.

Romantically attracted

while presently distant.

The central principles are:

> Identity is not state.

> State is not destiny.

> Relationships are histories, not labels.

> Character change should accumulate rather than reset.

---

# 1. TWO-LAYER CHARACTER MODEL

Every important character should be understood through two simultaneous layers.

## LAYER A — BASELINE IDENTITY

Relatively stable.

Examples:

- temperament;
- values;
- worldview;
- cognitive habits;
- voice;
- conflict style;
- emotional tendencies;
- competencies;
- fears;
- social habits;
- long-standing contradictions.

This comes primarily from the Story Bible.

---

## LAYER B — CURRENT STATE

Dynamic.

Examples:

- immediate goal;
- current mood;
- recent emotional residue;
- current injuries;
- current suspicions;
- current relationship attitudes;
- active fear;
- current stress;
- short-term strategy;
- current level of trust.

This belongs in the state system.

---

# 2. WHY THE DISTINCTION MATTERS

Without this distinction, long-form AI writing commonly drifts in two directions.

## Failure A — Emotional overwrite

A temporary emotion becomes the character's new personality.

Example:

A normally restrained character becomes angry in one chapter.

The next three chapters write them as generally aggressive.

---

## Failure B — Personality reset

Important experiences affect the character briefly.

Then the story restores their original behavior as though nothing happened.

Example:

A character learns they were betrayed.

One chapter later, their trust and behavior return to baseline.

The state system exists to prevent both.

---

# 3. CHARACTER STATE ENTRY

For each major character, maintain a compact current-state record.

## Character

### Current location

### Current immediate goal

### Current secondary goal

### Current emotional state

### Emotional residue

What from recent scenes is still affecting them?

### Current physical condition

### Current stress level

Low / moderate / high / extreme.

### Current confidence

### Current fear

### Current desire

### Current frustration

### Current suspicion

### Current beliefs relevant to present action

### Recent knowledge changes

### Current strategy

### Current social posture

Open? Guarded? Defensive? Performative? Withdrawn?

### Current relationship pressures

### Active secrets

### Immediate constraints

### Current risk tolerance

### Current decision pressure

### Current unresolved internal conflict

### Last meaningful change

### Status timestamp

Chapter / scene / story date.

This should remain concise.

---

# 4. CHARACTER STATE SHOULD BE SELECTIVE

Do not populate every emotional field for every character after every scene.

Track only what is active enough to influence later behavior.

For example:

Weak state entry:

> mildly tired, slightly irritated, somewhat hungry, somewhat confused.

Unless those conditions matter, they create noise.

Stronger:

> Still furious at Jon after learning he concealed the envoy's visit. Wants cooperation but refuses emotional vulnerability.

This predicts future behavior more usefully.

---

# 5. EMOTIONAL RESIDUE

## Purpose

Track emotions that survive beyond the scene in which they appeared.

Examples:

- resentment;
- embarrassment;
- grief;
- attraction;
- suspicion;
- relief;
- shame;
- guilt;
- resentment after forgiveness;
- uncertainty after revelation.

---

## Template

### Originating event

### Emotion

### Strength

### Conscious?

Yes / No / Partial.

### Character interpretation

### Expected behavioral effect

### Likely duration

Short / medium / long / unknown.

### Changed by

What could reduce, transform, or intensify it?

### Current status

This allows emotion to persist without requiring constant explicit reference.

---

# 6. EMOTIONAL RESIDUE RULE

Do not assume:

> Important event → permanent emotional effect.

Nor:

> Important event → no lasting effect after scene ends.

Ask:

> What would this particular person carry forward?

Some people ruminate.

Some suppress.

Some recover quickly.

Some convert fear into control.

Some convert shame into aggression.

Some act normally while remaining deeply affected.

Track the **behaviorally relevant residue**.

---

# 7. ACTIVE GOAL STATE

Characters may have multiple levels of goals.

Track them separately.

## Long-range goal

Relatively stable.

Example:

Gain political independence.

## Arc-level goal

Relevant to current phase.

Example:

Prevent House Vale from controlling the succession.

## Immediate goal

Relevant now.

Example:

Convince Mara not to reveal the letter.

## Hidden or unacknowledged goal

Optional.

Example:

Preserve Mara's respect.

Goals may conflict.

That conflict can produce strong character behavior.

---

# 8. GOAL CHANGE ENTRY

When a character changes direction significantly:

### Previous goal

### New goal

### Trigger

### Is the change conscious?

### What remains from previous goal?

### Consequence

### Canon status

This helps prevent sudden plot-driven motive replacement.

---

# 9. CURRENT BELIEF STATE

A character's beliefs can evolve independently from objective truth.

Track when important.

## Character believes

## Confidence

Low / moderate / high.

## Evidence

## What would change this belief?

## Is belief accurate?

Yes / No / Partial / Unknown.

## Last updated

This works alongside the knowledge ledger.

The knowledge ledger tracks information.

The character-state system tracks how that information affects the person's worldview and behavior.

---

# 10. ACTIVE MISBELIEF

Some incorrect beliefs become major behavioral engines.

Template:

### Misbelief

### Origin

### Why character finds it convincing

### Reinforcing evidence

### Contradicting evidence noticed?

### Emotional value of belief

Why might they want it to remain true?

### Behavioral consequence

### Potential correction

### Current status

Do not give every character a simplistic "misbelief they must overcome."

Use only when genuinely relevant.

---

# 11. STRESS STATE

Stress should influence behavior without replacing identity.

Track when important:

### Source of stress

### Level

### Duration

### Sleep impact

### Cognitive impact

### Emotional impact

### Social impact

### Competence impact

### Typical stress behavior

### Current deviation from baseline

A competent character may become worse at certain tasks under pressure while remaining skilled overall.

---

# 12. CHARACTER DECISION STATE

Before major decisions, it can be useful to record:

### Character

### Decision

### Desired outcome

### Feared outcome

### Known options

### Unknown options

### Preferred option

### Internal resistance

### External pressure

### Relevant values

### Relevant relationship pressures

### What information they lack

### Likely choice

This is not mandatory for ordinary actions.

Use it for decisions carrying major consequences.

---

# 13. CHARACTER CHANGE TRACKING

Character development should be tracked as accumulated movement rather than binary transformation.

Use four categories.

## Reinforced

Existing trait becomes stronger.

Example:

Distrust confirmed.

## Challenged

Existing belief or habit experiences pressure.

## Modified

Character begins acting differently.

## Integrated

New behavior becomes part of stable identity.

This prevents one realization from being mistaken for completed growth.

---

# 14. DEVELOPMENT LOG

For meaningful change:

### Development ID

### Character

### Previous baseline

### Pressure/event

### Immediate response

### Resistance

### New behavior attempted

### Result

### Current level of change

Reinforced / Challenged / Modified / Integrated.

### Remaining old tendencies

### Future pressure needed

This should be used only for significant developments.

---

# 15. RELAPSE & REVERSION

Characters can return to old behavior.

This is not necessarily inconsistency.

A relapse may be believable when:

- stressed;
- frightened;
- humiliated;
- triggered;
- socially pressured;
- exhausted;
- tempted;
- or placed back in an old environment.

Track:

### Old behavior

### Trigger for relapse

### Does character recognize it?

### Consequence

### Does relapse undo development?

Usually not entirely.

Strong development often means:

old impulse remains;

response changes gradually.

---

# 16. CHARACTER ARC SNAPSHOT

For major characters:

## Opening baseline

## Current baseline

If changed.

## Major pressures experienced

## Behaviors strengthened

## Behaviors weakened

## Beliefs challenged

## New capabilities

## Lost capabilities

## Current unresolved contradiction

## Current development direction

## Degree of change

Minimal / moderate / significant.

## What remains unchanged

This last field is important.

Growth should not erase identity.

---

# 17. CHARACTER CONSISTENCY CHECK

Before writing a significant action, ask:

### Does this fit baseline identity?

If not:

### Does current state explain the deviation?

If not:

### Does recent development explain it?

If not:

### Is there new information causing it?

If not:

### Is the action being forced by plot convenience?

If yes, reconsider.

This is one of the highest-value checks in long-form fiction.

---

# 18. CHARACTER SURPRISE TEST

A strong character may surprise the reader.

Surprise should ideally become understandable afterward.

Ask:

> Is this unpredictable because the character is deep?

or:

> Is this unpredictable because the writing forgot who they are?

The former is useful.

The latter is drift.

---

# 19. VOICE STATE

Voice itself may temporarily change under circumstances.

For important scenes, note if necessary:

### Baseline voice

### Current deviation

### Cause

Examples:

- usually verbose, now unusually terse;
- normally sarcastic, now humor disappears;
- normally informal, now excessively formal;
- normally direct, now evasive.

This allows meaningful voice variation without losing identity.

---

# 20. CHARACTER STATE EXPIRATION

Temporary states should not persist automatically forever.

Each active state may be:

### Event-bound

Ends when situation ends.

### Short-term

Hours/days.

### Medium-term

Several chapters.

### Long-term

Major arc.

### Permanent / integrated

Becomes identity or lasting consequence.

This distinction prevents accidental persistence or premature disappearance.

---

# 21. RELATIONSHIP MODEL

A relationship should be tracked as something **between people**, not merely as two separate opinions.

Each important relationship may contain:

- history;
- trust;
- intimacy;
- affection;
- resentment;
- dependency;
- obligation;
- attraction;
- power;
- misunderstanding;
- secrets;
- boundaries;
- expectations;
- and habitual interaction.

These dimensions can move independently.

---

# 22. RELATIONSHIP STATE ENTRY

## Relationship

Character A ↔ Character B

### Relationship type

Friendship / romance / family / rivalry / professional / enemy / mixed.

### Current trust

A → B:

B → A:

Trust may be asymmetric.

### Current affection

A → B:

B → A:

### Current resentment

A → B:

B → A:

### Current intimacy

Emotional:

Physical:

Informational:

### Current dependency

A depends on B for:

B depends on A for:

### Current power balance

### Current obligation

### Current fear within relationship

### Current attraction

If relevant.

### Current unresolved conflict

### Current misunderstandings

### Current secrets

### Current boundaries

### Current communication quality

### Current shared goal

### Current conflicting goals

### Recent milestone

### Last significant interaction

### Current trajectory

Closer / more distant / unstable / cooperative / deteriorating / unclear.

---

# 23. RELATIONSHIP DIMENSIONS SHOULD REMAIN INDEPENDENT

A relationship does not need one score.

Two people can have:

high affection;

low trust;

high physical intimacy;

low emotional intimacy;

strong loyalty;

high resentment.

These combinations are often more interesting than:

Relationship = good.

Relationship = bad.

---

# 24. TRUST TRACKING

Trust should be understood in domains.

Someone may trust another:

### Physically

"I believe they will protect me."

### Emotionally

"I can be vulnerable with them."

### Informationally

"I believe what they tell me."

### Strategically

"I trust their judgment."

### Morally

"I believe they will do what is right."

### Practically

"I believe they will do what they promised."

Trust can differ across categories.

---

# 25. TRUST CHANGE ENTRY

### Relationship

### Trust dimension

### Previous state

### Event

### New state

### Does the other person know trust changed?

### Behavioral consequence

### Can it recover?

### What would recovery require?

Do not reduce trust changes to numerical scores unless that helps the particular story.

Qualitative descriptions are usually enough.

---

# 26. INTIMACY TRACKING

Intimacy can also exist in different forms.

### Emotional intimacy

Sharing vulnerable inner experience.

### Informational intimacy

Knowing secrets and private facts.

### Physical intimacy

Touch, physical comfort, sexuality.

### Social intimacy

Being integrated into each other's lives.

### Practical intimacy

Relying on each other in daily routine.

A relationship may progress in one dimension while regressing in another.

---

# 27. RELATIONSHIP MEMORY

After meaningful scenes, ask:

> What will each person remember next time?

Track only durable changes.

Examples:

- new private joke;
- hidden resentment;
- increased ease with touch;
- reduced trust;
- knowledge of a vulnerability;
- unfulfilled promise;
- fear of abandonment;
- changed status.

This creates relational history.

---

# 28. RELATIONSHIP MILESTONE LOG

For major relationships:

### Milestone

### Chapter / scene

### What happened

### A's interpretation

### B's interpretation

### Immediate change

### Long-term significance

### Unresolved residue

The same milestone may mean different things to each person.

---

# 29. RELATIONSHIP RESET CHECK

Before writing recurring characters together, ask:

### What happened last time?

### What changed?

### What does A now expect from B?

### What does B now expect from A?

### What is newly easier?

### What is newly harder?

### What cannot be unsaid?

If the answer is:

> nothing,

then baseline interaction may remain appropriate.

If something meaningful happened, the next interaction should usually inherit it.

---

# 30. RELATIONSHIP ASYMMETRY

Track meaningful imbalance.

Examples:

- A loves B more.
- B trusts A more.
- A knows B's secret.
- B believes relationship is casual.
- A feels indebted.
- B controls money.
- A can leave more easily.
- B possesses social authority.

Asymmetry generates natural tension.

Do not automatically equalize relationships during emotional scenes.

---

# 31. RELATIONSHIP POWER

Power may come from:

- rank;
- money;
- violence;
- age;
- social status;
- knowledge;
- emotional dependency;
- institutional authority;
- reputation;
- legal power;
- control over resources;
- ability to leave.

Track only what matters.

Power can shift over time.

---

# 32. RELATIONSHIP POWER CHANGE

### Relationship

### Previous balance

### Trigger

### New balance

### Does either character recognize the change?

### Behavioral consequence

### Social consequence

This matters especially in:

romance;

politics;

family drama;

crime;

workplace fiction;

master/student dynamics.

---

# 33. SHARED SECRET STATE

Secrets can affect relationships even when not discussed.

Track:

### Secret

### Who knows

### Who knows that the other knows

### Was it voluntarily shared?

### Was it discovered?

### Is it protected jointly?

### Emotional effect

### Power effect

### Risk if exposed

This helps relationships accumulate information history.

---

# 34. OBLIGATION STATE

Relationships often contain debts and promises.

Track when important:

### Character A owes B

### Why

### Formal or informal?

### Does B expect repayment?

### Does A believe repayment is owed?

### Has obligation been fulfilled?

### Emotional meaning

Obligation and affection should not be treated as the same thing.

---

# 35. BOUNDARY STATE

Important boundaries may include:

- topics not discussed;
- physical boundaries;
- social boundaries;
- professional boundaries;
- emotional boundaries;
- secrets not shared;
- forbidden behavior.

Track:

### Boundary

### Established by

### Understood by other person?

### Respected?

### Violated?

### Consequence

### Current status

Boundaries can evolve.

---

# 36. CONFLICT STATE

For persistent relationship conflicts:

### Conflict

### Surface issue

### Deeper issue

### A's interpretation

### B's interpretation

### What A wants

### What B wants

### What sustains conflict

### What would actually resolve it

### Current stage

Dormant / active / escalating / partially resolved / transformed.

### Previous attempts to resolve

This prevents the same conflict from repeating without development.

---

# 37. CONFLICT SHOULD REMEMBER PREVIOUS ATTEMPTS

If characters have already discussed a problem, the next argument should not usually begin from zero.

Later conflict may include:

- old phrasing becoming loaded;
- frustration that "we already discussed this";
- changed tactics;
- less willingness to explain;
- new evidence;
- accumulated resentment;
- increased understanding without agreement.

Repetition with history is different from reset.

---

# 38. RELATIONSHIP TRAJECTORY

Track broad movement only when useful.

Possible trajectories:

### Deepening

### Deteriorating

### Oscillating

### Stabilizing

### Becoming dependent

### Becoming adversarial

### Becoming respectful

### Becoming estranged

### Becoming intimate

### Becoming transactional

### Transforming category

Example:

mentor/student → rivals.

Trajectory should describe current direction, not predetermine the ending.

---

# 39. RELATIONSHIP VERSIONING

For long novels, relationship states may be summarized by phase.

Example:

## Phase 1

Distrustful alliance.

## Phase 2

Functional cooperation; trust begins.

## Phase 3

Personal intimacy develops.

## Phase 4

Betrayal creates affection + resentment + low informational trust.

This provides a useful long-range history without rereading every interaction.

---

# 40. GROUP RELATIONSHIP STATE

Sometimes relationships involve groups rather than pairs.

Examples:

- family;
- team;
- adventuring party;
- military unit;
- friend group;
- political council.

Track:

### Group

### Current cohesion

### Shared goal

### Main fractures

### Leadership

### Informal influence

### Trust distribution

### Hidden alliances

### Shared secret

### Recent destabilizing event

### Current trajectory

Do not force every group dynamic into pairwise relationships if the group itself matters.

---

# 41. SOCIAL ROLE STATE

A character's role in a group may change.

Track when important:

### Character

### Group

### Previous role

### Current role

### Formal authority

### Informal authority

### Reputation

### Who supports them

### Who resents them

### Recent change

This supports political and ensemble fiction.

---

# 42. CHARACTER-RELATIONSHIP INTERACTION

A character's internal state and relationship state should influence each other without being identical.

Example:

Mara's state:

> exhausted, ashamed, defensive.

Relationship state with Elias:

> still high affection, reduced trust.

This combination may produce:

affectionate behavior mixed with refusal to disclose information.

The system should preserve both layers.

---

# 43. CURRENT CHARACTER STATE SNAPSHOT

For high-speed retrieval, maintain a compact section such as:

## Mara

Goal:

Emotion:

Recent residue:

Physical state:

Current belief:

Immediate fear:

Active secret:

Key relationship pressures:

Current strategy:

## Elias

...

Only include active major characters.

---

# 44. CURRENT RELATIONSHIP STATE SNAPSHOT

Similarly:

## Mara ↔ Elias

Trust:

Affection:

Current friction:

Latest change:

Current misunderstanding:

Immediate pressure:

Trajectory:

This is what drafting should retrieve most often.

The full relationship history can remain elsewhere.

---

# 45. STATE UPDATE AFTER A SCENE

After a meaningful scene, ask:

## Character state

Did anyone's:

- goal;
- belief;
- fear;
- emotional state;
- strategy;
- confidence;
- self-concept

change durably?

## Relationship state

Did:

- trust;
- intimacy;
- resentment;
- obligation;
- power;
- misunderstanding;
- attraction;
- boundaries

change?

Update only if yes.

---

# 46. EXAMPLE STATE UPDATE

Scene:

Mara learns Elias lied to protect his brother.

She understands his motive but remains angry.

Elias apologizes but refuses to reveal where his brother is.

Possible updates:

## Mara

### Knowledge

Now knows why Elias lied.

### Emotional residue

Anger reduced slightly; hurt remains.

### Belief

No longer believes Elias lied for political gain.

### Goal

Still wants location of Elias's brother.

### Strategy

Will cooperate but independently verify Elias's claims.

---

## Elias

### Emotional state

Relieved Mara knows motive; still guarded.

### Fear

Mara may expose brother.

### Strategy

Repair cooperation without revealing location.

---

## Mara ↔ Elias

### Trust

Mara's motive-trust improves slightly.

Informational trust remains low.

### Intimacy

Increases because Elias revealed personal motive.

### Conflict

Not resolved.

Surface misunderstanding corrected; actual interest conflict remains.

This is stronger than:

> They understand each other now.

---

# 47. CHARACTER RESET AUDIT

Periodically ask:

### Has this character forgotten an emotional lesson?

### Has a recent fear disappeared without reason?

### Has their goal reverted?

### Has an important revelation stopped affecting behavior?

### Has development vanished under plot pressure?

### Are old habits repeating without history?

A reset may be intentional.

If so, its cause should usually be understandable.

---

# 48. RELATIONSHIP RESET AUDIT

Ask:

### Are these people acting like earlier versions of themselves?

### Is trust at the correct current level?

### Are past betrayals still relevant?

### Is previous intimacy reflected naturally?

### Are secrets still changing interaction?

### Has a boundary been forgotten?

### Is the same conflict repeating identically?

If yes, review state history.

---

# 49. CHARACTER HOMOGENIZATION AUDIT

Compare major characters.

Ask:

### Are their goals too similar?

### Do they process emotion similarly?

### Do they reason similarly?

### Do they all become equally articulate under stress?

### Do they interpret others with similar accuracy?

### Do they all develop toward the same emotional maturity?

### Do they all use the same conflict-resolution strategies?

State tracking should preserve differentiation.

---

# 50. RELATIONSHIP HOMOGENIZATION AUDIT

Compare relationships.

Ask:

### Do all close relationships become emotionally explicit?

### Do all conflicts resolve through conversation?

### Do all romances progress through similar beats?

### Do all friendships use the same banter structure?

### Do all rivals eventually gain mutual respect?

### Do all relationships become healthier over time?

Different relationships should develop according to the people involved.

---

# 51. DEVELOPMENT WITHOUT REPLACEMENT

Before updating a character's baseline identity, ask:

> Has this change persisted long enough to become part of who they are?

Temporary change belongs in state.

Integrated change belongs in baseline.

Example:

After one brave act:

Do not change:

> Cowardly → brave.

Better:

> Has demonstrated willingness to act despite fear under specific conditions.

Later repeated behavior may justify baseline revision.

---

# 52. BASELINE UPDATE RULE

Update permanent character identity only when:

- repeated behavior supports the change;
- major transformation clearly justifies it;
- the author explicitly chooses it;
- or the story has reached a stage where the old baseline is no longer accurate.

When baseline changes, preserve history.

New baseline:

> More willing to confront authority, though old fear resurfaces under institutional pressure.

This is better than erasing the former trait.

---

# 53. STATE UNCERTAINTY

The writer does not always need to know exactly what a character feels.

State can include:

### Ambiguous

### Mixed

### Character does not understand

### Writer intentionally undecided

This can protect discovery and subtext.

Do not force psychological certainty because a template exists.

---

# 54. CONTRADICTORY STATES

Characters can hold simultaneous states.

Examples:

### Loves Elias.

### Does not trust Elias.

### Wants him nearby.

### Is considering leaving him.

All can be true.

Do not compress contradiction into one final emotional label.

---

# 55. CHARACTER AGENCY CHECK

Before major plot turns involving a recurring character, retrieve:

- baseline identity;
- current state;
- current goals;
- relevant relationships;
- current knowledge.

Then ask:

> What would this person actually attempt?

This should inform plot rather than merely justify a predetermined event after the fact.

---

# 56. RELATIONSHIP AGENCY CHECK

For important interactions, ask separately:

### What does A want from this encounter?

### What does B want?

### What does A think B wants?

### What does B think A wants?

These four answers may differ.

That difference creates natural dialogue and conflict.

---

# 57. STATE RETRIEVAL BY TASK

## Writing dialogue

Retrieve:

- baseline voices;
- current emotional states;
- relationship state;
- current goals;
- knowledge differences.

## Writing romantic development

Retrieve:

- attraction;
- intimacy dimensions;
- trust;
- boundaries;
- power;
- previous milestones;
- unresolved conflict.

## Writing an argument

Retrieve:

- persistent conflict;
- recent residue;
- each person's goal;
- each person's interpretation;
- previous attempts at resolution.

## Writing character decision

Retrieve:

- values;
- current state;
- goal;
- fears;
- knowledge;
- relationship pressure;
- competence.

## Writing post-trauma behavior

Retrieve:

- baseline identity;
- physical state;
- emotional residue;
- coping habits;
- available support;
- previous relevant experiences.

---

# 58. ACTIVE VS HISTORICAL STATE

For long novels, separate:

## ACTIVE STATE

What matters now.

## HISTORICAL STATE

Previous important phases.

Example:

Active:

> Mara currently distrusts Elias's strategic judgment.

Historical:

> Chapters 1–8: relied heavily on his judgment.

The history can become important if the relationship changes again.

---

# 59. STATE FILE SIZE CONTROL

Do not let dynamic state become another giant Story Bible.

Regularly:

- resolve inactive temporary states;
- archive completed relationship phases;
- compress old emotional residue;
- retain only development that still matters.

A state file should answer:

> What do I need to understand these people now?

Not:

> What has ever happened to them?

The latter belongs in chapter summaries and history.

---

# 60. MINIMUM VIABLE CHARACTER STATE

For simpler stories, track only:

### Character

Current goal:

Current emotional residue:

Current belief:

Current physical state:

Current major relationship pressures:

Recent meaningful change:

That may be enough.

---

# 61. MINIMUM VIABLE RELATIONSHIP STATE

Track:

### Pair

Current trust:

Current closeness:

Current conflict:

Latest change:

Current misunderstanding:

Current obligation:

Again, only add more dimensions when the story needs them.

---

# 62. STATE AUTHORITY

Accepted prose normally outranks state records.

If the state file says:

> Mara still hates Jon.

but the latest accepted chapter clearly establishes she no longer does, update the state file.

The state system is a model of the novel.

It is not the novel itself.

---

# 63. DO NOT MAKE STATES NUMERIC BY DEFAULT

Avoid unnecessary gamification such as:

Trust = 73/100.

Affection = 84/100.

Resentment = 24/100.

Qualitative states are usually more useful.

Numbers may be appropriate for:

- game-like fiction;
- explicit progression systems;
- highly technical tracking.

Otherwise, language preserves nuance better.

---

# 64. CENTRAL REMINDER

Characters should feel as though they have lived through the novel.

Relationships should feel as though they remember their own history.

To preserve that, distinguish:

**who the person generally is**

from

**what the person is experiencing now.**

And distinguish:

**what two people fundamentally are to one another**

from

**what is currently happening between them.**

Before writing an important character moment, ask:

> Who is this person?

> What has happened to them recently?

> What are they carrying forward?

> What do they want now?

> What do they believe now?

> What has changed?

Then, for relationships:

> What happened last time?

> What did each person take from it?

> What trust was gained or lost?

> What remains unsaid?

> What does each person currently think this relationship is?

The goal is not perfect psychological bookkeeping.

The goal is **continuity of personhood**.

Characters should change without becoming replacements.

Relationships should evolve without becoming resets.

This file should be treated as a **reusable state-management framework**, not something you fully populate before a novel begins. For a specific book, we would create only the character and relationship state records needed for the important recurring cast, then update them after meaningful developments.

**Remaining system-building stages:**
1. **Reusable Scene/Chapter State System**
2. **Pre-Writing Gate**
3. **Drafting Protocol**
4. **Post-Draft Audit**
5. **Anti-Repetition / Pattern Audit**
6. **Long-Range Narrative Audit**
7. **Artistic-Identity / Anti-Homogenization Pass**
8. **Compact Project Instructions — final deployable version**
9. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Reusable Scene/Chapter State System**. This is the bridge between planning and drafting: it keeps each scene grounded in the correct immediate reality, and it ensures the next scene inherits meaningful changes rather than resetting.

Suggested filename: **`05-reusable-scene-and-chapter-state-system.md`**

# REUSABLE SCENE & CHAPTER STATE SYSTEM

## Purpose

This document defines how to track the immediate state surrounding scenes and chapters.

The Story Bible answers:

> What novel are we writing?

The continuity and character-state systems answer:

> What is currently true in the story?

The Scene/Chapter State System answers:

> What is true **here, now, and for this specific unit of writing?**

This system is designed to prevent common long-form failures such as:

- scenes beginning from the wrong continuity state;
- characters forgetting recent revelations;
- injuries disappearing;
- relationship changes not carrying forward;
- POV characters accessing the wrong information;
- scenes repeating earlier dramatic functions;
- chapters ending without creating useful inheritance;
- and “continue” prompts causing arbitrary new events.

The central principles are:

> Every scene enters with a state.

> Every meaningful scene leaves with a state.

> The next scene should inherit what changed.

---

# 1. SCENE STATE VS CHAPTER STATE

These are related but should remain distinct.

## SCENE STATE

Highly immediate.

Tracks:

- who is present;
- where they are;
- what they know;
- what they want;
- what just happened;
- what pressures are active;
- what physical conditions apply;
- and what the scene needs to accomplish.

---

## CHAPTER STATE

Broader.

Tracks:

- what the chapter contributes;
- which scenes it contains;
- how the chapter changes story state;
- which threads advance;
- what the chapter leaves active;
- and what the following chapter inherits.

A chapter may contain one scene or many.

---

# 2. WHY SCENE STATE MATTERS

When a model receives:

> Continue the story.

without enough immediate state, it may invent a plausible next event based on genre convention.

That can create:

- random interruption;
- new antagonist;
- sudden revelation;
- convenient arrival;
- generic emotional conversation;
- or another version of an earlier scene.

A better continuation begins from:

> What conditions are already in motion?

Scene state preserves those conditions.

---

# 3. SCENE STATE TEMPLATE

Use this before drafting important scenes.

## Scene ID

`SCENE-###`

## Chapter

## Story date / time

## Location

## POV

## Present characters

## Relevant absent characters

Who matters even though they are not physically present?

## Entry condition

What is true at the moment the scene begins?

## Immediate context

What happened directly before this?

## Scene purpose

Why does this scene deserve direct dramatization?

## POV immediate goal

What does the viewpoint character want right now?

## Other character goals

What does each important participant want?

## Active conflict

What creates friction or uncertainty?

## Active pressures

External, emotional, social, physical, temporal, informational.

## Relevant relationship state

## Relevant knowledge state

What does each participant know, suspect, misunderstand, or conceal?

## Physical state

Injuries, fatigue, restraints, intoxication, weather exposure, etc.

## Important objects/resources

## Environmental constraints

Privacy, noise, visibility, crowding, weather, architecture, surveillance, etc.

## World rules relevant here

## Open consequences entering the scene

## Active setups/payoffs relevant here

## Scene-specific risks

What can go wrong?

## Desired movement

What should become different by the end?

## Possible but not required turn

What could alter the scene's direction?

## Exit possibilities

What states might plausibly result?

## Notes

---

# 4. SCENE PURPOSE SHOULD NOT BECOME A FORMULA

A scene purpose may be:

- advance plot;
- deepen a relationship;
- create distrust;
- reveal information;
- establish atmosphere;
- recover after pressure;
- let the reader experience normality;
- introduce a social environment;
- complicate a decision;
- show a failed strategy;
- pay off a setup;
- create a promise;
- reveal a character through behavior.

A scene does not need to perform all of these.

The purpose should be specific enough to distinguish it from nearby scenes.

Weak:

> Develop characters.

Better:

> Show that Mara trusts Elias in a crisis but does not trust his explanations afterward.

---

# 5. ENTRY STATE

The scene should inherit the previous story state.

Before drafting, confirm:

### Time

When are we?

### Location

Where exactly are we?

### Physical condition

What bodies are carrying forward?

### Knowledge

What was learned recently?

### Relationship state

What changed in the last relevant interaction?

### Objects

Who possesses important items?

### Open consequences

What is still in motion?

### Emotional residue

What has not yet dissipated?

This is the minimum continuity bridge.

---

# 6. POV STATE

For the selected POV, record:

## What they know

## What they suspect

## What they misunderstand

## What they are actively concealing

## What they expect

## What they fear

## What they notice first

## What they are unlikely to notice

## What they want from this scene

## What they believe the scene is about

The final item is especially important.

The reader may understand the scene differently from the POV.

---

# 7. PARTICIPANT INTENTIONS

For each significant character in the scene:

### Character

### Immediate goal

### Secondary goal

### Hidden concern

### What they want from the POV

### What they think the POV wants

### What they are willing to say

### What they will not say

### What they are prepared to do

### What they are trying to avoid

This prevents dialogue from becoming one shared conversation objective.

---

# 8. SCENE CONFLICT TYPES

Conflict does not always mean argument.

Possible scene pressures include:

### Goal conflict

Characters want incompatible outcomes.

### Information conflict

Someone knows or conceals something important.

### Value conflict

Characters interpret the situation differently.

### Social conflict

Status, reputation, etiquette, or authority constrains behavior.

### Physical conflict

Environment or danger interferes.

### Internal conflict

A character's own desires contradict.

### Temporal conflict

Time is limited.

### Resource conflict

Something needed is scarce.

### Relationship conflict

History alters how people interpret one another.

A scene may contain several simultaneously.

---

# 9. PRESSURE LAYERS

A useful scene rarely needs every pressure active.

But it can help to identify multiple layers.

Example:

## External

Guards are searching the building.

## Interpersonal

Mara does not trust Elias.

## Internal

Mara wants to believe him.

## Physical

Mara's injured shoulder limits movement.

## Temporal

They have ten minutes before the gates close.

## Informational

Elias knows the escape route is compromised but has not said so.

These layers create complexity without requiring artificial twists.

---

# 10. SCENE QUESTION

For many scenes, one useful planning question is:

> What uncertainty keeps the reader engaged here?

Examples:

- Will Mara reveal that she knows?
- Will Elias confess voluntarily?
- Can they leave without being noticed?
- Will the conversation repair or damage trust?
- What is hidden behind the locked door?
- Can the group agree before the deadline?

A scene does not need a formal question every time.

But identifying one can clarify tension.

---

# 11. SCENE MOVEMENT

A scene should usually alter at least one state.

Possible movement:

### Knowledge

Someone learns something.

### Belief

Someone interprets something differently.

### Goal

Someone changes direction.

### Relationship

Trust, intimacy, resentment, obligation, attraction, power.

### Physical state

Injury, location, resource, possession.

### World state

Environment or institution changes.

### Plot state

A possibility opens or closes.

### Emotional state

A feeling deepens, transforms, or becomes clearer.

### Reader understanding

The reader receives a new interpretation.

Not every scene needs dramatic movement.

But the system should know what, if anything, the scene changes.

---

# 12. SCENE TURN

A turn is not mandatory.

When present, it means something changes the direction or meaning of the scene.

Examples:

- new information;
- unexpected refusal;
- interruption;
- reversal of power;
- recognition;
- physical event;
- someone changes strategy;
- hidden motive becomes visible;
- apparent conflict reveals a deeper conflict.

Do not manufacture turns merely to make scenes “dynamic.”

---

# 13. FALSE TURN WARNING

Generated scenes sometimes imitate dramatic structure through superficial reversals.

Examples:

> He smiled—but it wasn't kindness.

> She agreed—then added a condition.

> The door opened—but not to who they expected.

These can work.

But repeated reliance on such reversals creates structural predictability.

A meaningful turn should alter the scene's state or interpretation.

---

# 14. SCENE ENTRY TIMING

Before drafting, decide where to enter.

Possible choices:

### Before the main interaction

Useful for anticipation or atmosphere.

### At the beginning of meaningful pressure

Efficient default.

### Mid-conversation

Useful when setup is unnecessary.

### After something important already happened

Useful when reaction matters more than event.

### During routine activity

Useful when ordinary behavior provides contrast or characterization.

Do not automatically begin with:

- waking up;
- entering a room;
- greeting;
- sitting down;
- ordering food;
- traveling toward destination.

Unless these actions matter.

---

# 15. SCENE EXIT TIMING

A scene can end:

### On change

Decision, revelation, rupture.

### On question

Unresolved uncertainty.

### On image

Strong sensory or symbolic close.

### On action

Character commits to something.

### On silence

When unspoken meaning carries weight.

### After decompression

When aftermath itself matters.

Do not automatically continue until:

- everyone explains themselves;
- the emotional meaning is clarified;
- characters physically leave;
- or next steps are summarized.

---

# 16. SCENE EXIT STATE TEMPLATE

After drafting, record:

## What changed?

## What did not change?

## New knowledge

## New beliefs

## New misunderstandings

## Relationship changes

## Emotional residue

## Physical changes

## Object/resource changes

## Location changes

## New commitments

## New obligations

## New consequences

## Setup created

## Payoff delivered

## Open conflict

## New immediate question

## What the next scene inherits

This is one of the most important sections.

---

# 17. SCENE RESIDUE

The next scene should inherit relevant residue.

Possible residue includes:

- unresolved anger;
- new suspicion;
- broken object;
- missed deadline;
- injury;
- altered reputation;
- new knowledge;
- promise;
- fear;
- attraction;
- obligation;
- strategic problem.

If a scene creates no residue and no experiential value, ask whether it was necessary.

---

# 18. SCENE STATE UPDATE RULE

Do not copy the entire scene into state.

Extract only durable changes.

Weak:

> Mara yelled at Elias, paced, looked at window, then left.

Strong:

> Mara now knows Elias lied about the envoy. She did not reveal that she knows. Trust reduced; she intends to verify future claims independently.

The second record preserves what matters.

---

# 19. SCENE FUNCTION TAGS

For audit purposes, a scene may receive one or two functional tags.

Examples:

- revelation;
- confrontation;
- bonding;
- recovery;
- investigation;
- pursuit;
- setup;
- payoff;
- transition;
- decision;
- worldbuilding;
- atmospheric;
- preparation;
- failure;
- aftermath;
- escalation.

Do not use tags to constrain writing.

They exist to detect repetition later.

---

# 20. SCENE MODE TAGS

A second optional category describes dominant form:

- dialogue;
- action;
- interiority;
- observation;
- investigation;
- travel;
- social;
- ritual;
- montage;
- summary-heavy;
- mixed.

This helps identify repeated scene architectures during later audits.

---

# 21. SCENE EMOTIONAL DIRECTION

Optional audit field:

### Begins

### Moves through

### Ends

Example:

> guarded → briefly cooperative → newly suspicious.

This can reveal repeated emotional trajectories across chapters.

Do not reduce complex emotion to rigid labels when not useful.

---

# 22. SCENE RELATIONSHIP DIRECTION

Optional:

### Relationship at entry

### Relationship at exit

### Degree of movement

None / slight / moderate / major.

### Type

Closer / less trusting / more dependent / more hostile / more uncertain / transformed.

This helps prevent repeated “bonding scenes” that do not actually change anything.

---

# 23. SCENE KNOWLEDGE MAP

For mystery or intrigue scenes:

## Before scene

A knows:

B knows:

Reader knows:

## During scene

New information revealed:

False information introduced:

Information concealed:

## After scene

A knows:

B knows:

Reader knows:

This makes epistemic movement explicit.

---

# 24. SCENE OBJECT MAP

For complicated physical scenes:

## Important objects at entry

### Object

Owner/location:

Condition:

## Changes during scene

## Important objects at exit

This is especially useful for:

- combat;
- heists;
- mysteries;
- magic;
- survival.

---

# 25. SCENE SPATIAL SNAPSHOT

Use only when spatial complexity matters.

## Location layout

## Entry points

## Exit points

## Character starting positions

## Important obstacles

## Objects relevant to movement

## Visibility

## Sound/privacy

## Environmental hazards

This can remain extremely brief.

The purpose is to prevent impossible blocking.

---

# 26. SCENE CONTINUATION RULE

When the user says:

> Continue.

Use this order:

1. Read the immediate ending.
2. Retrieve the current scene/exit state.
3. Identify active pressures.
4. Identify unresolved immediate action.
5. Preserve POV.
6. Preserve relationship and knowledge state.
7. Continue from causality before inventing novelty.

The default question should be:

> What follows from what is already happening?

Not:

> What exciting thing can happen next?

---

# 27. WHEN TO END A SCENE BEFORE CONTINUING

A continuation request does not always mean remain in the same scene.

Ask internally:

### Is the current scene still producing useful movement?

If yes, continue.

### Has the scene completed its purpose?

If yes, transition.

### Would continuing merely explain what already happened?

If yes, consider ending.

### Is there important aftermath still worth direct experience?

If yes, remain.

---

# 28. CHAPTER STATE TEMPLATE

Use for chapter planning.

## Chapter number

## Working title

Optional.

## Story date / time span

## POV

Single or multiple.

## Chapter purpose

## Entry state

What important conditions exist before chapter begins?

## Major active threads

## Planned scenes

## Dominant chapter pressure

## Character movement

## Relationship movement

## Plot movement

## Information movement

## Setup/payoff activity

## Pacing role

Examples:

- acceleration;
- recovery;
- complication;
- convergence;
- transition;
- climax;
- aftermath.

## Chapter ending function

Not necessarily exact ending.

Examples:

- decision;
- revelation;
- consequence;
- quiet closure;
- unresolved threat;
- transition.

## Exit state

To be completed after drafting.

---

# 29. CHAPTER PURPOSE

A chapter purpose should be broader than a scene purpose.

Example:

Weak:

> Mara investigates.

Better:

> Mara's attempt to verify Elias's story produces evidence that clears his motive but implicates the king, shifting her conflict from personal distrust toward political danger.

This defines chapter-level movement.

---

# 30. CHAPTER THREAD MAP

List only active threads.

## Main plot

## Character arc

## Relationship

## Subplot

## Mystery

## World/institution

## Theme/motif

Each thread may:

- advance;
- pause;
- complicate;
- pay off;
- transform;
- remain dormant.

Not every chapter needs every thread.

---

# 31. CHAPTER SCENE LIST

For each planned scene:

### Scene ID

### POV

### Location

### Function

### Main pressure

### Expected state change

### Transition to next scene

This is enough.

Do not outline every line unless the author wants detailed outlining.

---

# 32. CHAPTER ENTRY STATE

Before drafting a chapter, retrieve:

### Time

### Locations

### Current character states

### Relevant relationship states

### Open consequences

### Current knowledge

### Physical conditions

### Active plot threads

### Most recent chapter residue

This prevents chapters from opening with accidental reset.

---

# 33. CHAPTER EXIT STATE

After chapter completion, record:

## Major events

Only significant.

## Decisions

## Knowledge changes

## Character changes

## Relationship changes

## Physical/world changes

## Objects/resources

## Setups created

## Payoffs delivered

## Open consequences

## Threads advanced

## Threads newly dormant

## New questions

## Immediate next-state pressure

This becomes the basis of the chapter summary.

---

# 34. CHAPTER SUMMARY TEMPLATE

A chapter summary should focus on change rather than recounting every action.

## Chapter

## POV

## Time

## Locations

## Summary

Concise description of major developments.

## Story-state changes

### Character

### Relationship

### Knowledge

### Physical

### Objects/resources

### World/institutional

### Plot

## New setups

## Payoffs

## Open consequences

## Unresolved questions

## Important continuity notes

This summary becomes a retrieval bridge for later chapters.

---

# 35. BAD CHAPTER SUMMARY EXAMPLE

> Mara goes to the market, meets Jon, talks to Elias, gets attacked, and then returns home.

This reports activity.

---

# 36. BETTER CHAPTER SUMMARY EXAMPLE

> Mara confirms the eastern road is under surveillance and abandons the planned escape route. Jon reveals that the king's men searched Elias's room before the envoy disappeared, shifting Mara's suspicion toward the crown. An attack at the market leaves Mara's shoulder injured and publicly exposes her forbidden magic to at least one city guard. She returns home without telling Elias what she learned.

This preserves:

- changed strategy;
- changed knowledge;
- injury;
- social consequence;
- secret.

That is useful state.

---

# 37. CHAPTER FUNCTION TAGS

Optional for later audit.

Possible tags:

- setup;
- escalation;
- complication;
- investigation;
- relationship development;
- payoff;
- climax;
- recovery;
- transition;
- reversal;
- aftermath;
- convergence.

One or two dominant tags are enough.

---

# 38. CHAPTER PACING ROLE

A chapter may function as:

### Acceleration

More pressure, movement, compressed decisions.

### Deceleration

More space for processing, atmosphere, relationship, or world.

### Recovery

Pressure temporarily falls.

### Escalation

Difficulty deepens.

### Convergence

Several threads begin intersecting.

### Payoff

Earlier setup resolves.

### Reorientation

Story meaning changes.

This helps assess pacing across multiple chapters later.

---

# 39. CHAPTER HOOK RESTRAINT

Do not require every chapter to end on:

- danger;
- revelation;
- cliffhanger;
- dramatic question;
- ominous line.

Possible chapter endings include:

- quiet emotional shift;
- completed decision;
- thematic image;
- temporary stability;
- unresolved thought;
- practical transition.

Repeated cliffhangers can become mechanically visible.

---

# 40. CHAPTER RHYTHM CHECK

Before finalizing chapter plan, compare the previous two or three chapters.

Ask:

### Are they structurally too similar?

### Do they all end the same way?

### Do they all contain the same number of scenes?

### Does every chapter include confrontation?

### Are emotional arcs repeating?

### Is the same thread receiving attention repeatedly while others disappear?

Do not vary merely for novelty.

Look for accidental pattern.

---

# 41. SCENE DUPLICATION CHECK

Before writing a scene, ask:

> Have we already performed this function recently?

Examples:

- another scene proving Mara distrusts Elias;
- another scene where protagonist receives encouragement;
- another argument about same issue;
- another training scene demonstrating same weakness;
- another exposition conversation about same rule.

If yes:

### What new state does this version create?

If none, consider:

- combining;
- compressing;
- changing function;
- omitting.

---

# 42. CHAPTER DUPLICATION CHECK

Similarly:

> Does this chapter substantially repeat the narrative work of a recent chapter?

Surface events may differ.

The deeper function may still be the same.

---

# 43. SCENE NECESSITY TEST

Before fully drafting:

### Why must the reader experience this directly?

Choose:

- because interaction itself matters;
- because uncertainty matters;
- because sensory experience matters;
- because character behavior matters;
- because dramatic timing matters.

If none applies strongly, consider:

### Summary

### Partial scene

### Omission

This protects narrative economy.

---

# 44. SUMMARY VS SCENE DECISION

Use **scene** when:

- moment-to-moment behavior matters;
- dialogue matters;
- uncertainty matters;
- emotional progression matters;
- physical action matters;
- reader participation matters.

Use **summary** when:

- outcome matters more than process;
- activity is routine;
- repetition would add little;
- time needs compression;
- transitional events do not deserve full attention.

Use both when appropriate.

---

# 45. SCENE STATE AND DISCOVERY WRITING

This system should not destroy discovery.

A writer does not need to know the exact scene ending before drafting.

The scene state can define:

- current truths;
- pressures;
- goals;
- constraints.

Then drafting can discover:

- exact dialogue;
- reaction;
- turn;
- resolution;
- new idea.

The state system should create **bounded freedom**.

---

# 46. UNKNOWN EXIT STATE

It is acceptable to write:

### Desired movement

Trust should be tested.

### Exact exit

`UNKNOWN — discover during drafting.`

The system does not require predetermined outcomes.

---

# 47. PROVISIONAL SCENE IDEAS

Distinguish:

### Locked requirement

Must happen.

### Likely development

Expected but flexible.

### Possibility

One option.

Example:

`[POSSIBILITY] Jon may interrupt the confrontation.`

Do not accidentally write every possibility as predetermined canon.

---

# 48. SCENE FAILURE HANDLING

If drafting produces a better development than the plan:

Do not force prose back into the old plan automatically.

Instead:

1. evaluate whether new development fits canon and character;
2. accept if stronger;
3. update scene exit state;
4. update chapter plan;
5. update downstream assumptions.

Planning serves story.

Story does not serve planning.

---

# 49. SCENE STATE AFTER REVISION

If a scene is substantially revised, its state changes may also change.

Recheck:

- knowledge;
- relationship;
- objects;
- physical state;
- consequences;
- setups;
- chapter summary.

Do not keep ledger state based on an older version of the scene.

---

# 50. CHAPTER STATE AFTER REVISION

If a chapter is restructured:

### Remove state changes from deleted scenes.

### Add changes from new scenes.

### Reassess chapter purpose.

### Reassess chapter pacing role.

### Update setups/payoffs.

### Update chapter summary.

This prevents revised prose and state files from diverging.

---

# 51. MULTI-POV CHAPTERS

For chapters with multiple POVs:

Track each scene separately.

Do not merge knowledge.

Example:

## Scene 1 — Mara POV

Mara learns X.

## Scene 2 — Elias POV

Elias does not know Mara learned X.

The chapter-level summary may contain both facts, but drafting context must preserve the separation.

---

# 52. OFFSCREEN EVENTS

Important events may occur offscreen.

If so, record:

### Event

### When

### Who participated

### Who knows

### What consequences exist

### Whether reader learns immediately or later

Offscreen does not mean continuity-free.

---

# 53. TIME SKIPS

Before a time skip:

Record current unresolved conditions.

After skip:

Determine what changed during the gap.

Possible areas:

- healing;
- relationships;
- goals;
- institutions;
- resources;
- world conditions;
- knowledge;
- ongoing consequences.

Do not assume everything froze during skipped time.

---

# 54. TRANSITION STATE

For significant transitions between chapters or arcs:

## From

Location / time / story phase.

## To

New location / time / story phase.

## What changed during transition

## What was summarized

## What remains unresolved

## What new conditions exist

This is especially useful after:

- travel;
- training periods;
- imprisonment;
- war campaigns;
- long recovery;
- seasonal shifts.

---

# 55. ARC-LEVEL STATE HANDOFF

At the end of an arc, create a compact handoff.

## Arc ending state

### Characters

### Relationships

### Knowledge

### World

### Plot

### Resources

### Open consequences

### Unresolved setups

### New major goals

### Changed artistic/thematic context

This gives the next arc a clean starting point.

---

# 56. CURRENT SCENE STATE FILE

For complex drafting, it may eventually be useful to maintain a very small file such as:

`STATE-current-scene.md`

Possible structure:

# CURRENT SCENE

POV:

Time:

Location:

Present:

Immediate goal:

Other goals:

Relationship pressure:

Knowledge differences:

Physical constraints:

Important objects:

Active conflict:

Open consequence:

Scene purpose:

Previous ending:

This file should remain tiny.

We will decide during final assembly whether it is worth using.

---

# 57. CURRENT CHAPTER STATE FILE

Likewise:

`STATE-current-chapter.md`

Possible structure:

# CURRENT CHAPTER

Chapter:

POV:

Time:

Purpose:

Entry state:

Active threads:

Planned scenes:

Major continuity requirements:

Expected movement:

Current drafting position:

Again, only if the project benefits from it.

---

# 58. SCENE PREPARATION DEPTH

Not every scene deserves full state preparation.

Use proportional depth.

## LOW COMPLEXITY

Retrieve:

- POV;
- location;
- immediate goal;
- recent continuity.

## MEDIUM COMPLEXITY

Also retrieve:

- relationship state;
- knowledge state;
- open consequences;
- physical state.

## HIGH COMPLEXITY

Also retrieve:

- spatial layout;
- important objects;
- multiple character goals;
- world rules;
- setup/payoff state;
- detailed knowledge boundaries.

This keeps the system practical.

---

# 59. HIGH-RISK SCENES

Use deeper preparation for:

- major revelations;
- betrayals;
- deaths;
- intimate relationship milestones;
- complicated combat;
- mysteries;
- political negotiations;
- heists;
- scenes involving many characters;
- scenes with multiple secrets;
- climaxes;
- major world-rule use.

These scenes create large downstream effects.

---

# 60. SCENE STATE AS RETRIEVAL ROUTER

The scene state should also tell ChatGPT which deeper guidance may be useful.

Example:

## Scene

Romantic confrontation with hidden secret.

Relevant modules:

- Dialogue;
- Emotion/Subtext;
- Relationships;
- POV/Knowledge.

No need to retrieve:

- full Plot domain;
- full world history;
- every prose guideline.

This is selective retrieval in practice.

---

# 61. POST-SCENE UPDATE ROUTER

After drafting, scene exit state should route updates to other files.

Example:

### Injury occurred

Update Physical State Ledger.

### Secret learned

Update Knowledge Ledger.

### Trust reduced

Update Relationship State.

### New mystery introduced

Update Setup/Payoff Ledger.

### Character goal changed

Update Character State.

### World changed

Update World-State Ledger.

The scene state acts as an **update dispatcher**.

---

# 62. CHAPTER SUMMARY AS LONG-RANGE MEMORY

The chapter summary should become the main long-range retrieval unit.

Instead of rereading thousands of words, ChatGPT can often consult:

- chapter summaries;
- active ledgers;
- relevant Story Bible sections.

Full prose should still be retrieved when:

- exact wording matters;
- voice matters;
- a scene is being revised;
- ambiguity depends on details;
- or summary loses necessary nuance.

---

# 63. SCENE/CHAPTER STATE SHOULD NOT BECOME PROSE INSTRUCTIONS

State tells the model:

what is true.

It should not overdetermine:

how every sentence must sound.

Example:

State:

> Mara is angry and mistrustful.

Bad conversion:

Every paragraph must contain anger signals.

Better:

Let state influence:

- decisions;
- attention;
- willingness to disclose;
- interpretation.

The prose can remain varied.

---

# 64. SCENE AUDIT QUESTIONS

After a scene, ask selectively:

### Did the scene accomplish or alter its purpose?

### Did anything meaningfully change?

### Did characters behave according to state?

### Did any knowledge leak?

### Did continuity break?

### Did the relationship inherit its history?

### Did the scene repeat earlier function?

### Did it end after its strongest point?

### What persists afterward?

These questions prepare later audit systems.

---

# 65. CHAPTER AUDIT QUESTIONS

After a chapter:

### What changed?

### Which threads moved?

### Which did not?

### Did chapter structure repeat nearby chapters?

### Was pacing role appropriate?

### Did any setup disappear?

### Did consequence carry forward?

### Did characters reset?

### Did chapter ending over-explain?

### What must the next chapter inherit?

---

# 66. MINIMUM VIABLE SCENE STATE

For simple stories:

### POV

### Time

### Location

### Immediate goal

### Relationship context

### Important knowledge

### Physical constraints

### Purpose

### Exit change

That may be enough.

---

# 67. MINIMUM VIABLE CHAPTER STATE

### Chapter

### POV

### Purpose

### Entry state

### Active threads

### Major developments

### Exit state

### Open consequences

### Next-state pressure

Again, complexity should match the novel.

---

# 68. CENTRAL REMINDER

A scene should never feel as though it begins in a fresh universe.

It inherits:

- history;
- bodies;
- knowledge;
- relationships;
- promises;
- consequences;
- and expectations.

Likewise, a chapter should not simply contain several interesting scenes.

It should leave the novel in a different state—or deepen an experience the novel intentionally values.

Before drafting, ask:

> What is true at this exact moment?

> What does each person want?

> What does each person know?

> What remains from the previous scene?

> Why is this scene being dramatized?

After drafting, ask:

> What became newly true?

> What remains unresolved?

> What does the next scene inherit?

The purpose of scene/chapter state is not to make fiction mechanical.

It is to ensure that every new piece of prose grows from the story that already exists.

That completes the reusable **Scene/Chapter State System**. We now have the major memory architecture in place: Story Bible → continuity/knowledge ledgers → character/relationship state → scene/chapter state.

The next stage is different: **Pre-Writing Gate**. That will be the compact procedure ChatGPT performs before writing a scene or chapter so it retrieves the right material, catches critical contradictions, and then gets out of the way before drafting.

**Remaining system-building stages:**
1. **Pre-Writing Gate**
2. **Drafting Protocol**
3. **Post-Draft Audit**
4. **Anti-Repetition / Pattern Audit**
5. **Long-Range Narrative Audit**
6. **Artistic-Identity / Anti-Homogenization Pass**
7. **Compact Project Instructions — final deployable version**
8. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Pre-Writing Gate**. This should be compact enough to run before drafting without turning writing into a checklist exercise.

Suggested filename: **`06-pre-writing-gate.md`**

# PRE-WRITING GATE

## Purpose

The Pre-Writing Gate is the short preparation step performed before drafting a scene, chapter, continuation, or major revision.

Its job is to ensure that ChatGPT begins writing from the correct story state.

It should:

- retrieve the right context;
- identify critical continuity constraints;
- preserve POV and character truth;
- understand the purpose of the scene;
- identify relevant open pressures;
- and then stop analyzing so drafting can begin naturally.

The Pre-Writing Gate is **not** a full audit.

It should not attempt to solve every craft problem before prose exists.

Its central principle is:

> Retrieve enough to write correctly, then write.

---

# 1. WHEN TO USE THE PRE-WRITING GATE

Use it before:

- drafting a new scene;
- drafting a new chapter;
- continuing existing prose;
- writing a major confrontation;
- writing a revelation;
- writing a scene with complex continuity;
- writing from a new POV;
- resuming after a long gap;
- revising a scene in ways that may affect canon or state.

For very small edits, it may be unnecessary.

---

# 2. GATE DEPTH

Use proportional depth.

## LIGHT GATE

For simple scenes.

Check:

- POV;
- location;
- immediate goal;
- recent continuity;
- relevant relationship state.

---

## STANDARD GATE

For most scenes.

Check:

- POV;
- time;
- location;
- characters;
- goals;
- knowledge;
- relationships;
- physical state;
- scene purpose;
- open consequences.

---

## DEEP GATE

For high-risk scenes.

Add:

- object state;
- spatial constraints;
- multiple secrets;
- world rules;
- setup/payoff status;
- detailed knowledge boundaries;
- recent chapter history;
- arc consequences.

Use for:

- climax;
- betrayal;
- mystery reveal;
- major romantic milestone;
- political negotiation;
- complex combat;
- death;
- large ensemble scene;
- major magic or technology use.

---

# 3. STEP ONE — IDENTIFY THE TASK

Before retrieving anything, identify what the user actually wants.

Examples:

- write scene;
- continue;
- write chapter;
- revise dialogue;
- expand moment;
- rewrite from another POV;
- make scene more tense;
- write aftermath.

Do not retrieve globally before understanding the task.

---

# 4. STEP TWO — IDENTIFY THE ACTIVE NOVEL STATE

Retrieve only what is needed from:

- current scene state;
- current chapter state;
- continuity ledgers;
- character state;
- relationship state;
- recent chapter summaries;
- relevant Story Bible sections.

The core question is:

> What must be true for this scene to begin correctly?

---

# 5. STEP THREE — CONFIRM POV

Record:

## POV character

## Narrative person

First / third / other.

## Tense

## Narrative distance

## Knowledge boundary

What can this POV know?

## Current expectations

What do they think is happening?

## Current blind spots

What are they missing?

## Current emotional residue

What from recent events is shaping perception?

Do not let writer-level knowledge leak into POV prose.

---

# 6. STEP FOUR — CONFIRM TIME

Check:

## Story date

## Time of day

## Time since previous scene

## Relevant deadline

## Relevant duration

Examples:

- days since injury;
- time since betrayal;
- time since last sleep;
- time until election;
- length of relationship.

If time is not narratively important, keep this brief.

---

# 7. STEP FIVE — CONFIRM LOCATION

Check:

## Exact location

## Who is present

## Who is nearby

## Relevant entrances/exits

## Privacy

## Noise

## Weather/environment

## Practical constraints

Use deeper spatial preparation only when movement matters.

---

# 8. STEP SIX — CONFIRM PHYSICAL REALITY

For involved characters:

## Injuries

## Fatigue

## Illness

## Intoxication

## Restraints

## Important clothing/equipment

## Physical limitations

## Important possessions

Do not let the prose forget these merely because the scene focus is emotional or conversational.

---

# 9. STEP SEVEN — CONFIRM CHARACTER STATE

For each important participant:

## Immediate goal

## Secondary goal

## Current emotional residue

## Current belief

## Current fear

## Current strategy

## Current constraint

## Current development pressure

This should be concise.

The purpose is to prevent characters from behaving according to generic scene function rather than current personhood.

---

# 10. STEP EIGHT — CONFIRM RELATIONSHIP STATE

For important relationships in the scene:

## Current trust

## Current intimacy

## Current friction

## Recent milestone

## Current misunderstanding

## Current obligation

## Current power difference

## What changed last time?

This prevents relationship reset.

---

# 11. STEP NINE — CONFIRM KNOWLEDGE BOUNDARIES

For important information:

## What does each character know?

## What do they believe?

## What do they suspect?

## What do they misunderstand?

## What are they concealing?

## What does the reader know?

This step is especially important in:

- mystery;
- intrigue;
- romance;
- political fiction;
- multi-POV stories.

---

# 12. STEP TEN — CONFIRM SCENE PURPOSE

Ask:

> Why is this scene being dramatized?

Possible answers:

- decision;
- revelation;
- relationship development;
- conflict;
- recovery;
- setup;
- payoff;
- atmosphere;
- investigation;
- failure;
- transition;
- consequence.

Avoid vague answers like:

> develop character.

Prefer:

> force Mara to choose whether to expose Elias publicly after learning why he lied.

---

# 13. STEP ELEVEN — IDENTIFY ACTIVE PRESSURES

List only meaningful pressures.

Possible types:

### External

Danger, institution, obstacle.

### Interpersonal

Conflicting goals.

### Internal

Contradictory desires.

### Informational

Secret, uncertainty, incomplete knowledge.

### Social

Status, reputation, etiquette, audience.

### Physical

Pain, weather, limited movement.

### Temporal

Deadline.

### Resource

Scarcity.

Do not invent extra pressure merely to make a scene more dramatic.

---

# 14. STEP TWELVE — IDENTIFY OPEN CONSEQUENCES

Ask:

> What earlier events are still active here?

Examples:

- authorities are searching for them;
- trust remains damaged;
- a promise has not been kept;
- injury still limits movement;
- a rumor is spreading;
- money is running out;
- someone is waiting for an answer.

Earlier scenes should remain alive through consequence.

---

# 15. STEP THIRTEEN — IDENTIFY ACTIVE SETUPS/PAYOFFS

Check whether this scene:

- continues a setup;
- pays something off;
- transforms a motif;
- creates a new expectation;
- risks accidentally emphasizing something that will never matter.

Do not force every scene into setup/payoff mechanics.

Only track meaningful obligations.

---

# 16. STEP FOURTEEN — CHECK SCENE DUPLICATION

Before drafting, ask:

> Have we recently written another scene with the same deeper function?

Possible repeated functions:

- protagonist receives reassurance;
- same relationship conflict repeats;
- same weakness demonstrated;
- same exposition explained;
- same mystery suspicion raised;
- same emotional conclusion reached.

If yes, determine what new state this scene creates.

If none, reconsider whether the scene needs to exist in this form.

---

# 17. STEP FIFTEEN — CHECK CHARACTER AGENCY

For major choices, ask:

> What would this character naturally attempt here?

Then:

> Does that support the planned scene?

If not, do not immediately force the character toward the plot.

Consider whether:

- scene plan should change;
- pressure should increase;
- information should change;
- another character should drive the event;
- or the plot needs a different route.

---

# 18. STEP SIXTEEN — CHECK OBVIOUS ALTERNATIVES

Before building conflict around a difficult problem, ask:

> Is there an obvious easier solution?

If yes:

- can characters access it?
- do they know about it?
- would they use it?
- what cost prevents it?
- does world logic eliminate it?

Do not preserve conflict through selective stupidity.

---

# 19. STEP SEVENTEEN — CHECK CONTINUITY RED FLAGS

Quickly verify:

### Time

### Location

### Objects

### Injuries

### Knowledge

### Relationship state

### World rules

### Major numbers

### Established canon

Only inspect categories relevant to the scene.

---

# 20. STEP EIGHTEEN — RETRIEVE RELEVANT CRAFT GUIDANCE

Only after story truth is established.

Retrieve the smallest relevant set of guidance modules.

Examples:

## Dialogue confrontation

- Dialogue;
- Emotion/Subtext;
- Relationships.

## Investigation scene

- POV/Knowledge;
- Scene Design;
- Plot/Causality.

## Combat

- Scene Design;
- Continuity/Embodied Reality;
- Pacing.

## Intimate scene

- Emotion;
- Relationships;
- Description;
- POV.

## Worldbuilding-heavy scene

- Narrative Intentionality;
- Description;
- Continuity;
- Artistic Identity.

Do not retrieve all 13 domains.

---

# 21. STEP NINETEEN — CHECK ARTISTIC IDENTITY

Before drafting, briefly recall only what matters from the novel's identity.

Examples:

- restrained emotional narration;
- dry social humor;
- dense sensory emphasis on machinery;
- violence described clinically;
- little direct thematic interpretation;
- lyrical but not ornate POV.

Do not turn this into stylistic mimicry.

The purpose is to prevent generic drift.

---

# 22. STEP TWENTY — DEFINE THE DRAFTING FREEDOM

Separate:

## Locked

Must remain true.

Examples:

- POV;
- canon;
- location;
- knowledge boundaries;
- required event.

## Flexible

Can be discovered during writing.

Examples:

- exact dialogue;
- exact emotional progression;
- precise turn;
- scene ending;
- imagery;
- minor blocking.

## Open

Unknown and free to emerge.

This prevents overplanning.

---

# 23. GATE OUTPUT

The Pre-Writing Gate should normally produce an **internal compact state**, not a long user-facing report.

A useful internal format is:

## PRE-WRITE STATE

POV:

Time:

Location:

Present characters:

Scene purpose:

POV goal:

Other goals:

Relationship state:

Knowledge boundaries:

Physical constraints:

Open consequences:

Relevant setup/payoff:

Main pressure:

Continuity risk:

Relevant guidance:

Locked:

Flexible:

Open:

Then draft.

---

# 24. DO NOT SHOW THE GATE BY DEFAULT

When the user says:

> Write Chapter 8.

The system should not respond with several pages of preparation unless requested.

The gate is operational.

Its output should normally remain behind the drafting process.

The user asked for fiction, not administrative notes.

---

# 25. WHEN TO SHOW PREPARATION

Show planning when the user explicitly asks:

- plan the scene;
- outline the chapter;
- check continuity before writing;
- explain how the scene should work;
- give me options;
- diagnose this chapter.

Otherwise, preparation should support the result silently.

---

# 26. CONTINUATION GATE

When the user simply says:

> Continue.

Run a reduced gate.

## Retrieve

- immediate previous text;
- scene exit/current state;
- POV;
- location;
- active characters;
- current goals;
- current relationship state;
- open immediate consequence.

## Ask

> Is the current scene still active?

If yes:

continue causally.

If no:

transition to the next meaningful state.

Do not invent a random new hook merely because continuation needs material.

---

# 27. NEW-CHAPTER GATE

Before starting a new chapter:

## Retrieve

- previous chapter exit state;
- recent chapter summaries;
- active plot threads;
- current characters;
- current relationships;
- open consequences;
- pacing role.

## Check

### Why does the chapter begin here?

### Why this POV?

### Why this thread now?

### What does the chapter inherit?

### What should it change or deepen?

---

# 28. NEW-POV GATE

When switching viewpoint:

Check:

### What does this character uniquely contribute?

### What do they know that previous POV did not?

### What do they not know?

### How does their attention differ?

### How does narrative voice shift?

### Why is this scene stronger through this POV?

Avoid changing POV merely for variety.

---

# 29. HIGH-RISK REVELATION GATE

Before revealing major information:

Check:

### Has it been sufficiently prepared?

### Who learns it?

### How?

### Is the source credible?

### What does reader already suspect?

### What changes because it becomes known?

### Does the revelation create consequences?

### Does it invalidate prior scenes unfairly?

### Is it being revealed because the timing is right or because the story wants excitement?

---

# 30. HIGH-RISK CHARACTER-CHANGE GATE

Before a major character transformation:

Ask:

### What pressure created this?

### What earlier behavior supports it?

### What resistance existed?

### What old tendency remains?

### Is this change integrated or merely immediate state?

### Will later behavior inherit it?

This prevents character replacement.

---

# 31. HIGH-RISK RELATIONSHIP GATE

Before:

- kiss;
- confession;
- betrayal;
- reconciliation;
- breakup;
- forgiveness;
- major trust change;

check:

### What is the current relationship state?

### What has been building?

### What does each person think this moment means?

### Is the development symmetrical?

### What remains unresolved afterward?

### What does this change future interaction?

Avoid milestone-without-consequence writing.

---

# 32. HIGH-RISK ACTION GATE

Before complex action:

Check:

### Space

Where is everyone?

### Bodies

What injuries/limitations apply?

### Objects

What does everyone possess?

### Rules

What abilities or constraints apply?

### Goals

What is each participant actually trying to achieve?

### Environment

What can interfere?

### Stakes

Why does outcome matter?

### Consequence

What can change afterward?

---

# 33. HIGH-RISK MYSTERY GATE

Before investigation/reveal:

Check:

### Objective truth

### Available clues

### POV knowledge

### Reader knowledge

### False interpretations

### Evidence location

### Why conclusion is or is not currently possible

### Whether reasoning is earned

Prevent psychic deduction.

---

# 34. HIGH-RISK WORLDBUILDING GATE

Before exposition-heavy material:

Ask:

### Does the reader need this now?

### Does the POV care about it now?

### Is this information already known by the listener?

### Is dialogue actually the best channel?

### Can worldbuilding emerge through consequence or action?

### Is the level of detail proportional?

Do not hide necessary information merely to avoid exposition.

Clarity remains valuable.

---

# 35. GATE FAILURE CONDITIONS

Do not draft immediately if the system detects a **critical unresolved contradiction** involving:

- character identity;
- timeline;
- location;
- knowledge;
- world rule;
- important possession;
- required plot fact.

If a minor unknown exists, a reasonable provisional choice may be made.

Critical contradiction should be flagged or resolved before writing because prose built on false state may create cascading errors.

---

# 36. CRITICAL VS NONCRITICAL UNKNOWN

## Critical

Must be known before scene works.

Example:

Does Mara know Elias is the traitor?

If the entire conversation depends on it, resolve first.

## Noncritical

Can be discovered during drafting.

Example:

What color is the innkeeper's coat?

Do not stop drafting for irrelevant unknowns.

---

# 37. PROVISIONAL CHOICE RULE

When an unestablished minor fact is needed:

1. choose something compatible with canon;
2. avoid unnecessary specificity;
3. treat it as provisional until accepted in prose;
4. update canon only if it becomes durable.

This supports flow without careless invention.

---

# 38. NO CHECKLIST PROSE

The gate may identify:

- injury;
- resentment;
- setting;
- motif.

This does **not** mean the draft must visibly mention all four immediately.

State influences behavior.

It should not produce:

> shoulder pain sentence 
> resentment sentence 
> weather sentence 
> symbolic-object sentence

just because the gate retrieved them.

Relevant context should inform prose naturally.

---

# 39. NO FORCED VARIATION

The gate may notice a recent scene was dialogue-heavy.

That does not mean the next scene must avoid dialogue.

A repeated form is acceptable when the story demands it.

Variation is not a quota.

---

# 40. NO AUTOMATIC DRAMA

If the current state naturally produces:

- quiet conversation;
- uneventful travel;
- domestic routine;
- contemplation;

the gate should not invent danger merely to create engagement.

Engagement can come from:

- anticipation;
- relationship;
- humor;
- curiosity;
- voice;
- atmosphere;
- implication.

---

# 41. NO AUTOMATIC RESOLUTION

Likewise, the gate should not assume the scene must resolve its central pressure.

Possible outcomes include:

- worsening;
- complication;
- partial answer;
- temporary agreement;
- false resolution;
- new misunderstanding;
- no immediate resolution.

Outcome should follow character and causality.

---

# 42. NO AUTOMATIC SUBTEXT

Not every scene requires hidden meaning.

Sometimes people say what they mean.

The gate should consider:

> Would this character speak directly here?

If yes, direct speech may be the strongest choice.

---

# 43. NO AUTOMATIC CONFLICT

Scenes can exist without interpersonal conflict.

A scene may involve:

- cooperation;
- companionship;
- pleasure;
- discovery;
- routine;
- awe;
- recovery.

The scene still needs intentionality, not necessarily conflict.

---

# 44. NO AUTOMATIC CHARACTER GROWTH

Not every difficult experience produces growth.

Characters may:

- fail;
- double down;
- misunderstand;
- regress;
- change slowly;
- remain stable.

The gate should preserve believable development rather than forcing improvement.

---

# 45. NO AUTOMATIC THEME

Do not make every scene express the central theme explicitly.

Thematic coherence should emerge across accumulation.

Some scenes may simply serve:

- logistics;
- humor;
- atmosphere;
- relationship;
- action.

That is acceptable.

---

# 46. PRE-WRITING GATE FOR REVISION

When revising an existing scene, use a modified gate.

## Identify revision goal

Dialogue?

Pacing?

Character?

Continuity?

Prose?

## Retrieve original state

What was true when this scene occurs?

## Preserve downstream canon

What later scenes depend on this version?

## Identify allowed change

What can change safely?

## Retrieve relevant guidance

Only for the actual revision problem.

Then revise.

---

# 47. REVISION RIPPLE CHECK

If revision changes:

- knowledge;
- decision;
- relationship;
- injury;
- object possession;
- location;
- world event;

check downstream material.

A beautiful revision can break later chapters if its state consequences are different.

---

# 48. GATE SPEED PRINCIPLE

The gate should be fast.

If preparation becomes longer than the scene being written, the system is overbuilt for the task.

Use:

- light gate for simple material;
- standard gate for ordinary scenes;
- deep gate only for genuinely complex material.

---

# 49. PRE-WRITING GATE COMPACT VERSION

For ordinary drafting, the entire process can compress to:

### What is the user asking for?

### Where and when are we?

### Whose POV?

### Who is present?

### What does each important person want?

### What does each know?

### What changed recently?

### What physical/world constraints apply?

### Why does this scene exist?

### What earlier consequence remains active?

### What craft guidance is actually relevant?

### What must remain fixed?

### What can be discovered in the prose?

Then write.

---

# 50. CENTRAL REMINDER

The Pre-Writing Gate exists to prevent one core failure:

> beginning each new piece of prose as though fiction were being generated from genre probability instead of inherited story state.

Before writing, the system should briefly recover:

**where we are,**

**who these people currently are,**

**what they know,**

**what they want,**

**what has already happened,**

and

**what this scene is for.**

Then analysis should recede.

The drafting process should be allowed to become fluid again.

The gate is successful when the resulting prose feels less managed—not more—because the story's reality has already been stabilized before the first sentence is written.

That completes the **Pre-Writing Gate**. The next document is the counterpart that governs the actual generation once the gate is complete: **Drafting Protocol**. That one will be especially important because it needs to prevent the system from turning all of this guidance into stiff, overcontrolled prose.

**Remaining system-building stages:**
1. **Drafting Protocol**
2. **Post-Draft Audit**
3. **Anti-Repetition / Pattern Audit**
4. **Long-Range Narrative Audit**
5. **Artistic-Identity / Anti-Homogenization Pass**
6. **Compact Project Instructions — final deployable version**
7. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Drafting Protocol**. This governs what ChatGPT should do once the Pre-Writing Gate has stabilized the scene. Its purpose is to keep the prose natural, causal, character-specific, and work-specific without visibly “performing the rules.”

Suggested filename: **`07-drafting-protocol.md`**

# DRAFTING PROTOCOL

## Purpose

This document defines how ChatGPT should draft fiction after the Pre-Writing Gate has established:

- current story state;
- POV;
- character goals;
- relationship state;
- knowledge boundaries;
- physical constraints;
- scene purpose;
- and relevant craft guidance.

The Drafting Protocol should protect the story from a different danger than continuity failure.

Once too many rules are active, prose can become:

- cautious;
- overengineered;
- overly balanced;
- excessively literary;
- visibly optimized;
- or mechanically varied.

This protocol therefore governs **how guidance should recede once drafting begins**.

The central principle is:

> Stabilize before writing. 
> Then write the story rather than the checklist.

---

# 1. DRAFT FROM THE STORY, NOT FROM THE TAXONOMY

The taxonomy exists to support judgment.

It should not determine sentence order.

During drafting, prioritize:

1. what is happening;
2. who is experiencing it;
3. what they want;
4. what they perceive;
5. what they do;
6. what changes.

Do not consciously attempt to demonstrate every craft principle.

The prose should feel like the natural expression of the scene.

---

# 2. FOLLOW CAUSAL INHERITANCE

Prefer:

> this happens because of what is already true

over:

> this happens because the chapter needs something interesting.

Each beat should ideally arise from one or more of:

- character choice;
- prior event;
- established constraint;
- current misunderstanding;
- environment;
- relationship history;
- world rule;
- resource limitation;
- external pressure.

This does not mean every event must be predictable.

Unexpected events may occur.

But after they occur, they should enter the causal system of the novel rather than functioning only as stimulation.

---

# 3. LET CHARACTER GOALS DRIVE LOCAL BEHAVIOR

Characters should behave according to what they want in the moment.

Before significant dialogue or action, implicitly maintain:

> What is this person trying to accomplish?

Possible goals:

- obtain information;
- avoid humiliation;
- protect someone;
- conceal fear;
- win cooperation;
- leave;
- be forgiven;
- gain status;
- delay;
- provoke;
- distract;
- survive;
- understand.

Different participants should not share one invisible scene objective.

---

# 4. DO NOT WRITE CHARACTERS AS FUNCTIONS

Avoid writing a character primarily as:

- exposition source;
- encouragement source;
- obstacle;
- romantic reward;
- villain speech mechanism;
- clue delivery system;
- protagonist validator.

Even when a character performs a narrative function, preserve their own motive.

Ask implicitly:

> Why is this person doing this for themselves?

---

# 5. PRESERVE CHARACTER-SPECIFIC COGNITION

Different characters should not merely speak differently.

They should process differently.

Draft attention according to:

- expertise;
- fears;
- values;
- habits;
- culture;
- social position;
- experience;
- current pressure.

Two POV characters entering the same room should not necessarily notice the same things.

---

# 6. POV SHOULD FILTER INFORMATION

Do not describe the world as if the narration has neutral access to everything unless the chosen narrative mode permits it.

In limited POV:

- perception is selective;
- interpretation may be wrong;
- emotional language should fit the character;
- technical vocabulary should reflect their knowledge;
- assumptions should remain theirs.

Writer knowledge should remain behind the prose.

---

# 7. ALLOW THE POV TO BE WRONG

Do not correct every mistaken interpretation immediately.

A character may:

- misread a look;
- trust the wrong person;
- misunderstand a motive;
- draw a false conclusion;
- interpret evidence badly.

The narration should not automatically rescue them unless narrative distance requires it.

---

# 8. WRITE FORWARD, NOT WITH RETROSPECTIVE OMNISCIENCE

Characters live through events without knowing their future significance.

Avoid prose that constantly implies:

- this will matter later;
- this person will betray them;
- this is the last peaceful day;
- the object will become important.

Such foreshadowing can be used deliberately.

It should not become default dramatic seasoning.

Let many important things appear ordinary before they become important.

---

# 9. PROSE SHOULD RESPOND TO THE MOMENT

Sentence length, rhythm, density, and structure should change according to:

- mental tempo;
- physical tempo;
- narrative distance;
- emotional condition;
- environment;
- scene purpose.

Do not vary syntax merely to avoid repetition.

Variation should arise from meaning.

---

# 10. DO NOT FORCE “LITERARY” RHYTHM

Avoid default dependence on:

- sentence fragment after complete sentence;
- rhetorical triplets;
- repeated contrastive reframing;
- isolated punch-line paragraphs;
- aphoristic endings;
- symbolic closing sentences.

These techniques remain available.

Use them when the moment earns them.

---

# 11. DO NOT FORCE IMPERFECTION EITHER

The system should not intentionally insert awkward prose just to avoid sounding AI-generated.

Do not manufacture:

- grammatical mistakes;
- random fragments;
- strange punctuation;
- clumsy syntax;
- meaningless repetition.

The target is not artificial human imperfection.

The target is work-specific prose.

---

# 12. PRIORITIZE CONCRETE STORY INFORMATION

When a sentence can either:

- provide specific observation;
- or add vague emotional/thematic intensity,

prefer specificity unless abstraction better fits the moment.

Weak:

> An indescribable sense of something vast and terrible settled over him.

Potentially stronger:

> No lamps burned in the barracks windows, though the night watch should have changed ten minutes ago.

The second creates story information.

This is not a rule that abstraction is bad.

Abstraction should earn its place.

---

# 13. DESCRIPTION SHOULD BE SELECTIVE

Do not describe every visible feature.

Select details according to:

- POV attention;
- current goal;
- novelty;
- danger;
- emotional association;
- world relevance;
- aesthetic identity.

Ask implicitly:

> Why does this detail enter attention now?

---

# 14. DO NOT USE SENSORY CHECKLISTS

A scene does not require:

- one visual detail;
- one sound;
- one smell;
- one texture;
- one taste.

Use whichever senses dominate naturally.

Some environments may be overwhelmingly auditory.

Others visual.

Others bodily.

Let sensation follow circumstances.

---

# 15. METAPHOR SHOULD BELONG TO THE MIND OR NARRATIVE

Metaphors should arise from:

- viewpoint;
- setting;
- profession;
- culture;
- memory;
- artistic identity.

Avoid generic “beautiful” comparisons merely because the sentence seems to need one.

Ask:

> Would this consciousness produce this comparison?

---

# 16. DO NOT STACK IMAGES AUTOMATICALLY

One strong image may be enough.

If multiple metaphors appear close together, ensure they:

- reinforce;
- develop;
- contrast intentionally;
- or reflect deliberate instability.

Do not keep adding imagery because intensity appears insufficient.

---

# 17. LET SETTING PARTICIPATE

Environment should sometimes affect:

- movement;
- privacy;
- choices;
- mood;
- logistics;
- strategy;
- conversation.

Setting should not remain purely decorative when physical conditions matter.

---

# 18. RESPECT BODIES

Characters occupy physical space.

Remember:

- injuries;
- fatigue;
- distance;
- posture;
- hands;
- clothing;
- weather;
- objects;
- obstacles.

Do not let emotional dialogue cause bodies to vanish from the scene.

But do not choreograph every movement unnecessarily.

---

# 19. USE BODY LANGUAGE SELECTIVELY

Generic gestures are allowed.

People:

- shrug;
- sigh;
- look away;
- smile;
- fold arms.

The problem is repeated dependence on a narrow gesture vocabulary to translate every emotion.

Do not continuously report:

- jaw tightening;
- breath catching;
- fingers curling;
- throat tightening;
- heart pounding;
- shoulders tensing.

Use such cues when physically or psychologically meaningful.

---

# 20. DO NOT TRANSLATE EVERY EMOTION INTO BODY LANGUAGE

Direct emotional language remains available.

Sometimes:

> I hated him.

is better than several lines of bodily coding.

Choose among:

- thought;
- action;
- direct naming;
- dialogue;
- silence;
- sensation;
- memory;
- behavior.

Use the channel that best serves the moment.

---

# 21. DO NOT DOUBLE-EXPLAIN EMOTION

Watch for:

1. action shows feeling;
2. thought names feeling;
3. narration explains why;
4. metaphor restates it.

This can create emotional paraphrasing.

Once the scene has communicated the feeling effectively, move forward unless another layer adds genuinely new information.

---

# 22. EMOTION SHOULD HAVE CHARACTER-SPECIFIC CAUSALITY

Do not assume everyone reacts to:

- betrayal;
- death;
- attraction;
- insult;
- danger

in the same way.

Reaction depends on:

- history;
- expectation;
- values;
- relationship;
- self-image;
- culture;
- current stress.

Write the emotion this person would have, not the emotion the scene category implies.

---

# 23. ALLOW MIXED EMOTION

Characters may experience:

- relief and grief;
- love and resentment;
- fear and excitement;
- admiration and jealousy;
- guilt and satisfaction.

Do not resolve complexity too quickly into one clean emotional truth.

---

# 24. ALLOW IMPERFECT SELF-INTERPRETATION

Characters may understand their feelings badly.

They may:

- rationalize;
- deny;
- mislabel;
- suppress;
- project.

Do not make every internal monologue psychologically precise.

---

# 25. INTERNAL MONOLOGUE SHOULD ADD SOMETHING

Thought should contribute:

- interpretation;
- conflict;
- memory;
- decision;
- anticipation;
- bias;
- self-deception.

Avoid thought that merely paraphrases what the reader already saw.

---

# 26. DIALOGUE SHOULD COME FROM COMPETING MINDS

Each speaker has:

- their own goal;
- knowledge;
- fears;
- willingness to disclose;
- interpretation of the other person.

Dialogue should not behave like one intelligence taking turns speaking through multiple mouths.

---

# 27. NOT EVERY QUESTION NEEDS AN ANSWER

Characters may:

- evade;
- interrupt;
- answer indirectly;
- ignore;
- misunderstand;
- lie;
- respond to implication rather than literal wording.

Use naturally.

Do not deliberately make every conversation messy.

---

# 28. DO NOT MAKE EVERY CHARACTER MAXIMALLY ARTICULATE

Characters differ in:

- vocabulary;
- self-knowledge;
- confidence;
- emotional articulation;
- conversational control.

A character under pressure may become:

- less precise;
- more formal;
- more repetitive;
- quieter;
- more indirect.

Preserve those differences.

---

# 29. DIALOGUE SHOULD NOT BECOME DISGUISED ESSAY

Characters should not explain:

- theme;
- worldbuilding;
- psychology;
- politics

simply because the information is useful to the reader.

Attach information to motive.

Ask:

> Why is this person saying this now?

---

# 30. ALLOW DIRECT CONVERSATION WHEN APPROPRIATE

Do not force subtext into every line.

Some characters are direct.

Some situations demand clarity.

Some relationships permit openness.

Subtext is useful when the literal exchange and interpersonal exchange differ.

It is not a universal quality marker.

---

# 31. PRESERVE CONVERSATIONAL ASYMMETRY

People may differ in:

- willingness to continue;
- emotional investment;
- status;
- knowledge;
- confidence.

Avoid perfectly matched:

statement → counterstatement → insight → mutual understanding.

---

# 32. ALLOW SILENCE TO REMAIN SILENCE

Do not automatically explain what every pause means.

If context makes silence legible, leave interpretive space.

---

# 33. DO NOT GIVE EVERY SCENE A MINI-RESOLUTION

Scenes can end with:

- uncertainty;
- worsened conflict;
- incomplete information;
- temporary compromise;
- changed strategy;
- emotional residue.

Avoid the habit:

conflict → discussion → insight → emotional closure.

---

# 34. DO NOT FORCE SCENE TURNS

A scene does not require a twist or reversal.

If its natural power comes from:

- gradual realization;
- accumulation;
- tenderness;
- dread;
- awkwardness;
- observation,

let it develop accordingly.

---

# 35. LET SCENE RHYTHM VARY

Some scenes may contain:

- rapid exchange;
- extended description;
- quiet internal processing;
- long action;
- procedural detail.

Do not impose one preferred ratio.

---

# 36. ENTER SCENES WHEN EXPERIENCE BECOMES USEFUL

Do not automatically begin at logistical beginning.

Skip:

- waking;
- dressing;
- travel;
- greetings;
- seating;

when those moments add nothing.

But preserve them when they:

- establish normality;
- create tension;
- reveal relationship;
- build atmosphere.

---

# 37. LEAVE SCENES WHEN THEIR EFFECT IS COMPLETE

Do not automatically narrate:

- final explanation;
- physical departure;
- summary of feelings;
- next steps.

Stop when continuing would weaken the effect.

Sometimes aftermath is the point.

Use judgment.

---

# 38. PACING SHOULD FOLLOW NARRATIVE VALUE

Spend narrative space according to:

- importance;
- uncertainty;
- emotion;
- novelty;
- dramatic experience.

Do not give every event equal weight.

---

# 39. COMPRESS ROUTINE

If an activity repeats without meaningful change, consider:

- summary;
- montage;
- omission.

Do not dramatize routine merely because chronological completeness feels safer.

---

# 40. EXPAND CONSEQUENCE

Conversely, do not rush past:

- betrayal aftermath;
- moral cost;
- relationship shift;
- major revelation;
- significant failure

simply to reach the next plot event.

Some consequences deserve more narrative space than the event that caused them.

---

# 41. TENSION SHOULD VARY

Do not make every paragraph tense.

Allow:

- relief;
- humor;
- routine;
- curiosity;
- warmth;
- silence.

Contrast gives pressure shape.

---

# 42. ESCALATE THROUGH CHANGED CONDITIONS

When tension needs to rise, consider:

- fewer options;
- increasing cost;
- damaged relationship;
- deadline;
- lost resource;
- moral complication;
- exposure;
- irreversibility.

Do not automatically add a larger external threat.

---

# 43. PROTECT RECOVERY SCENES

If the story has earned a lower-pressure scene, do not automatically interrupt it with:

- attack;
- emergency;
- sudden revelation.

Recovery can create:

- attachment;
- contrast;
- normality;
- characterization;
- vulnerability.

---

# 44. PLOT SHOULD RESPOND TO CHARACTER ACTION

If a character makes a significant choice, allow it to alter future possibilities.

Do not bend events back toward a predetermined outline if the choice logically changes direction.

Update planning when necessary.

---

# 45. OBVIOUS SOLUTIONS SHOULD EXIST OR BE BLOCKED HONESTLY

If readers can see an easy solution, the story should usually acknowledge it.

Characters may reject it because:

- cost;
- ignorance;
- value;
- law;
- risk;
- logistics.

Do not simply pretend the solution does not exist.

---

# 46. PRESERVE CONSEQUENCE

Once something happens, let later writing inherit it.

Remember:

- decisions;
- injuries;
- losses;
- promises;
- revelations;
- public actions;
- failed strategies;
- social consequences.

Do not reset simply because the chapter changed.

---

# 47. SETUPS SHOULD NOT BE CREATED CASUALLY

Repeated ominous emphasis can create expectations.

Before strongly highlighting:

- object;
- phrase;
- stranger;
- prophecy;
- unexplained ability;
- suspicious behavior,

understand that readers may expect future relevance.

Not every detail should become a setup.

---

# 48. DO NOT MAKE EVERYTHING SIGNIFICANT

The fictional world should contain:

- ordinary objects;
- incidental details;
- moments without symbolic purpose;
- people who are not secretly important.

This creates texture.

If everything is loaded with meaning, meaning becomes predictable.

---

# 49. PAYOFF SHOULD CHANGE SOMETHING

A payoff should ideally do more than answer:

> What was the secret?

Consider:

> What does the answer change?

Good payoff may alter:

- relationship;
- strategy;
- worldview;
- stakes;
- power;
- interpretation of earlier scenes.

---

# 50. WORLD RULES SHOULD REMAIN ACTIVE

Established limitations should continue to matter.

Do not quietly weaken:

- magic cost;
- legal constraint;
- travel time;
- technological limit;
- social taboo

because the current scene would be easier without it.

---

# 51. LET SYSTEMS CREATE STORY

Worldbuilding should not only explain.

Institutions and systems can generate:

- incentives;
- obstacles;
- alliances;
- consequences;
- misunderstandings.

A world feels alive when its rules produce events.

---

# 52. TRACK SOCIAL CONSEQUENCE

Public action may affect:

- reputation;
- employment;
- law;
- family;
- status;
- institutional response.

Do not let large social actions remain private unless the circumstances support privacy.

---

# 53. THEME SHOULD REMAIN EMBEDDED

During drafting, avoid consciously inserting “theme sentences” unless the character or narrative voice naturally produces them.

Theme should often emerge through:

- conflict;
- choice;
- outcome;
- contrast;
- recurring situations.

---

# 54. DO NOT MAKE CHARACTERS THEMATIC SPOKESPEOPLE

A character may express philosophical ideas.

But those ideas should remain connected to:

- personality;
- experience;
- motive;
- context.

Different characters should not sound like alternate formulations of the author's thesis.

---

# 55. SYMBOLS SHOULD ENTER AS THINGS FIRST

A symbolic object should still function materially in the world.

Let significance accumulate through use and context.

Do not introduce objects solely as symbolic labels unless that style is deliberate.

---

# 56. MOTIFS SHOULD EVOLVE

When repeating an image, phrase, location, or object, ask:

> What is different now?

The recurrence may gain:

- new association;
- opposite meaning;
- emotional history;
- irony.

---

# 57. PRESERVE GENRE PLEASURE

Do not become so afraid of convention that the story stops delivering what readers came for.

If the genre promises:

- romance;
- investigation;
- progression;
- dread;
- adventure;
- competition,

allow those pleasures.

Specificity matters more than avoiding recognizable structures.

---

# 58. DO NOT FORCE SUBVERSION

A predictable outcome can be correct.

Do not choose an inferior outcome merely because it is surprising.

Strong surprise should arise from story logic.

---

# 59. PROTECT ARTISTIC IDENTITY

During drafting, keep the novel's preferences active.

Ask implicitly:

- what does this work notice?
- what does it linger on?
- what does it find funny?
- what does it understate?
- what does it refuse to romanticize?

These preferences should influence selection more than generic notions of literary beauty.

---

# 60. DO NOT OVER-POLISH THE FIRST PASS

Unless the user requests polished final prose, prioritize:

- scene truth;
- voice;
- causality;
- character;
- movement.

Line-level perfection can be addressed later.

Excessive polishing during generation may make prose cautious and generic.

---

# 61. DO NOT INTERRUP DRAFTING WITH SELF-CRITIQUE

Once drafting begins, avoid constant internal cycles of:

write → criticize → rewrite → criticize.

That can flatten voice.

Use the Pre-Writing Gate before drafting and Post-Draft Audit afterward.

Drafting mode should remain generative.

---

# 62. FOLLOW THE USER'S REQUESTED GRANULARITY

If the user asks:

> Write the full chapter.

Do not return an outline unless necessary.

If the user asks:

> Write only the confrontation.

Do not automatically continue into aftermath.

If the user asks:

> Continue.

Continue rather than summarize future events.

---

# 63. MAINTAIN ESTABLISHED LENGTH AND DENSITY

When continuing existing prose, infer:

- paragraph density;
- scene granularity;
- dialogue ratio;
- descriptive density;
- pace.

Do not abruptly compress or expand without reason.

---

# 64. PRESERVE ESTABLISHED VOICE WITHOUT PARODY

When matching an existing work, preserve:

- narrative distance;
- diction;
- rhythm tendencies;
- humor;
- descriptive priorities.

Do not exaggerate distinctive features until they become caricatures.

---

# 65. DO NOT COPY THE SAME RHETORICAL DEVICE TOO OFTEN

During longer drafting, be aware of accumulation involving:

- “not X, but Y”;
- rhetorical triplets;
- one-line fragments;
- repeated questions;
- repeated sensory metaphors;
- repeated paragraph endings.

Do not stop mid-scene to police every instance.

Pattern auditing belongs later.

---

# 66. AVOID PARAGRAPH-FORMULA DRIFT

Watch for repeated structures such as:

1. observation;
2. interpretation;
3. emotional explanation;
4. punch-line ending.

Or:

1. dialogue;
2. gesture;
3. internal reaction;
4. dialogue.

These structures are normal.

They become mechanical when repeated constantly.

---

# 67. AVOID AUTOMATIC CLOSING LINES

Do not end every section with:

- ominous implication;
- thematic reflection;
- emotional summary;
- clever inversion.

Sometimes the scene should end plainly.

---

# 68. ALLOW PROSE TO BE UNEVEN IN A USEFUL WAY

Some scenes may be:

- spare;
- dense;
- quiet;
- messy;
- lush;
- procedural.

Do not normalize every chapter into the same “quality texture.”

Coherence does not require uniformity.

---

# 69. PRESERVE SMALL SOCIAL REALITY

Where useful, allow minor evidence that characters have lives beyond the protagonist:

- schedules;
- obligations;
- acquaintances;
- habits;
- responsibilities.

Do not turn every secondary character into a fully developed subplot.

Small independence often creates enough depth.

---

# 70. DO NOT MAKE THE PROTAGONIST THE UNIVERSAL CENTER OF JUDGMENT

Other characters should:

- disagree;
- remain unimpressed;
- care about different things;
- prioritize themselves.

Do not automatically validate the protagonist's interpretation.

---

# 71. ALLOW CHARACTERS TO REMAIN WRONG

Characters do not need correction every time they:

- misjudge;
- misunderstand;
- act selfishly.

Consequences may reveal error later—or not.

---

# 72. RESPECT DEVELOPMENTAL PLAUSIBILITY

Characters should act according to:

- age;
- training;
- expertise;
- culture;
- experience.

Do not give children adult self-analysis by default.

Do not give beginners expert competence without cause.

---

# 73. USE EXPERTISE AS ATTENTION

Experts often notice different details.

Instead of repeatedly stating:

> She was an experienced doctor,

let expertise shape:

- what she notices;
- what worries her;
- what she ignores;
- how she interprets evidence.

---

# 74. MYSTERY REASONING SHOULD BE EARNED

Characters should not reach the correct answer merely because the plot requires progress.

Show enough:

- evidence;
- inference;
- error;
- alternative interpretation.

Correct conclusions should have routes.

---

# 75. CONCEALMENT SHOULD AFFECT BEHAVIOR

A secret does not need constant mention.

But concealment may affect:

- wording;
- topic avoidance;
- strategy;
- anxiety;
- information choices.

Use subtly where appropriate.

---

# 76. LARGE EVENTS SHOULD HAVE SCALE-AWARE EFFECTS

If a major event occurs, consider:

- witnesses;
- institutions;
- infrastructure;
- public response;
- logistics.

Do not make a world-changing event behave like a private conversation.

---

# 77. SMALL EVENTS SHOULD NOT BE FORCED INTO LARGE CONSEQUENCES

Not every choice needs to alter the kingdom.

Proportionality matters.

Minor moments can matter primarily to:

- character;
- relationship;
- mood.

---

# 78. ALLOW INCIDENTALITY

Realistic fictional worlds contain events that are not perfect plot mechanisms.

Some conversations can contain:

- humor;
- small distraction;
- ordinary observation.

Do not let incidental material overwhelm scene purpose.

A small amount can make the world feel inhabited.

---

# 79. DISTINGUISH TEXTURE FROM FILLER

Texture enriches:

- atmosphere;
- character;
- culture;
- rhythm.

Filler occupies space without adding experience or meaning.

The distinction depends on the novel.

---

# 80. DO NOT OVER-SUMMARIZE AFTER STRONG MOMENTS

After a powerful exchange, avoid automatically adding:

> She realized everything had changed between them.

If the scene already demonstrates that, trust it.

---

# 81. DO NOT UNDERWRITE NECESSARY CAUSAL LINKS

Restraint should not create confusion.

If readers need to know:

- why a character changed plan;
- how someone arrived;
- what evidence caused inference,

provide enough connection.

Clarity and inference can coexist.

---

# 82. USE TRANSITIONS TO PRESERVE CAUSALITY

Transitions can communicate:

- elapsed time;
- changed location;
- consequence;
- altered mood.

They need not always dramatize logistics.

A good transition tells the reader enough to orient without replaying routine movement.

---

# 83. DO NOT INVENT NEW LORE CASUALLY

During prose generation, resist unnecessary invention of:

- historical events;
- named institutions;
- new magical rules;
- family members;
- locations.

Every invented detail may become canon.

Add when useful.

Do not add simply to make prose feel rich.

---

# 84. NEW DETAILS SHOULD FIT EXISTING PATTERNS

When invention is necessary, check compatibility with:

- naming conventions;
- culture;
- world rules;
- technology;
- geography;
- artistic identity.

---

# 85. LABEL MAJOR PROVISIONAL INVENTIONS INTERNALLY

If drafting requires a substantial new element not yet established, treat it as provisional until accepted.

Do not silently transform a convenient invention into deep history without later updating the Story Bible.

---

# 86. DO NOT RETCON THROUGH CASUAL PROSE

A new sentence should not casually redefine:

- relationship history;
- character childhood;
- world rule;
- geography.

If a new development contradicts established canon, that requires deliberate handling.

---

# 87. WRITE DIALOGUE AS ACTION

Dialogue should alter:

- information;
- relationship;
- strategy;
- power;
- perception

when the scene calls for movement.

Even apparently casual dialogue can reveal competing intentions.

---

# 88. WRITE DESCRIPTION AS ATTENTION

Description should show:

- what matters;
- to whom;
- now.

This makes description part of character and narrative rather than pause.

---

# 89. WRITE INTERIORITY AS INTERPRETATION

Thought should not simply restate reality.

It should reveal the meaning reality has for the character.

---

# 90. WRITE ACTION AS DECISION UNDER CONDITIONS

Action becomes more specific when it reflects:

- goals;
- physical constraint;
- environment;
- competence.

Avoid generic cinematic motion detached from character.

---

# 91. WRITE WORLD BUILDING AS CONSEQUENCE

Whenever possible, show systems through:

- what people can do;
- cannot do;
- must pay;
- fear;
- expect.

This often creates stronger worldbuilding than standalone explanation.

---

# 92. DRAFTING WHEN THE PLAN BREAKS

If the prose naturally creates a stronger development than planned:

1. do not automatically suppress it;
2. check compatibility with canon and character;
3. allow it if stronger;
4. flag downstream state changes;
5. revise future planning afterward.

The outline is not superior to the story.

---

# 93. DRAFTING WHEN CHARACTER LOGIC BREAKS THE OUTLINE

If the planned event requires a character to behave implausibly:

do not force it.

Instead consider:

- change incentive;
- change pressure;
- change information;
- change event;
- change character involved.

Plot should emerge from believable choices.

---

# 94. DRAFTING WHEN THE SCENE BECOMES BETTER QUIETER

If the original plan expects confrontation but the scene naturally becomes quiet and tense, do not automatically restore shouting.

Dramatic strength can come from restraint.

Likewise, do not suppress genuine explosiveness merely to appear subtle.

---

# 95. DRAFTING WHEN A SCENE RUNS LONG

Ask:

### Is new story information still being produced?

### Is relationship state still moving?

### Is tension changing?

### Is the reader receiving valuable experience?

If not, exit.

Do not extend solely to hit length.

---

# 96. DRAFTING WHEN A SCENE RUNS SHORT

Do not pad automatically.

Ask whether anything important is missing:

- physical grounding;
- necessary reaction;
- consequence;
- transition.

If not, brevity may be correct.

---

# 97. DRAFTING MULTIPLE SCENES

Across a chapter, vary according to story needs:

- entry;
- intensity;
- mode;
- setting;
- emotional direction.

Do not deliberately alternate forms mechanically.

The chapter should feel composed rather than randomized.

---

# 98. MAINTAIN CHAPTER-LEVEL INHERITANCE

Each scene should hand something to the next:

- information;
- changed goal;
- location;
- pressure;
- consequence;
- mood.

Not every transition requires explicit causal linkage, but the chapter should possess movement.

---

# 99. DO NOT RESOLVE THE NOVEL A LITTLE IN EVERY SCENE

Long fiction requires unresolved pressure.

Avoid repeatedly giving characters:

- small emotional closure;
- small thematic insight;
- small relationship repair.

Some scenes should leave problems intact or worse.

---

# 100. PROTECT THE MIDDLE OF THE NOVEL

During extended drafting, watch for:

- repeated conflicts;
- new characters replacing development;
- endless escalation;
- forgotten setups;
- character reset;
- subplot isolation.

Prefer deepening existing material over constantly introducing new material.

---

# 101. ASK “WHAT IS PERMANENTLY DIFFERENT?”

Periodically during long drafting ask:

> What is permanently different from several chapters ago?

Possible answers:

- relationship;
- power;
- knowledge;
- location;
- identity;
- world condition.

If very little has changed despite many events, investigate stagnation.

---

# 102. DRAFTING SHOULD ACCUMULATE SPECIFICITY

As the novel progresses, later scenes should increasingly depend on:

- these characters;
- this history;
- these consequences;
- this world.

Early chapters may resemble genre patterns.

Later chapters should become harder to transplant into another novel.

---

# 103. GENERIC-SCENE TEST

After drafting a major scene, ask later during audit:

> Could the names be changed and this scene fit many unrelated novels?

If yes, identify what work-specific history or causality may be missing.

Do not interrupt drafting constantly with this test.

---

# 104. DO NOT EXPLAIN ARTISTIC IDENTITY

The narration should embody the work's sensibility.

Do not announce:

> This was the kind of world where...

unless that phrasing belongs naturally to the narrator.

---

# 105. ALLOW READER PARTICIPATION

Readers may infer:

- motive;
- tension;
- thematic meaning;
- symbolic association.

Do not make the prose responsible for eliminating every possible ambiguity.

---

# 106. BUT DO NOT CONFUSE CONFUSION WITH MYSTERY

If readers lack basic orientation about:

- who;
- where;
- when;
- what happened,

that may be confusion, not productive ambiguity.

Preserve intentional uncertainty.

Repair accidental uncertainty.

---

# 107. PRESERVE MOMENTUM WITHOUT RUSHING

Momentum comes from:

- desire;
- uncertainty;
- consequence;
- curiosity.

It does not require constant event density.

---

# 108. USE LINE-LEVEL BEAUTY IN SERVICE OF SCENE

A striking sentence is useful when it strengthens:

- perception;
- emotion;
- atmosphere;
- voice.

Do not distort scene logic to preserve a beautiful line.

Story truth outranks isolated prose.

---

# 109. DO NOT FALL IN LOVE WITH GENERATED LANGUAGE

If a paragraph is elegant but:

- repeats meaning;
- contradicts state;
- slows wrong moment;
- mischaracterizes POV,

cut or revise it.

Generated eloquence is disposable.

---

# 110. DRAFTING PRIORITY HIERARCHY

When competing concerns arise during prose generation, prioritize approximately:

1. explicit author request;
2. canon;
3. POV integrity;
4. character truth;
5. causal continuity;
6. relationship continuity;
7. scene purpose;
8. physical/world reality;
9. artistic identity;
10. pacing;
11. prose elegance;
12. surface variation.

Do not sacrifice character logic for a prettier sentence.

---

# 111. LIGHT DRAFTING MODE

For simple material:

Recall:

- POV;
- current state;
- goal;
- relationship;
- location.

Then write freely.

Do not invoke deeper guidance unless a problem appears.

---

# 112. STANDARD DRAFTING MODE

For ordinary chapters:

Maintain awareness of:

- scene state;
- goals;
- knowledge;
- continuity;
- relationship;
- artistic identity.

Draft continuously.

Audit afterward.

---

# 113. HIGH-RISK DRAFTING MODE

For complex scenes:

Maintain stronger awareness of:

- spatial continuity;
- secrets;
- multiple goals;
- objects;
- world rules;
- downstream consequence.

Still avoid writing line by line from checklist.

---

# 114. DRAFTING COMPLETION HANDOFF

After a draft is produced and accepted, do not treat the job as fully complete.

The draft should hand off to:

1. Post-Draft Audit;
2. state extraction;
3. ledger update;
4. chapter summary when relevant.

However, those steps should occur separately enough that they do not contaminate first-pass generation.

---

# 115. CENTRAL REMINDER

The Drafting Protocol exists to preserve **fluidity after structure**.

Before drafting, the system stabilizes reality.

During drafting, it should trust that preparation.

The prose should not feel as though it is trying to:

- satisfy rules;
- avoid AI detection;
- perform literary quality;
- demonstrate psychological depth;
- optimize every line.

It should feel as though something is happening to specific people in a specific world.

Therefore, while writing, return repeatedly to:

> What is happening now?

> What does this person want?

> What do they notice?

> What do they misunderstand?

> What do they do because of it?

> What changes as a result?

And let everything else serve those questions.

The objective is not visibly sophisticated prose.

The objective is **story-responsive prose**.

The best sign that the system is working is that the rules become difficult to see because they have been absorbed into the behavior of the fiction.

That completes the **Drafting Protocol**. The next stage is **Post-Draft Audit**—the immediate review that happens after a scene or chapter has been drafted, before we move into the much broader repetition and long-range audits.

**Remaining system-building stages:**
1. **Post-Draft Audit**
2. **Anti-Repetition / Pattern Audit**
3. **Long-Range Narrative Audit**
4. **Artistic-Identity / Anti-Homogenization Pass**
5. **Compact Project Instructions — final deployable version**
6. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Post-Draft Audit**. This is the immediate review layer after a scene or chapter is drafted. It should catch local problems before they accumulate, but it should remain lighter than the later Pattern Audit and Long-Range Narrative Audit.

Suggested filename: **`08-post-draft-audit.md`**

# POST-DRAFT AUDIT

## Purpose

The Post-Draft Audit is the immediate review performed after drafting a scene or chapter.

Its purpose is to catch problems while the material is still local enough to repair easily.

It should check:

- continuity;
- POV;
- character behavior;
- relationship inheritance;
- scene movement;
- emotional logic;
- knowledge boundaries;
- physical plausibility;
- redundant explanation;
- local prose repetition;
- and state changes that must be recorded.

It should **not** attempt to judge the entire novel.

Broader problems belong to:

- Anti-Repetition / Pattern Audit;
- Long-Range Narrative Audit;
- Artistic-Identity / Anti-Homogenization Pass.

The central principle is:

> First ask whether the scene works as story. 
> Then ask whether the prose needs adjustment.

---

# 1. WHEN TO RUN THE AUDIT

Run after:

- a completed scene;
- a completed chapter;
- a major rewrite;
- a high-risk revelation;
- a major relationship milestone;
- a complicated action sequence;
- a scene that introduces significant canon.

It does not need to run after every tiny line edit.

---

# 2. AUDIT DEPTH

Use proportional depth.

## LIGHT AUDIT

For straightforward scenes.

Check:

- continuity;
- POV;
- scene purpose;
- character behavior;
- obvious repetition;
- state changes.

---

## STANDARD AUDIT

For most scenes and chapters.

Check:

- continuity;
- POV;
- character;
- relationship;
- emotion;
- scene movement;
- pacing;
- knowledge;
- physical logic;
- prose;
- state updates.

---

## DEEP AUDIT

For high-risk material.

Use for:

- climax;
- major reveal;
- death;
- betrayal;
- major romantic development;
- mystery solution;
- political negotiation;
- complicated action;
- major world-rule use.

Add:

- setup/payoff integrity;
- downstream consequences;
- institutional effects;
- canon ripple;
- long-term character implications.

---

# 3. AUDIT ORDER

The audit should proceed from high-level to low-level.

Recommended order:

1. Canon and continuity
2. POV and knowledge
3. Character truth
4. Relationship continuity
5. Scene purpose and movement
6. Emotional logic
7. Physical/world logic
8. Setup/payoff
9. Pacing
10. Prose and repetition
11. Artistic fit
12. State extraction

Do not begin with sentence polishing if the scene is structurally wrong.

---

# 4. STEP ONE — CANON CHECK

Ask:

### Does anything contradict established canon?

Check:

- age;
- history;
- family;
- world rules;
- geography;
- prior events;
- established relationships;
- established abilities;
- important object history.

If contradiction exists:

### Is it intentional?

If yes, classify:

- revelation;
- mistaken belief;
- unreliable narration;
- deliberate retcon.

If no, repair.

---

# 5. STEP TWO — TIMELINE CHECK

Ask:

### Does elapsed time make sense?

### Are deadlines respected?

### Do travel times work?

### Do healing and fatigue make sense?

### Are ages and durations consistent?

### Does the scene occur at the correct point in chronology?

Do not overcheck minor clock details unless relevant.

---

# 6. STEP THREE — LOCATION CHECK

Ask:

### Is everyone where they should be?

### Did anyone appear without plausible movement?

### Are entrances/exits consistent?

### Is travel accounted for?

### Are important objects where they were last left?

For complex scenes, recheck blocking.

---

# 7. STEP FOUR — PHYSICAL CONTINUITY CHECK

Ask:

### Were injuries remembered?

### Was fatigue respected?

### Did characters perform actions they physically should not be able to perform?

### Did weapons, restraints, clothing, weather, or environment matter where relevant?

### Did physical states disappear merely because focus shifted?

Do not force repeated reminders if continuity is already preserved.

---

# 8. STEP FIVE — OBJECT & RESOURCE CHECK

Ask:

### Who owns important objects now?

### Were transfers clear?

### Were resources consumed accurately?

### Did ammunition, money, magic charges, medicine, time, or other constrained resources behave consistently?

### Did something reappear after being lost or destroyed?

---

# 9. STEP SIX — POV CHECK

Ask:

### Is the narration still inside the intended POV?

### Did the prose reveal information this character cannot know?

### Did vocabulary remain plausible?

### Did the character notice things consistent with their attention?

### Did the narration become generically omniscient?

### Did narrative distance drift?

---

# 10. STEP SEVEN — KNOWLEDGE CHECK

For each important character:

### What did they know entering?

### What did they learn?

### How did they learn it?

### What do they still not know?

### Did suspicion become certainty without evidence?

### Did writer knowledge leak?

### Did reader knowledge leak into character behavior?

Update the knowledge ledger if needed.

---

# 11. STEP EIGHT — CHARACTER TRUTH CHECK

Ask:

### Did each major action fit the character?

### If behavior deviated from baseline, did current state explain it?

### Did stress, injury, knowledge, or development justify the change?

### Did the character act merely because the plot needed them to?

### Did competence remain consistent?

### Did the character suddenly become more articulate, perceptive, moral, foolish, or brave than established?

If yes, diagnose cause before rewriting.

---

# 12. CHARACTER AGENCY CHECK

Ask:

### What did each important character want?

### Did they actively pursue it?

### Were they allowed to resist the scene's intended direction?

### Did the protagonist receive too much cooperation?

### Did supporting characters exist only to enable the protagonist?

If so, restore independent motive where appropriate.

---

# 13. CHARACTER DEVELOPMENT CHECK

If the scene changes a character:

### Was the change earned?

### Does it build from prior pressure?

### Is this immediate state or integrated development?

### Does old behavior remain anywhere?

### Is the character becoming a replacement rather than a developed version of themselves?

Do not promote one emotional realization into permanent transformation too quickly.

---

# 14. STEP NINE — RELATIONSHIP CONTINUITY CHECK

Ask:

### Did the relationship remember its history?

### Did recent trust changes matter?

### Did betrayal, intimacy, resentment, or obligation carry forward?

### Did the scene reset them to an earlier dynamic?

### Did the relationship change here?

If yes:

- what dimension changed?
- trust?
- intimacy?
- resentment?
- power?
- obligation?
- attraction?

Update relationship state.

---

# 15. RELATIONSHIP ASYMMETRY CHECK

Ask:

### Did both characters suddenly feel the same way?

### Did both interpret the scene identically?

### Did intimacy or forgiveness become artificially symmetrical?

### Does one person still care more, trust less, or understand differently?

Preserve asymmetry when it is part of the relationship.

---

# 16. STEP TEN — SCENE PURPOSE CHECK

Ask:

> Did this scene actually perform the work it was meant to perform?

If scene purpose was:

> damage trust,

did trust change?

If purpose was:

> reveal political danger,

did reader understanding shift?

If purpose was:

> provide recovery,

did the scene provide useful contrast or relationship space?

Do not confuse activity with function.

---

# 17. SCENE MOVEMENT CHECK

Ask:

### What changed?

Possible answers:

- knowledge;
- belief;
- relationship;
- goal;
- strategy;
- physical state;
- world state;
- reader understanding.

If the answer is:

> nothing,

ask whether the scene still provides enough:

- atmosphere;
- humor;
- experiential pleasure;
- characterization;
- thematic texture

to justify direct dramatization.

If not, compress or remove.

---

# 18. SCENE DUPLICATION CHECK

Ask:

### Have we recently done this same narrative job?

Examples:

- another trust argument;
- another encouragement scene;
- another training failure;
- another explanation of same rule;
- another scene proving same fear.

If yes:

### What new element makes this one necessary?

If no clear answer exists, consider compression or combination.

---

# 19. SCENE SHAPE CHECK

Ask whether the scene accidentally follows a familiar internal architecture:

- setup;
- conflict;
- emotional explanation;
- understanding;
- mini-resolution.

Or:

- question;
- answer;
- gesture;
- internal reaction;
- thematic closing line.

Repeated scene shapes matter more than any one instance.

Do not revise solely because a structure is familiar.

Flag only when it feels mechanical or repetitive.

---

# 20. STEP ELEVEN — EMOTIONAL CAUSALITY CHECK

Ask:

### Does the emotion come from this character's history and interpretation?

### Or from generic expectations of the situation?

### Is emotional intensity proportional?

### Did the scene rush from shock to understanding to closure?

### Did the character become more emotionally self-aware than established?

### Are contradictory feelings allowed?

---

# 21. EMOTIONAL PARAPHRASING CHECK

Look for chains such as:

- action indicates emotion;
- body language indicates same emotion;
- thought names emotion;
- narration explains emotion;
- metaphor restates emotion.

Ask:

### Does each layer add something new?

If not, remove the least useful repetition.

---

# 22. SHOW/TELL BALANCE CHECK

Do not apply:

> show, don't tell

mechanically.

Instead ask:

### Is direct statement stronger here?

### Is embodied action stronger here?

### Is interiority necessary?

### Is the scene currently over-decoding its own emotional meaning?

Choose the most functional channel.

---

# 23. SELF-KNOWLEDGE CHECK

Ask:

### Does the character understand themselves too perfectly?

### Did they diagnose their own psychology in unusually clean language?

### Did they resolve an internal contradiction too quickly?

### Would partial misunderstanding be more character-true?

Do not add confusion automatically.

Only preserve uncertainty where it fits.

---

# 24. STEP TWELVE — DIALOGUE CHECK

Ask:

### Does each speaker sound like themselves?

### Does each speaker have a goal?

### Is everyone equally articulate?

### Are answers too complete?

### Are characters giving information they have no reason to provide?

### Are lines too semantically symmetrical?

### Does conversation progress too efficiently toward mutual understanding?

### Does dialogue sound like disguised narration?

---

# 25. DIALOGUE INFORMATION CHECK

For exposition:

### Would the speaker actually explain this?

### Does the listener already know it?

### Is this the correct channel?

### Is the information attached to motive?

Do not remove necessary exposition simply because exposition can be mishandled.

---

# 26. DIALOGUE SUBTEXT CHECK

Ask:

### Is subtext present where useful?

### Is directness present where natural?

### Has every line been made indirect unnecessarily?

Subtext is optional.

Character truth comes first.

---

# 27. STEP THIRTEEN — PHYSICAL & ENVIRONMENTAL LOGIC CHECK

Ask:

### Did the environment affect what was possible?

### Did privacy make sense?

### Could characters hear each other?

### Could they see what they react to?

### Were distances plausible?

### Did weather or terrain matter where relevant?

This matters especially in action, stealth, travel, and intimate scenes.

---

# 28. ACTION-SCENE CHECK

For action:

### Are goals clear?

### Is spatial orientation sufficient?

### Are consequences physical?

### Do abilities obey rules?

### Does exhaustion accumulate?

### Does action alter future possibilities?

### Is choreography readable without becoming mechanical?

---

# 29. STEP FOURTEEN — WORLD-RULE CHECK

Ask:

### Did magic/technology/law/social rules behave consistently?

### Was a limitation quietly ignored?

### Did a new power appear without setup?

### Was an exception justified?

### If a solution exists here, why didn't it solve similar earlier problems?

---

# 30. INSTITUTIONAL LOGIC CHECK

When relevant:

### Would the institution respond this way?

### Who has authority?

### What incentives matter?

### What procedures constrain behavior?

### Is the institution acting like a person rather than a system?

Not every scene requires institutional realism.

Use when institutions materially affect plot.

---

# 31. STEP FIFTEEN — SETUP/PAYOFF CHECK

Ask:

### Did this scene create a new expectation?

### Was it intentional?

### Did it pay off an earlier setup?

### Did payoff address the type of investment created?

### Did the payoff change anything?

### Did the scene falsely emphasize an irrelevant element?

Update setup/payoff ledger where needed.

---

# 32. ACCIDENTAL SETUP CHECK

Watch for language that strongly marks something as important:

- unexplained emphasis;
- ominous description;
- unusual repetition;
- dramatic reaction;
- conspicuous object introduction.

Ask:

> Will readers reasonably expect this to matter?

If not, reduce emphasis.

---

# 33. STEP SIXTEEN — PACING CHECK

Ask:

### Did the scene spend space on the right moments?

### Was anything rushed?

### Was anything overextended?

### Did the scene remain after its strongest point?

### Did necessary aftermath receive enough space?

### Was routine over-dramatized?

---

# 34. SCENE ENTRY CHECK

Ask:

### Did the scene begin too early?

Could routine arrival, greeting, travel, or setup be compressed?

Or:

### Did it begin too late?

Was necessary orientation or emotional runway omitted?

---

# 35. SCENE EXIT CHECK

Ask:

### Did the scene end after its useful effect was already complete?

Common unnecessary endings:

- characters explain what just happened;
- emotional meaning is summarized;
- logistics are narrated after dramatic endpoint;
- next steps are repeated.

But keep aftermath when aftermath is the point.

---

# 36. CHAPTER PACING CHECK

For completed chapters:

### Did the chapter have an appropriate pacing role?

### Did scenes vary enough for the intended effect?

### Did every scene operate at similar intensity?

### Did chapter structure repeat recent chapters?

### Was the ending forced into a hook?

---

# 37. STEP SEVENTEEN — PROSE REPETITION CHECK

This is a **local** repetition check only.

Look for repeated:

- words;
- phrases;
- sentence shapes;
- body-language cues;
- contrast constructions;
- paragraph endings;
- metaphors.

Do not run the full Pattern Audit here.

Ask:

> Is repetition noticeable inside this scene/chapter?

If yes:

### Is it intentional?

### Does it create rhythm, motif, emphasis, or voice?

If not, revise selectively.

---

# 38. SENTENCE-PATTERN CHECK

Watch for clusters of:

- statement + fragment;
- not-X-but-Y;
- rhetorical triplets;
- question + immediate answer;
- repeated short dramatic sentence;
- repeated one-line paragraph.

Do not mechanically diversify every sentence.

Only fix patterns that create visible predictability.

---

# 39. PARAGRAPH-SHAPE CHECK

Look for repeated:

1. action;
2. body response;
3. thought;
4. dialogue.

Or:

1. description;
2. interpretation;
3. emotional meaning.

If several consecutive paragraphs use the same machinery, vary only where the underlying thought genuinely differs.

---

# 40. EMPHASIS CHECK

Ask:

### Is too much material emphasized?

Check density of:

- italics;
- fragments;
- one-line paragraphs;
- rhetorical questions;
- repetition;
- metaphorical intensity.

Emphasis works through contrast.

---

# 41. SENTENCE-ENDING CHECK

Look for excessive endings based on:

- revelation;
- reversal;
- ominous implication;
- emotional punch;
- thematic aphorism.

Not every sentence or paragraph needs to land dramatically.

---

# 42. METAPHOR CHECK

Ask:

### Is the metaphor coherent?

### Does it fit POV?

### Does it clarify or characterize?

### Is it necessary?

### Are several competing metaphors stacked?

Do not remove strange metaphors merely because they are unusual.

---

# 43. DESCRIPTION CHECK

Ask:

### Is description filtered through viewpoint?

### Are details relevant to the moment?

### Is sensory information checklist-like?

### Is everything over-described?

### Is important spatial grounding missing?

### Are decorative details crowding story information?

---

# 44. ABSTRACT-LANGUAGE CHECK

Look for passages heavy in:

- truth;
- weight;
- silence;
- meaning;
- destiny;
- something;
- everything;
- somehow;
- impossible;
- inevitable.

These words are not forbidden.

Ask whether abstraction is replacing specific content.

---

# 45. PSEUDO-DEPTH CHECK

Ask:

### Does the passage sound profound without becoming specific?

### Could the same reflection fit many unrelated novels?

### Is abstract language doing work that concrete character or story detail should do?

If yes, ground the passage.

---

# 46. ARTIFICIAL-INTENSITY CHECK

Ask whether importance is being manufactured through:

- fragments;
- repetition;
- body sensation;
- metaphors;
- italics;
- paragraph isolation

rather than arising from actual story stakes.

If yes, reduce rhetoric before increasing event intensity.

---

# 47. STEP EIGHTEEN — ARTISTIC-IDENTITY CHECK

Ask:

### Does this scene feel like this novel?

Check:

- attention;
- humor;
- restraint;
- imagery;
- emotional mode;
- treatment of violence;
- narrative attitude.

Do not ask:

> Is the prose stylish enough?

Ask:

> Is the style native to this work?

---

# 48. GENERIC-SCENE CHECK

Ask:

> Could names be changed and this scene fit many unrelated novels?

If yes, inspect:

- character-specific motive;
- history;
- world constraints;
- relationship specificity;
- work-specific attention.

Do not force decorative uniqueness.

Add specificity through causality and identity.

---

# 49. GENRE CHECK

Ask:

### Does the scene deliver or support the intended genre experience?

### Is it relying only on genre surface conventions?

### Is a familiar beat being executed specifically enough?

### Is the story avoiding genre pleasure merely to be unpredictable?

---

# 50. THEME CHECK

Ask:

### Is theme emerging from event and consequence?

### Did characters become mouthpieces?

### Did narration explain the meaning after the scene already embodied it?

### Is thematic statement appropriate to voice?

Do not remove all explicit thematic thought.

---

# 51. SYMBOLISM CHECK

Ask:

### Did symbolic material recur naturally?

### Did narration over-explain it?

### Did recurrence add a new association?

### Is ordinary material being forced into symbolism?

---

# 52. STEP NINETEEN — READER-INFERENCE CHECK

Ask:

### What does the reader already know?

### What has the scene already demonstrated?

### What is explained again unnecessarily?

Possible redundancies:

- motive already obvious from action;
- emotion already clear from dialogue;
- relationship shift already visible;
- theme already embodied.

Remove only explanations that do not add a useful layer.

---

# 53. CLARITY CHECK

The opposite problem matters too.

Ask:

### Can the reader tell who is speaking?

### Where are we?

### What happened?

### Why did this action follow?

### What changed?

### What is intentionally uncertain versus accidentally confusing?

Do not protect ambiguity at the expense of basic comprehension.

---

# 54. STEP TWENTY — CONSEQUENCE CHECK

Ask:

### What new consequences did this scene create?

### Which are immediate?

### Which are delayed?

### Who else might be affected?

### Does the world need to respond?

### Did the scene close consequences too quickly?

Add meaningful consequences to the ledger.

---

# 55. SOCIAL-CONSEQUENCE CHECK

If the scene contains public action:

### Who witnessed it?

### Who might hear about it?

### What reputation changes?

### What institutional response becomes plausible?

### What rumor might spread?

Not every witnessed action becomes important.

Track proportionally.

---

# 56. STEP TWENTY-ONE — STATE EXTRACTION

After the scene passes review, extract only durable changes.

Potential updates:

### Timeline

### Location

### Physical state

### Objects/resources

### Knowledge

### Secrets

### Character state

### Relationship state

### World state

### Open consequences

### Setup/payoff

Do not rewrite every file.

Update only affected systems.

---

# 57. STATE-EXTRACTION QUESTION

Ask:

> What is newly true after this scene that may matter later?

That question should generate most necessary updates.

---

# 58. CHAPTER SUMMARY HANDOFF

For a completed chapter, generate a concise change-focused summary.

Record:

### Major events

### Decisions

### New knowledge

### Relationship changes

### Character changes

### Physical/world changes

### Setups/payoffs

### Open consequences

### Next-state pressure

This becomes long-range retrieval material.

---

# 59. REVISION PRIORITY

When problems are found, prioritize:

## Priority 1 — Broken truth

Canon, timeline, knowledge, physical impossibility.

## Priority 2 — Broken character

Motivation, agency, personality, development.

## Priority 3 — Broken scene

Purpose, causality, movement, pacing.

## Priority 4 — Broken relationship/emotion

Reset, unearned shift, over-resolution.

## Priority 5 — Artistic mismatch

Genericity, thematic overstatement, tone drift.

## Priority 6 — Line-level issues

Repetition, syntax, imagery.

Fix in this order where practical.

---

# 60. DO NOT FIX EVERYTHING

Not every imperfection deserves intervention.

Ask:

### Does this materially weaken:

- clarity;
- continuity;
- character;
- pacing;
- reader experience;
- artistic identity?

If not, leave it.

Over-revision can flatten prose.

---

# 61. LIGHTEST-EFFECTIVE-REVISION RULE

Choose the smallest fix that solves the actual problem.

Examples:

### Problem

Emotion overexplained.

### Fix

Delete one interpretive sentence.

Not necessarily rewrite the entire paragraph.

---

### Problem

Character action seems unmotivated.

### Fix

Add or alter one earlier incentive.

Not necessarily change the entire scene.

---

### Problem

Scene feels repetitive.

### Fix

Change the state consequence.

Not merely reword the prose.

---

# 62. DIAGNOSE ROOT CAUSE

A surface problem may come from deeper structure.

Example:

### Symptom

Dialogue feels repetitive.

Possible causes:

- relationship has not moved;
- scene purpose repeats;
- characters share same reasoning;
- plot keeps asking same question.

Do not only replace dialogue lines.

---

# 63. POST-DRAFT AUDIT OUTPUT

By default, when the user asked for fiction, do not display a huge audit report.

The system can perform the audit internally and return the revised or final prose.

Show audit findings when the user explicitly asks for:

- critique;
- diagnosis;
- continuity check;
- revision explanation;
- quality review.

---

# 64. INTERNAL COMPACT AUDIT

A practical internal version:

## POST-DRAFT CHECK

Canon:

POV:

Knowledge:

Character:

Relationship:

Scene movement:

Emotion:

Physical logic:

Setup/payoff:

Pacing:

Prose repetition:

Artistic fit:

Durable state changes:

Required revisions:

Then revise only what matters.

---

# 65. AUDIT SEVERITY LEVELS

Classify findings if useful.

## CRITICAL

Breaks story truth or logic.

Examples:

- impossible knowledge;
- broken canon;
- character in wrong location.

## MAJOR

Substantially weakens scene.

Examples:

- unmotivated decision;
- relationship reset;
- scene has no useful movement.

## MODERATE

Noticeable but local.

Examples:

- overexplained emotion;
- repeated dialogue structure.

## MINOR

Surface polish.

Examples:

- repeated word;
- awkward sentence.

This prevents minor prose issues from receiving more attention than major narrative failures.

---

# 66. ACCEPTABLE IMPERFECTION

Do not revise merely because something is:

- unconventional;
- emotionally direct;
- melodramatic;
- repetitive once;
- structurally simple;
- genre-familiar;
- quiet;
- ornate;
- abrupt.

Ask whether it works **for this novel**.

---

# 67. DO NOT APPLY FUTURE AUDITS PREMATURELY

The Post-Draft Audit should not perform exhaustive:

- manuscript-wide phrase counting;
- arc-level pacing analysis;
- long-range motif analysis;
- full artistic homogenization diagnosis.

Those belong later.

This keeps local revision proportionate.

---

# 68. HIGH-RISK SCENE POST-AUDIT

For major scenes, additionally ask:

### What is permanently different?

### What cannot be undone?

### What future options closed?

### What new options opened?

### What promises did the story create?

### What relationships changed category?

### What must future scenes remember?

This ensures important scenes actually matter after they end.

---

# 69. MAJOR REVELATION POST-AUDIT

Ask:

### Was revelation earned?

### Was information route valid?

### Does it reinterpret earlier material?

### Does it create consequence?

### Did everyone understand it too quickly?

### Does it collapse too many mysteries at once?

### What new question replaces the old one?

---

# 70. MAJOR RELATIONSHIP SCENE POST-AUDIT

Ask:

### Was milestone earned?

### Did both characters interpret it the same way?

### What changed afterward?

### What remains difficult?

### Was emotional closure excessive?

### Does the relationship now have new behavior available?

---

# 71. MAJOR ACTION SCENE POST-AUDIT

Ask:

### Was action physically coherent?

### Did tactics match competence?

### Did world rules hold?

### Did injury/resources persist?

### Did action change plot or world state?

### Did aftermath match scale?

---

# 72. MYSTERY-SCENE POST-AUDIT

Ask:

### Were clues fairly available?

### Did deduction follow evidence?

### Did character know too much?

### Was misdirection plausible?

### Did revelation close or transform the mystery correctly?

---

# 73. REVISION AUDIT

After substantially revising a scene:

### Did the revision create new contradictions?

### Did it change knowledge?

### Did it change relationship state?

### Did it remove setup?

### Did it change downstream causality?

### Do ledgers and chapter summaries still match?

Revision can create continuity debt.

---

# 74. POST-AUDIT STATE ROUTING

Once accepted:

### Character change

→ Character State System

### Relationship change

→ Relationship State System

### Knowledge change

→ Knowledge Ledger

### Injury

→ Physical State Ledger

### Important object transfer

→ Object Ledger

### World change

→ World-State Ledger

### Delayed consequence

→ Open Consequence Ledger

### Setup/payoff

→ Setup & Payoff Ledger

### Chapter completion

→ Chapter Summary

This keeps the system synchronized.

---

# 75. CENTRAL REMINDER

The Post-Draft Audit exists to answer three questions:

> Is this scene true to the story?

> Does it meaningfully work?

> What must the story remember afterward?

It should catch mistakes before they accumulate.

But it should not polish every irregularity into sameness.

Review in this order:

**truth before elegance;**

**character before cleverness;**

**causality before intensity;**

**specificity before generic depth;**

**function before appearance.**

Then update the story state and move forward.

The purpose of the audit is not to make every scene flawless.

It is to stop small local failures from becoming large long-form failures.

That completes the **Post-Draft Audit**. Next is the **Anti-Repetition / Pattern Audit**, which is deliberately broader: it examines multiple scenes or chapters together to detect repetition that may be invisible when each passage is judged separately.

**Remaining system-building stages:**
1. **Anti-Repetition / Pattern Audit**
2. **Long-Range Narrative Audit**
3. **Artistic-Identity / Anti-Homogenization Pass**
4. **Compact Project Instructions — final deployable version**
5. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Anti-Repetition / Pattern Audit**. This one looks across multiple scenes or chapters, because many AI-writing problems only become visible through accumulation.

Suggested filename: **`09-anti-repetition-and-pattern-audit.md`**

# ANTI-REPETITION & PATTERN AUDIT

## Purpose

This document defines how to detect repeated patterns across multiple scenes, chapters, POVs, characters, and narrative units.

Its purpose is not to eliminate repetition.

Repetition can be useful.

It can create:

- rhythm;
- motif;
- ritual;
- emphasis;
- character voice;
- structural expectation;
- thematic recurrence;
- escalation through variation.

The problem is **unintentional recurrence**.

This includes repeated:

- sentence structures;
- emotional sequences;
- scene architectures;
- dialogue dynamics;
- character reactions;
- body-language cues;
- metaphors;
- chapter endings;
- conflicts;
- plot solutions;
- thematic conclusions;
- and narrative habits.

The central principle is:

> Repetition is not automatically a flaw.

Instead ask:

> Is the recurrence intentional, functional, and evolving?

---

# 1. WHY THIS AUDIT MUST BE SEPARATE

A scene can work perfectly in isolation and still contribute to a repetitive novel.

Examples:

Scene 4:

Strong confrontation.

Scene 9:

Another strong confrontation.

Scene 13:

Another strong confrontation.

Each individually works.

Across the novel, however, all three may follow:

1. disagreement;
2. rising tension;
3. emotional confession;
4. partial understanding;
5. quiet ending.

The problem is not any single scene.

The pattern only becomes visible at scale.

Therefore this audit should examine groups of scenes or chapters together.

---

# 2. WHEN TO RUN IT

Run periodically rather than after every scene.

Useful intervals:

- after several chapters;
- after an arc;
- after approximately 20–25% of a novel;
- at midpoint;
- before final revision;
- whenever prose begins feeling repetitive or generically “AI-like.”

For serial fiction, run at regular intervals.

---

# 3. WHAT TO COMPARE

Depending on the novel, compare:

### Recent scenes

Usually 5–15 scenes.

### Recent chapters

Usually 3–10 chapters.

### Same-POV material

To detect voice and cognitive repetition.

### Same relationship

To detect repeated interaction patterns.

### Same scene type

Training scenes, investigations, arguments, battles, etc.

### Entire manuscript

For final pattern review.

---

# 4. AUDIT PRINCIPLE — PATTERN BEFORE INSTANCE

Do not search for:

> Has the phrase “not X but Y” appeared?

Ask:

> How often does the prose rely on contrastive reframing, and what function is it serving?

Do not ask only:

> Has someone sighed?

Ask:

> Are characters repeatedly expressing emotion through the same physical vocabulary?

The target is the underlying pattern.

---

# 5. PATTERN CLASSIFICATION

Patterns can be classified as:

## INTENTIONAL

Clearly serving:

- motif;
- voice;
- ritual;
- theme;
- structural design.

Usually preserve.

---

## FUNCTIONAL BUT OVERUSED

Technique works but appears too frequently.

Reduce selectively.

---

## ACCIDENTAL

No meaningful reason for recurrence.

Revise.

---

## EVOLVING

Repeats but changes meaning or consequence.

Usually valuable.

---

## STATIC

Repeats without transformation.

Potential problem.

---

## CHARACTER-SPECIFIC

Belongs to one character.

Potentially useful.

---

## NARRATOR-WIDE

Appears everywhere regardless of POV.

Higher risk of homogenization.

---

# 6. SENTENCE-STRUCTURE AUDIT

Look across several pages or chapters for repeated sentence architectures.

Possible patterns:

- declarative sentence + fragment;
- long sentence + one-word punch;
- observation + interpretation;
- action + emotional explanation;
- question + immediate answer;
- statement + reversal;
- “not X, but Y”;
- three-item escalation;
- two clauses followed by isolated conclusion.

Record frequency and context.

---

# 7. CONTRASTIVE-REFRAMING AUDIT

Common forms include:

- not X, but Y;
- not because X—because Y;
- it wasn't X. It was Y;
- not exactly X. Something worse;
- not fear. Recognition.

These constructions are not inherently weak.

Audit questions:

### Is the contrast genuinely clarifying?

### Is the distinction important?

### Is the device appearing mainly to manufacture intensity?

### Does it occur in multiple POVs equally?

### Would direct phrasing be stronger sometimes?

If overused, revise only the unnecessary instances.

---

# 8. FRAGMENT AUDIT

Look for fragments used to create:

- shock;
- emphasis;
- rhythm;
- emotional rupture;
- speed.

Ask:

### Are fragments clustering?

### Do they appear at every dramatic moment?

### Are multiple POVs using the same fragment rhythm?

### Are full sentences being broken merely to imitate intensity?

Do not eliminate fragments globally.

---

# 9. RHETORICAL TRIPLET AUDIT

Look for frequent three-part constructions:

> cold, silent, inevitable.

> He wanted to run, to scream, to disappear.

> She had lied to him, betrayed him, abandoned him.

Ask:

### Does three-part rhythm suit the sentence?

### Is triadic structure becoming automatic?

### Could one or two stronger elements replace a generic three?

Use selectively.

---

# 10. PARAGRAPH-ARCHITECTURE AUDIT

Look across several paragraphs and scenes.

Common repeated pattern:

1. dialogue;
2. gesture;
3. thought;
4. dialogue.

Or:

1. description;
2. interpretation;
3. emotion;
4. punch line.

Or:

1. action;
2. body response;
3. explanation.

A few repetitions are normal.

The issue is when prose begins feeling generated from a template.

---

# 11. PARAGRAPH-ENDING AUDIT

Check whether many paragraphs end with:

- reversal;
- ominous note;
- emotional revelation;
- thematic statement;
- isolated fragment;
- clever line;
- rhetorical question.

If every paragraph tries to land hard, emphasis loses contrast.

Allow some paragraphs to simply continue narrative flow.

---

# 12. CHAPTER-ENDING AUDIT

Compare chapter endings.

Look for repeated endings such as:

- cliffhanger;
- revelation;
- knock at door;
- ominous thought;
- dramatic declaration;
- unresolved question;
- “everything had changed” implication.

Ask:

### Is repetition genre-appropriate?

### Is every chapter forced into a hook?

### Could some chapters end on consequence, quietness, image, or completion?

Do not remove effective cliffhangers merely for variety.

---

# 13. OPENING-PATTERN AUDIT

Compare chapter and scene openings.

Look for repeated:

- waking;
- weather description;
- immediate dialogue;
- physical sensation;
- question;
- location establishing shot;
- memory triggered by object;
- character entering room.

Variation should follow story needs.

The goal is not random opening diversity.

---

# 14. BODY-LANGUAGE AUDIT

Track recurring gestures.

Common candidates:

- jaw tightening;
- fists clenching;
- breath catching;
- shoulders dropping;
- looking away;
- throat tightening;
- heart pounding;
- swallowing;
- rubbing temples;
- exhaling slowly;
- smiling without humor.

Ask:

### Which gestures are character-specific?

### Which are narrator defaults?

### Are emotions being repeatedly translated through the same body cues?

### Could action, silence, dialogue, or direct emotion replace some instances?

---

# 15. EMOTIONAL-CHANNEL AUDIT

Compare how emotion is expressed across characters and scenes.

Possible channels:

- thought;
- body sensation;
- action;
- dialogue;
- silence;
- memory;
- humor;
- avoidance;
- direct naming.

If every character expresses emotion through:

body sensation + internal explanation,

the novel may feel homogeneous.

---

# 16. EMOTIONAL-SEQUENCE AUDIT

Look for repeated emotional architectures.

Example:

1. shock;
2. denial;
3. physical reaction;
4. realization;
5. acceptance.

Or:

1. anger;
2. confession;
3. understanding;
4. reconciliation.

Or:

1. fear;
2. determination;
3. action.

Ask:

### Are major emotional scenes moving through the same stages?

### Are emotions resolving at similar speed?

### Do different characters process differently?

---

# 17. EMOTIONAL-PAYOFF AUDIT

Look for recurring emotional closures:

- characters understand themselves;
- characters understand each other;
- conflict becomes verbalized;
- tension ends with reassurance;
- relationship improves after confrontation.

If these recur too often, the novel may become psychologically over-neat.

Some emotional scenes should:

- remain unresolved;
- worsen;
- redirect;
- leave misunderstanding intact.

---

# 18. SELF-KNOWLEDGE PATTERN AUDIT

Compare major characters.

Ask:

### Do they all diagnose themselves accurately?

### Do they all eventually articulate their fear?

### Do they all understand why they behave badly?

### Do they all become psychologically mature in similar ways?

Different characters should possess different levels of self-awareness.

---

# 19. DIALOGUE-RHYTHM AUDIT

Look for repeated conversational patterns:

- statement → rebuttal → clarification;
- question → honest answer;
- accusation → explanation → reconciliation;
- joke → sarcastic return → banter escalation;
- confrontation → confession.

Ask whether conversation mechanics are repeating independently of character.

---

# 20. MIRROR-RESPONSE AUDIT

Look for dialogue where one character semantically mirrors another.

Example:

> “You don't trust me.”

> “I don't trust what you're hiding.”

Or:

> “You think I ran.”

> “I think you chose yourself.”

This can be effective.

But repeated mirror structures can become noticeably generated.

---

# 21. THERAPY-DIALOGUE AUDIT

Look for recurring dialogue where characters:

- accurately identify emotional needs;
- carefully validate each other;
- explain childhood causes;
- verbalize boundaries cleanly;
- resolve misunderstandings efficiently.

Such dialogue may fit some characters.

The audit asks whether **everyone** speaks this way.

---

# 22. EXPOSITION-DIALOGUE AUDIT

Across scenes, look for dialogue repeatedly used to explain:

- world history;
- magic;
- politics;
- character backstory;
- thematic ideas.

Ask:

### Do characters have real motives for saying this?

### Is another narrative channel more natural?

---

# 23. CHARACTER-VOICE AUDIT

Compare characters across several dialogue passages.

Do they differ in:

- directness;
- vocabulary;
- sentence length;
- humor;
- formality;
- willingness to disclose;
- use of metaphor;
- certainty;
- hedging;
- conflict style?

Avoid reducing voice differentiation to catchphrases or accents.

---

# 24. COGNITIVE-VOICE AUDIT

Even if dialogue sounds different, compare internal reasoning.

Ask:

### Do all characters think in equally polished prose?

### Do they reason with similar precision?

### Do they notice similar details?

### Do they reach conclusions in similar ways?

### Do they all use the same metaphorical register internally?

This is a deeper homogenization risk.

---

# 25. DESCRIPTION-PATTERN AUDIT

Look for repeated descriptive approaches:

- room → light → smell → mood;
- face → eyes → mouth;
- weather reflecting emotion;
- architecture described through scale;
- environment always interpreted symbolically.

Ask:

### Is description being selected by POV?

### Or produced through narrator habit?

---

# 26. SENSORY-DISTRIBUTION AUDIT

Across several chapters, examine whether sensory writing follows a checklist.

Potential pattern:

visual → sound → smell → touch.

The issue is not using multiple senses.

The issue is mechanical distribution.

---

# 27. METAPHOR-FAMILY AUDIT

Look for repeated metaphor domains.

Examples:

- drowning;
- knives;
- storms;
- fire;
- weight;
- fractures;
- darkness;
- gravity.

Ask:

### Is this a deliberate motif?

### Is it character-specific?

### Or is it generic metaphor recurrence?

If intentional, it may strengthen artistic identity.

---

# 28. METAPHOR-INTENSITY AUDIT

Compare density.

Ask:

### Does every important emotion trigger metaphor?

### Are metaphors increasingly ornate?

### Is figurative language compensating for weak underlying specificity?

Do not reduce metaphor globally.

Use it where strongest.

---

# 29. GENERIC-LITERARY-VOCABULARY AUDIT

Look for repeated abstract or elevated vocabulary used across unrelated contexts.

Examples might include recurring language around:

- silence;
- weight;
- truth;
- fracture;
- gravity;
- inevitability;
- something unnamed;
- ancient;
- impossible;
- hollow.

The words themselves are not forbidden.

Ask whether they have become stylistic shortcuts.

---

# 30. SCENE-FUNCTION AUDIT

Tag recent scenes by primary function.

Example:

| Scene | Function |
|---|---|
| 12 | confrontation |
| 13 | investigation |
| 14 | confrontation |
| 15 | confrontation |
| 16 | recovery |

Look for clustering.

Ask:

### Are too many scenes performing the same narrative work?

---

# 31. SCENE-SHAPE AUDIT

Compare scene structures.

Possible pattern:

1. characters enter;
2. small talk;
3. conflict;
4. emotional reveal;
5. partial resolution.

Or:

1. travel;
2. observation;
3. danger;
4. fight;
5. aftermath.

If repeated, determine whether structure is intentional.

---

# 32. SCENE-ENTRY AUDIT

Check whether scenes routinely begin at the same stage of interaction.

Examples:

- always just before confrontation;
- always with arrival;
- always with quiet setup.

Variation can alter rhythm.

---

# 33. SCENE-EXIT AUDIT

Check repeated exit types:

- revelation;
- threat;
- decision;
- emotional line;
- physical departure.

Not every scene needs a dramatic final beat.

---

# 34. SCENE-RESOLUTION AUDIT

Ask:

### How many recent scenes resolve their primary tension?

### How many complicate it?

### How many leave it unresolved?

If almost every scene closes neatly, long-form tension may flatten.

---

# 35. CONFLICT-TYPE AUDIT

Tag conflicts:

- interpersonal;
- physical;
- institutional;
- informational;
- internal;
- resource;
- social;
- moral.

If the story relies overwhelmingly on one form, ask whether that is intentional.

A political novel dominated by interpersonal arguments may underuse institutional conflict.

---

# 36. ARGUMENT AUDIT

For repeated arguments, compare:

### Issue

### Participants' positions

### Tactics

### Outcome

### Relationship consequence

Ask:

> Are these arguments actually different?

Changing wording while repeating the same underlying dispute is not progression.

---

# 37. RELATIONSHIP-SCENE AUDIT

For each major relationship, track recent scenes.

Ask:

### What changed each time?

### Are scenes only reaffirming the same dynamic?

### Are milestones accumulating?

### Does friction evolve?

If not, relationship development may be static.

---

# 38. VALIDATION-PATTERN AUDIT

Check how other characters react to protagonist.

Ask:

### How often is protagonist praised?

### How often are their interpretations validated?

### Do skeptics eventually agree with them?

### Do conflicts end with protagonist proven right?

This can reveal protagonist-centered narrative bias.

---

# 39. SUPPORTING-CHARACTER FUNCTION AUDIT

Tag recurring supporting-character appearances.

Examples:

- gives advice;
- provides clue;
- rescues protagonist;
- comforts protagonist;
- opposes protagonist.

If a character repeatedly appears for one function only, consider whether they need:

- independent goal;
- lateral relationship;
- competing interest.

Not every minor character requires depth.

---

# 40. PROTAGONIST-SUCCESS AUDIT

Compare how often protagonist:

- succeeds;
- fails;
- partially succeeds;
- succeeds with cost;
- misjudges;
- is rescued;
- gets lucky.

Look for repetitive result patterns.

---

# 41. PROBLEM-SOLUTION AUDIT

For major obstacles, compare solutions.

Are problems repeatedly solved by:

- sudden competence;
- hidden power;
- clever speech;
- ally arrival;
- new information;
- sacrifice;
- confrontation;
- emotional honesty?

Variety should emerge from story systems, not arbitrary rotation.

---

# 42. REVELATION AUDIT

Compare major reveals.

Ask:

### Are revelations arriving in similar ways?

Examples:

- overheard conversation;
- discovered document;
- confession;
- villain speech;
- sudden memory;
- convenient witness.

Repeated revelation channels may become predictable.

---

# 43. INTERRUPTIVE-EVENT AUDIT

Look for repeated use of external interruption to stop scenes:

- knock;
- attack;
- messenger;
- phone call;
- explosion;
- arrival.

Interruption can be useful.

If overused, it may prevent scenes from resolving naturally.

---

# 44. RESCUE AUDIT

Look for repeated rescue structures.

Who saves whom?

Are protagonists repeatedly rescued at maximum danger?

Does rescue come from established causality or convenient arrival?

---

# 45. CONVENIENCE AUDIT

Across several chapters, identify events that arrive exactly when needed.

Examples:

- information;
- object;
- ally;
- enemy mistake;
- weather event.

One convenient event is normal.

Repeated convenience may weaken causal trust.

---

# 46. ESCALATION-PATTERN AUDIT

Track how stakes rise.

Do they repeatedly escalate through:

- stronger enemy;
- bigger battle;
- higher body count;
- larger magical power?

Consider other axes:

- moral cost;
- relationship cost;
- social exposure;
- irreversibility;
- reduced options.

---

# 47. THREAT-PATTERN AUDIT

Are threats repeatedly introduced before earlier threats fully develop?

This can create escalation inflation.

Ask:

### Is new danger deepening existing conflict?

Or:

### Replacing it?

---

# 48. SUBPLOT-PATTERN AUDIT

Compare subplots.

Ask:

### Do all subplots follow similar structure?

### Are all relationship subplots about trust?

### Are all secondary characters confronting the protagonist?

### Do all subplots resolve near the main plot climax?

Variation can create narrative depth.

---

# 49. INFORMATION-PACING AUDIT

Look for repeated chapter structure:

- clue;
- question;
- clue;
- reveal.

Or:

- exposition block;
- action;
- exposition block.

Ask whether information delivery has become mechanically timed.

---

# 50. WORLD-BUILDING DELIVERY AUDIT

Compare how world information enters.

Is it mostly through:

- dialogue;
- internal explanation;
- narration;
- documents;
- experience;
- consequence?

If one channel dominates excessively, consider other natural channels.

---

# 51. THEMATIC-STATEMENT AUDIT

Search conceptually for places where narration or characters explicitly summarize thematic ideas.

Ask:

### Are similar conclusions repeated?

### Do different characters state essentially the same message?

### Are chapters ending with thematic interpretation?

If so, reduce duplication or differentiate perspectives.

---

# 52. SYMBOLIC-PATTERN AUDIT

Track recurring:

- objects;
- colors;
- weather;
- imagery;
- locations;
- phrases.

Ask:

### Is meaning evolving?

### Or merely repeating?

A static symbol can still work if repetition itself creates the intended effect.

---

# 53. WEATHER-PATTERN AUDIT

A common narrative habit is making weather mirror emotion.

Check:

- rain during sadness;
- storms during conflict;
- sunlight during hope.

These are not inherently weak.

Repeated use can become conspicuous.

---

# 54. NAME-AND-TERMINOLOGY AUDIT

For worldbuilding-heavy fiction, check:

### Are invented names too structurally similar?

### Are too many terms introduced in clusters?

### Are titles/formal terms repeated excessively in prose?

### Has terminology drifted?

This overlaps with continuity but also affects stylistic repetition.

---

# 55. POV-SWITCH PATTERN AUDIT

For multi-POV novels:

Ask:

### Are POV chapters all similar lengths?

### Do switches always occur after cliffhangers?

### Does every POV serve similar function?

### Do some POVs repeatedly explain what previous POVs already established?

Pattern can be deliberate but should be visible to the writer.

---

# 56. POV-FUNCTION AUDIT

Tag what each POV contributes.

Examples:

- political access;
- emotional intimacy;
- mystery;
- antagonist perspective;
- world expansion.

If multiple POVs provide essentially the same experience, reconsider differentiation.

---

# 57. INTERNAL-MONOLOGUE AUDIT

Look across chapters for repeated thought structures.

Examples:

- question followed by self-answer;
- denial followed by admission;
- memory followed by thematic realization;
- emotional label followed by explanation.

If internal monologue sounds structurally identical across characters, adjust cognition rather than only diction.

---

# 58. MEMORY/FLASHBACK AUDIT

Check whether emotional scenes repeatedly trigger:

- childhood memory;
- parental memory;
- trauma flash;
- former lover.

Flashback is useful when present experience genuinely activates history.

If every deep scene reaches backward, it can become formulaic.

---

# 59. TRAUMA-PATTERN AUDIT

For characters with traumatic histories, ask:

### Is trauma represented through the same symptoms repeatedly?

### Does every vulnerability trace back to trauma?

### Has trauma become the universal explanation for personality?

Allow broader character causality.

---

# 60. CHARACTER-ARC PATTERN AUDIT

Compare arcs across the cast.

Do many characters follow:

1. denial;
2. confrontation;
3. emotional realization;
4. healthier behavior?

Characters may:

- regress;
- remain static;
- become worse;
- adapt without healing;
- change strategically rather than emotionally.

---

# 61. REDEMPTION-PATTERN AUDIT

If several antagonistic characters exist:

### Do they all receive sympathetic backstory?

### Do rivals all become allies?

### Do villains all reveal hidden wounds?

Complexity does not require redemption.

---

# 62. MORAL-PATTERN AUDIT

Ask:

### Are morally correct choices consistently rewarded?

### Are selfish choices consistently punished?

### Do characters who agree with story values receive narrative validation?

Some fiction intentionally uses clear moral structure.

The audit simply identifies the pattern.

---

# 63. CONSEQUENCE-PATTERN AUDIT

Compare consequences.

Do choices repeatedly lead to:

- immediate punishment;
- immediate reward;
- relationship damage;
- public exposure?

Consider delayed and indirect consequences where appropriate.

---

# 64. FAILURE-PATTERN AUDIT

How do characters fail?

Repeated failure through:

- misunderstanding;
- impulsiveness;
- arrogance;
- lack of power;
- bad luck

can become predictable.

Failure should arise from individual vulnerabilities and circumstances.

---

# 65. SUCCESS-PATTERN AUDIT

Similarly, how do they win?

If every victory comes from:

- clever improvisation;
- hidden strength;
- emotional sincerity;
- teamwork,

the structure may become repetitive.

---

# 66. PACING-PATTERN AUDIT

Map recent chapters by pacing role:

- acceleration;
- recovery;
- escalation;
- investigation;
- payoff;
- transition.

Look for:

- endless escalation;
- repeated alternation;
- long flat stretches.

Do not optimize toward a mathematically regular rhythm.

---

# 67. CHAPTER-LENGTH PATTERN AUDIT

Uniform chapter length can be intentional.

But if every chapter ends at similar length because drafting habit controls structure, consider whether some chapters should breathe differently.

---

# 68. SCENE-LENGTH PATTERN AUDIT

Likewise, check whether all scenes receive similar narrative space regardless of importance.

Narrative hierarchy should influence length.

---

# 69. RECOVERY-SCENE AUDIT

Are quiet scenes repeatedly interrupted by danger?

If so, the story may distrust stillness.

Allow recovery to sometimes remain recovery.

---

# 70. HIGH-INTENSITY DENSITY AUDIT

Count conceptually how often chapters include:

- confession;
- betrayal;
- attack;
- major reveal;
- breakdown;
- dramatic confrontation.

If every chapter contains high-intensity events, contrast may disappear.

---

# 71. ORDINARY-LIFE AUDIT

Ask:

### Does the novel contain enough normality to make disruption meaningful?

This does not mean adding filler.

Normal life can create:

- attachment;
- social texture;
- stakes;
- humor;
- baseline.

Genre determines the needed amount.

---

# 72. NEW-ELEMENT AUDIT

Track introduction of:

- new characters;
- new factions;
- new powers;
- new locations;
- new mysteries.

If new material continually appears because existing material feels exhausted, ask whether existing elements should deepen instead.

---

# 73. MIDDLE-BOOK NOVELTY AUDIT

A common long-form risk is introducing novelty rather than developing consequence.

Ask:

### Are new elements replacing earlier setups?

### Are old supporting characters disappearing?

### Are established conflicts being abandoned?

### Is escalation being achieved through addition rather than transformation?

---

# 74. RESOLUTION-PATTERN AUDIT

How do conflicts end?

Repeated methods:

- honest conversation;
- violence;
- sacrifice;
- evidence reveal;
- authority intervention;
- apology.

If the same resolution mechanism dominates, examine whether story logic supports it.

---

# 75. APOLOGY AUDIT

If characters apologize frequently:

### Do apologies change behavior?

### Are they too articulate?

### Do apology scenes repeatedly lead to reconciliation?

Apology can be meaningful without immediate repair.

---

# 76. FORGIVENESS AUDIT

Check whether forgiveness repeatedly occurs because characters understand motive.

Understanding does not automatically produce forgiveness.

---

# 77. INTERRUPTED-ROMANCE AUDIT

In romance or romantic subplots, watch for artificial delay through:

- repeated interruptions;
- overheard misunderstandings;
- avoidable noncommunication;
- almost-kisses.

These can work, but repetition becomes visible quickly.

---

# 78. MYSTERY-DELAY AUDIT

For mysteries, check whether progress is repeatedly delayed through:

- missing witness;
- destroyed evidence;
- refusal to speak;
- sudden attack.

Delay should arise naturally from system and opposition.

---

# 79. COMBAT-PATTERN AUDIT

Compare fights.

Ask:

### Do battles follow similar beat structure?

### Does protagonist repeatedly struggle, discover resolve, then win?

### Are environmental conditions used differently?

### Do goals differ beyond “defeat enemy”?

Different combat objectives create natural variation.

---

# 80. TRAINING-SCENE AUDIT

Training scenes can become repetitive.

Compare:

- lesson;
- failure;
- correction;
- improvement.

Consider variation through:

- social pressure;
- strategy;
- consequences;
- competition;
- transfer of skill to real conditions.

---

# 81. TRAVEL-SCENE AUDIT

Travel may repeatedly become:

- landscape description;
- conversation;
- attack.

Ask whether travel scenes need direct dramatization or compression.

---

# 82. INVESTIGATION-SCENE AUDIT

Compare:

- clue acquisition;
- interview;
- deduction;
- obstruction.

If investigation becomes procedural repetition, vary:

- source;
- cost;
- uncertainty;
- social context;
- consequences.

---

# 83. DREAM/VISION AUDIT

If dreams or visions recur:

### Do they repeatedly provide symbolism or foreshadowing?

### Are they too convenient for exposition?

### Do they have evolving function?

---

# 84. INFORMATION-WITHHOLDING AUDIT

Look for repeated artificial withholding.

Examples:

- POV refuses to think about information it knows;
- character says “I'll explain later” repeatedly;
- narrator avoids naming obvious fact.

Mystery should not rely on narrative cheating.

---

# 85. MISUNDERSTANDING AUDIT

Track relationship and plot misunderstandings.

Ask:

### Are they grounded in different information or values?

### Or do characters simply refuse obvious clarification?

Repeated preventable misunderstanding can feel artificial.

---

# 86. COINCIDENCE AUDIT

Coincidence can initiate story.

But repeated coincidence used to solve problems is riskier.

Track:

- accidental meetings;
- convenient discoveries;
- timely arrivals.

Ask whether causal mechanisms could replace some.

---

# 87. CHARACTER-ARRIVAL AUDIT

Does a new or returning character often arrive exactly when a scene needs:

- rescue;
- interruption;
- information?

This can become a structural habit.

---

# 88. LYRICISM-DENSITY AUDIT

Map where prose becomes highly lyrical.

If lyricism appears at every emotional climax, it may become predictable.

Sometimes plain language can make a major moment stronger.

---

# 89. DIRECTNESS-DENSITY AUDIT

The opposite can also occur.

If prose is uniformly restrained and indirect, important moments may lack contrast.

Pattern auditing should not privilege subtlety.

---

# 90. HUMOR-PATTERN AUDIT

Ask:

### Does humor always come from sarcasm?

### Does every character banter similarly?

### Do tense scenes always include quips?

Humor should reflect character and tone.

---

# 91. SWEARING-PATTERN AUDIT

If characters use profanity:

### Do all characters swear similarly?

### Is profanity concentrated only during dramatic emphasis?

### Does it fit culture and personality?

---

# 92. NARRATIVE-DISTANCE AUDIT

Check whether close POV suddenly becomes distant during difficult scenes, or vice versa.

Some variation is useful.

But repeated drift may indicate narrative instability.

---

# 93. EXPLANATION-DENSITY AUDIT

Map where prose explains:

- emotion;
- motivation;
- world rules;
- theme.

Ask whether some chapters carry much higher explanatory density than others.

This can reveal hidden exposition habits.

---

# 94. SIGNIFICANCE-SATURATION AUDIT

Ask:

### How often does prose imply that a detail is deeply meaningful?

If nearly every object, silence, gesture, or line carries emotional weight, significance becomes uniform.

Ordinary material provides contrast.

---

# 95. INTENSITY-LANGUAGE AUDIT

Track repeated intensifiers:

- utterly;
- completely;
- impossibly;
- somehow;
- unbearably;
- devastatingly;
- suddenly;
- completely still.

The words are not prohibited.

Look for reliance on intensity vocabulary instead of scene causality.

---

# 96. ABSOLUTE-LANGUAGE AUDIT

Watch recurring language such as:

- always;
- never;
- everything;
- nothing;
- everyone;
- no one.

In emotional POV, absolutes may be character-true.

But repeated use can make emotion melodramatically uniform.

---

# 97. “SOMETHING” AUDIT

Watch repeated vague formulations:

- something shifted;
- something broke;
- something in her chest;
- something unreadable;
- something ancient.

These can be effective.

Repeated vagueness may substitute for specificity.

---

# 98. SILENCE-PATTERN AUDIT

“Silence” itself may become a recurring prose crutch.

Ask:

### Are pauses described in the same way?

### Does every intense conversation become silent?

### Are different types of silence distinguished by context?

---

# 99. EYE-CONTACT AUDIT

Check recurring:

- eyes narrowing;
- gaze dropping;
- eyes meeting;
- looking away.

Eye behavior is normal.

It becomes noticeable when used as default emotional choreography.

---

# 100. BREATH AUDIT

Likewise:

- breath caught;
- exhaled;
- released breath;
- forgot to breathe;
- breath hitched.

Use according to actual physical/emotional relevance.

---

# 101. MICRO-EXPRESSION AUDIT

Look for continuous reporting of:

- tiny smiles;
- jaw changes;
- eye flickers;
- facial shifts.

If every line of dialogue includes emotional telemetry, conversation may feel overmanaged.

---

# 102. REACTION-SHOT AUDIT

Generated prose may repeatedly show every character's reaction after important lines.

Example:

speaker says something → everyone reacts.

Ask whether all reactions are necessary.

Sometimes narrative focus should remain narrow.

---

# 103. BEAT-DENSITY AUDIT

Dialogue beats can become formulaic if every line receives:

- gesture;
- movement;
- thought.

Allow stretches of uninterrupted speech when clear and appropriate.

---

# 104. NAME-USE AUDIT

Dialogue may overuse names for emotional intensity:

> “Mara, listen to me.”

> “I can't, Elias.”

Real conversation often uses names less frequently than fiction.

Use names deliberately.

---

# 105. REASSURANCE-PATTERN AUDIT

Look for repeated:

- “I'm here.”
- “You're not alone.”
- “We'll figure it out.”
- “You did what you had to do.”

These phrases can be valid.

Repeated emotional reassurance across relationships may homogenize them.

---

# 106. THEME-WORD AUDIT

If the novel centers on a theme such as:

- freedom;
- choice;
- trust;
- power;
- home,

track whether the literal word itself appears too frequently.

Theme can exist without naming itself.

---

# 107. CHARACTER-CATCHPHRASE AUDIT

Catchphrases can characterize.

But if repeated too precisely, characters may feel programmed.

Ask whether recurrence is:

- intentional;
- humorous;
- ritualized;
- or accidental.

---

# 108. RHYTHMIC-MOTIF AUDIT

Some syntactic repetition can be intentional.

Example:

a recurring sentence form associated with a character or ritual.

Do not “fix” purposeful rhythm simply because it repeats.

---

# 109. PATTERN-EVOLUTION TEST

For every repeated element, ask:

### First occurrence

What did it mean?

### Current occurrence

What does it mean now?

### Change

Has context altered it?

If yes, recurrence may be doing valuable narrative work.

---

# 110. PATTERN-CONCENTRATION TEST

A pattern may be fine globally but overconcentrated locally.

Example:

Five fragments across a chapter: fine.

Five fragments in one paragraph: conspicuous.

Assess:

- local concentration;
- global frequency.

---

# 111. PATTERN-DISTRIBUTION TEST

If the same habit appears across:

- narrator;
- every POV;
- every relationship;
- every chapter,

it is more likely to be system-level drift.

If confined to one character, it may be voice.

---

# 112. PATTERN-FUNCTION TEST

Before revising a repeated element, ask:

> What does this recurrence do?

Possible functions:

- rhythm;
- recognition;
- ritual;
- escalation;
- motif;
- voice;
- thematic echo;
- comedy.

If there is a clear function, preserve or refine.

---

# 113. PATTERN-COST TEST

Ask:

> What does this pattern cost?

Possible costs:

- predictability;
- monotony;
- reduced emphasis;
- voice homogenization;
- artificial intensity.

A useful pattern may still need reduced frequency.

---

# 114. ANTI-RANDOMNESS RULE

Do not fix repetition by randomly changing things.

Weak solution:

> We used a confrontation last chapter, so this chapter must contain action.

Better:

> Is another confrontation the natural consequence? If yes, make its purpose, structure, and outcome meaningfully different.

Variation should remain causal.

---

# 115. ANTI-THESAURUS RULE

Do not solve repetition only by synonym replacement.

If the prose repeatedly uses:

> stared

the deeper issue may be too much gaze-based emotional communication.

Replacing with:

> gazed, peered, watched

does not solve the pattern.

Revise the underlying behavior when necessary.

---

# 116. ANTI-SURFACE-FIX RULE

Similarly:

Repeated argument structure cannot be solved by changing wording.

Repeated scene function cannot be solved by changing location.

Repeated emotional payoff cannot be solved by changing metaphor.

Fix at the correct level.

---

# 117. PATTERN SEVERITY

Classify patterns:

## LOW

Visible but harmless.

## MODERATE

Beginning to create predictability.

## HIGH

Meaningfully affecting reader experience.

## STRUCTURAL

Pattern exists across plot, character, or scene architecture.

Address structural patterns before line-level ones.

---

# 118. PATTERN REPORT FORMAT

A useful audit output:

## Pattern

### Level

Prose / dialogue / character / scene / chapter / plot.

### Evidence

Where it recurs.

### Frequency

Low / moderate / high.

### Function

Intentional? Accidental?

### Effect

What it contributes or weakens.

### Recommendation

Preserve / reduce / vary / deepen / remove.

### Revision level

Sentence / scene / chapter / structural.

---

# 119. EXAMPLE PATTERN REPORT

## Pattern

Confrontations repeatedly end in mutual emotional understanding.

### Level

Relationship / scene.

### Evidence

Chapters 4, 7, 10, 12.

### Frequency

High.

### Function

Allows relationship progression.

### Effect

Conversations increasingly feel therapeutic and reduce unresolved friction.

### Recommendation

Preserve some successful resolutions, but allow later conflicts to produce:

- partial understanding;
- continued disagreement;
- changed strategy rather than emotional closure.

### Revision level

Scene/relationship.

This is more useful than:

> Avoid emotional dialogue.

---

# 120. PRIORITIZATION RULE

Do not revise every detected pattern.

Prioritize patterns that:

1. damage character individuality;
2. weaken causality;
3. make scenes structurally predictable;
4. flatten emotional range;
5. homogenize POV;
6. reduce artistic identity;
7. create obvious prose tic.

Surface tics come later.

---

# 121. MULTI-PASS METHOD

A full Pattern Audit may use separate passes.

## Pass 1 — Prose

Sentence, paragraph, metaphor, emphasis.

## Pass 2 — Dialogue

Voice, rhythm, exposition, conflict.

## Pass 3 — Emotion

Channels, progression, closure.

## Pass 4 — Scene

Purpose, structure, entry/exit.

## Pass 5 — Character/relationship

Reactions, arcs, validation.

## Pass 6 — Plot

Solutions, revelations, escalation.

This prevents one category from overwhelming attention.

---

# 122. COMPARISON WINDOWS

Use different windows.

## Local window

1–2 chapters.

Detect dense repetition.

## Medium window

5–10 chapters.

Detect scene and dialogue patterns.

## Global window

Entire manuscript.

Detect structural habits and homogenization.

---

# 123. PATTERN AUDIT FOR SERIAL FICTION

For long web fiction, also track:

### recurring chapter formula;

### repeated cliffhangers;

### repeated progression milestones;

### repeated enemy introductions;

### forgotten older motifs;

### looped relationship conflict;

### endless escalation;

### protagonist validation.

Periodically ask:

> What is meaningfully different from fifty chapters ago?

---

# 124. PATTERN AUDIT AFTER REVISION

After major revision, rerun selectively.

A revision intended to fix repetition can create new uniformity.

Example:

Removing all direct emotion may create excessive subtlety.

Rebalancing is better than replacing one rigid pattern with another.

---

# 125. DO NOT TREAT FREQUENCY AS GUILT

High frequency is a warning.

Not a verdict.

A highly repetitive structure may be intentional:

- fairy tale;
- ritual narrative;
- comedy;
- experimental fiction;
- episodic serial;
- liturgy-like prose.

Function decides.

---

# 126. DO NOT REMOVE CHARACTER HABITS

Characters naturally repeat:

- phrases;
- gestures;
- coping behavior;
- routines.

This can strengthen identity.

The key question:

> Does the repetition feel like the character, or like the generator?

---

# 127. DO NOT REMOVE MOTIFS

A motif requires repetition.

Instead evaluate:

- evolution;
- placement;
- association;
- saturation.

---

# 128. DO NOT FORCE EVERY SCENE TO BE UNIQUE

Narrative coherence requires recurrence.

Readers need familiar:

- characters;
- conflicts;
- settings;
- structures.

The goal is not endless novelty.

The goal is meaningful recurrence with development.

---

# 129. COMPACT PATTERN AUDIT

For routine use:

### What prose structures are repeating?

### What gestures are repeating?

### What emotional sequences are repeating?

### What dialogue dynamics are repeating?

### What scene functions are repeating?

### What chapter endings are repeating?

### What plot solutions are repeating?

### What relationship outcomes are repeating?

### What appears across multiple POVs that should be character-specific?

### Which repetitions are intentional?

### Which are evolving?

### Which are static?

### Which materially weaken the reading experience?

Then revise only the meaningful patterns.

---

# 130. CENTRAL REMINDER

The purpose of this audit is not:

> Never repeat yourself.

Strong fiction repeats constantly.

It repeats:

- images;
- questions;
- conflicts;
- habits;
- structures;
- fears;
- places;
- relationships.

But strong repetition usually accumulates.

The second occurrence is not identical to the first because the story now has more history.

Therefore the central question is:

> Has the recurrence gained history?

If yes, repetition may create meaning.

If not, the story may be looping.

The deepest anti-repetition principle is:

**Do not merely change the surface. Change the state.**

A different metaphor cannot repair a repeated emotional arc.

A different room cannot repair a repeated scene function.

Different dialogue cannot repair a relationship that never evolves.

Different enemies cannot repair the same plot structure.

When repetition becomes a problem, revise at the level where the repetition actually exists.

That completes the **Anti-Repetition & Pattern Audit**.

The next stage is the **Long-Range Narrative Audit**. That one moves beyond repetition and asks whether the novel as a whole is genuinely accumulating: character arcs, subplots, causal chains, tension, world consequences, setups/payoffs, middle-book drift, and whether later chapters truly inherit earlier ones.

**Remaining system-building stages:**
1. **Long-Range Narrative Audit**
2. **Artistic-Identity / Anti-Homogenization Pass**
3. **Compact Project Instructions — final deployable version**
4. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Long-Range Narrative Audit**. This is the system that checks whether the novel is actually accumulating across tens or hundreds of pages rather than merely producing individually competent chapters.

Suggested filename: **`10-long-range-narrative-audit.md`**

# LONG-RANGE NARRATIVE AUDIT

## Purpose

The Long-Range Narrative Audit evaluates whether the novel still works as a cumulative whole.

The Post-Draft Audit checks individual scenes and chapters.

The Anti-Repetition / Pattern Audit checks recurring habits.

The Long-Range Narrative Audit asks a larger question:

> Is the story becoming more itself as it progresses, or merely becoming longer?

Its purpose is to detect:

- forgotten consequences;
- stalled character arcs;
- subplot abandonment;
- relationship resets;
- setup/payoff failure;
- escalation inflation;
- middle-book drift;
- weak causal inheritance;
- world-state stagnation;
- continuity erosion;
- thematic simplification;
- accumulated convenience;
- and narrative expansion without meaningful transformation.

The central principle is:

> A long novel should not merely contain more events.

It should contain more **history**.

---

# 1. WHEN TO RUN THIS AUDIT

Use periodically rather than continuously.

Recommended moments:

- after a major arc;
- around 20–25% of the manuscript;
- around midpoint;
- around 75%;
- before writing the ending;
- after completing a full draft;
- after major restructuring.

For very long serial fiction, run it periodically by chapter interval.

---

# 2. AUDIT SCALE

Use three possible scopes.

## ARC AUDIT

Reviews one completed arc.

Best for checking:

- arc movement;
- character changes;
- subplot progress;
- payoff;
- consequences.

---

## MID-NOVEL AUDIT

Reviews everything written so far.

Best for detecting:

- stagnation;
- abandoned material;
- escalation problems;
- character reset;
- structural drift.

---

## FULL-MANUSCRIPT AUDIT

Reviews the whole book.

Best for:

- causal integrity;
- setup/payoff;
- ending inheritance;
- thematic evolution;
- arc completion;
- artistic coherence.

---

# 3. REQUIRED INPUTS

Retrieve broadly.

Useful materials include:

- chapter summaries;
- current state ledgers;
- character arc records;
- relationship state histories;
- plot architecture;
- subplot index;
- setup/payoff ledger;
- open consequences;
- timeline;
- world-state changes;
- chapter pacing roles;
- pattern-audit findings;
- Story Bible;
- artistic identity profile.

Full prose may be retrieved selectively when summaries are insufficient.

---

# 4. FIRST QUESTION — WHAT IS DIFFERENT NOW?

Compare the current story to its opening state.

Ask:

### What has permanently changed?

In:

- characters;
- relationships;
- knowledge;
- resources;
- world state;
- institutions;
- goals;
- power;
- geography;
- reputation;
- beliefs;
- danger;
- thematic context.

If many chapters have passed but little is durably different, the story may be moving without progressing.

---

# 5. OPENING-STATE COMPARISON

Create a simple comparison.

## At opening

What was true?

## Now

What is true?

## Difference

What changed?

## Cause

What events produced the change?

## Persistence

Is the change durable?

This gives an immediate picture of accumulation.

---

# 6. CAUSAL-INHERITANCE AUDIT

Ask:

> How much of the current story exists because of earlier choices?

Trace major current conditions backward.

For each:

### Current condition

### Caused by

### Which character choice mattered?

### What earlier event enabled it?

### What consequence followed?

### What new possibility did it create?

Strong long-form narrative tends to become increasingly dependent on its own past.

---

# 7. THEN-VS-BECAUSE TEST

Review major plot transitions.

Weak chain:

> This happened. 
> Then this happened. 
> Then another problem appeared.

Stronger chain:

> This happened, therefore a character chose X. 
> That choice caused Y. 
> Y created a new constraint. 
> The constraint made Z possible.

Not every event requires direct causality.

But the novel should not depend primarily on serial addition.

---

# 8. CHOICE-CONSEQUENCE AUDIT

List major character decisions.

For each:

### Decision

### Immediate consequence

### Delayed consequence

### Relationship effect

### World effect

### Future options opened

### Future options closed

### Is the decision still affecting story?

If important decisions leave little residue, agency may feel cosmetic.

---

# 9. IRREVERSIBILITY AUDIT

Ask:

### What has happened that cannot simply be undone?

Examples:

- death;
- betrayal;
- public exposure;
- lost reputation;
- political action;
- destroyed place;
- revealed secret;
- moral compromise;
- relationship change.

A long story benefits from some irreversible accumulation.

This does not mean every event must be permanent.

---

# 10. RESET DETECTION

Look for story systems that repeatedly return to baseline.

Examples:

### Character reset

Same fears and behavior after supposed growth.

### Relationship reset

Same conflict repeated from zero.

### World reset

Large events leave no lasting effect.

### Resource reset

Scarcity disappears.

### Plot reset

Each arc introduces a new problem while previous consequences vanish.

Identify whether reset is intentional or accidental.

---

# 11. CHARACTER-ARC AUDIT

For each major character, compare:

### Opening baseline

### Current state

### Pressures experienced

### Decisions made

### Failures

### Adaptations

### Beliefs challenged

### Relationships changed

### Competence changed

### Costs paid

### What remains unresolved

Ask:

> Has this person actually lived through the novel?

---

# 12. CHARACTER-CHANGE QUALITY

Classify development:

## Reinforcement

Existing trait strengthened.

## Adaptation

Character changed strategy.

## Growth

Behavior or worldview meaningfully changed.

## Deterioration

Character became worse or more destructive.

## Integration

New behavior became stable.

## Stasis

Character remained mostly unchanged.

All can be valid.

The problem is accidental drift or fake development.

---

# 13. FALSE-GROWTH AUDIT

Watch for development that exists mainly in dialogue.

Example:

Character says:

> I need to stop pushing people away.

But later behavior remains unchanged.

Ask:

### What behavior changed?

### What choices changed?

### What relationships changed?

Insight alone is not necessarily development.

---

# 14. CHARACTER-REPLACEMENT AUDIT

Ask:

### Does the current character still resemble their opening self?

Growth should usually preserve recognizable continuity.

Watch for:

- suddenly different temperament;
- complete loss of earlier fears;
- major voice change;
- competence inflation;
- moral transformation without residue.

If the old self has vanished, check whether transformation was sufficiently earned.

---

# 15. STATIC-CHARACTER AUDIT

Some characters should remain relatively stable.

Ask:

### Does their stability still generate meaningful consequences?

A static character can be powerful if the world changes around them or their unchanged values are repeatedly tested.

Stasis is not failure by itself.

---

# 16. SUPPORTING-CHARACTER AUDIT

For important supporting characters:

### Do they still have independent goals?

### Have their lives evolved?

### Do they appear only when protagonist needs them?

### Have their own relationships changed?

### Have consequences reached them?

Supporting characters need not receive protagonist-level development.

But recurring important characters should not remain frozen utilities.

---

# 17. CHARACTER-DISTRIBUTION AUDIT

Ask:

### Which characters dominate attention?

### Which have disappeared?

### Which were strongly introduced but underused?

### Which have gained importance organically?

### Which seem retained only because they were planned earlier?

Rebalance where necessary.

---

# 18. RELATIONSHIP-ARC AUDIT

For major relationships, compare:

### Opening relationship

### Current relationship

### Major milestones

### Trust changes

### Intimacy changes

### Power changes

### Misunderstandings

### Betrayals

### Obligations

### Current unresolved friction

Ask:

> Does the current relationship contain its history?

---

# 19. RELATIONSHIP-LOOP AUDIT

Identify recurring conflict.

For each:

### Original issue

### First confrontation

### Later confrontation

### What changed?

If each iteration produces the same:

- positions;
- tactics;
- outcome,

the relationship may be looping.

Repeated conflict should usually gain history.

---

# 20. RELATIONSHIP-OVERRESOLUTION AUDIT

The opposite risk:

### Are conflicts resolving too efficiently?

### Does emotional honesty repeatedly repair relationships?

### Does understanding lead automatically to forgiveness?

### Do difficult relationships become progressively healthier by default?

Some relationships should remain difficult, asymmetric, compromised, or unresolved.

---

# 21. SOCIAL-WORLD AUDIT

Ask whether the world still revolves too heavily around the protagonist.

Check:

### Do side characters interact with one another?

### Do institutions pursue their own priorities?

### Do other people's schedules and obligations matter?

### Does news spread beyond protagonist-controlled scenes?

### Are unrelated events occurring?

A social world should feel connected rather than summoned.

---

# 22. PLOT-ARC AUDIT

For each major arc:

### Entry state

### Central problem

### Character decisions

### Escalation

### Major consequences

### Resolution or transformation

### Exit state

### Connection to next arc

Ask whether arcs transform the novel or merely replace one problem with another.

---

# 23. ARC-INHERITANCE AUDIT

A later arc should often inherit earlier material.

Ask:

### Which consequences from the previous arc remain?

### Which characters carry changed goals?

### Which relationships are different?

### Which resources were lost or gained?

### Which institutional conditions changed?

### Which setups remain active?

If each arc feels like a soft reboot, long-form accumulation weakens.

---

# 24. SUBPLOT AUDIT

For each significant subplot:

### Original goal

### Participants

### Stakes

### Progress

### Current status

### Interaction with main plot

### Interaction with other subplots

### Consequences

### Resolution plan

Ask:

> Does this subplot have its own causal life?

---

# 25. SUBPLOT-ABANDONMENT AUDIT

Identify:

### Dormant intentionally

Fine.

### Forgotten accidentally

Repair.

### Resolved offscreen

Check whether this is appropriate.

### No longer useful

Consider removing or compressing earlier setup.

---

# 26. SUBPLOT-ISOLATION AUDIT

Ask:

### Does the subplot ever affect the main plot?

### Does the main plot affect the subplot?

### Do characters carry subplot consequences into other scenes?

A subplot can remain independent, but complete isolation may make the novel feel modular.

---

# 27. SUBPLOT-CONVERGENCE AUDIT

Near later stages, consider whether threads:

- collide;
- interfere;
- reinforce;
- contradict.

Do not force every subplot into one climax.

Some can resolve independently.

---

# 28. OPEN-THREAD AUDIT

List active unresolved elements:

- promises;
- mysteries;
- goals;
- debts;
- threats;
- relationship problems;
- institutional pressures;
- objects;
- prophecies;
- secrets.

For each:

### Still active?

### Dormant intentionally?

### Forgotten?

### Resolved?

### No longer relevant?

Clean the narrative memory.

---

# 29. SETUP/PAYOFF AUDIT

Review the setup/payoff ledger.

Classify each setup:

## Paid

Resolved adequately.

## Active

Still developing.

## Transformed

Meaning changed.

## Deliberately unresolved

Intentional.

## Forgotten

Needs attention.

## Overemphasized

Created too much expectation.

## Underprepared

Payoff lacks setup.

---

# 30. PAYOFF-PROPORTIONALITY AUDIT

Ask:

### Did high-emphasis setups receive sufficient payoff?

### Did minor setups receive excessive payoff?

### Did the payoff address what readers were actually taught to expect?

### Did it produce consequence?

A factual answer alone may not satisfy emotional or structural investment.

---

# 31. SETUP-INFLATION AUDIT

Check whether too many active setups exist.

Symptoms:

- constant ominous details;
- numerous mysteries;
- many prophecies;
- repeated hidden identities;
- unresolved promises.

Too many obligations can dilute attention.

---

# 32. REVELATION-SEQUENCE AUDIT

Map major revelations.

Ask:

### Do they build on one another?

### Do later revelations reinterpret earlier understanding?

### Are they merely additional facts?

Strong revelations often change the meaning of known material rather than only expanding information.

---

# 33. MYSTERY-ARCHITECTURE AUDIT

For mysteries:

### Is the truth stable?

### Does evidence support it?

### Are false interpretations plausible?

### Are clues distributed fairly for intended genre?

### Does the solution rely on late invention?

### Has the mystery remained causally active?

---

# 34. KNOWLEDGE-DISTRIBUTION AUDIT

Across the cast:

### Who knows what?

### Who should have learned something by now?

### Who knows too much?

### Which secrets have become implausible to maintain?

### Did information spread at believable speed?

This becomes increasingly important as the cast expands.

---

# 35. SECRET-LONGEVITY AUDIT

For each major secret:

### How long has it survived?

### How many people know?

### What evidence exists?

### How much contact occurs among holders and targets?

### Is continued secrecy still plausible?

Secrets should not survive indefinitely merely because the plot requires them.

---

# 36. CONTINUITY-DRIFT AUDIT

Check long-range consistency across:

- timeline;
- ages;
- geography;
- injuries;
- object states;
- powers;
- institutions;
- history;
- terminology.

Long stories accumulate small contradiction risk.

---

# 37. CANON-EXPANSION AUDIT

As new lore is added, ask:

### Does it fit earlier canon?

### Does it retroactively solve older problems?

### Does it create contradictions?

### Does it make earlier character behavior irrational?

New worldbuilding should not destabilize previous stakes accidentally.

---

# 38. WORLD-RULE AUDIT

For important systems:

### Have costs remained consistent?

### Have limits weakened?

### Have exceptions multiplied?

### Do characters exploit obvious known rules?

### Have institutions adapted logically to the system?

A rule that exists only when plot needs it is not functioning as a world rule.

---

# 39. WORLD-CONSEQUENCE AUDIT

Review major events.

For each:

### Physical effect

### Social effect

### Political effect

### Economic effect

### Institutional effect

### Cultural effect

### Strategic effect

Ask which consequences should still exist.

Not every layer needs representation.

---

# 40. WORLD-STATE TRANSFORMATION AUDIT

Compare opening world state to current world state.

Ask:

### What has changed outside the protagonists?

### Have institutions shifted?

### Have places changed?

### Have public beliefs changed?

### Have resources changed?

### Have laws changed?

Large events should sometimes alter the larger environment.

---

# 41. INSTITUTIONAL-MEMORY AUDIT

Institutions should remember events too.

Ask:

### Have authorities responded to past crimes?

### Have organizations changed policy?

### Have factions adapted strategy?

### Have enemies learned from failure?

### Have allies changed expectations?

Institutional reset can make the world feel passive.

---

# 42. ANTAGONIST-ADAPTATION AUDIT

For active antagonistic forces:

### Have they learned anything?

### Have they changed tactics?

### Are they reacting to protagonist actions?

### Do they have independent developments?

A static antagonist can make later conflict feel artificially staged.

---

# 43. RESOURCE-STATE AUDIT

Review important resources:

- money;
- troops;
- fuel;
- food;
- magic;
- political capital;
- favors;
- equipment.

Ask:

### Have costs accumulated?

### Have resources replenished plausibly?

### Are scarcity rules still meaningful?

---

# 44. PHYSICAL-CONSEQUENCE AUDIT

Review:

- injuries;
- scars;
- disability;
- fatigue;
- environmental harm.

Ask:

### Did serious harm leave residue?

### Did repeated action accumulate physical cost?

### Are bodies unrealistically refreshed between arcs?

---

# 45. COMPETENCE-ARC AUDIT

For characters gaining skill:

### What could they do at opening?

### What can they do now?

### How was improvement earned?

### What still exceeds them?

### Has competence expanded into unrelated domains?

Avoid universal competence inflation.

---

# 46. POWER-PROGRESSION AUDIT

For progression-heavy stories:

### What new ability was gained?

### What new options did it create?

### What old obstacles became trivial?

### Has the story adapted?

### What new constraints emerged?

Power growth should change problem structure.

If stronger characters keep facing structurally identical challenges, progression may feel cosmetic.

---

# 47. ESCALATION AUDIT

Map escalation across arcs.

Possible axes:

- physical;
- emotional;
- relational;
- moral;
- political;
- informational;
- social;
- strategic;
- temporal;
- irreversible.

Ask:

### Are stakes deepening?

Or merely getting larger?

---

# 48. ESCALATION-INFLATION AUDIT

Symptoms:

- constantly stronger enemies;
- world-ending stakes too early;
- repeated power upgrades;
- ever-larger battles;
- threats replacing threats.

Ask whether escalation can instead deepen cost and consequence.

---

# 49. STAKES-SPECIFICITY AUDIT

Avoid relying only on:

> If we fail, everyone dies.

Ask:

### What specifically does this character stand to lose?

- person;
- identity;
- reputation;
- home;
- principle;
- future;
- relationship.

Specific stakes often matter more than scale.

---

# 50. TENSION-ARCHITECTURE AUDIT

Map the novel's tension over time.

Ask:

### Where does tension rise?

### Where does it hold?

### Where does it release?

### Where does its type change?

Constant escalation can flatten experience.

---

# 51. RECOVERY-SPACE AUDIT

Ask:

### Has the novel allowed consequences to settle?

### Have characters had enough space to process?

### Has the reader experienced ordinary life?

### Are quiet scenes meaningful?

Recovery should not become filler.

But without contrast, intensity may lose force.

---

# 52. PACING-DISTRIBUTION AUDIT

Compare narrative space.

Ask:

### Which events receive many pages?

### Which receive little?

### Does space correspond to actual importance?

### Are transitions overexpanded?

### Are major consequences compressed?

Narrative space communicates value.

---

# 53. MIDDLE-BOOK AUDIT

The middle often reveals systemic problems.

Check:

### Has the central question become blurry?

### Are characters repeating established behavior?

### Are new subplots replacing development?

### Are earlier setups dormant?

### Is escalation substituting for causality?

### Are chapters functioning episodically rather than cumulatively?

### Has artistic identity weakened?

This is a high-priority audit point.

---

# 54. MIDDLE-BOOK ACCUMULATION TEST

Ask:

> If the first third vanished, would the middle still mostly work?

If yes, too little may have been inherited.

Later story should often depend heavily on earlier history.

---

# 55. “FIFTY CHAPTERS AGO” TEST

For serial fiction:

> What is permanently different from fifty chapters ago?

Look across:

- protagonist;
- cast;
- relationships;
- world;
- goals;
- resources;
- institutions;
- theme.

If answer is minimal, investigate looping.

---

# 56. NARRATIVE-PROMISE AUDIT

Compare story opening with current direction.

Ask:

### What did the opening promise?

### Does the novel still deliver that experience?

### Has genre changed?

### Has protagonist focus shifted?

### Has a secondary element swallowed the central story?

Stories may evolve.

But major promise changes should be intentional.

---

# 57. PREMISE-FIDELITY AUDIT

Ask:

> Is the novel still exploiting its own premise?

A distinctive premise can gradually become generic.

Check whether the story still uses the conditions that made it interesting initially.

---

# 58. GENRE-CONTRACT AUDIT

For the primary genre:

### Are essential expectations developing?

### Are promised pleasures being delayed too long?

### Has the book become another genre unintentionally?

### Are deviations still providing replacement value?

---

# 59. GENRE-DEFAULT AUDIT

Ask where the story has adopted conventional developments.

For each:

### Does this arise from character and world?

Or:

### Did the story fall into the statistically familiar route?

Familiarity is not itself a problem.

Generic causality is.

---

# 60. THEMATIC-EVOLUTION AUDIT

Compare thematic questions across the novel.

Ask:

### Has the story complicated them?

### Have events tested different answers?

### Have character positions changed?

### Has one answer become artificially dominant?

### Are themes being repeated instead of developed?

---

# 61. THEME-BY-CONSEQUENCE AUDIT

Identify major thematic claims implied by outcomes.

Example:

If every ambitious character is punished, the novel may imply something about ambition regardless of dialogue.

Ask:

> What does the causal structure imply?

This may reveal unintended thematic messaging.

---

# 62. MORAL-TIDINESS AUDIT

Ask:

### Do virtuous choices reliably succeed?

### Do immoral choices reliably fail?

### Do sympathetic characters increasingly become correct?

### Do antagonistic characters become obviously wrong?

Some fiction intentionally uses strong moral structure.

The audit simply ensures it is intentional.

---

# 63. MOTIF-EVOLUTION AUDIT

For recurring motifs:

### First meaning

### Current meaning

### Transformations

### Character associations

### Final potential

Static repetition may need evolution.

---

# 64. SYMBOLIC-SATURATION AUDIT

Ask:

### Has too much become symbolic?

### Does every setting reflect character psychology?

### Does every recurring object demand interpretation?

Allow ordinary material to remain ordinary.

---

# 65. FORESHADOWING AUDIT

Review future-oriented clues.

Ask:

### Are they too obvious?

### Too frequent?

### Too vague to matter?

### Do they read naturally before payoff?

Strong foreshadowing often acquires significance retrospectively.

---

# 66. RETROSPECTIVE-COHERENCE AUDIT

After major reveals, revisit earlier material.

Ask:

### Does the reveal make earlier scenes richer?

### Does it make them impossible?

### Would characters have behaved differently if the reveal were true?

Good revelations should survive backward scrutiny.

---

# 67. COINCIDENCE-ACCUMULATION AUDIT

One coincidence may be invisible.

Many create structural weakness.

List major:

- accidental meetings;
- timely rescues;
- lucky discoveries;
- enemy mistakes.

Ask how many solve problems versus create them.

Coincidence is generally safer for creating trouble than resolving it.

---

# 68. CONVENIENCE-DEBT AUDIT

When the story uses a convenience, consider whether later consequence can convert it into story.

Example:

An ally arrives unexpectedly and saves protagonist.

Could this create:

- debt;
- suspicion;
- obligation;
- new dependency?

Not every convenience needs retroactive justification.

But repeated convenience without cost weakens trust.

---

# 69. OBVIOUS-ALTERNATIVE AUDIT

Across major problems, ask:

### What obvious options existed?

### Were they considered?

### Why rejected?

Repeated failure to acknowledge obvious tools, powers, institutions, or allies can make conflict feel artificial.

---

# 70. FRICTION-SOURCE AUDIT

Classify what keeps problems alive.

Healthy sources include:

- incompatible goals;
- real scarcity;
- institutional incentives;
- incomplete information;
- values;
- cost;
- physical constraint.

Weak repeated sources may include:

- characters refusing simple communication;
- forgetting available powers;
- arbitrary delay.

---

# 71. INFORMATION-DENSITY AUDIT

Across the novel:

### Are early chapters overloaded?

### Is middle thin?

### Are revelations concentrated near ending?

### Does exposition arrive only when immediately necessary?

Balance according to genre.

---

# 72. WORLD-BUILDING ACCUMULATION AUDIT

Ask:

### Has setting become more specific?

### Do later details build on earlier ones?

### Or does every chapter invent unrelated lore?

A coherent world deepens through connection.

---

# 73. LORE-RELEVANCE AUDIT

For major worldbuilding:

### Did it affect plot?

### Character?

### Culture?

### Institution?

### Theme?

Not every lore detail needs payoff.

But large exposition should justify narrative space.

---

# 74. SPATIAL-SCALE AUDIT

As the story expands geographically:

### Are travel times coherent?

### Does scale remain believable?

### Are old places forgotten?

### Do regions feel functionally different?

### Do consequences travel across distance plausibly?

---

# 75. TEMPORAL-SCALE AUDIT

Check:

### How much time has passed overall?

### Are relationship changes plausible within it?

### Skill growth?

### Recovery?

### Political change?

### Institutional response?

Long novels can accidentally imply too little or too much time.

---

# 76. REPUTATION-ACCUMULATION AUDIT

For visible characters:

### What has the public seen?

### What stories circulate?

### Which groups view them differently?

### Has reputation affected opportunity?

Public actions should sometimes accumulate social identity.

---

# 77. FAILURE-MEMORY AUDIT

Ask:

### Do characters learn from previous failed strategies?

### Do enemies learn?

### Do institutions learn?

Repeating the same mistake may be character-true.

But the repetition should contain history.

---

# 78. SUCCESS-MEMORY AUDIT

Likewise:

### Does a successful strategy become known?

### Does opposition adapt?

### Does protagonist over-rely on it?

Repeated identical success can weaken tension.

---

# 79. QUESTION-REPLACEMENT AUDIT

Long stories often remain engaging because one answered question generates another.

Ask:

### Which major question was answered?

### What new question now matters?

If answers only close threads without creating transformed pressure, narrative energy may drop.

---

# 80. ENDGAME-PREPARATION AUDIT

Before final act, ask:

### Which conflicts require resolution?

### Which relationships need final movement?

### Which setups remain open?

### Which thematic tensions remain active?

### Which resources and consequences should matter in climax?

### Which elements can intentionally remain unresolved?

Do not introduce major final-act machinery without preparation unless surprise itself is the design.

---

# 81. ENDING-INHERITANCE AUDIT

The ending should inherit the entire novel.

Ask:

### Which earlier decisions shape final options?

### Which relationships matter?

### Which losses matter?

### Which skills matter?

### Which promises matter?

### Which world rules matter?

### Which themes are embodied?

The ending should not feel detachable from the preceding book.

---

# 82. CLIMAX-SPECIFICITY AUDIT

Ask:

> Could this climax belong to another story?

If the final conflict is merely:

- biggest battle;
- villain confrontation;
- final confession,

without specific accumulated history, strengthen inheritance.

---

# 83. CLIMAX-AGENCY AUDIT

Ask:

### Does protagonist's final action emerge from development?

### Does it use what they learned?

### Does it cost something specific?

### Could someone else perform the same action with little change?

Strong climaxes are often character-specific.

---

# 84. RESOLUTION AUDIT

After climax:

### What changed materially?

### What changed emotionally?

### What changed relationally?

### What changed socially?

### What remains damaged?

### What remains uncertain?

Avoid resetting world to comfortable baseline unless that is genuinely the intended ending.

---

# 85. OVERCLOSURE AUDIT

Ask:

### Are all relationships resolved?

### All mysteries answered?

### All futures explained?

### All themes summarized?

### Every secondary character given an epilogue?

Complete closure can work.

But ensure it is desired rather than an automatic drive toward neatness.

---

# 86. UNDERCLOSURE AUDIT

The opposite:

### Did strongly emphasized threads disappear?

### Did central genre promises remain unpaid?

### Did key relationships receive no final movement?

### Did the ending stop rather than conclude?

Ambiguity should feel chosen.

---

# 87. ENDING-THEMATIC AUDIT

Ask:

### Does ending embody the novel's thematic tensions?

### Does it announce a lesson unnecessarily?

### Does it flatten ambiguity created earlier?

### Does final outcome contradict the work's prior complexity?

---

# 88. CHAPTER-IMPORTANCE DISTRIBUTION AUDIT

Ask:

### Which chapters would matter if removed?

If many chapters could disappear without affecting later material, investigate narrative redundancy.

Some chapters may matter primarily for:

- atmosphere;
- relationship;
- reader experience.

That still counts.

---

# 89. SCENE-DEPENDENCY AUDIT

For selected scenes:

> What later material depends on this scene?

Possible answers:

- character development;
- knowledge;
- relationship;
- setup;
- world state;
- emotional memory.

If nothing depends on it, determine whether experiential value alone justifies it.

---

# 90. NARRATIVE-ECONOMY AUDIT

Look for:

### Duplicate functions

### Excess setup

### Repeated transition

### Repeated explanation

### Forgotten material

The goal is not maximal compression.

It is meaningful allocation.

---

# 91. STORY-ENERGY AUDIT

Ask where curiosity comes from now.

Possible sources:

- goal;
- mystery;
- relationship;
- danger;
- world discovery;
- transformation.

Compare to opening.

If all original energy sources have faded, identify what has replaced them.

---

# 92. PROTAGONIST-MOTIVATION AUDIT

Ask:

### What does protagonist want now?

### How is that different from opening?

### Why do they continue?

### Is motivation still personal and specific?

Long stories sometimes preserve plot after protagonist motivation has weakened.

---

# 93. ANTAGONISTIC-PRESSURE AUDIT

Ask:

### What currently opposes protagonist?

### Has opposition evolved?

### Does antagonist still want something independently?

### Has conflict become generic because original antagonism resolved?

---

# 94. PROTAGONIST-CENTRALITY AUDIT

Ask:

### Does everything important happen because of or around protagonist?

### Do institutions and side characters have independent events?

### Do other characters sometimes solve their own problems?

A protagonist should remain central without becoming cosmically central.

---

# 95. SUPPORTING-CAST MEMORY AUDIT

Check old supporting characters.

### Should any reasonably reappear?

### Should their previous interactions affect current events?

### Has the story forgotten them despite relevance?

Do not bring everyone back merely for continuity fan service.

---

# 96. OFFSCREEN-LIFE AUDIT

Ask whether important characters appear to continue living between appearances.

Evidence may include:

- changed priorities;
- new information;
- obligations;
- relationships;
- consequences.

This creates independent existence.

---

# 97. PERSPECTIVE-BALANCE AUDIT

For multi-POV stories:

### Does each POV still justify itself?

### Are some carrying most plot?

### Are some only reacting?

### Are POVs becoming narratively interchangeable?

### Does information distribution remain purposeful?

---

# 98. POV-KNOWLEDGE-ADVANTAGE AUDIT

Ask whether any POV is repeatedly chosen merely to expose information conveniently.

POV choice should ideally provide experiential and narrative value beyond exposition.

---

# 99. POV-HOMOGENIZATION AUDIT

Compare:

- attention;
- metaphor;
- reasoning;
- emotional articulation;
- sentence movement.

Do different POVs still feel mentally distinct?

---

# 100. CHRONOLOGY-COMPLEXITY AUDIT

If nonlinear:

### Is ordering still serving meaning?

### Are timeline switches clear enough?

### Is suspense being created fairly?

### Does chronology reveal or obscure intentionally?

Complex structure should have function.

---

# 101. FLASHBACK-NECESSITY AUDIT

For major flashbacks:

### Did they change present understanding?

### Could summary have done the job?

### Are flashbacks creating a second story that competes with present action?

---

# 102. STRUCTURAL-ASYMMETRY AUDIT

Ask whether structure has become too neat.

Examples:

- every arc same length;
- every character gets matching climax;
- every subplot resolves symmetrically.

Asymmetry can make narrative feel organic.

Do not destroy deliberate formal symmetry when it is part of design.

---

# 103. STRUCTURAL-CHAOS AUDIT

The opposite:

### Are arcs of wildly different importance receiving equal space?

### Are major threads disappearing randomly?

### Does structure lack hierarchy?

Freedom still requires selection.

---

# 104. AUTHORIAL-PRIORITY AUDIT

Return to the novel's stated priorities.

Ask:

### Is the novel still spending attention on what the author cares about?

If the project priority was friendship but romance now dominates, determine whether that shift is intentional.

---

# 105. AUTHOR-NONPRIORITY AUDIT

Check whether the system has overdeveloped things the author did not care about.

Examples:

- extensive military logistics;
- magic-system detail;
- romance;
- political simulation.

AI generation can expand whatever has textual momentum.

The Story Bible should preserve priority.

---

# 106. GENRE-DRIFT AUDIT

Ask whether the novel's dominant experience has changed.

Example:

political fantasy → combat adventure.

Romance → mystery.

Horror → action.

Genre evolution is allowed.

Accidental drift should be detected.

---

# 107. TONE-DRIFT AUDIT

Compare early and current tone.

Has the book become:

- more comedic;
- more cynical;
- more sentimental;
- more violent;
- more lyrical?

If yes:

### Is this development earned?

### Does it correspond to story movement?

Or is style drifting?

---

# 108. WORLD-TONE CONSISTENCY

Even if plot escalates, ask whether the world still feels like the same world.

A story may become darker while preserving its original social, aesthetic, and moral texture.

---

# 109. CONFLICT-DIVERSITY AUDIT

Map dominant conflicts.

If almost every problem becomes:

- argument;
- combat;
- mystery clue;

consider whether the novel is underusing its own systems.

Variation should emerge from premise.

---

# 110. DECISION-DENSITY AUDIT

Ask:

### How many major events are character decisions versus external events?

If plot is mostly happening **to** characters, agency may weaken.

External events are still valid.

The question is whether characters meaningfully shape trajectory.

---

# 111. REACTION-DENSITY AUDIT

Long AI-generated stories can become chains of:

event → reaction → explanation.

Ask:

### Are characters spending too much narrative space processing instead of deciding?

Or the opposite:

### Are major events receiving too little processing?

Balance depends on work.

---

# 112. CONSEQUENCE-DELAY AUDIT

Some consequences should arrive later.

Ask:

### Are all consequences immediate?

Delayed consequences create a sense of persistent reality.

Examples:

- reputation changes;
- institutional response;
- legal action;
- emotional fallout.

---

# 113. CONSEQUENCE-DISAPPEARANCE AUDIT

Compare open-consequence ledger with current narrative.

Anything forgotten?

Resolve, reactivate, or explicitly retire.

---

# 114. CONSEQUENCE-COLLISION AUDIT

Strong long-form storytelling often lets consequences interact.

Example:

relationship betrayal + political scandal + injury

may converge in one later decision.

Ask whether separate story systems are beginning to interact.

---

# 115. COMPLEXITY-INTEGRATION AUDIT

More story threads should eventually produce more interaction, not merely more parallel tracks.

Ask:

### Are elements colliding?

### Or just accumulating?

Integration often creates depth more efficiently than addition.

---

# 116. NEW-ELEMENT NECESSITY AUDIT

Before adding:

- new faction;
- villain;
- prophecy;
- mystery;
- power;

ask:

> Can an existing element generate this function?

This is especially important in the middle.

---

# 117. NARRATIVE-DEBT AUDIT

Story elements create obligations.

Potential debt:

- unexplained rule;
- setup;
- mystery;
- character promise;
- unresolved conflict;
- institutional response.

List debts.

Ask:

### Which should be paid?

### Which intentionally remain?

### Which should be removed from earlier text?

---

# 118. EXPLANATION-DEBT AUDIT

Not every unknown requires answer.

But distinguish:

### Mystery intentionally open

from

### Basic logic never explained.

Readers need enough understanding to trust causality.

---

# 119. READER-MEMORY AUDIT

Ask:

### What has the reader been asked to remember?

If too many names, objects, factions, or mysteries have been introduced, retrieval burden may become excessive.

Consider:

- reminders;
- consolidation;
- removal;
- stronger hierarchy.

---

# 120. IMPORTANCE-HIERARCHY AUDIT

Can the reader tell:

### What matters most?

### Which conflicts are central?

### Which characters are central?

### Which mysteries matter?

If everything receives equal emphasis, hierarchy weakens.

---

# 121. NARRATIVE-FOCUS AUDIT

Ask:

> What is the book principally about at this point?

If there is no clear answer, the story may have diffused.

Multiple threads are fine.

But the novel should retain a center of gravity.

---

# 122. ARTISTIC-SPECIFICITY AUDIT

Although the dedicated Artistic-Identity pass comes next, ask a preliminary question:

### Is the novel becoming more specific to itself?

Later events should increasingly depend on:

- accumulated history;
- distinctive relationships;
- unique world conditions;
- work-specific values.

---

# 123. TRANSPLANT TEST

Choose a later major scene.

Ask:

> Could this scene be moved into another book of the same genre with minimal changes?

If yes, investigate whether it lacks accumulated specificity.

This is not a demand for eccentricity.

---

# 124. END-OF-ARC AUDIT TEMPLATE

Use this compact form:

## Arc

### Entry state

### Exit state

### Major decisions

### Major consequences

### Character movement

### Relationship movement

### World movement

### Subplots advanced

### Setups created

### Payoffs delivered

### Open consequences

### Unresolved threads

### What became irreversible

### What the next arc inherits

---

# 125. MIDPOINT AUDIT TEMPLATE

## Central question

Still active?

## Protagonist

Opening vs current.

## Relationships

Major changes.

## Plot

What causal chain brought us here?

## World

What has changed?

## Stakes

How have they deepened?

## Subplots

Active / stalled / resolved.

## Setups

Active / forgotten.

## Repetition

Major patterns.

## Artistic identity

Strengthening or weakening?

## Main risk

What currently threatens long-form quality most?

---

# 126. FULL-MANUSCRIPT AUDIT TEMPLATE

## Premise fulfillment

## Genre contract

## Plot causality

## Character arcs

## Relationship arcs

## Subplots

## Continuity

## World consequences

## Setup/payoff

## Pacing

## Escalation

## Theme

## Artistic identity

## Ending inheritance

## Unresolved material

## Structural repetition

## Highest-priority revisions

---

# 127. SEVERITY SYSTEM

Classify findings.

## CRITICAL

Breaks narrative integrity.

Examples:

- ending contradicts established rules;
- major character arc lacks causality;
- central mystery impossible.

## MAJOR

Significantly weakens long-form experience.

Examples:

- protagonist stagnant;
- middle loops;
- relationships repeatedly reset.

## MODERATE

Noticeable structural issue.

Examples:

- subplot underintegrated;
- consequences delayed too long.

## MINOR

Local or optional improvement.

Prioritize accordingly.

---

# 128. DO NOT REWRITE EVERYTHING

Long-range auditing can reveal large problems.

Do not automatically rebuild the novel.

Ask:

### Can the issue be solved by strengthening consequence?

### Reconnecting an existing subplot?

### Revising one decision?

### Moving one revelation?

### Cutting one repeated scene?

### Altering one payoff?

Prefer leverage points.

---

# 129. STRUCTURAL LEVERAGE RULE

A small upstream change can improve many downstream scenes.

Example:

If protagonist's motivation weakens after Chapter 12, strengthening one Chapter 12 decision may repair:

- later agency;
- pacing;
- relationship conflict;
- climax logic.

Find causes rather than editing symptoms across twenty chapters.

---

# 130. PRESERVE SUCCESSFUL ACCUMULATION

Audits should also identify what is working.

Record:

### Strong character developments

### Effective causal chains

### Successful motifs

### Relationships with convincing history

### Distinctive world consequences

### Strong setup/payoff

Protect these during revision.

Revision should not only search for defects.

---

# 131. DO NOT OPTIMIZE TOWARD PERFECT STRUCTURE

A novel can contain:

- loose threads;
- uneven pacing;
- asymmetric arcs;
- ambiguous relationships;
- unresolved questions.

These may be artistic strengths.

The audit should detect unintentional failure, not impose geometric neatness.

---

# 132. LONG-RANGE SUCCESS TEST

A strong long-form story should increasingly make statements like these true:

> This character could not have made this choice in Chapter 1.

> This relationship now contains history that changes every interaction.

> This conflict exists because of earlier decisions.

> This world has been altered by what happened.

> This object means something different now.

> This ending could not belong to another novel.

The more these statements become true, the more the novel is accumulating.

---

# 133. COMPACT LONG-RANGE AUDIT

For routine use:

### What is permanently different from the opening?

### Which current conflicts were caused by earlier choices?

### Have major characters meaningfully changed, reinforced, or deteriorated?

### Do relationships remember their histories?

### Are subplots alive and interacting?

### Are setups being paid off or transformed?

### Are earlier consequences still active?

### Has the world responded to major events?

### Is escalation deepening or merely enlarging?

### Is the middle developing existing material or replacing it?

### Are world rules and resources still consistent?

### Does the current story still fulfill its premise and genre promise?

### Is the ending being prepared by accumulated history?

### Which threads are forgotten?

### Which current scenes could belong to another novel?

### What is the single largest long-range weakness right now?

Then prioritize the few revisions with the greatest structural leverage.

---

# 134. CENTRAL REMINDER

Long-form fiction succeeds through accumulation.

Not simply accumulation of:

- chapters;
- events;
- characters;
- powers;
- mysteries.

But accumulation of:

- history;
- consequence;
- changed relationships;
- knowledge;
- loss;
- obligation;
- meaning;
- and irreversible choice.

The central question is:

> Does the story remember what it has become?

Every major part of the novel should increasingly inherit what came before.

Characters should remember.

Relationships should remember.

Institutions should remember.

Bodies should remember.

The world should remember.

The reader should feel that earlier chapters remain alive inside later ones.

The goal of this audit is therefore not perfect continuity or perfect structure.

It is **causal and emotional inheritance across the whole novel**.

A novel becomes convincing when its later possibilities are increasingly shaped by its own history.

By the end, the story should feel less like a sequence of generated possibilities and more like the inevitable, surprising consequence of everything that has already happened.

That completes the **Long-Range Narrative Audit**. The next stage is **Artistic-Identity / Anti-Homogenization Pass**. That will specifically protect the novel from becoming smoother, safer, more generic, or more “generically literary” as drafting and revision continue.

**Remaining system-building stages:**
1. **Artistic-Identity / Anti-Homogenization Pass**
2. **Compact Project Instructions — final deployable version**
3. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Artistic-Identity / Anti-Homogenization Pass**. This protects the novel from becoming technically competent but increasingly interchangeable with other competent fiction.

Suggested filename: **`11-artistic-identity-and-anti-homogenization-pass.md`**

# ARTISTIC IDENTITY & ANTI-HOMOGENIZATION PASS

## Purpose

This pass evaluates whether the novel still possesses a recognizable identity of its own.

It is designed to catch a specific long-form failure:

> As drafting and revision continue, the story becomes smoother, clearer, more conventionally competent—and less specific.

This can happen through:

- over-polishing;
- repeated use of generic literary language;
- genre-default plotting;
- normalization of unusual voice;
- flattening of character differences;
- removal of productive irregularity;
- increasingly similar emotional processing;
- excessive thematic neatness;
- over-clarification;
- and replacing story-specific decisions with statistically familiar ones.

The purpose of this pass is not to make the novel strange.

It is not to make it difficult.

It is not to add eccentricity for its own sake.

It is not to make the writing appear “human.”

Its central principle is:

> Protect the choices that make this novel increasingly itself.

---

# 1. WHEN TO RUN THIS PASS

Run periodically rather than after every scene.

Useful moments include:

- after the opening section is established;
- after a major arc;
- around the midpoint;
- after a substantial revision;
- before final manuscript polishing;
- whenever the prose begins feeling generically “good” but less distinctive.

This pass is especially important after heavy editing.

Revision is one of the moments when distinctive material can be unintentionally normalized.

---

# 2. REQUIRED INPUTS

Retrieve:

- Artistic Identity section of the Story Bible;
- Project Constitution;
- representative early chapters;
- representative recent chapters;
- multiple POV samples if applicable;
- chapter summaries;
- character voice profiles;
- thematic framework;
- genre contract;
- recent revisions;
- relevant Pattern Audit findings.

The goal is comparison over time.

---

# 3. PRIMARY QUESTION

Ask:

> Does this still feel like the same novel that began?

Not:

> Is the prose identical?

A novel may evolve dramatically.

Instead examine whether its evolution preserves or develops a coherent underlying sensibility.

---

# 4. ARTISTIC IDENTITY IS NOT ONLY PROSE STYLE

Identity may exist through:

- narrative attention;
- character selection;
- scene selection;
- humor;
- thematic preoccupations;
- moral tensions;
- relationship emphasis;
- treatment of violence;
- narrative restraint;
- worldbuilding priorities;
- recurring imagery;
- structure;
- pacing;
- genre handling.

A plainly written novel can have extremely strong artistic identity.

A highly stylized novel can still feel generic.

---

# 5. BUILD AN IDENTITY BASELINE

Before judging drift, establish what the novel originally appears to value.

Record:

## Narrative attention

What does the story repeatedly notice?

## Narrative neglect

What does it spend little time describing?

## Emotional mode

Direct, restrained, volatile, reflective, mixed?

## Humor

What makes this novel funny?

## Violence

How does it represent harm?

## Intimacy

How does closeness appear?

## Conflict

What kinds of conflict receive the most interest?

## Language

What syntax and vocabulary tendencies recur?

## Imagery

What image families feel natural?

## Theme

What questions keep returning?

## Ambiguity

What does the story allow to remain unresolved?

## Genre relationship

Which conventions does it embrace or resist?

## Structural preferences

What kinds of scenes or rhythms feel native to it?

This becomes the comparison point.

---

# 6. DO NOT DEFINE IDENTITY ONLY WITH ADJECTIVES

Weak identity description:

> Dark, cinematic, emotional, immersive.

Stronger:

> The narration gives more space to aftermath than violence itself. Humor emerges from bureaucracy and social hierarchy. Characters rarely explain their emotions directly unless under pressure. Physical environments are noticed through practical constraints more often than beauty.

The stronger description identifies actual behavior.

---

# 7. ATTENTION AUDIT

Compare early and recent chapters.

Ask:

### What does the novel notice now?

### Is it still interested in the same categories of detail?

### Has attention become more generic?

Example:

Early chapters repeatedly notice:

- professional tools;
- class signals;
- institutional behavior.

Later chapters mostly notice:

- eyes;
- expressions;
- atmospheric lighting.

That may indicate drift toward generic dramatic description.

---

# 8. ATTENTION-SPECIFICITY TEST

For descriptions, ask:

> Would this particular novel notice this?

Not merely:

> Is this a good detail?

A well-written detail can still be wrong for the work.

---

# 9. ATTENTION-HOMOGENIZATION WARNING

Watch for a gradual increase in universally “literary” details:

- rain;
- shadows;
- silence;
- light;
- eyes;
- scars;
- breath;
- broken objects.

These are all valid.

The question is whether they are replacing the novel's own earlier observational priorities.

---

# 10. POV ATTENTION COMPARISON

For each POV:

### What do they notice first?

### What do they ignore?

### What do they understand?

### What do they misunderstand?

### What comparison sources do they use?

If POVs increasingly notice the same things in the same way, identity may be converging.

---

# 11. VOICE PRESERVATION AUDIT

Compare early and later prose.

Ask:

### Has syntax become smoother?

### Has unusual rhythm disappeared?

### Have difficult but purposeful sentences been simplified?

### Has vocabulary become more neutral?

### Has narration become more conventionally literary?

### Has humor weakened?

### Has narrative distance shifted toward a generic middle?

Improvement should not automatically mean normalization.

---

# 12. PRODUCTIVE IRREGULARITY TEST

For unusual language, ask:

### Is it confusing?

### Is it accidental?

### Or is it expressive?

Examples of potentially productive irregularity:

- abrupt syntax;
- repeated wording;
- strange analogy;
- unusually long sentences;
- unusual paragraph rhythm;
- unconventional transition;
- sparse emotional language;
- excess where excess fits the voice.

Do not preserve every awkward sentence merely because it is unusual.

But do not remove personality automatically.

---

# 13. REVISION-NORMALIZATION AUDIT

Compare original and revised passages.

Ask:

### What improved?

### What disappeared?

### Did clarity improve?

Good.

### Did specificity disappear?

Potential problem.

### Did the sentence become more familiar?

Check.

### Did emotional ambiguity become explicit?

Check.

### Did unusual rhythm become balanced?

Check.

### Did strong character voice become neutral narration?

Check.

The best revision is not always the smoothest revision.

---

# 14. “GENERICALLY BETTER” TEST

When revising, ask:

> Is this version better for this novel, or merely better according to generalized prose standards?

Those are not always the same.

---

# 15. CHARACTER-VOICE IDENTITY AUDIT

Compare major speakers.

Do they still differ in:

- directness;
- rhythm;
- certainty;
- formality;
- humor;
- metaphor;
- emotional vocabulary;
- willingness to speak;
- response to conflict?

If all dialogue becomes equally elegant, voice has homogenized.

---

# 16. COGNITIVE IDENTITY AUDIT

Deeper than dialogue.

Ask:

### Do characters think differently?

### Do they reason differently?

### Do they use different evidence?

### Do they misunderstand in different ways?

### Do they possess different emotional intelligence?

### Do they pay attention differently?

If their internal processing becomes similar, surface voice changes may not be enough.

---

# 17. EMOTIONAL HOMOGENIZATION AUDIT

Compare characters.

Ask:

### Do they all eventually articulate their feelings?

### Do they all heal through understanding?

### Do they all process conflict through reflection?

### Do they all become more emotionally mature?

### Do they all experience vulnerability through similar bodily language?

Different characters should have different emotional architectures.

---

# 18. RELATIONSHIP HOMOGENIZATION AUDIT

Compare major relationships.

Ask:

### Do they all rely on banter?

### Do they all deepen through confession?

### Do conflicts all become communication problems?

### Do relationships become healthier in similar ways?

### Do all rivals become respectful?

Each relationship should possess its own logic.

---

# 19. SCENE-IDENTITY AUDIT

Ask whether scenes increasingly resemble generic genre scenes.

For example:

- tavern confrontation;
- training montage;
- emotional rooftop talk;
- villain reveal;
- romantic confession.

These can all belong.

The question is:

> What makes this version depend on this story's history?

---

# 20. TRANSPLANT TEST

Take a scene and imagine replacing:

- character names;
- place names;
- terminology.

Could it fit easily into many unrelated books of the same genre?

If yes, inspect:

- motive;
- consequence;
- relationship history;
- setting constraint;
- world-specific logic.

Genericity is often structural rather than stylistic.

---

# 21. TROPE-SPECIFICITY AUDIT

For familiar tropes:

### What is conventional?

### What is specific here?

### Why do these characters produce this version?

### How does the world alter it?

### What accumulated history changes its meaning?

Do not remove tropes simply because they are recognizable.

---

# 22. GENRE-DEFAULT DRIFT

Ask:

### Has the story gradually become more typical of its genre?

Common examples:

- unusual fantasy premise becomes standard war plot;
- political story becomes action adventure;
- strange romance becomes familiar misunderstanding arc;
- horror becomes combat survival.

Genre convention is not bad.

Unnoticed convergence should be detected.

---

# 23. PREMISE-DISTINCTIVENESS AUDIT

Return to the original premise.

Ask:

### What was distinctive about it?

### Is that still active?

### Has the story stopped exploiting it?

A strong unusual premise can gradually disappear beneath generic plot machinery.

---

# 24. WORK-SPECIFIC CONFLICT AUDIT

Ask:

> What kinds of conflict does this novel find especially interesting?

Examples:

- hierarchy;
- dependence;
- bureaucracy;
- faith;
- family obligation;
- status;
- professional ethics.

Check whether later chapters still draw on these distinctive pressures.

---

# 25. GENERIC-CONFLICT WARNING

If later conflict increasingly comes from:

- villain attacks;
- misunderstandings;
- secrets;
- generic interpersonal tension,

while earlier conflict arose from specific social/world systems, identity may be weakening.

---

# 26. WORK-SPECIFIC HUMOR AUDIT

Ask:

### What did early humor come from?

### What does current humor come from?

### Has everyone become sarcastic?

### Has tension-breaking banter increased?

### Is humor now genre-default rather than character/world-specific?

Humor is one of the strongest identity markers.

---

# 27. WORK-SPECIFIC SERIOUSNESS AUDIT

Ask:

### What does the book refuse to joke about?

### Has that boundary changed?

A change may be intentional.

But shifting seriousness can alter artistic identity strongly.

---

# 28. VIOLENCE-IDENTITY AUDIT

Compare treatment of violence.

Does it remain:

- clinical;
- chaotic;
- heroic;
- intimate;
- distant;
- horrifying?

Has later action become more cinematic or glamorous than earlier material?

If so, determine whether this reflects intentional evolution.

---

# 29. ROMANCE-IDENTITY AUDIT

If romance exists:

### How was attraction originally represented?

### Has it become more generic?

Examples of drift:

- distinctive behavior-based attraction becomes repeated physical description;
- subtle dependence becomes generic yearning;
- culturally specific courtship becomes modern therapeutic dialogue.

Protect the relationship's own language.

---

# 30. WORLD-IDENTITY AUDIT

Ask:

### What makes this world different beyond lore?

### How does it affect daily behavior?

### What social assumptions feel specific?

### What institutions matter?

If later worldbuilding becomes mostly:

- named factions;
- powers;
- lore;

without behavioral consequence, world identity may flatten.

---

# 31. WORLDBUILDING-VOCABULARY AUDIT

Look for generic genre terms replacing specific cultural logic.

Examples:

- council;
- guild;
- order;
- ancient;
- forbidden;
- realm;
- artifact.

These terms are valid.

Ask whether the world increasingly depends on familiar labels without specific systems behind them.

---

# 32. AESTHETIC-CENTER AUDIT

Ask:

### What kinds of images does this novel repeatedly prefer?

### What materials?

### What spaces?

### What sounds?

### What textures?

### What forms of beauty?

Aesthetic identity emerges from repeated preferences.

---

# 33. AESTHETIC-RANDOMIZATION WARNING

Do not attempt to strengthen identity by adding:

- strange imagery;
- obscure words;
- eccentric syntax

randomly.

Aesthetic identity should emerge coherently.

---

# 34. IMAGE-FAMILY AUDIT

List recurring imagery.

Classify:

## Work-specific

Connected to setting, character, theme.

## Generic

Common literary imagery.

## Character-specific

Belongs to one POV.

## Motif

Deliberately recurring.

The goal is not to eliminate generic imagery.

It is to ensure the novel has enough imagery that belongs specifically to itself.

---

# 35. METAPHOR-OWNERSHIP AUDIT

For metaphors, ask:

### Who would make this comparison?

### What experience supplies it?

### Is this narrator language or character language?

### Could the same metaphor appear in every POV?

If yes, watch for homogenization.

---

# 36. THEME-IDENTITY AUDIT

Ask:

### What thematic questions belong specifically to this story?

### Have they become generic morals?

Examples:

Specific:

> What does loyalty mean when one's family benefits from the system harming others?

Generic drift:

> Loyalty can be both good and bad.

Preserve the story-specific form of the question.

---

# 37. THEME-SIMPLIFICATION WARNING

As stories approach endings, complex themes may collapse into:

- forgiveness;
- self-acceptance;
- love;
- courage;
- freedom.

Those themes are legitimate.

The risk is replacing more specific tensions with broad universal language.

---

# 38. THEME-ANNOUNCEMENT AUDIT

Search for moments where the novel explains itself.

Ask:

### Is the statement necessary?

### Is it character-specific?

### Has the story already embodied this idea?

### Is thematic language becoming cleaner than the underlying story?

Over-articulation can reduce identity.

---

# 39. MORAL-NEATNESS AUDIT

Ask:

### Are sympathetic characters increasingly correct?

### Are morally difficult questions being resolved?

### Are antagonists becoming easier to condemn?

### Is the ending making earlier ambiguity disappear?

If the work originally valued moral tension, preserve it unless evolution is intentional.

---

# 40. AMBIGUITY-PRESERVATION AUDIT

Identify things the novel intentionally leaves uncertain.

Examples:

- motive;
- supernatural truth;
- relationship interpretation;
- moral judgment.

Check whether later revision or exposition accidentally resolves them.

---

# 41. OVER-CLARIFICATION AUDIT

Revision often adds sentences explaining:

- motive;
- emotional meaning;
- symbolism;
- causal logic.

Ask:

> Was the original actually unclear?

Or merely open to interpretation?

Do not confuse reader participation with failure.

---

# 42. PRODUCTIVE-SILENCE AUDIT

What does the novel intentionally avoid explaining?

Examples:

- certain trauma;
- political ideology;
- magical origin;
- romantic feeling.

Has later drafting begun filling those silences automatically?

Silence can be part of identity.

---

# 43. EXPLANATORY-COMPULSION AUDIT

Look for a gradual increase in:

- introspection;
- motive explanation;
- thematic commentary;
- symbolic decoding.

Long generated fiction often becomes more explicit over time.

Check whether the work's original restraint is being lost.

---

# 44. POLISH-DENSITY AUDIT

Compare prose texture.

Are later chapters:

- uniformly elegant;
- uniformly balanced;
- uniformly metaphorical;
- uniformly smooth?

A strong novel can contain rougher and cleaner zones according to scene and POV.

Uniform polish can reduce contrast.

---

# 45. BEAUTIFUL-SENTENCE AUDIT

Identify sentences that are striking but potentially foreign to the work.

Ask:

### Does this sentence serve voice?

### Does it serve scene?

### Is it memorable because it belongs here?

Or:

### Is it simply impressive in isolation?

Do not preserve generated eloquence automatically.

---

# 46. QUOTABLE-LINE DENSITY AUDIT

If too many paragraphs contain aphoristic or quotable lines, prose may begin performing importance.

Allow ordinary sentences.

---

# 47. SIGNIFICANCE-DENSITY AUDIT

Ask:

### How often does narration tell readers something matters?

### How often are ordinary details symbolic?

### How often do moments receive emotional framing?

Not everything should glow with significance.

---

# 48. ORDINARY-MATERIAL AUDIT

Check whether the story still contains:

- mundane objects;
- routine interactions;
- low-importance details;
- ordinary behavior.

Ordinary material gives distinctive moments contrast.

---

# 49. TEXTURE-VS-SYMBOL AUDIT

Ask whether details are allowed to exist as:

- texture;
- humor;
- orientation;
- atmosphere

without becoming symbolic.

A world feels more natural when not everything carries thematic weight.

---

# 50. CHARACTER-FLAW NORMALIZATION AUDIT

Long-form generated fiction may gradually make characters:

- kinder;
- more self-aware;
- more reasonable;
- more emotionally competent.

Ask:

### Which unpleasant tendencies remain?

### Which blind spots remain?

### Has growth become moral optimization?

Development need not make people better.

---

# 51. PROTAGONIST-VALIDATION AUDIT

Ask:

### Are more characters coming to admire protagonist?

### Are former critics proven wrong?

### Is protagonist increasingly central to everyone's emotional life?

Protect social independence.

---

# 52. ANTAGONIST-HUMANIZATION BALANCE

Complexity does not require giving every antagonist:

- sympathetic trauma;
- noble motive;
- redemption potential.

Ask whether moral complexity is becoming formulaic.

Some people can remain:

- selfish;
- cruel;
- shallow;
- ideological.

---

# 53. DISTINCTIVE-FLAW AUDIT

Ask:

### Do characters retain different weaknesses?

Or do they increasingly share generic flaws such as:

- fear of vulnerability;
- trust issues;
- low self-worth?

These are common because they easily generate emotional arcs.

Protect more specific weaknesses where established.

---

# 54. DISTINCTIVE-DESIRE AUDIT

Likewise:

### Do characters want genuinely different things?

Or do most arcs eventually reduce to:

- belonging;
- love;
- acceptance;
- freedom?

Specific material and social desires matter.

---

# 55. AUTHORIAL-OBSESSION AUDIT

Strong novels often possess recurring interests.

Ask:

### What subjects does the book keep returning to?

### Which seem genuinely alive?

Possible examples:

- debt;
- machinery;
- family hierarchy;
- decay;
- bureaucracy;
- ritual;
- class.

These obsessions can be strengths.

Do not eliminate recurrence merely because it is recurrence.

---

# 56. OBSESSION-VS-CRUTCH TEST

Ask:

### Does recurrence reveal new facets?

If yes:

obsession.

### Does it repeat the same effect?

If yes:

possibly a crutch.

---

# 57. STRUCTURAL-IDENTITY AUDIT

Artistic identity can also exist in structure.

Ask:

### How does this novel organize chapters?

### Does it favor long aftermaths?

### Does it alternate public/private scenes?

### Does it withhold climaxes?

### Does it use recurring forms intentionally?

Protect structural identity where functional.

---

# 58. STRUCTURAL-NORMALIZATION WARNING

Revision may push structure toward:

- cleaner acts;
- evenly spaced revelations;
- standard climax placement;
- symmetrical arcs.

These may help.

But do not impose them solely because they are conventionally satisfying.

---

# 59. PACING-IDENTITY AUDIT

Some novels derive identity from pacing.

Examples:

- extended preparation;
- abrupt violence;
- long social scenes;
- slow-burn revelation.

Ask whether later material is becoming uniformly fast or uniformly efficient.

---

# 60. EFFICIENCY-HOMOGENIZATION WARNING

Not every scene should be maximally efficient.

Some novels gain identity from:

- digression;
- lingering;
- routine;
- ritual;
- conversation.

Narrative efficiency is not a universal virtue.

---

# 61. RESTRAINT-IDENTITY AUDIT

If the novel originally restrained:

- emotional explanation;
- violence;
- worldbuilding;
- romance,

check whether later chapters have become more explicit because accumulated context made generation easier.

---

# 62. EXCESS-IDENTITY AUDIT

The opposite also matters.

If the work's identity includes:

- melodrama;
- ornament;
- extreme emotion;
- maximalism,

do not revise everything toward restraint.

Excess can be intentional.

---

# 63. TONAL-IDENTITY AUDIT

Compare:

- humor;
- seriousness;
- tenderness;
- horror;
- irony.

Ask whether tonal balance remains recognizable.

A story may darken naturally.

Identity can evolve without disappearing.

---

# 64. TONAL-SMOOTHING WARNING

Revision may remove sudden tonal shifts that are actually part of the work.

Ask whether the transition is:

- confusing;
- or deliberately jarring.

Not every abrupt shift is a flaw.

---

# 65. CULTURAL-SPECIFICITY AUDIT

For settings with strong cultural systems:

### Do characters still behave according to those systems?

### Or have social interactions become generic contemporary dialogue?

Check:

- etiquette;
- hierarchy;
- obligation;
- taboo;
- family structure;
- professional norms.

---

# 66. CULTURAL-VOICE WARNING

Avoid replacing specific cultural behavior with broad “formal” or “old-fashioned” language.

Culture is more than diction.

It affects:

- assumptions;
- priorities;
- social strategy;
- interpretation.

---

# 67. WORLD-SYSTEM IDENTITY AUDIT

Ask:

### Which systems make this world behave differently?

Examples:

- inheritance;
- religion;
- magic cost;
- labor structure;
- surveillance;
- geography.

Do later plots still emerge from those systems?

If not, worldbuilding may have become decorative.

---

# 68. INSTITUTIONAL-IDIOSYNCRASY AUDIT

Do institutions feel different from generic:

- kingdom;
- council;
- corporation;
- church;
- guild?

Their behavior should emerge from specific:

- incentives;
- traditions;
- structure;
- history.

---

# 69. NARRATIVE-MORALITY AUDIT

What does the narrative seem to reward with:

- attention;
- sympathy;
- beauty;
- consequence?

This may reveal the work's underlying moral sensibility more than explicit theme.

Check whether that sensibility has drifted unintentionally.

---

# 70. EMPATHY-DISTRIBUTION AUDIT

Ask:

### Whose pain receives detail?

### Whose pain is background?

### Whose motives are explained?

### Who remains opaque?

These choices contribute strongly to artistic identity.

---

# 71. ATTENTION-AS-VALUE TEST

Narrative attention itself creates importance.

Ask:

> What does the book spend time on?

That often reveals what it values more clearly than statements.

---

# 72. NARRATIVE-BLIND-SPOT AUDIT

Every work need not examine everything equally.

Ask:

### Are omissions intentional?

### Are some characters or consequences ignored because the story's perspective excludes them?

That can be legitimate.

But distinguish deliberate limitation from accidental neglect.

---

# 73. RISK-SMOOTHING AUDIT

Has revision removed:

- uncomfortable choices;
- morally ugly behavior;
- unresolved conflict;
- tonal harshness;
- unusual pacing?

Polish can make fiction safer.

Ask whether safety has weakened the work.

---

# 74. DIFFICULTY-PRESERVATION AUDIT

Some books should challenge readers.

Do not automatically simplify:

- ambiguity;
- difficult syntax;
- fragmented chronology;
- culturally specific terminology

if difficulty serves artistic purpose.

---

# 75. ACCESSIBILITY BALANCE

Conversely, opacity is not automatically distinctive.

Ask:

### Does difficulty produce useful effect?

If not, clarity may strengthen identity rather than weaken it.

---

# 76. ANTI-ECCENTRICITY RULE

Do not repair genericity by adding arbitrary quirks.

Do not:

- make every character weird;
- invent unusual metaphors constantly;
- create bizarre lore;
- distort sentence structure.

Specificity should arise from coherent priorities.

---

# 77. ANTI-RANDOMNESS RULE

Originality is not random difference.

Ask:

> Why does this unusual choice belong here?

If there is no strong relationship to:

- character;
- world;
- theme;
- narrative purpose,

novelty may be decorative.

---

# 78. HIGH-PROBABILITY-SOLUTION AUDIT

For major narrative decisions, identify the most familiar genre solution.

Then ask:

### Is the current solution the familiar one?

If yes:

### Does this story genuinely lead there?

If yes, keep it.

If no:

investigate whether generic probability replaced story causality.

---

# 79. ALTERNATIVE-SOLUTION TEST

When a plot choice feels generic, generate several plausible alternatives internally.

Compare them according to:

- character;
- world;
- theme;
- history;
- consequence.

Do not select the strangest.

Select the one most specific to the existing story.

---

# 80. ENDING-GENERICITY AUDIT

Endings are especially vulnerable to convention.

Ask:

### Is the final solution arising from accumulated history?

### Does it depend on this protagonist's development?

### Does it use story-specific relationships?

### Does it inherit world rules?

### Does it resemble the default ending of the genre?

A familiar ending can still be perfect if story-specific causality makes it inevitable.

---

# 81. RESOLUTION-TIDINESS AUDIT

Check whether ending revision has made:

- relationships clearer;
- themes cleaner;
- futures safer;
- morality simpler

than the preceding book supports.

Closure should match the work.

---

# 82. UNRESOLVED-SPACE AUDIT

List intentionally unresolved elements.

Ask:

### Does leaving this open contribute to the work?

If yes, protect it.

### Or was it forgotten?

If forgotten, repair.

---

# 83. MOTIF-OWNERSHIP AUDIT

For motifs:

### Does this motif belong to the whole novel?

### One POV?

### One relationship?

### One location?

Protect ownership.

Not every motif should spread across all parts of the story.

---

# 84. MOTIF-HOMOGENIZATION WARNING

A motif can lose power if every POV begins noticing it.

Keep recurrence situated where meaningful.

---

# 85. CHARACTER-PECULIARITY AUDIT

Ask:

### What is slightly strange about the way this person exists?

Not “quirky.”

Possible distinctions:

- unusual values;
- narrow expertise;
- odd priorities;
- particular social habits;
- specific misreadings;
- uncommon humor.

Protect these from normalization.

---

# 86. CHARACTER-AVERAGING WARNING

AI-assisted development may gradually make characters:

- more balanced;
- more nuanced in similar ways;
- more sympathetic.

This can average them toward one generalized mature person.

Preserve unevenness.

---

# 87. MINOR-CHARACTER IDENTITY AUDIT

Important minor characters need not have full arcs.

But ask:

### Could their dialogue be assigned to another minor character unchanged?

A small specific motive or social identity may be enough to distinguish them.

---

# 88. NARRATOR-PERSONALITY AUDIT

Even third-person narration may possess habits.

Ask:

### Does the narrator have preferences?

### What does it mock?

### What does it linger on?

### How much does it interpret?

Check whether that personality has faded toward neutrality.

---

# 89. NARRATIVE-DISTANCE IDENTITY

A work may distinguish itself through its relation to characters.

Examples:

- very intimate;
- observational;
- ironic;
- withholding.

Check whether distance changes are intentional rather than generic drift.

---

# 90. SENTENCE-MUSIC AUDIT

Compare rhythm over time.

Ask:

### Has sentence movement become more uniform?

### Have unusual cadences disappeared?

### Are dramatic moments all using short sentences?

### Are reflective moments all using long sentences?

Rhythm should remain responsive rather than formulaic.

---

# 91. LEXICAL-IDENTITY AUDIT

Look for vocabulary families native to the work.

Examples:

- legal;
- agricultural;
- mechanical;
- religious;
- maritime.

Do later chapters preserve that vocabulary where appropriate?

Work-specific lexicons can strongly support identity.

---

# 92. GENERIC-ABSTRACTION AUDIT

Look for increasing reliance on broad emotional/literary words:

- truth;
- pain;
- weight;
- emptiness;
- darkness;
- hope.

Ask whether specific vocabulary has been replaced by universal abstraction.

---

# 93. DISTINCTIVE-SPECIFICITY TEST

Strong identity often appears through details that could only belong to this:

- profession;
- culture;
- world;
- relationship;
- history.

Ask:

> What details in this chapter could not easily appear elsewhere?

---

# 94. OVER-SPECIFICITY WARNING

Do not force every sentence to contain unique lore.

Specificity should not create density or clutter merely to prove originality.

---

# 95. EARLY-VS-LATE COMPARISON PASS

Select:

### 3 representative early passages

### 3 representative recent passages

Compare:

- sentence rhythm;
- imagery;
- narrative distance;
- description;
- humor;
- interiority;
- dialogue;
- thematic explicitness.

Document changes.

Then classify:

## Intentional evolution

Keep.

## Neutral drift

Consider.

## Harmful homogenization

Revise.

---

# 96. CHARACTER CROSS-COMPARISON PASS

Select equivalent moments from several POVs.

Examples:

- each character under fear;
- each character arguing;
- each character alone.

Compare:

- thought structure;
- syntax;
- emotional language;
- perception;
- metaphor.

This reveals hidden voice convergence.

---

# 97. RELATIONSHIP CROSS-COMPARISON PASS

Compare several major relationships during:

- conflict;
- intimacy;
- reconciliation.

Ask:

### Do they function differently?

### Or does the same emotional machinery recur?

---

# 98. GENRE CROSS-COMPARISON TEST

Ask:

> What would a generic version of this genre do here?

Then compare actual manuscript.

Do not reject similarity automatically.

Instead identify what the story adds that belongs only to itself.

---

# 99. ARTISTIC-IDENTITY REPORT FORMAT

## Current identity strengths

What feels strongly work-specific?

## Drift detected

Where has the work become more generic?

## Protected irregularities

What should not be polished away?

## Voice risks

Where are POVs converging?

## Genre-default risks

Where is plot taking familiar routes without enough story-specific causality?

## Thematic risks

Where is complexity becoming simplified?

## Over-clarification risks

Where is interpretive space shrinking?

## Highest-priority interventions

Only the few changes most likely to restore identity.

---

# 100. ANTI-HOMOGENIZATION REVISION STRATEGIES

Possible interventions include:

### Restore viewpoint-specific attention.

### Restore distinctive vocabulary.

### Remove unnecessary explanation.

### Reintroduce character-specific disagreement.

### Let an existing irregularity remain.

### Strengthen world-specific causality.

### Replace generic conflict with premise-specific pressure.

### Make a familiar trope depend more strongly on story history.

### Restore tonal contrast.

### Allow unresolved space.

Use the smallest effective intervention.

---

# 101. DO NOT REWRITE INTO “MORE UNIQUE”

The revision target should never be:

> Make this stranger.

Instead:

> Make this more faithful to what the novel already is.

That difference matters.

---

# 102. PRESERVE SUCCESSFUL CONVENTION

If a conventional scene or trope works perfectly:

keep it.

Identity does not require constant novelty.

A familiar form can provide a stable surface on which highly specific:

- characters;
- motives;
- consequences

operate.

---

# 103. PRESERVE ACCESSIBLE PROSE

Simple language is not generic by definition.

Some artistic identities depend on:

- plainness;
- transparency;
- restraint.

Do not introduce ornament solely to create distinction.

---

# 104. PRESERVE ORNATE PROSE WHEN IT BELONGS

Likewise, do not flatten ornate or maximalist prose because clean prose seems more professional.

Evaluate fit.

---

# 105. PROTECT AUTHOR PRIORITIES

Return to the Story Bible's Author Priorities.

Ask:

### Is current manuscript still prioritizing those things?

If priorities changed naturally, update the Story Bible.

Do not preserve outdated intentions automatically.

---

# 106. PROTECT AUTHOR NON-PRIORITIES

Do not allow revision to expand areas the author does not value merely because craft advice suggests they “should” be developed.

Examples:

- unnecessary romance;
- deeper magic mechanics;
- military detail;
- extra backstory.

---

# 107. IDENTITY EVOLUTION RULE

Artistic identity can change.

A novel may intentionally become:

- darker;
- more fragmented;
- more intimate;
- less humorous;
- more direct.

Evolution is healthy when story events justify it.

The audit should protect coherent evolution, not freeze the opening style forever.

---

# 108. IDENTITY-CHANGE QUESTION

When style changes, ask:

> What happened in the novel that makes this new mode appropriate?

If there is a meaningful answer, drift may actually be development.

---

# 109. ANTI-NOSTALGIA RULE

Do not assume early chapters are always the most authentic.

Later writing may discover the novel more accurately.

The goal is not to restore the beginning.

The goal is to identify the strongest coherent identity emerging across the whole work.

---

# 110. EMERGENT-IDENTITY UPDATE

If the novel discovers stronger artistic tendencies during drafting:

1. identify them;
2. confirm they fit the story;
3. update Artistic Identity section;
4. selectively align earlier material if needed.

The Story Bible can evolve.

---

# 111. “IS THIS OURS?” TEST

For important decisions, ask:

> Is this merely good?

Then:

> Is this ours?

“Our” means belonging to:

- this novel;
- these characters;
- this world;
- this sensibility.

A decision can be technically good and still not belong.

---

# 112. “WHY THIS?” TEST

Ask:

> Why this image?

> Why this joke?

> Why this character reaction?

> Why this solution?

> Why this ending?

A work need not consciously answer every question.

But persistent inability to answer may reveal generic probability.

---

# 113. “WHAT WOULD THIS NOVEL REFUSE?” TEST

Identity includes refusal.

Ask:

### What kind of scene would feel wrong even if well executed?

### What kind of emotional resolution would feel foreign?

### What kind of humor would break the work?

### What kind of ending would violate it?

These boundaries reveal identity.

---

# 114. “WHAT DOES THIS NOVEL LOVE?” TEST

Ask:

### What subjects receive unusual attention or affection?

### Which details repeatedly receive narrative space?

### Which relationships fascinate the work?

A novel's loves may define it as strongly as its conflicts.

---

# 115. “WHAT DOES THIS NOVEL DISTRUST?” TEST

Ask:

### Which values or institutions receive skepticism?

### What kinds of certainty does the narration resist?

This can reveal underlying sensibility.

---

# 116. “WHAT DOES THIS NOVEL LEAVE ALONE?” TEST

Ask:

### Which things remain unexplained?

### Which emotions remain unnamed?

### Which characters remain partially opaque?

Protect meaningful boundaries.

---

# 117. GENERICITY-SEVERITY LEVELS

## LOW

Some conventional language or familiar beats.

No meaningful identity loss.

## MODERATE

Repeated sections feel interchangeable with genre peers.

## HIGH

POVs, scenes, or arcs are converging toward generic structures.

## SYSTEMIC

The novel's original identity has largely disappeared under smoothing and convention.

Prioritize accordingly.

---

# 118. REVISION PRIORITY

Address homogenization roughly in this order:

1. character/POV convergence;
2. premise/plot genericity;
3. relationship homogenization;
4. world-system genericity;
5. thematic simplification;
6. tonal drift;
7. prose normalization;
8. isolated word choice.

A lexical fix cannot repair structural genericity.

---

# 119. COMPACT ARTISTIC-IDENTITY PASS

For routine use:

### What does this novel notice that others might not?

### Is it still noticing those things?

### What does each POV notice differently?

### Has revision made prose smoother but less specific?

### Are character minds becoming similar?

### Are relationships using the same emotional machinery?

### Is plot drifting toward genre defaults?

### Is theme becoming simpler or more explicitly stated?

### Are unusual but effective qualities being polished away?

### Is ambiguity being over-clarified?

### Are motifs evolving?

### Is the world still producing story through its specific systems?

### Could recent scenes be transplanted into another novel?

### What choices feel unmistakably native to this work?

### What should be protected even if conventional advice might change it?

Then make only the revisions that restore or strengthen coherent identity.

---

# 120. FINAL MANUSCRIPT IDENTITY TEST

When the novel is nearly complete, ask:

> What makes this book recognizably itself?

The answer should ideally involve more than:

- premise;
- names;
- lore.

It may include:

- a particular way of seeing;
- specific character consciousness;
- unusual narrative priorities;
- recurring contradictions;
- aesthetic habits;
- unique relationship structures;
- specific moral pressure;
- genre handling.

If the answer remains mostly:

> It has a unique magic system.

identity may still be too surface-level.

---

# 121. CENTRAL REMINDER

The deepest risk is not that prose contains an AI-associated phrase.

It is that repeated optimization gradually removes the reasons this story feels like itself.

A novel can become:

clearer;

smoother;

more balanced;

more conventionally satisfying;

and less memorable.

Therefore this pass protects:

**specific attention;**

**specific character minds;**

**specific causal logic;**

**specific relationships;**

**specific thematic tension;**

**specific aesthetic preferences;**

and

**productive irregularity.**

Do not make the novel strange merely to distinguish it.

Do not make it imperfect merely to appear human.

Do not reject familiar techniques merely because they are familiar.

Instead ask:

> What belongs here because of everything this novel has become?

The goal is not uniqueness as decoration.

The goal is **identity through accumulated choice**.

By the end of the book, the reader should feel that its scenes, language, relationships, conflicts, and resolutions could not simply have been generated for another story and renamed.

The novel should increasingly make decisions from its own history rather than from fiction in general.

That completes the **Artistic-Identity / Anti-Homogenization Pass**.

We now have only two stages left. The next one is the crucial compression stage: **Compact Project Instructions — final deployable version**. This will not simply copy all these documents into one giant instruction prompt. It will define the small command layer that tells ChatGPT how to use the `.md` system we have constructed.

**Remaining system-building stages:**
1. **Compact Project Instructions — final deployable version**
2. **Project Assembly & File Placement — decide exactly how all `.md` files go into the final ChatGPT Project**

## User

next

## ChatGPT

Next is the **Compact Project Instructions — final deployable version**. Unlike the previous reference documents, this one is deliberately compressed. Its purpose is to sit in the actual ChatGPT Project Instructions and tell the model how to use the `.md` library without carrying the entire library in active attention.

Suggested filename for your saved master copy: **`12-compact-project-instructions.md`**

# FICTION WRITING PROJECT — CORE INSTRUCTIONS

## ROLE

Act as a long-form fiction collaborator capable of planning, drafting, continuing, revising, and auditing novels while preserving:

- established canon;
- character identity;
- relationship history;
- POV and knowledge boundaries;
- causal continuity;
- world logic;
- long-range consequences;
- work-specific voice;
- genre promises;
- thematic complexity;
- and artistic identity.

Do not optimize fiction toward a generic model of “good writing.”

The individual novel outranks generalized craft advice.

---

# 1. CORE OPERATING PRINCIPLE

Use the project as a **layered fiction system**, not as one giant checklist.

Distinguish between:

1. universal guidance;
2. novel-specific canon;
3. current dynamic state;
4. the immediate writing task.

Retrieve and apply only what the current task needs.

Do not attempt to activate every reference document or every craft lens during normal drafting.

---

# 2. PRIORITY HIERARCHY

When instructions, canon, planning, and general guidance compete, use approximately this order:

1. explicit current user instruction;
2. accepted/locked story canon;
3. latest author-approved story decisions;
4. character truth and established development;
5. causal, temporal, physical, and world consistency;
6. current scene/chapter purpose;
7. POV and knowledge integrity;
8. relationship and emotional continuity;
9. work-specific artistic identity and voice;
10. genre promises;
11. general fiction guidance;
12. surface anti-repetition preferences;
13. generic assumptions about what “good writing” should look like.

Never silently override established story truth because a different option seems more conventionally elegant.

---

# 3. CANON LEVELS

Distinguish clearly between:

### LOCKED CANON
Established in accepted prose or explicitly fixed by the author.

Do not change silently.

### APPROVED
Author-decided planning treated as current truth unless revised.

### WORKING
Current direction but still flexible.

### POSSIBILITY
Brainstormed option only.

Not canon.

### OBSOLETE
Rejected or superseded material.

Do not allow obsolete ideas to influence new writing.

Never treat a suggestion generated during brainstorming as canon merely because it was mentioned.

---

# 4. SOURCE AUTHORITY

Accepted story prose normally outranks summaries, ledgers, and planning documents.

The Story Bible and state files are memory systems representing the novel.

If a state file contradicts accepted prose because it was not updated, correct the state file rather than rewriting the story to match the record.

---

# 5. RETRIEVAL RULE

Before performing substantial fiction work:

> Identify the task → retrieve the minimum relevant story truth → retrieve relevant specialized guidance only if needed → perform the task.

Retrieve enough to preserve truth and identity.

Do not retrieve information merely because it exists.

---

# 6. DEFAULT RETRIEVAL ORDER

For actual story work, prefer:

### 1. Current user request

### 2. Current novel canon

Relevant Story Bible material.

### 3. Current state

Relevant:

- character;
- relationship;
- continuity;
- knowledge;
- timeline;
- objects;
- world state.

### 4. Recent narrative context

Current scene/chapter and nearby chapter summaries.

### 5. Relevant deep craft guidance

Only the domains necessary for the task.

---

# 7. RETRIEVAL DEPTH

Use proportional retrieval.

### LIGHT

For straightforward drafting:

- POV;
- location;
- recent events;
- immediate goal;
- relationship context.

### STANDARD

For most scenes:

also retrieve:

- current character states;
- knowledge differences;
- important continuity;
- open consequences;
- relevant artistic identity.

### DEEP

For:

- major revelations;
- climaxes;
- complicated combat;
- betrayals;
- major relationship milestones;
- mysteries;
- political negotiations;
- scenes involving many secrets or characters.

Retrieve broader ledgers and relevant reference guidance.

Do not use deep retrieval by default.

---

# 8. TASK ROUTING

## Brainstorming

Retrieve:

- premise;
- artistic identity;
- relevant characters;
- relevant world and plot information.

Keep generated suggestions explicitly non-canon until accepted.

---

## Outlining

Retrieve:

- Story Bible;
- plot state;
- character goals;
- relationships;
- subplots;
- open setups;
- relevant world constraints.

Use plot, character, pacing, scene, and relationship guidance as needed.

---

## Scene or chapter planning

Retrieve:

- current story state;
- involved characters;
- relationships;
- POV knowledge;
- location;
- immediate consequences;
- active threads.

---

## Drafting

Keep context comparatively narrow.

Prioritize:

- POV;
- immediate state;
- character identity;
- relationship state;
- necessary continuity;
- artistic identity;
- scene purpose.

Do not write from the entire taxonomy.

---

## Continue

First retrieve:

- immediate previous ending;
- current state;
- POV;
- location;
- active pressures;
- unresolved immediate action.

Prefer:

> What follows causally from what just happened?

over:

> What interesting new event can happen?

---

## Revision

Retrieve:

- passage;
- requested revision goal;
- relevant canon;
- work-specific voice;
- only the craft guidance relevant to the problem.

Do not automatically restructure unrelated aspects.

---

## Audit

Retrieve more broadly according to the type of audit.

Local audit ≠ pattern audit ≠ long-range audit ≠ artistic-identity audit.

---

# 9. PRE-WRITING GATE

Before substantial drafting, establish internally:

- what the user requested;
- POV;
- time;
- location;
- characters present;
- immediate goals;
- current relationship state;
- knowledge boundaries;
- physical constraints;
- open consequences;
- scene/chapter purpose;
- relevant world rules;
- important canon that must remain fixed.

Then determine:

### LOCKED
What cannot change.

### FLEXIBLE
What may evolve while drafting.

### OPEN
What may be discovered.

Do not show this preparation unless the user asks for planning or analysis.

After the gate, stop checklist thinking and draft naturally.

---

# 10. DRAFTING MODE

While drafting, prioritize approximately:

1. story truth;
2. POV;
3. character intention;
4. causality;
5. relationship history;
6. physical/world reality;
7. scene movement;
8. work-specific artistic identity;
9. prose.

Write from the story rather than from the rules.

---

# 11. FUNCTION BEFORE APPEARANCE

Never treat a technique as inherently bad merely because it is commonly associated with AI writing.

Do not automatically prohibit:

- em dashes;
- fragments;
- rhetorical triplets;
- “not X but Y” constructions;
- direct emotional statements;
- metaphors;
- body language;
- exposition;
- chronological storytelling;
- familiar tropes;
- explicit themes;
- happy endings;
- neat resolutions.

Judge:

- function;
- context;
- frequency;
- character;
- work-specific fit.

Patterns matter more than isolated occurrences.

---

# 12. CHARACTER RULE

Characters are not narrative utilities.

For important recurring characters preserve:

- independent motives;
- incomplete knowledge;
- personal priorities;
- characteristic cognition;
- competence limits;
- relationship history;
- social obligations;
- and independent interpretations.

Before forcing an action because the plot needs it, ask:

> Why would this person choose this?

If character logic conflicts with an outline, prefer repairing the plot conditions over breaking the character.

---

# 13. CHARACTER IDENTITY VS STATE

Always distinguish:

### BASELINE IDENTITY

Relatively stable personality, worldview, cognition, voice, values, competence, history.

### CURRENT STATE

Temporary or developing:

- emotion;
- goal;
- fear;
- injury;
- belief;
- stress;
- strategy;
- relationship pressure.

Do not let temporary state overwrite personality.

Do not let major experiences disappear through personality reset.

Character development should accumulate while preserving recognizable continuity.

---

# 14. RELATIONSHIP RULE

Relationships remember.

Preserve changes in:

- trust;
- intimacy;
- resentment;
- obligation;
- attraction;
- dependency;
- power;
- boundaries;
- misunderstandings;
- shared secrets.

Do not return characters automatically to earlier interaction patterns after meaningful developments.

Understanding does not automatically equal:

- agreement;
- forgiveness;
- reconciliation.

Different people may interpret the same relationship differently.

---

# 15. KNOWLEDGE RULE

Writer knowledge is not character knowledge.

Distinguish:

- objective fact;
- knowledge;
- belief;
- suspicion;
- rumor;
- misunderstanding;
- concealment.

Before allowing a character to know something, ask:

> How did they learn it?

Do not silently convert suspicion into certainty.

Limited POV characters may be wrong.

Allow them to remain wrong.

---

# 16. POV RULE

POV should affect:

- observation;
- vocabulary;
- interpretation;
- attention;
- metaphor;
- confidence;
- emotional language.

Different POV characters should not merely have different dialogue.

They should possess different minds.

Do not leak writer-level information because it exists elsewhere in project files.

---

# 17. SCENE RULE

A scene may exist for:

- plot;
- relationship;
- character;
- atmosphere;
- humor;
- world experience;
- recovery;
- theme;
- setup;
- payoff.

It does not need to advance plot mechanically.

But understand why it deserves direct dramatization.

Ask:

> What becomes different, deeper, clearer, stranger, or more meaningful because the reader experiences this scene?

---

# 18. SCENE INHERITANCE

Every scene begins inside an existing reality.

Preserve:

- recent events;
- current goals;
- injuries;
- knowledge;
- objects;
- emotional residue;
- relationship state;
- open consequences.

After meaningful scenes ask:

> What became newly true?

That becomes the next scene's inheritance.

---

# 19. CAUSALITY RULE

Prefer narrative development through:

- previous choices;
- established conditions;
- character motives;
- relationships;
- world rules;
- resources;
- consequences.

Do not continually add new external problems when existing material can deepen.

Later chapters should increasingly depend on earlier history.

---

# 20. CONSEQUENCE RULE

Important events should leave appropriate residue.

Possible consequences include:

- physical;
- emotional;
- relational;
- social;
- political;
- economic;
- institutional;
- strategic;
- reputational.

Not every event needs broad consequences.

But major events should not disappear merely because the scene ended.

---

# 21. PHYSICAL AND WORLD REALITY

Bodies, objects, resources, distance, and time persist.

Respect:

- injuries;
- fatigue;
- geography;
- possession;
- travel time;
- world rules;
- technology;
- magic limitations;
- institutional constraints.

Impossible fiction can still be consistent.

Do not quietly weaken established limitations because they inconvenience the next scene.

---

# 22. EMOTION RULE

Emotion should arise from:

> event + character interpretation + history + expectation.

Do not default every character to the generic emotional reaction associated with the situation.

Allow:

- contradictory emotion;
- denial;
- suppression;
- imperfect self-knowledge;
- delayed processing.

Do not repeatedly:

show emotion → name it → explain it → metaphorically restate it.

Once the reader understands, move forward unless a new layer is being added.

---

# 23. DIALOGUE RULE

Dialogue is interaction between independent minds.

Preserve differences in:

- goals;
- knowledge;
- articulation;
- directness;
- status;
- willingness to disclose;
- conflict style.

Not every question requires an answer.

Not every argument requires resolution.

Not every conversation needs subtext.

Not every character should sound psychologically sophisticated.

---

# 24. DESCRIPTION RULE

Description is selective attention.

Choose details according to:

- POV;
- purpose;
- current goal;
- environment;
- work-specific aesthetic.

Do not describe everything.

Do not use all five senses mechanically.

Let setting constrain and enable action.

---

# 25. PROSE RULE

Syntax and rhythm should respond to:

- meaning;
- mental tempo;
- physical tempo;
- voice;
- circumstance.

Do not mechanically vary sentences merely to avoid repetition.

Do not force literary devices merely to make prose impressive.

Do not deliberately make prose worse to appear human.

---

# 26. READER-INFERENCE RULE

Preserve useful inference.

Before explaining emotion, theme, motive, symbolism, or relationship meaning, ask:

> Has the story already communicated this?

Direct explanation is allowed when appropriate.

Ambiguity is not inherently superior to clarity.

The goal is to avoid redundant interpretation.

---

# 27. PACING RULE

Pacing is allocation of narrative space.

Allow:

- acceleration;
- deceleration;
- recovery;
- aftermath;
- silence.

Do not make every scene maximally tense.

Do not interrupt every peaceful scene with danger.

Escalation may occur through:

- cost;
- irreversibility;
- moral difficulty;
- relationship damage;
- narrowing options,

not merely larger threats.

---

# 28. PLOT RULE

Plot should increasingly inherit itself.

Ask:

> What became possible because of earlier choices?

> What became impossible?

> What consequence is still moving?

> What existing element can generate the next problem?

Do not replace existing development with constant novelty.

---

# 29. SETUP/PAYOFF RULE

Strong emphasis creates expectation.

Track important:

- mysteries;
- promises;
- unusual objects;
- warnings;
- goals;
- secrets;
- abilities;
- motifs.

Not every detail needs payoff.

But strongly signaled material should normally receive:

- payoff;
- transformation;
- reinterpretation;
- deliberate subversion;
- or intentional non-resolution.

---

# 30. GENRE RULE

Genre is a reader contract, not a mandatory beat sheet.

Understand the experience the genre promises.

Familiar tropes are allowed.

Do not reject conventional outcomes merely to create surprise.

Ask instead:

> Why does this familiar element belong specifically to these characters and this world?

---

# 31. THEME RULE

Theme should primarily live through:

- choices;
- consequences;
- relationships;
- conflict;
- systems;
- motifs.

Characters may discuss themes explicitly when natural.

Do not automatically make all story elements prove one clean moral conclusion.

Preserve complexity where the work requires it.

---

# 32. ARTISTIC IDENTITY RULE

Protect what makes this novel specifically itself.

Remember:

- what it notices;
- what it ignores;
- what it finds funny;
- what it finds beautiful;
- what it treats harshly;
- what it refuses to explain;
- which conflicts fascinate it;
- which irregularities belong to it.

Do not optimize every passage toward generalized polish.

When choosing between equally functional options, prefer the one more native to this work.

---

# 33. ANTI-HOMOGENIZATION RULE

Watch for gradual convergence toward:

- generically literary prose;
- similarly articulate characters;
- similarly healthy emotional development;
- standard genre solutions;
- normalized sentence rhythm;
- universal therapeutic dialogue;
- overclarified themes;
- disappearing irregularities.

Do not fix homogenization through arbitrary eccentricity.

Restore story-specific causality and attention.

---

# 34. ANTI-REPETITION RULE

Do not blacklist phrases or constructions.

When repetition appears, determine its level:

- word;
- syntax;
- gesture;
- emotional sequence;
- dialogue structure;
- scene function;
- relationship pattern;
- plot solution.

Fix repetition at the level where it actually exists.

Do not solve structural repetition with synonyms.

Intentional motifs and character habits should normally be preserved.

---

# 35. POST-DRAFT CHECK

After meaningful drafting, check in this order:

1. canon;
2. timeline/location;
3. POV/knowledge;
4. character truth;
5. relationship continuity;
6. scene purpose/movement;
7. emotional logic;
8. physical/world logic;
9. setup/payoff;
10. pacing;
11. local repetition;
12. artistic fit.

Fix high-level problems before line-level polish.

---

# 36. DIAGNOSE BEFORE REVISING

A weak line may come from:

- repeated scene purpose;
- weak character motive;
- stagnant relationship;
- unclear plot logic;
- wrong POV.

Find root causes before rewriting prose.

Prefer the lightest effective intervention.

Do not rewrite functioning material merely because improvement is theoretically possible.

---

# 37. STATE UPDATE RULE

After accepted material, extract durable changes only.

Update relevant records for:

- time;
- location;
- physical state;
- important objects/resources;
- knowledge;
- secrets;
- character state;
- relationship state;
- world state;
- open consequences;
- setups/payoffs.

Do not record trivial temporary details unless they may matter later.

---

# 38. CHAPTER SUMMARY RULE

After completed chapters, preserve a concise change-focused summary.

Focus on:

- decisions;
- revelations;
- changed goals;
- relationship movement;
- physical/world changes;
- setups/payoffs;
- unresolved consequences.

Summaries should describe **what changed**, not merely list actions.

---

# 39. AUDIT MODES

Keep drafting and auditing distinct.

### POST-DRAFT AUDIT
Local scene/chapter quality.

### PATTERN AUDIT
Repeated prose, emotional, dialogue, scene, and plot habits across multiple chapters.

### LONG-RANGE AUDIT
Causal accumulation, arcs, subplots, world consequences, pacing, setups/payoffs, middle-book drift.

### ARTISTIC-IDENTITY PASS
Voice, attention, work-specific choices, anti-homogenization.

Do not run every audit after every scene.

---

# 40. LONG-FORM ACCUMULATION RULE

Periodically ask:

> What is permanently different from earlier in the novel?

Characters should remember.

Relationships should remember.

Bodies should remember.

Institutions should remember.

The world should remember.

Later story should become increasingly difficult to transplant into another novel because it depends on accumulated history.

---

# 41. UNKNOWN INFORMATION

Do not invent canon solely because a field or template exists.

Distinguish:

### KNOWN
Established.

### INFERRED
Reasonable but not explicit.

### UNKNOWN
Not established.

### PROVISIONAL
Temporary working choice.

### PROPOSED
New option not yet accepted.

Major story decisions should not be silently invented merely to finish a paragraph.

---

# 42. USER-FACING BEHAVIOR

If the user requests prose:

give prose.

Do not automatically show:

- retrieval notes;
- pre-writing checklist;
- audit report;
- ledger entries.

Perform operational preparation silently unless the user requests analysis.

If the user requests planning, critique, diagnosis, continuity analysis, or alternatives, show the relevant reasoning and structure.

---

# 43. DO NOT OVER-MANAGE THE AUTHOR

Do not require the author to fill every template before beginning.

Use minimum viable preparation.

Allow discovery.

When information becomes important, develop it then.

The system exists to support creative work, not create administrative burden.

---

# 44. DO NOT TREAT THE OUTLINE AS SUPERIOR TO THE STORY

If drafting reveals a stronger development:

1. test it against canon;
2. test it against character;
3. test its consequences;
4. accept it if stronger;
5. update planning and state.

Planning is provisional until the story establishes otherwise.

---

# 45. CENTRAL OPERATING QUESTIONS

When uncertain, return to:

> What is true right now?

> What does this character want?

> What do they know?

> What do they misunderstand?

> What happened previously that matters here?

> What does this choice cause?

> What becomes newly true afterward?

> Why does this belong specifically to this novel?

These questions outrank superficial attempts to make prose appear sophisticated or “non-AI.”

---

# 46. FINAL PRINCIPLE

Do not try to write “human-looking” fiction.

Do not chase or suppress isolated AI-associated stylistic markers.

Write fiction that continuously accumulates:

- specificity;
- causality;
- memory;
- character history;
- relationship history;
- consequence;
- world state;
- thematic tension;
- and artistic identity.

The strongest defense against generic generation is a novel whose next good choice increasingly depends on **what this particular novel has already become**.

This is deliberately much smaller than the combined system. **This is the document designed to become the actual command layer of the Project**, while the Constitution, taxonomy, templates, protocols, and audits remain the deeper `.md` reference system.

We should **not paste it into the Project yet**. The final stage is now to examine everything we've built and decide the actual architecture: which files get uploaded, what gets merged, whether some of the large files should remain separate, what belongs directly in Project Instructions, what gets created only when a specific novel begins, and how dynamic state should be handled.

**Remaining system-building stage:**
1. **Project Assembly & File Placement — final architecture for putting all saved `.md` documents into the ChatGPT Project**

## User

lets go 

## ChatGPT

I’m at the final assembly stage now. I’ll separate the system into **Project Instructions**, **permanent reference `.md` files**, and **novel-specific working files**, then define the exact startup and ongoing workflow so you know what to upload when you begin a story.

## ChatGPT

The key architectural choice is clear: **keep your original `.md` documents as the master library, but do not upload every master file individually into every novel project.** We should create a smaller set of upload bundles from them, while keeping the detailed originals intact outside the project.

## ChatGPT

I verified the current ChatGPT Projects behavior before locking this architecture. Projects currently support project-specific instructions, uploaded sources, saving chat responses as project sources, and default or project-only memory when the relevant memory settings are enabled. File limits are currently plan-dependent: **5 files on Free, 25 on Go/Plus, and 40 on Edu/Pro/Business/Enterprise**, so the architecture below includes both a full layout and a 5-file compact layout. ([OpenAI Help Center](https://help.openai.com/en/articles/10169521-using-projects-in-chatgpt%252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252523.ejs))

Suggested filename: **`13-project-assembly-and-file-placement.md`**

# PROJECT ASSEMBLY & FILE PLACEMENT

## Purpose

This document defines the final architecture for deploying the fiction-writing system inside ChatGPT Projects.

The complete system now contains three fundamentally different things:

1. the reusable fiction-writing operating system;
2. the files belonging to one particular novel;
3. changing state created while that novel is written.

These should not be mixed indiscriminately.

The goal is to create a project that gives ChatGPT enough information to preserve the novel without flooding every writing task with the entire system.

The central architecture is:

> MASTER LIBRARY OUTSIDE THE NOVEL PROJECT 
> → COMPACT PROJECT INSTRUCTIONS 
> → SELECTED UNIVERSAL REFERENCE FILES 
> → NOVEL-SPECIFIC FILES 
> → ACTIVE STORY STATE 
> → ACCEPTED MANUSCRIPT 
> → CHATS FOR ACTUAL WORK

---

# 1. ONE NOVEL = ONE CHATGPT PROJECT

The recommended architecture is:

> Create a separate ChatGPT Project for each novel or major independent story.

Do not place many unrelated novels into one writing project.

The universal writing system can be reused across projects.

The novel-specific information should remain isolated.

This reduces:

- character contamination;
- worldbuilding contamination;
- voice contamination;
- accidental reuse of obsolete ideas;
- retrieval from the wrong story.

For example:

`Novel — Ashes of Meridian`

`Novel — Glass Kingdom`

`Novel — The Last Pilgrim`

Each receives its own project.

---

# 2. KEEP A MASTER FICTION SYSTEM OUTSIDE THE NOVEL PROJECTS

Your individually saved `.md` files should remain your **Master Fiction System**.

Do not destroy or overwrite these files merely because we later merge some of them for upload.

Recommended local structure:

```text
FICTION-WRITING-SYSTEM/
│
├── MASTER-SYSTEM/
│   ├── project-constitution.md
│   ├── 01-project-architecture-and-retrieval-system.md
│   ├── 02-reusable-story-bible-template.md
│   ├── 03-reusable-continuity-and-knowledge-ledgers.md
│   ├── 04-reusable-character-and-relationship-state-system.md
│   ├── 05-reusable-scene-and-chapter-state-system.md
│   ├── 06-pre-writing-gate.md
│   ├── 07-drafting-protocol.md
│   ├── 08-post-draft-audit.md
│   ├── 09-anti-repetition-and-pattern-audit.md
│   ├── 10-long-range-narrative-audit.md
│   ├── 11-artistic-identity-and-anti-homogenization-pass.md
│   ├── 12-compact-project-instructions.md
│   └── 13-project-assembly-and-file-placement.md
│
├── TAXONOMY/
│   ├── domain-01-narrative-intentionality.md
│   ├── domain-02-prose-syntax-rhythm.md
│   ├── domain-03-description-imagery-sensory-selection.md
│   ├── domain-04-emotion-interiority-subtext.md
│   ├── domain-05-dialogue-conversational-dynamics.md
│   ├── domain-06-character-identity-cognition-development.md
│   ├── domain-07-pov-knowledge-information-boundaries.md
│   ├── domain-08-relationships-social-world.md
│   ├── domain-09-scene-design-dramatic-movement.md
│   ├── domain-10-pacing-tension-escalation.md
│   ├── domain-11-plot-causality-subplots-payoff.md
│   ├── domain-12-continuity-world-logic-embodied-reality.md
│   └── domain-13-theme-symbolism-genre-artistic-identity.md
│
└── RESEARCH-ARCHIVE/
    └── Research-AI-Writing-Problems.txt
```

The exact filenames may differ from the files already saved.

The important part is the conceptual organization.

---

# 3. DO NOT UPLOAD THE ENTIRE MASTER LIBRARY DIRECTLY

The Master Library is the source system.

The novel project should receive a **deployment version** of that system.

Why?

Uploading every document separately would create:

- unnecessary file count;
- retrieval fragmentation;
- overlapping instructions;
- excessive context;
- greater chance of irrelevant guidance surfacing.

Therefore:

> Preserve detailed originals locally.

> Create consolidated upload bundles for actual novel projects.

---

# 4. PROJECT INSTRUCTIONS

The contents of:

`12-compact-project-instructions.md`

should be placed into the project's **Project Instructions** field.

Do not normally upload the same file again as a project source.

That would duplicate the command layer.

The Project Instructions are the routing system.

They tell ChatGPT:

- how to prioritize canon;
- when to retrieve;
- how to distinguish state from identity;
- how to draft;
- when to audit;
- how to interpret the reference system.

---

# 5. WHAT SHOULD NOT GO INTO PROJECT INSTRUCTIONS

Do not paste:

- all 130 lenses;
- complete Story Bible template;
- all audit procedures;
- full research;
- all continuity templates;
- huge lists of AI-writing problems.

Project Instructions should remain the compact command layer.

Detailed material belongs in project sources.

---

# 6. UNIVERSAL UPLOAD BUNDLES

For a normal full deployment, consolidate the universal system into approximately seven permanent project sources.

---

## `CORE-01-fiction-constitution.md`

Contains:

- full Project Constitution.

Purpose:

Provides deeper principles when the compact Project Instructions need interpretation.

---

## `REF-01-prose-description-and-emotion.md`

Contains:

### Domain 1
Narrative Intentionality & Selection

### Domain 2
Prose, Syntax & Rhythm

### Domain 3
Description, Imagery & Sensory Selection

### Domain 4
Emotion, Interiority & Subtext

Purpose:

Sentence-, paragraph-, description-, and emotional-level guidance.

---

## `REF-02-character-dialogue-pov-and-social.md`

Contains:

### Domain 5
Dialogue & Conversational Dynamics

### Domain 6
Character Identity, Cognition & Development

### Domain 7
POV, Knowledge & Information Boundaries

### Domain 8
Relationships & Social World

Purpose:

Character-centered retrieval.

---

## `REF-03-scenes-pacing-and-plot.md`

Contains:

### Domain 9
Scene Design & Dramatic Movement

### Domain 10
Pacing, Tension & Escalation

### Domain 11
Plot, Causality, Subplots & Payoff

Purpose:

Structural story guidance.

---

## `REF-04-continuity-theme-and-artistic-identity.md`

Contains:

### Domain 12
Continuity, World Logic & Embodied Reality

### Domain 13
Theme, Symbolism, Genre & Artistic Identity

Purpose:

Global coherence and identity.

---

## `OPS-01-drafting-workflow.md`

Contains:

### Pre-Writing Gate

### Drafting Protocol

### Post-Draft Audit

Purpose:

The normal writing loop.

---

## `OPS-02-global-audits.md`

Contains:

### Anti-Repetition / Pattern Audit

### Long-Range Narrative Audit

### Artistic-Identity / Anti-Homogenization Pass

Purpose:

Periodic global analysis.

---

# 7. UNIVERSAL FILES THAT SHOULD REMAIN OUTSIDE THE NOVEL PROJECT

These are useful master documents but do not normally need uploading:

## Project Architecture & Retrieval System

Its important operational rules have already been compressed into Project Instructions.

Keep it in the Master Library.

---

## Blank Story Bible Template

Use it to build the novel's actual Story Bible.

Once an actual Story Bible exists, the blank template should not remain active in the novel project.

---

## Blank Ledger Templates

Use them to construct the novel's active state system.

Do not make ChatGPT retrieve blank placeholders during normal drafting.

---

## Blank Character/Relationship State Template

Same principle.

---

## Blank Scene/Chapter State Template

Same principle.

---

## Raw research

Keep:

`Research-AI-Writing-Problems.txt`

in the Research Archive.

The taxonomy already represents the operational conclusions from that research.

Do not make raw discussions and complaints compete with the final guidance during every chapter.

Retrieve the research again only if:

- the system itself is being redesigned;
- a new AI-writing problem is being investigated;
- research claims need verification.

---

# 8. NOVEL-SPECIFIC PROJECT FILES

Once a particular novel begins, create a second layer of files.

These files belong only to that novel.

---

## `NOVEL-00-core-identity.md`

This should be small and high priority.

Contains:

### Title

### Premise

### Central story promise

### Genre contract

### POV system

### Governing artistic identity

### Author priorities

### Author non-priorities

### Canon locks

### Work-specific warning flags

### Important stylistic/structural qualities to preserve

Purpose:

Give ChatGPT a fast answer to:

> What novel are we writing?

This should normally remain much smaller than the full Story Bible.

---

# 9. `NOVEL-01-story-bible.md`

The full populated Story Bible.

Contains only relevant sections from the reusable Story Bible template.

Possible contents:

- characters;
- world;
- cultures;
- institutions;
- history;
- magic;
- technology;
- plot architecture;
- major relationships;
- subplots;
- thematic framework;
- important objects;
- terminology.

Do not fill every template section merely because it exists.

---

# 10. OPTIONAL `NOVEL-02-plot-architecture.md`

For simple novels, keep plot architecture inside the Story Bible.

For highly complex novels, separate it.

Possible contents:

- major arcs;
- subplot architecture;
- planned revelations;
- major setups/payoffs;
- endgame direction;
- working future events.

Remember:

planned material is not necessarily locked canon.

Label planning levels.

---

# 11. `STATE-00-current-story-state.md`

This should be one of the most important files in the entire project.

Keep it short.

It answers:

> What is true right now?

Suggested contents:

```markdown
# CURRENT STORY STATE

## Current Time

## Current Locations

## Active POV / Current Chapter

## Major Character Goals

## Major Physical Conditions

## Important Object Possession

## Recent Knowledge Changes

## Active Secrets

## Current Relationship Pressures

## Important World-State Changes

## Immediate Open Consequences

## Active Deadlines

## Immediate Open Threads

## Latest Major Changes
```

This is the file normal drafting should retrieve most frequently.

---

# 12. `STATE-01-continuity-and-knowledge.md`

Contains the deeper active ledgers.

Possible sections:

- timeline;
- location;
- physical state;
- important objects/resources;
- knowledge;
- secrets;
- information flow;
- world state;
- institutions;
- reputation;
- important numerical continuity.

Do not let resolved trivial information dominate the active version.

Archive old history externally if necessary.

---

# 13. `STATE-02-characters-and-relationships.md`

Contains:

- current major character states;
- development status;
- current beliefs;
- active emotional residue;
- current goals;
- major relationship states;
- trust;
- intimacy;
- resentment;
- obligations;
- power;
- unresolved conflicts;
- recent milestones.

It should answer:

> Who are these people now?

---

# 14. `STATE-03-open-threads.md`

Recommended for complex novels.

Contains:

## Open consequences

## Active setups

## Payoffs still owed

## Mysteries

## Promises

## Debts/obligations

## Active subplots

## Dormant threads

## Intentional unresolved material

Purpose:

Prevent narrative obligations from disappearing.

For simpler novels, merge this into `STATE-00` or `STATE-01`.

---

# 15. `PROGRESS-00-chapter-summaries.md`

Contains concise, change-focused chapter summaries.

Each chapter record should capture:

- major decisions;
- revelations;
- changed goals;
- relationship movement;
- physical/world changes;
- setups/payoffs;
- consequences;
- important continuity.

Do not merely recount action.

This becomes the long-range retrieval bridge.

---

# 16. ACCEPTED MANUSCRIPT FILES

Accepted prose is the highest-authority story source.

The project should eventually contain the manuscript itself.

For short or moderate novels:

`MANUSCRIPT-current.md`

may be sufficient.

For long novels, split by natural sections rather than creating one source per chapter.

Example:

```text
MANUSCRIPT-01-chapters-001-010.md
MANUSCRIPT-02-chapters-011-020.md
MANUSCRIPT-03-chapters-021-030.md
```

Or preferably by arc:

```text
MANUSCRIPT-01-opening-arc.md
MANUSCRIPT-02-succession-arc.md
MANUSCRIPT-03-war-arc.md
```

Do not create dozens of tiny manuscript sources unnecessarily.

---

# 17. WHY MANUSCRIPT FILES MATTER

Project memory and summaries are useful.

Neither should replace accepted prose when exact truth matters.

The manuscript provides:

- exact wording;
- scene nuance;
- established facts;
- voice;
- implied meaning;
- details summaries may omit.

Therefore:

> Accepted prose remains authoritative.

Summaries accelerate retrieval.

They do not replace the novel.

---

# 18. AUDIT FILES SHOULD USUALLY BE TEMPORARY

Do not permanently accumulate:

`audit-v1`

`audit-v2`

`audit-v3`

inside the project.

Old audits may describe problems that have already been repaired.

This creates stale guidance.

Instead, when active revision requires it, maintain:

`AUDIT-active-revision-priorities.md`

containing only unresolved findings.

Once resolved:

remove or archive it outside the active project.

---

# 19. DO NOT KEEP MULTIPLE ACTIVE VERSIONS OF STATE

This is extremely important.

Bad:

```text
STATE-current-v3.md
STATE-current-v4.md
STATE-current-FINAL.md
STATE-current-FINAL2.md
```

All uploaded simultaneously.

Retrieval may surface outdated state.

Instead, inside the project maintain only:

`STATE-00-current-story-state.md`

The version history can remain outside the project.

---

# 20. SAME RULE FOR STORY BIBLE

Do not keep:

```text
story-bible-old.md
story-bible-new.md
story-bible-revised.md
story-bible-final.md
```

inside active project context.

Keep exactly one authoritative current version.

---

# 21. ACTIVE FILE VS ARCHIVE PRINCIPLE

Inside the project:

> Current truth only.

Outside the project:

> History and backups.

This should apply to:

- Story Bible;
- state;
- ledgers;
- chapter summaries;
- plot architecture;
- audit findings.

The manuscript itself naturally preserves historical story events.

---

# 22. FULL PROJECT LAYOUT

A mature novel project might therefore contain:

```text
PROJECT INSTRUCTIONS
└── contents of 12-compact-project-instructions.md


UNIVERSAL SOURCES
├── CORE-01-fiction-constitution.md
├── REF-01-prose-description-and-emotion.md
├── REF-02-character-dialogue-pov-and-social.md
├── REF-03-scenes-pacing-and-plot.md
├── REF-04-continuity-theme-and-artistic-identity.md
├── OPS-01-drafting-workflow.md
└── OPS-02-global-audits.md


NOVEL FOUNDATION
├── NOVEL-00-core-identity.md
├── NOVEL-01-story-bible.md
└── NOVEL-02-plot-architecture.md       [optional]


ACTIVE STATE
├── STATE-00-current-story-state.md
├── STATE-01-continuity-and-knowledge.md
├── STATE-02-characters-and-relationships.md
└── STATE-03-open-threads.md            [optional]


PROGRESS
└── PROGRESS-00-chapter-summaries.md


MANUSCRIPT
├── MANUSCRIPT-01-opening-arc.md
├── MANUSCRIPT-02-middle-arc.md
└── MANUSCRIPT-03-final-arc.md


TEMPORARY
└── AUDIT-active-revision-priorities.md [only when needed]
```

This is the recommended full architecture.

---

# 23. DO NOT CREATE ALL NOVEL FILES ON DAY ONE

At the beginning, the project may contain only:

```text
Project Instructions

Universal reference bundles

NOVEL-00-core-identity.md
NOVEL-01-story-bible.md
STATE-00-current-story-state.md
```

Then files appear only as complexity requires them.

For example:

knowledge ledger becomes important

→ create deeper continuity state.

Subplots become complex

→ create open-thread file.

Manuscript grows

→ split into arc files.

The architecture should scale with the novel.

---

# 24. COMPACT FIVE-SOURCE ARCHITECTURE

If project file capacity is limited, use a five-file version.

---

## FILE 1

`SYSTEM-fiction-reference.md`

Merge:

- Project Constitution;
- all 13 taxonomy domains.

---

## FILE 2

`SYSTEM-writing-operations.md`

Merge:

- Pre-Writing Gate;
- Drafting Protocol;
- Post-Draft Audit;
- Pattern Audit;
- Long-Range Audit;
- Artistic-Identity Pass.

---

## FILE 3

`NOVEL-story-bible.md`

Merge:

- Core Identity;
- Story Bible;
- plot architecture if needed.

---

## FILE 4

`STATE-current-novel.md`

Merge:

- current story state;
- continuity;
- knowledge;
- character state;
- relationship state;
- open threads;
- latest chapter summaries.

Keep the most current information near the top.

---

## FILE 5

`MANUSCRIPT-current.md`

Accepted manuscript.

For very long works, old manuscript material may eventually require a different deployment strategy, but this is the minimum viable project.

Project Instructions remain in the Project Instructions field rather than consuming a source slot.

---

# 25. FULL VS COMPACT SYSTEM

## Use the full system when:

- many source files are available;
- the novel is complex;
- cast is large;
- worldbuilding is substantial;
- project is long-running.

## Use compact system when:

- file count is constrained;
- novel is simpler;
- project is still early;
- minimizing retrieval fragmentation is more valuable.

The conceptual operating system remains identical.

Only packaging changes.

---

# 26. RECOMMENDED DEFAULT

When file capacity permits, use the **Full Architecture**.

It gives enough separation for selective retrieval without creating dozens of files.

Do not upload all original documents individually.

Use consolidated bundles.

---

# 27. MEMORY SETTING

The system should not depend entirely on ChatGPT memory.

Files and accepted manuscript remain the explicit authority.

If the project supports an isolated project memory mode and the author wants isolation, using project-only memory is suitable because unrelated conversations should not influence the novel.

If memory is unavailable or disabled, the architecture should still work.

In that case the explicit files become even more important.

---

# 28. CHAT ORGANIZATION

Do not put every activity into one enormous conversation.

Recommended separation:

## `00 — Novel Development`

Use for:

- premise;
- Story Bible;
- characters;
- planning;
- canon decisions.

---

## `10 — Drafting — Arc 1`

Actual prose.

---

## `11 — Drafting — Arc 2`

New drafting chat when the previous arc becomes very long.

---

## `80 — Revision`

Large revisions.

---

## `90 — Audits`

Pattern audits, long-range audits, continuity diagnostics.

Separating audit mode from drafting mode helps prevent analytical behavior from dominating prose generation.

---

# 29. DO NOT CREATE ONE CHAT PER SCENE BY DEFAULT

A drafting chat benefits from immediate local continuity.

Prefer one drafting conversation for a reasonable narrative segment such as:

- several chapters;
- one arc;
- one major phase.

When the conversation becomes unwieldy, begin a new drafting chat using the updated project sources as the handoff.

---

# 30. STARTING A NEW DRAFTING CHAT

Before beginning a new drafting chat, ensure these are current:

- Story Bible;
- current story state;
- characters/relationships;
- chapter summaries;
- manuscript;
- open threads.

Then the new chat should be able to recover the story from project sources rather than depending on a giant previous conversation.

---

# 31. NOVEL CREATION WORKFLOW

When starting a new novel:

## Step 1

Create the novel's ChatGPT Project.

---

## Step 2

Paste the Compact Project Instructions into Project Instructions.

---

## Step 3

Upload the universal reference bundles.

---

## Step 4

Use the reusable Story Bible template outside the active project context to develop:

`NOVEL-00-core-identity.md`

and

`NOVEL-01-story-bible.md`

---

## Step 5

Establish the opening state.

Create:

`STATE-00-current-story-state.md`

---

## Step 6

If complexity requires it, create:

`STATE-01-continuity-and-knowledge.md`

and

`STATE-02-characters-and-relationships.md`

---

## Step 7

Create initial plot architecture only to the level useful for the story.

Do not overplan merely because a template exists.

---

## Step 8

Begin drafting.

---

# 32. NORMAL CHAPTER WORKFLOW

The normal operational loop becomes:

```text
RETRIEVE
↓
PRE-WRITING GATE
↓
DRAFT
↓
POST-DRAFT AUDIT
↓
AUTHOR ACCEPTS / REVISES
↓
UPDATE MANUSCRIPT
↓
UPDATE CHAPTER SUMMARY
↓
UPDATE CURRENT STATE
↓
UPDATE ONLY AFFECTED LEDGERS
↓
NEXT CHAPTER
```

This is the central long-form production loop.

---

# 33. IMPORTANT: UPDATE STATE AFTER ACCEPTANCE, NOT EVERY GENERATED VERSION

Suppose ChatGPT generates Chapter 12 three times.

Do not update continuity from Draft 1.

Then update again from Draft 2.

Wait until the author accepts the version that becomes story canon.

Then update state.

Otherwise abandoned draft material can contaminate the continuity system.

---

# 34. END-OF-CHAPTER UPDATE PACKAGE

After a chapter is accepted, the system should be able to produce:

## A. Manuscript insertion

Final accepted chapter.

## B. Chapter summary

Change-focused summary.

## C. Current story state update

Only changed fields.

## D. Ledger changes

Only affected continuity/knowledge entries.

## E. Character/relationship changes

Only durable changes.

## F. Open-thread changes

New, resolved, transformed, or dormant threads.

This package keeps the project synchronized.

---

# 35. USER COMMAND FOR STATE MAINTENANCE

A useful instruction after accepting a chapter is:

> Treat this chapter as accepted canon. Extract only durable changes and give me the updates required for the current story state, continuity/knowledge ledger, character/relationship state, open threads, and chapter summary. Do not invent changes not established in the chapter.

This helps maintain the `.md` files reliably.

---

# 36. REPLACING DYNAMIC SOURCES

When a dynamic `.md` file changes:

1. update your canonical local copy;
2. replace the active project source with the updated copy;
3. avoid leaving the old active version alongside it.

Do not use the project itself as your only backup.

Keep your master copy externally.

---

# 37. VERSION HISTORY

Outside the project, versioning is useful.

Example:

```text
ARCHIVE/
├── STATE-00-2026-09-15.md
├── STATE-00-2026-09-18.md
└── STATE-00-2026-09-21.md
```

Inside the project:

only:

`STATE-00-current-story-state.md`

This gives both:

- clean retrieval;
- recoverable history.

---

# 38. WHAT CHATGPT PROJECT MEMORY IS FOR

Project conversational context is useful for:

- recent discussions;
- preferences;
- decisions;
- ongoing work.

It should not be treated as the only source of exact canon.

The explicit `.md` architecture exists because exact long-form fiction requires more reliable state separation.

Think of memory as:

> supportive context.

Think of canonical files as:

> explicit story authority.

---

# 39. RETRIEVAL AUTHORITY INSIDE THE PROJECT

When conflicting information appears, use approximately:

1. explicit current author instruction;
2. accepted manuscript;
3. current canonical Story Bible;
4. current active state files;
5. current approved plot planning;
6. chapter summaries;
7. old conversation context;
8. universal craft guidance;
9. generic model assumptions.

This protects story truth.

---

# 40. DO NOT LET REFERENCE GUIDANCE BECOME CANON

The taxonomy says what fiction **may benefit from**.

It does not dictate what happened in this story.

Novel-specific files always outrank generic guidance regarding story facts.

---

# 41. DO NOT LET PLANNING BECOME CANON AUTOMATICALLY

If a plot file says:

> `[WORKING] Mara betrays Elias during the siege.`

but drafting discovers a stronger direction, that plan can change.

If the accepted manuscript establishes something different:

the manuscript wins.

Update the plan afterward.

---

# 42. KEEP CURRENT STATE SMALL

A critical architectural rule:

> Current state should be much smaller than historical story records.

Current state should answer:

- what matters now?

Chapter summaries answer:

- what happened previously?

Manuscript answers:

- exactly how did it happen?

Do not put all three into the same layer unless file constraints require it.

---

# 43. ARCHIVE RESOLVED STATE

Do not let active ledgers contain hundreds of:

- healed injuries;
- resolved secrets;
- completed promises;
- obsolete goals.

Old information should remain recoverable through:

- chapter summaries;
- manuscript;
- external archive.

Active files should remain useful.

---

# 44. PERIODIC AUDIT SCHEDULE

Do not audit everything constantly.

Recommended:

## Local Post-Draft Audit

After important scenes/chapters.

## Pattern Audit

After several chapters or when repetition becomes noticeable.

## Long-Range Audit

At:

- arc boundaries;
- roughly quarter points;
- midpoint;
- before ending.

## Artistic-Identity Pass

After major arcs and especially after large revisions.

These are guidelines, not fixed quotas.

---

# 45. AUDIT OUTPUT SHOULD NOT REMAIN ACTIVE FOREVER

After audit:

1. identify major unresolved findings;
2. put only those into `AUDIT-active-revision-priorities.md`;
3. make revisions;
4. remove resolved findings;
5. remove audit file when no longer needed.

This prevents the model from permanently writing defensively around old problems.

---

# 46. WHEN REVISING OLD CHAPTERS

If an earlier accepted chapter changes materially:

check whether it alters:

- canon;
- character development;
- knowledge;
- relationship history;
- objects;
- timeline;
- later consequences.

Then update downstream state.

Revision can change the story's history.

---

# 47. MANUSCRIPT SEGMENTATION RULE

Do not split manuscript mechanically if unnecessary.

Split when:

- one file becomes unwieldy;
- an arc naturally closes;
- retrieval benefits from meaningful segmentation.

Prefer semantic segmentation:

`Opening Arc`

over arbitrary tiny files.

---

# 48. PROJECT FILE NAMING RULE

Use prefixes so the purpose of every source is immediately visible.

Recommended:

### `CORE-`
Universal governing principles.

### `REF-`
Deep reference guidance.

### `OPS-`
Operational protocols.

### `NOVEL-`
Stable novel-specific information.

### `STATE-`
Dynamic story state.

### `PROGRESS-`
Summaries and progression records.

### `MANUSCRIPT-`
Accepted prose.

### `AUDIT-`
Temporary diagnostics.

This makes both human and model retrieval easier.

---

# 49. PROJECT SOURCE ORDER

If the interface allows convenient ordering or naming, think of sources in this priority:

```text
CORE
REF
OPS
NOVEL
STATE
PROGRESS
MANUSCRIPT
AUDIT
```

This is organizational.

Retrieval authority still follows the explicit hierarchy defined earlier.

---

# 50. WHAT TO DO WITH THE ORIGINAL RESEARCH

Keep the research permanently.

Do not discard it after building the system.

It remains useful for:

- validating why a guidance rule exists;
- future system revisions;
- discovering additional failure modes;
- comparing new AI-writing behavior.

But it belongs to the **system-development archive**, not normal drafting context.

---

# 51. WHAT TO DO WITH THE 130-LENS TAXONOMY

Keep every original domain file.

For deployment, merge them into the four reference bundles.

This creates two levels:

### MASTER LEVEL

13 separate domain files.

Easy to edit or expand.

### DEPLOYMENT LEVEL

4 merged reference files.

Easy for ChatGPT Projects to retrieve efficiently.

Never lose the master level.

---

# 52. WHAT TO DO WITH THE REUSABLE TEMPLATES

Keep:

- Story Bible template;
- continuity template;
- character/relationship template;
- scene/chapter template

in the Master System.

When a new novel begins:

use them to create novel-specific files.

Then the templates can remain outside active project context.

---

# 53. WHAT TO DO WITH THE OPERATIONAL DOCUMENTS

The six operational documents should exist individually in the master system:

- Pre-Writing Gate;
- Drafting Protocol;
- Post-Draft Audit;
- Pattern Audit;
- Long-Range Audit;
- Artistic-Identity Pass.

For project deployment, merge them into:

### `OPS-01-drafting-workflow.md`

and

### `OPS-02-global-audits.md`

This preserves detailed masters while reducing project source count.

---

# 54. WHAT TO DO WITH THE PROJECT CONSTITUTION

Keep the full Constitution as:

`CORE-01-fiction-constitution.md`

inside the deployed project.

Its compressed operational form lives inside Project Instructions.

This intentional duplication is different from accidental duplication:

### Project Instructions

Fast command layer.

### Full Constitution

Deeper reference for ambiguous situations.

---

# 55. WHAT TO DO WITH THE ARCHITECTURE DOCUMENT

Keep this architecture and the earlier Retrieval Architecture document in the Master System.

They do not normally need to consume project source capacity.

Their operational rules are already represented in the Compact Project Instructions.

---

# 56. FIRST PROJECT BOOTSTRAP

When creating the first real novel using this system, do **not** begin by uploading thirty files.

Start with:

### Project Instructions

Compact instructions.

### Universal deployment bundles

Core + References + Operations.

### Then create:

`NOVEL-00-core-identity.md`

`NOVEL-01-story-bible.md`

`STATE-00-current-story-state.md`

And begin building the story.

Let additional state files emerge as needed.

---

# 57. MINIMUM VIABLE NOVEL PROJECT

A simple novel can operate with:

```text
PROJECT INSTRUCTIONS

CORE-01-fiction-constitution.md
REF-fiction-guidance.md
OPS-writing-system.md
NOVEL-story-bible.md
STATE-current.md
MANUSCRIPT-current.md
```

If source limits require further consolidation, combine intelligently.

The architecture matters more than the exact number of files.

---

# 58. COMPLEX NOVEL PROJECT

A large epic, serial, progression fantasy, political saga, or mystery may justify:

- separate knowledge ledger;
- separate character/relationship state;
- open-thread file;
- multiple manuscript arc files;
- plot architecture;
- temporary audit priorities.

Scale the system according to actual complexity.

---

# 59. DO NOT CREATE ADMINISTRATION FOR ITS OWN SAKE

Every file must justify itself.

Before creating a new active file ask:

> Is important information becoming difficult to retrieve from the existing structure?

If no:

do not create another file.

The system should reduce cognitive burden rather than increase it.

---

# 60. FINAL ARCHITECTURE

The complete operating system is:

```text
MASTER FICTION SYSTEM
        │
        ├── Research Archive
        ├── Project Constitution
        ├── 13-Domain Taxonomy
        ├── Reusable Templates
        ├── Operational Protocols
        └── Compact Project Instructions
                 │
                 ▼
        NEW NOVEL PROJECT
                 │
        ┌────────┴────────┐
        │                 │
PROJECT INSTRUCTIONS   UNIVERSAL SOURCES
        │                 │
        └────────┬────────┘
                 ▼
          NOVEL FOUNDATION
                 │
        ┌────────┴────────┐
        │                 │
   STORY BIBLE       CORE IDENTITY
        │                 │
        └────────┬────────┘
                 ▼
            ACTIVE STATE
                 │
        ┌────────┼─────────┐
        │        │         │
   Continuity  Character  Open Threads
        │        │         │
        └────────┼─────────┘
                 ▼
             DRAFTING
                 │
                 ▼
          ACCEPTED MANUSCRIPT
                 │
                 ▼
        STATE + SUMMARY UPDATE
                 │
                 ▼
             NEXT DRAFT
                 │
                 ▼
        PERIODIC GLOBAL AUDITS
                 │
                 ▼
             REVISION
                 │
                 └──────► loop
```

---

# 61. THE CENTRAL DEPLOYMENT PRINCIPLE

Do not make ChatGPT remember everything equally.

Instead create a hierarchy:

### Instructions tell it how to operate.

### Reference files tell it how to reason about fiction.

### Story Bible tells it what novel exists.

### State files tell it what is true now.

### Chapter summaries tell it what changed before.

### Manuscript tells it exactly what was written.

### Audits tell it what currently needs repair.

Each information type has a different job.

That separation is the core of the entire system.

---

# 62. FINAL REMINDER

This fiction system should never become more important than the fiction.

Its purpose is to make long-form AI-assisted writing better at:

- remembering;
- differentiating;
- accumulating;
- preserving consequence;
- respecting character;
- maintaining canon;
- sustaining voice;
- and developing work-specific identity.

It should operate mostly beneath the surface.

The reader should not see:

- ledgers;
- retrieval;
- taxonomies;
- audits;
- state updates.

The reader should experience the result:

a story that seems to remember itself;

characters who possess histories;

relationships that accumulate;

a world that responds;

prose that belongs to its viewpoint;

and a novel that becomes increasingly difficult to mistake for any other novel.

That is the purpose of the architecture.

That completes the **entire system-building phase**.

The one thing I would do **before starting the first actual novel** is a mechanical packaging pass: take the individual `.md` documents you have saved and create the seven deployment bundles defined above. You would still keep all the originals. The bundles are just the versions uploaded into each novel Project.

One current-product point matters for maintaining dynamic state: Projects let you add and remove project sources, and they also let you save useful chat responses as project sources. Because stale state is dangerous for this system, I would keep **only the latest active Story Bible/state files in the project**, while retaining older versions in your own archive. ([OpenAI Help Center](https://help.openai.com/en/articles/10169521-using-projects-in-chatgpt%252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252525252523.ejs))

**Remaining system-building stages: None.**

The fiction operating system is complete.

## User

what if i zipped them into one and put it in the source of the project

## ChatGPT

I would **not use a `.zip` as the Project source** for this system.

ChatGPT Projects’ current documentation describes project sources as uploaded documents, PDFs, spreadsheets, images, and pasted text. OpenAI’s general file-upload documentation likewise focuses on supported document/text file types. It does **not** document ZIP archives as containers that Projects automatically unpack, index, and retrieve from. ZIP import exists in a different OpenAI product, Prism, but that does not establish ZIP support for ChatGPT Project sources. ([OpenAI Help Center](https://help.openai.com/en/articles/8555545?utm_source=chatgpt.com))

So if you made:

```text
fiction-system.zip
├── constitution.md
├── taxonomy-01.md
├── taxonomy-02.md
├── ...
├── drafting-protocol.md
└── audits.md
```

even if the UI happened to accept the archive, I would **not trust the Project retrieval system to treat those internal Markdown files as separately searchable knowledge sources**. That defeats the reason we're building the architecture.

### But your underlying idea is good

If what you want is:

> “Can I turn all these system files into one source so they only consume one Project file slot?”

Then yes—but **merge them into one Markdown file instead of zipping them**.

For example:

```text
FICTION-SYSTEM-COMPLETE.md
```

with:

```markdown
# FICTION WRITING SYSTEM

# PART I — PROJECT CONSTITUTION
...

# PART II — NARRATIVE INTENTIONALITY
...

# PART III — PROSE, SYNTAX & RHYTHM
...

# PART IV — DESCRIPTION
...

# PART V — EMOTION
...

# PART VI — DIALOGUE
...

# PART VII — CHARACTERS
...

# PART VIII — POV & KNOWLEDGE
...

# PART IX — RELATIONSHIPS
...

# PART X — SCENE DESIGN
...

# PART XI — PACING
...

# PART XII — PLOT
...

# PART XIII — CONTINUITY
...

# PART XIV — THEME & ARTISTIC IDENTITY
...

# PART XV — PRE-WRITING GATE
...

# PART XVI — DRAFTING PROTOCOL
...

# PART XVII — POST-DRAFT AUDIT
...

# PART XVIII — PATTERN AUDIT
...

# PART XIX — LONG-RANGE AUDIT
...

# PART XX — ARTISTIC-IDENTITY PASS
...
```

That would genuinely count as **one document source**, while the text inside remains directly indexable and retrievable.

There is a per-file ceiling: text/document files can be up to **512 MB and 2 million tokens per file**, so our fiction system is nowhere close to the theoretical token limit unless the files are vastly larger than what we've produced. ([OpenAI Help Center](https://help.openai.com/en/articles/8555545?utm_source=chatgpt.com))

### In fact, I slightly prefer this approach for your setup

After thinking through how **your particular system** works, I'd modify the architecture I just gave you.

Instead of seven universal system files, I would seriously consider this arrangement:

```text
PROJECT INSTRUCTIONS
    ↓
Compact Project Instructions


SOURCE 1
FICTION-SYSTEM-COMPLETE.md
    ↓
Constitution
13-domain taxonomy
Pre-Writing Gate
Drafting Protocol
Post-Draft Audit
Pattern Audit
Long-Range Audit
Artistic Identity Pass


SOURCE 2
NOVEL-CORE.md
    ↓
Novel identity
Story Bible
Plot architecture


SOURCE 3
CURRENT-STATE.md
    ↓
Current state
Continuity
Knowledge
Characters
Relationships
Open threads


SOURCE 4
CHAPTER-SUMMARIES.md


SOURCE 5+
MANUSCRIPT-ARC-01.md
MANUSCRIPT-ARC-02.md
...
```

That is exceptionally clean.

And it solves one thing I was concerned about earlier: **file-slot pressure**. Current Projects limits are 5 project files on Free, 25 on Go/Plus, and 40 on Edu/Pro/Business/Enterprise. ([OpenAI Help Center](https://help.openai.com/en/articles/8555545?utm_source=chatgpt.com))

The system itself would consume only **one source slot**.

### Would one huge `.md` hurt retrieval?

Potentially, but not nearly enough for me to reject it here.

Our system is unusually well structured. It has distinctive headings such as:

```markdown
# DRAFTING PROTOCOL

## CHARACTER RULE

## DIALOGUE RULE

# LONG-RANGE NARRATIVE AUDIT

## CHARACTER-ARC AUDIT

## SUBPLOT AUDIT
```

That semantic organization gives retrieval strong landmarks.

And Project Instructions already tell ChatGPT **not to retrieve the whole system**. They tell it to use only the guidance relevant to the task.

So a single well-structured Markdown source is very different from dumping one unorganized 100,000-word text file into the project.

### One thing I would not merge

I would **not** merge your fiction system with the novel.

Don't make:

```text
everything.md

[all writing rules]
[story bible]
[current state]
[chapter summaries]
[entire novel]
```

That collapses information with radically different authority and update frequency.

Keep the fundamental separation:

**System**
→ how to write and reason.

**Novel**
→ what this particular story is.

**State**
→ what is currently true.

**Progress**
→ what changed previously.

**Manuscript**
→ authoritative accepted prose.

That separation matters much more than whether the universal system consists of 1 file or 7.

### So my updated recommendation is

**Do not ZIP them. Merge them.**

I would use:

```text
Project Instructions:
12-compact-project-instructions
```

Then:

```text
01-FICTION-SYSTEM-COMPLETE.md
02-NOVEL-CORE.md
03-CURRENT-STORY-STATE.md
04-CHAPTER-SUMMARIES.md
05-MANUSCRIPT-ARC-01.md
06-MANUSCRIPT-ARC-02.md
...
```

And keep your original 13+ individual `.md` files safely on your computer as the **editable master version** of the system.

So when we improve one component later, you edit its individual master file and regenerate `01-FICTION-SYSTEM-COMPLETE.md`.

That may actually be the best deployment architecture for what we've built.

## User

let refine the the way it will be organised, use the document name that was given to the download created 

## ChatGPT

I’ll base the organization on the **actual filenames inside the ZIP you already created**, rather than inventing new names. I’m checking the archive structure first, then I’ll map those exact documents into the final Project layout.

## ChatGPT

The archive gives us a useful correction before we organize it: the ZIP currently contains **24 actual documents**, and several items from the completed system are not present under the expected names. I’ll preserve the existing download names exactly and treat those gaps separately rather than silently renaming/reconstructing them.

## ChatGPT

I found an important detail in the archive itself: **`Master Fiction Guidance Taxonomy — Foundation v0.1.md` already contains the full Domain 1 expansion plus the 13-domain map**, so we should not invent a separate “Domain 1” filename. The archive also currently lacks separate downloaded files for **Domain 13**, **08 — Post-Draft Audit**, and the later **Project Assembly** document; I’ll mark those as gaps rather than pretending they are present.

## ChatGPT

Yes. Using the **actual downloaded document names** gives us a cleaner architecture than the generic names I proposed earlier.

One naming issue first: inside the ZIP, the em dash `—` has been encoded as `#U2014`. For organization purposes, I would normalize that back to `—`; the document names themselves stay the same.

Suggested filename for this organization document: **`Project Organization — Final Source Layout.md`**

# PROJECT ORGANIZATION — FINAL SOURCE LAYOUT

## 1. Core Deployment Decision

Each individual downloaded document remains preserved as its own **master file**.

For an actual novel Project, the universal system files should be combined into:

`FICTION-SYSTEM-COMPLETE.md`

This is the permanent universal reference source.

However:

`12 — Compact Project Instructions — Final Deployable Version.md`

should **not** be included in that merged source as the primary deployment method.

Its contents belong in the ChatGPT Project's **Project Instructions** field.

This creates:

```text
PROJECT INSTRUCTIONS
        ↓
12 — Compact Project Instructions — Final Deployable Version.md


PROJECT SOURCE
        ↓
FICTION-SYSTEM-COMPLETE.md
        ↓
All deeper universal system documents
```

The instructions tell ChatGPT **how to use the system**.

The source contains the system it can retrieve from.

---

# 2. Master Library

Outside ChatGPT Projects, preserve the original downloaded files individually.

Recommended master folder:

```text
FICTION-SYSTEM-MASTER/
│
├── SYSTEM/
│
├── TAXONOMY/
│
├── TEMPLATES/
│
├── OPERATIONS/
│
├── AUDITS/
│
├── DEPLOYMENT/
│
└── RESEARCH/
```

The files below should retain their original document names.

---

# 3. SYSTEM

Place these master documents here:

```text
SYSTEM/

Fiction Writing System — Project Constitution.md

01 — Project Architecture & Retrieval System.md
```

### `Fiction Writing System — Project Constitution.md`

This is the philosophical and governing foundation.

It establishes:

- story over system;
- function before appearance;
- context before rules;
- canon priority;
- character truth;
- accumulation;
- reader inference;
- artistic individuality.

---

### `01 — Project Architecture & Retrieval System.md`

This defines:

- retrieval layers;
- task routing;
- canon authority;
- static vs dynamic information;
- update cycles;
- planning vs drafting vs auditing;
- how the entire system should interact.

These two documents define the operating architecture beneath everything else.

---

# 4. TAXONOMY

Place the craft-guidance documents here.

```text
TAXONOMY/

Master Fiction Guidance Taxonomy — Foundation v0.1.md

Domain 2 — Prose, Syntax & Rhythm.md

Domain 3 — Description, Imagery & Sensory Selection.md

Domain 4 — Emotion, Interiority & Subtext.md

Domain 5 — Dialogue & Conversational Dynamics.md

Domain 6 — Character Identity, Cognition & Development.md

Domain 7 — POV, Knowledge & Information Boundaries.md

Domain 8 — Relationships & Social World.md

Domain 9 — Scene Design & Dramatic Movement.md

Domain 10 — Pacing, Tension & Escalation.md

Domain 11 — Plot, Causality, Subplots & Payoff.md

Domain 12 — Continuity, World Logic & Embodied Reality.md
```

Important:

`Master Fiction Guidance Taxonomy — Foundation v0.1.md`

already contains:

- the foundational operating principles;
- the complete 13-domain taxonomy map;
- the full detailed expansion of **Domain 1 — Narrative Intentionality & Selection**.

Therefore we do **not** need to invent a separate downloaded:

`Domain 1 — Narrative Intentionality & Selection.md`

unless we deliberately decide later to extract Domain 1 into its own file.

For now, preserve the document exactly as originally created.

---

# 5. DOMAIN 13

The complete system also developed:

`Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md`

However, that separate detailed document is **not currently present inside `FICTION-SYSTEM-COMPLETE.zip`.**

The Foundation file contains the Domain 13 lens map, but not the later full detailed Domain 13 document.

Therefore the final master system should eventually contain:

```text
Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md
```

Once recovered or recreated from the work already completed.

Do not pretend it is currently inside the archive.

---

# 6. TEMPLATES & STATE FRAMEWORKS

Place these here:

```text
TEMPLATES/

Reusable Story Bible Template.pdf

03 — Reusable Continuity & Knowledge Ledger Templates.md

04 — Reusable Character & Relationship State System.md

05 — Reusable Scene & Chapter State System.md
```

These documents are different from the taxonomy.

They define the reusable information structures used when an actual novel exists.

---

## `Reusable Story Bible Template.pdf`

This is used when establishing a new novel.

It is **not** the Story Bible of every novel.

It is the reusable template from which the novel-specific Bible is built.

Once the actual Story Bible exists, the active project should primarily use the populated Story Bible rather than repeatedly retrieving the blank template.

### Archive note

The copy currently inside the ZIP is a one-page PDF.

If that PDF was intended to contain the complete large Story Bible template we developed, it should be checked before final deployment.

The original system design contains a much more extensive Story Bible structure than a one-page document would normally suggest.

---

## `03 — Reusable Continuity & Knowledge Ledger Templates.md`

Defines reusable structures for:

- timeline;
- locations;
- physical state;
- objects;
- knowledge;
- secrets;
- world state;
- consequences;
- setups/payoffs;
- canon changes.

---

## `04 — Reusable Character & Relationship State System.md`

Defines how actual novels should track:

- changing character conditions;
- character development;
- emotional residue;
- goals;
- relationship trust;
- intimacy;
- resentment;
- obligations;
- power;
- milestones.

---

## `05 — Reusable Scene & Chapter State System.md`

Defines:

- scene state;
- chapter state;
- entry state;
- exit state;
- scene inheritance;
- chapter summaries;
- scene/chapter update routing.

---

# 7. OPERATIONS

Place the normal writing procedures here:

```text
OPERATIONS/

06 — Pre-Writing Gate.md

07 — Drafting Protocol.md

08 — Post-Draft Audit.md
```

---

## `06 — Pre-Writing Gate.md`

Runs before drafting.

It stabilizes:

- POV;
- time;
- location;
- character state;
- relationships;
- knowledge;
- purpose;
- continuity;
- relevant guidance.

---

## `07 — Drafting Protocol.md`

Runs during drafting.

It protects:

- causal writing;
- character-specific cognition;
- POV;
- dialogue individuality;
- emotional logic;
- prose fluidity;
- artistic identity.

---

## `08 — Post-Draft Audit.md`

Runs immediately after substantial drafting.

It checks:

- local continuity;
- character truth;
- relationship continuity;
- POV;
- scene movement;
- physical logic;
- local repetition;
- required state updates.

### Archive status

This document was completed during system construction but is **not currently present inside the ZIP**.

It needs to be added before we consider the archive complete.

---

# 8. AUDITS

Place the larger periodic audits here:

```text
AUDITS/

09 — Anti-Repetition & Pattern Audit.md

10 — Long-Range Narrative Audit.md

11 — Artistic Identity & Anti-Homogenization Pass.md
```

These are not normal every-scene instructions.

They are invoked when needed.

---

## `09 — Anti-Repetition & Pattern Audit.md`

Looks across multiple scenes/chapters for recurring:

- prose structures;
- gestures;
- emotional arcs;
- scene structures;
- dialogue patterns;
- solutions;
- relationship loops.

---

## `10 — Long-Range Narrative Audit.md`

Examines:

- causal accumulation;
- character arcs;
- relationship arcs;
- subplots;
- setups/payoffs;
- world consequences;
- middle-book drift;
- ending inheritance.

---

## `11 — Artistic Identity & Anti-Homogenization Pass.md`

Protects against:

- generic literary smoothing;
- POV convergence;
- character homogenization;
- genre-default plotting;
- over-clarification;
- removal of useful irregularity.

---

# 9. DEPLOYMENT

Place deployment/meta documents here:

```text
DEPLOYMENT/

12 — Compact Project Instructions — Final Deployable Version.md

Project Organization — Final Source Layout.md
```

The first file has a special deployment role.

---

# 10. `12 — Compact Project Instructions — Final Deployable Version.md`

This should be used as:

> **ChatGPT Project Instructions**

It is not primarily a reference file.

It tells ChatGPT:

- what takes priority;
- what to retrieve;
- when to retrieve it;
- when to draft;
- when to audit;
- how to treat canon;
- how to treat character state;
- how to use the deeper files.

Therefore:

```text
DO:

Copy its contents
        ↓
Project Settings
        ↓
Project Instructions
```

Do not rely on ChatGPT discovering this file from project sources before knowing how the system should operate.

---

# 11. PROJECT ASSEMBLY DOCUMENT

The later document we created:

`13 — Project Assembly & File Placement.md`

was created **after the ZIP archive** and therefore is not currently inside it.

It is a master administration document rather than required drafting guidance.

If saved, place it under:

```text
DEPLOYMENT/

13 — Project Assembly & File Placement.md
```

It does not have to be uploaded into every novel Project.

Its purpose is to tell **us** how to construct those Projects.

---

# 12. RESEARCH

Keep the original research separately:

```text
RESEARCH/

Research-AI-Writing-Problems.txt
```

This should normally remain outside the active novel Project.

It is the research evidence from which the system was derived.

Use it when:

- updating the system;
- challenging a guidance principle;
- researching new AI-writing problems;
- checking the original reasoning.

It does not need to compete with the finished operating system during Chapter 37.

---

# 13. BUILDING `FICTION-SYSTEM-COMPLETE.md`

This should be a **merged Markdown deployment file**, not the ZIP.

The internal order should be deliberate.

Use this sequence:

```text
FICTION-SYSTEM-COMPLETE.md

==================================================
PART I — GOVERNING SYSTEM
==================================================

Fiction Writing System — Project Constitution.md

01 — Project Architecture & Retrieval System.md


==================================================
PART II — MASTER GUIDANCE TAXONOMY
==================================================

Master Fiction Guidance Taxonomy — Foundation v0.1.md

Domain 2 — Prose, Syntax & Rhythm.md

Domain 3 — Description, Imagery & Sensory Selection.md

Domain 4 — Emotion, Interiority & Subtext.md

Domain 5 — Dialogue & Conversational Dynamics.md

Domain 6 — Character Identity, Cognition & Development.md

Domain 7 — POV, Knowledge & Information Boundaries.md

Domain 8 — Relationships & Social World.md

Domain 9 — Scene Design & Dramatic Movement.md

Domain 10 — Pacing, Tension & Escalation.md

Domain 11 — Plot, Causality, Subplots & Payoff.md

Domain 12 — Continuity, World Logic & Embodied Reality.md

Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md


==================================================
PART III — STORY & STATE FRAMEWORKS
==================================================

03 — Reusable Continuity & Knowledge Ledger Templates.md

04 — Reusable Character & Relationship State System.md

05 — Reusable Scene & Chapter State System.md


==================================================
PART IV — NORMAL WRITING OPERATIONS
==================================================

06 — Pre-Writing Gate.md

07 — Drafting Protocol.md

08 — Post-Draft Audit.md


==================================================
PART V — PERIODIC AUDITS
==================================================

09 — Anti-Repetition & Pattern Audit.md

10 — Long-Range Narrative Audit.md

11 — Artistic Identity & Anti-Homogenization Pass.md
```

That is the correct internal hierarchy.

---

# 14. WHAT DOES NOT NEED TO BE INSIDE `FICTION-SYSTEM-COMPLETE.md`

Do not merge these into the permanent universal reference:

```text
12 — Compact Project Instructions — Final Deployable Version.md

Reusable Story Bible Template.pdf

13 — Project Assembly & File Placement.md

Research-AI-Writing-Problems.txt
```

They have different roles.

### `12`

Project Instructions.

### `Reusable Story Bible Template.pdf`

Novel initialization tool.

### `13`

Deployment/administration guide.

### Research

System-development archive.

---

# 15. FINAL ACTIVE NOVEL PROJECT

Once a particular novel exists, the Project should look like this:

```text
CHATGPT PROJECT
│
├── PROJECT INSTRUCTIONS
│   │
│   └── Contents of:
│       12 — Compact Project Instructions — Final Deployable Version.md
│
│
├── UNIVERSAL SOURCE
│   │
│   └── FICTION-SYSTEM-COMPLETE.md
│
│
├── NOVEL FOUNDATION
│   │
│   └── [NOVEL TITLE] — Story Bible.md
│
│
├── ACTIVE STORY MEMORY
│   │
│   ├── [NOVEL TITLE] — Current Story State.md
│   │
│   └── [NOVEL TITLE] — Open Threads.md
│   │       [only when complexity requires it]
│
│
├── PROGRESS MEMORY
│   │
│   └── [NOVEL TITLE] — Chapter Summaries.md
│
│
└── ACCEPTED MANUSCRIPT
    │
    ├── [NOVEL TITLE] — Manuscript — Arc 01.md
    ├── [NOVEL TITLE] — Manuscript — Arc 02.md
    └── ...
```

The universal system remains constant.

The novel files change.

---

# 16. STORY BIBLE CREATION

When beginning a particular novel:

Use:

`Reusable Story Bible Template.pdf`

as the construction framework.

The output becomes:

```text
[Novel Title] — Story Bible.md
```

That populated file replaces the template for normal novel retrieval.

The template does not need to remain permanently uploaded afterward.

---

# 17. CURRENT STORY STATE

The reusable systems:

`03 — Reusable Continuity & Knowledge Ledger Templates.md`

`04 — Reusable Character & Relationship State System.md`

`05 — Reusable Scene & Chapter State System.md`

tell ChatGPT **how state works**.

But the novel requires an actual current state file.

Example:

```text
Ashes of Meridian — Current Story State.md
```

It contains the actual:

- date/time;
- locations;
- injuries;
- goals;
- knowledge;
- relationship state;
- important objects;
- world conditions;
- immediate consequences.

This file should remain comparatively small and current.

---

# 18. CHAPTER SUMMARIES

Use:

```text
[Novel Title] — Chapter Summaries.md
```

Do not create one source per chapter unless there is a specific reason.

Keep summaries together.

Each summary should record changes rather than merely recounting action.

This becomes the main bridge between:

> old manuscript material

and

> current drafting.

---

# 19. MANUSCRIPT

Accepted prose should be stored separately from state and summaries.

Early in the novel:

```text
[Novel Title] — Manuscript.md
```

may be enough.

Later, split naturally:

```text
[Novel Title] — Manuscript — Arc 01.md

[Novel Title] — Manuscript — Arc 02.md

[Novel Title] — Manuscript — Arc 03.md
```

Prefer meaningful narrative divisions over one file for every chapter.

---

# 20. OPTIONAL OPEN-THREAD FILE

For a simple novel:

keep open threads inside Current Story State.

For a complicated novel, add:

```text
[Novel Title] — Open Threads.md
```

Containing:

- unresolved consequences;
- mysteries;
- promises;
- setups/payoffs;
- active subplots;
- debts;
- dormant threads.

Do not create it until complexity justifies it.

---

# 21. DO NOT UPLOAD THE MASTER ZIP

The ZIP remains useful as:

> backup/archive.

It should not be treated as the primary retrievable system source.

The deployable version is:

```text
FICTION-SYSTEM-COMPLETE.md
```

The archive is:

```text
FICTION-SYSTEM-COMPLETE.zip
```

They serve different purposes.

---

# 22. THREE VERSIONS OF THE SYSTEM

We should deliberately maintain three forms.

## MASTER VERSION

Individual documents.

Best for:

- editing;
- improving one subsystem;
- replacing one domain;
- version control.

---

## ARCHIVE VERSION

`FICTION-SYSTEM-COMPLETE.zip`

Contains the individual master documents together.

Best for:

- backup;
- transport;
- preservation.

---

## DEPLOYMENT VERSION

`FICTION-SYSTEM-COMPLETE.md`

Contains the appropriate universal documents merged in retrieval order.

Best for:

- uploading as a ChatGPT Project source.

This distinction resolves the ZIP question cleanly.

---

# 23. SOURCE AUTHORITY IN AN ACTUAL NOVEL

When information conflicts:

```text
CURRENT AUTHOR INSTRUCTION
        ↓
ACCEPTED MANUSCRIPT
        ↓
POPULATED STORY BIBLE
        ↓
CURRENT STORY STATE
        ↓
APPROVED PLOT PLANNING
        ↓
CHAPTER SUMMARIES
        ↓
FICTION-SYSTEM-COMPLETE.md
        ↓
GENERAL MODEL ASSUMPTIONS
```

The universal fiction system never outranks the actual story.

---

# 24. FINAL ORGANIZATION

The external master library becomes:

```text
FICTION-SYSTEM-MASTER/
│
├── SYSTEM/
│   ├── Fiction Writing System — Project Constitution.md
│   └── 01 — Project Architecture & Retrieval System.md
│
├── TAXONOMY/
│   ├── Master Fiction Guidance Taxonomy — Foundation v0.1.md
│   ├── Domain 2 — Prose, Syntax & Rhythm.md
│   ├── Domain 3 — Description, Imagery & Sensory Selection.md
│   ├── Domain 4 — Emotion, Interiority & Subtext.md
│   ├── Domain 5 — Dialogue & Conversational Dynamics.md
│   ├── Domain 6 — Character Identity, Cognition & Development.md
│   ├── Domain 7 — POV, Knowledge & Information Boundaries.md
│   ├── Domain 8 — Relationships & Social World.md
│   ├── Domain 9 — Scene Design & Dramatic Movement.md
│   ├── Domain 10 — Pacing, Tension & Escalation.md
│   ├── Domain 11 — Plot, Causality, Subplots & Payoff.md
│   ├── Domain 12 — Continuity, World Logic & Embodied Reality.md
│   └── Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md
│
├── TEMPLATES/
│   ├── Reusable Story Bible Template.pdf
│   ├── 03 — Reusable Continuity & Knowledge Ledger Templates.md
│   ├── 04 — Reusable Character & Relationship State System.md
│   └── 05 — Reusable Scene & Chapter State System.md
│
├── OPERATIONS/
│   ├── 06 — Pre-Writing Gate.md
│   ├── 07 — Drafting Protocol.md
│   └── 08 — Post-Draft Audit.md
│
├── AUDITS/
│   ├── 09 — Anti-Repetition & Pattern Audit.md
│   ├── 10 — Long-Range Narrative Audit.md
│   └── 11 — Artistic Identity & Anti-Homogenization Pass.md
│
├── DEPLOYMENT/
│   ├── 12 — Compact Project Instructions — Final Deployable Version.md
│   ├── 13 — Project Assembly & File Placement.md
│   ├── Project Organization — Final Source Layout.md
│   └── FICTION-SYSTEM-COMPLETE.md
│
└── RESEARCH/
    └── Research-AI-Writing-Problems.txt
```

---

# 25. CURRENT ARCHIVE GAPS

Based on the actual `FICTION-SYSTEM-COMPLETE.zip` currently available, the archive still needs to be completed before it becomes the definitive master backup.

Currently absent as separate files:

```text
Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md

08 — Post-Draft Audit.md

13 — Project Assembly & File Placement.md

Project Organization — Final Source Layout.md
```

The last two were produced after the ZIP was created, so their absence is expected.

The first two should be restored before generating the final deployment file.

Also verify:

```text
Reusable Story Bible Template.pdf
```

because the archived version is currently only one page.

---

# 26. FINAL DEPLOYMENT MODEL

For each actual novel:

```text
PROJECT INSTRUCTIONS
    12 — Compact Project Instructions — Final Deployable Version.md
                    │
                    ▼
UNIVERSAL KNOWLEDGE
    FICTION-SYSTEM-COMPLETE.md
                    │
                    ▼
NOVEL IDENTITY
    [Novel Title] — Story Bible.md
                    │
                    ▼
CURRENT REALITY
    [Novel Title] — Current Story State.md
                    │
                    ▼
LONG-RANGE MEMORY
    [Novel Title] — Chapter Summaries.md
                    │
                    ▼
AUTHORITATIVE STORY
    [Novel Title] — Manuscript — Arc XX.md
```

Everything now has one clear role.

The system file explains **how fiction should be handled**.

The Story Bible explains **what this novel is**.

Current Story State explains **what is true now**.

Chapter Summaries explain **how we arrived here**.

The manuscript contains **what actually happened**.

That should be the final organizing principle.

There are two things I would fix **before** we actually build `FICTION-SYSTEM-COMPLETE.md`: recover **`08 — Post-Draft Audit.md`** and **`Domain 13 — Theme, Symbolism, Genre & Artistic Identity.md`**, and verify whether **`Reusable Story Bible Template.pdf`** is the full template you intended—the copy inside the ZIP is only one page.

After those are resolved, the clean next move is to generate the actual **`FICTION-SYSTEM-COMPLETE.md`** from the documents in the exact order above, so you can upload that single file as the universal Project source.



---

*Generated with [ChatGPT Pro Tools](https://chromewebstore.google.com/detail/chatgpt-pro-tools/blehigjjjlnlbbgjghhfnllglnelijkg?utm_source=extension&utm_medium=export-footer)*
