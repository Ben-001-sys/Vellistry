# Research AI Writing Problems

## User

I want you to do a very, very, very deep research. You are to delve into other sites. Yes. This research is to basically find the problems people have with AI-written books, novels, etc. Go to discussions to find the exact problem people get, or people see, when they are reading AI-written works. Research deeply, discussions in communities. Research very, very deeply the problems people have, people see, people come across when they are reading AI-generated or written works. All type of written works: novels, web novels, etc. All.

## ChatGPT

I’ll treat this as a community-sentiment research project, not a generic “AI writing is bad” overview. I’m going to separate reader complaints by medium (novels, web fiction, fanfic, publishing/marketplaces), look for recurring language people use, and distinguish firsthand reading complaints from creator/publisher backlash.

## ChatGPT

The strongest pattern so far is not simply “bad grammar.” Readers repeatedly describe the opposite: prose that is superficially competent but mechanically patterned, over-emphatic, repetitive, and contextually “off.” They especially notice dialogue cadence, continuity failures, characters converging into the same voice, and scenes that repeat emotional or plot functions without genuine development. 

## ChatGPT

I dug through reader and writer communities, including Royal Road, Reddit communities around progression fantasy, LitRPG, fanfiction/AO3, Kindle, beta reading, self-publishing, Goodreads discussions, Scribble Hub, OpenAI community discussions, plus recent academic work on AI-assisted fiction and creative homogenization.

One qualification matters before the findings: **none of the stylistic traits below proves that a text was AI-generated.** Many are ordinary weaknesses in human writing too. What communities are reacting to is usually a *cluster* of traits appearing repeatedly, especially when the prose suddenly changes style or when long-range story logic starts failing. False accusations have themselves become a serious problem. ([Goodreads](https://www.goodreads.com/topic/show/24586503-ai-accusation-against-new-authors?order=a&page=1&utm_source=chatgpt.com))

## The central finding

The complaint is much deeper than “AI writes badly.”

Readers repeatedly describe an uncanny mismatch:

**The sentence is competent. The paragraph is competent. Sometimes even the scene is competent. But the story as a whole does not seem to understand why its sentences, paragraphs, and scenes exist.**

A Royal Road critique expressed this unusually well: an individual line can sound as if a professional wrote it, while its *function in the scene* makes little sense. The prose possesses the appearance of literary significance without the underlying narrative intention. ([Royal Road](https://www.royalroad.com/forums/thread/151501?page=25&utm_source=chatgpt.com))

That single phenomenon explains a large fraction of the complaints I found.

---

# 1. Repetition is probably the most consistently reported problem

This occurs at several levels simultaneously.

### Repeated wording

Readers notice favorite phrases, adjectives, metaphors, sentence openings, gestures and emotional descriptions being recycled.

A Kindle reader who bought a suspected AI book reported that the narrative seemed to reach its natural ending halfway through and then simply continued repeating essentially the same message. ([Reddit](https://www.reddit.com/r/kindle/comments/1amg1k5?utm_source=chatgpt.com))

Royal Road readers similarly describe getting buried beneath “endless repetitions and purple prose.” ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

### Repeated sentence architecture

This is more irritating than repeated individual words because it creates a recognizable rhythm.

People repeatedly complain about constructions resembling:

- “Not X. Not Y. But Z.”
- “It wasn't merely X. It was Y.”
- “Not because X, but because Y.”
- short statement → dramatic fragment → explanatory sentence
- assertion → reassertion in slightly grander language
- three parallel fragments followed by a conclusion
- question followed immediately by an emphatic answer
- adjective pairs and stacked descriptive clauses

Royal Road users specifically called out the “Not this. Not this. But that.” structure as jarring. An OpenAI community discussion independently complains about repetitive structures such as “It’s not just X, it’s also Y.” ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

These structures are perfectly legitimate human rhetoric. The complaint is **frequency**.

A rhetorical flourish stops functioning as emphasis when everything receives emphasis.

---

# 2. Everything is written as if it is important

This is a surprisingly precise recurring complaint.

AI prose often seems unable to establish a hierarchy of significance.

A character opening a door, discovering a murdered king and deciding what cereal to eat can all receive approximately the same stylistic weight.

One Royal Road participant described the problem as AI being able to generate sophisticated-sounding prose but not knowing how to **pace the impacts**, comparing it to someone emphasizing every word while reading aloud. ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This creates what I would call **importance inflation**.

Instead of:

ordinary → interesting → tense → extraordinary → climax

the narrative becomes:

**meaningful → meaningful → profound → meaningful → profound → devastating → meaningful → profound**

Eventually none of it feels meaningful.

This is closely related to another Royal Road critique describing AI prose as exhibiting **“vague grandiosity”**: impressive-looking sentences whose presentation does not correspond to the actual significance or function of what is happening. ([Royal Road](https://www.royalroad.com/forums/thread/151501?page=25&utm_source=chatgpt.com))

---

# 3. Purple prose without observational specificity

Readers frequently complain that AI fiction is simultaneously **overwritten and vague**.

That sounds contradictory, but it isn't.

There may be many adjectives, metaphors, abstractions and emotional descriptions while remarkably little concrete information.

Royal Road discussions repeatedly characterize AI-heavy writing as:

- flowery,
- generic,
- ornate,
- exposition-heavy,
- cliché-driven,
- excessively metaphorical. ([Royal Road](https://www.royalroad.com/forums/thread/141654?utm_source=chatgpt.com))

One Reddit reader noticed a sequel suddenly oscillating between very short clipped prose and passages containing numerous metaphors and similes within only a few paragraphs. ([Reddit](https://www.reddit.com/r/litrpg/comments/1vcvwn1/list_of_confirmed_ai_books/?utm_source=chatgpt.com))

The underlying complaint isn't “metaphors are bad.”

It is:

**The prose sounds decorated rather than observed.**

Human description often reveals what *this particular viewpoint character* would notice.

AI-like description often seems to ask:

> What sounds literary here?

rather than:

> What would this person notice here, and why?

---

# 4. Metaphors that sound good locally but mean very little

This appears frequently in reader descriptions.

A metaphor may be syntactically elegant and emotionally suggestive while collapsing if examined literally.

Goodreads participants discussing AI writing described metaphor-heavy prose where the images feel like plausible pattern matches rather than deliberately chosen comparisons. ([Goodreads](https://www.goodreads.com/Topic/24739576/comments?subject=24739576&utm_source=chatgpt.com))

This produces a particular reading sensation:

**You understand the emotional category of the sentence without understanding its actual image.**

The reader thinks:

“Apparently this is supposed to mean sadness.”

But the metaphor itself doesn't deepen sadness.

It simply announces it.

---

# 5. Emotional paraphrasing

One emotion gets explained repeatedly.

For example, instead of allowing:

> She closed the door and kept her hand on the knob.

to carry emotional meaning, AI-style prose tends toward something structurally like:

> She closed the door. 
> The finality settled over her. 
> It wasn't merely sadness. 
> It was the realization that something had ended. 
> Something irreversible. 
> And for the first time she understood that there was no going back.

The problem isn't any individual sentence.

It is that **all six sentences perform essentially one emotional action**.

Readers repeatedly report this feeling of the text telling them the same thing again and again instead of progressing. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

This contributes enormously to perceived bloat.

---

# 6. Characters begin speaking in “LLM prose”

This phrasing came directly from a reader discussing a work whose plot, worldbuilding and characters they otherwise liked.

Later chapters apparently changed, and suddenly the **characters' thoughts and speech acquired the same AI-like prose style**. The reader described this as ruining an otherwise competent story. ([Reddit](https://www.reddit.com/r/ProgressionFantasy/comments/1vh8e7f/it_was_the_worst_feeling_not_great_not_good_but/?utm_source=chatgpt.com))

This points toward an important distinction:

AI voice doesn't stay confined to narration.

It can infect:

- dialogue,
- internal monologue,
- letters,
- jokes,
- arguments,
- villains,
- children,
- ancient beings,
- soldiers,
- academics.

Everyone starts sounding as though they were generated through the same rhetorical engine.

---

# 7. Character voices converge

This is one of the most important long-form complaints.

Royal Road readers describe AI-influenced fiction where every story—and frequently every character—shares an oddly similar voice: polished, modern, snappy and structurally alike regardless of setting or personality. ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

A sarcastic rogue, shy teenager, 900-year-old emperor and exhausted mother may technically use different vocabulary while sharing exactly the same:

- cadence,
- sentence length,
- emotional articulation,
- degree of self-awareness,
- argumentative structure,
- wit,
- rhetorical sophistication.

The result is **character differentiation by facts rather than by consciousness**.

They have different biographies but the same mind.

---

# 8. Dialogue feels like alternating “beats,” not conversation

This was described especially clearly in a recent Royal Road discussion.

Readers observed terse dialogue where each line exists primarily to set up the next:

A speaks.

B mirrors A.

A reformulates.

B answers symmetrically.

A challenges.

B produces a neat reversal.

The complaint was that characters didn't use the connective mess found in real conversation:

- hesitation,
- correction,
- filler,
- interruption,
- misunderstanding,
- unfinished thought,
- change of subject,
- answering the wrong part of a question,
- avoiding the question entirely.

Instead, every line becomes a **perfect conversational unit**.

Royal Road readers said the result feels closer to scripted beats than natural interaction and breaks immersion. ([Royal Road](https://www.royalroad.com/forums/thread/175111?utm_source=chatgpt.com))

---

# 9. Characters repeat one another

A related dialogue tell:

> “You're leaving.”
>
> “I'm leaving.”
>
> “You've decided.”
>
> “I have.”

Nothing is technically wrong.

But information does not move.

Several community discussions point to dialogue where one character essentially restates the previous character's statement before continuing. ([Royal Road](https://www.royalroad.com/forums/thread/175111?utm_source=chatgpt.com))

This creates **semantic ping-pong**.

Conversation happens without discovery.

---

# 10. Dialogue can be unnaturally self-aware

Characters often explain themselves too well.

They know:

- what they are feeling,
- why they are feeling it,
- what childhood event produced it,
- what contradiction they are experiencing,
- how the other person must feel,
- what lesson the moment represents.

Human beings, especially during conflict, are often much worse at this.

They:

- rationalize,
- evade,
- misunderstand themselves,
- lash out for the wrong reason,
- say something they regret,
- focus on irrelevant details,
- refuse to articulate the obvious.

AI dialogue often produces people who behave like their own therapists.

This is one reason community members repeatedly describe it as lacking contradiction, vulnerability or genuine subtext. ([Royal Road](https://www.royalroad.com/forums/thread/154464?page=1&utm_source=chatgpt.com))

---

# 11. Excessive explicit emotional labeling

Readers don't merely see sadness.

The text tells them someone is:

- conflicted,
- determined,
- vulnerable,
- resolute,
- uncertain,
- relieved,
- apprehensive,
- quietly devastated.

And then often explains why.

This removes interpretive participation.

Human fiction can say:

> “Fine,” he said, carefully placing the cracked cup in the sink.

and allow the reader to infer anger.

AI-style prose frequently feels compelled to complete the equation for the reader.

That is part of what communities mean when they complain of excessive **telling instead of showing**. ([Royal Road](https://www.royalroad.com/forums/thread/156581?utm_source=chatgpt.com))

---

# 12. Emotional reactions become generic physical choreography

Readers repeatedly notice reusable emotional actions.

Characters:

- narrow their eyes,
- furrow their brows,
- clench their jaws,
- release breaths,
- stiffen,
- soften,
- pause “for a beat,”
- let silence stretch,
- feel something tighten in their chest,
- feel something twist in their stomach,
- swallow hard.

Again: human authors use every one of these.

The AI-like impression emerges when the gestures become an almost closed vocabulary for human interiority.

A Scribble Hub reader even described an AI-heavy story repeatedly producing inappropriate brow-furrowing, including for a dog. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

That example is humorous, but the underlying issue is serious:

**the model associates an emotional context with a probable gesture and inserts it without sufficiently modeling embodiment.**

---

# 13. Contextually inappropriate behavior

Readers often describe moments where a sentence makes perfect grammatical sense but is bizarre in context.

A Royal Road reader summarized one suspected AI-assisted story as showing:

- odd comments that don't fit the scene,
- weak contextual memory,
- distinctive but inappropriate conversation cadence. ([Reddit](https://www.reddit.com/r/royalroad/comments/1rfygrx/gave_honest_and_nonnegative_feedback_on_an_ai/?utm_source=chatgpt.com))

Fanfiction readers describe similar failures: actions, concepts or behaviors appear where they don't belong because the generator seemingly recognized a local association without understanding the larger situation. ([Reddit](https://www.reddit.com/r/AO3/comments/zbpv03?utm_source=chatgpt.com))

This is an important distinction:

**AI errors are frequently pragmatic rather than grammatical.**

---

# 14. Scene-level amnesia

Long fiction creates facts.

Those facts become obligations.

If chapter 4 establishes that:

- Mara can't swim,
- the north gate is destroyed,
- James hates alcohol,
- vampires can't enter churches,
- Elena already knows the secret,

chapter 27 must respect those facts unless something changes.

Communities repeatedly report AI-written stories violating these commitments.

Examples include:

- names changing,
- prior discoveries being forgotten,
- locations shifting,
- relationships resetting,
- powers changing,
- established facts vanishing,
- characters rediscovering information they already know. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

Current research supports the broader limitation. A 2026 benchmark of long-horizon interactive narratives found a substantial gap between linguistic fluency and preservation of narrative commitments: excellent surface language did not guarantee consistency over extended sequences. ([arXiv](https://arxiv.org/abs/2608.08160?utm_source=chatgpt.com))

---

# 15. Character-name instability

This deserves its own mention because it is so visible.

Scribble Hub readers describe characters whose names drift or alternate inexplicably in AI-heavy stories. ([scribblehubforum.com](https://www.scribblehubforum.com/threads/is-it-even-possible-for-ai-assistants-like-chatgpt-to-generate-entire-long-novels.26303/?utm_source=chatgpt.com))

It destroys reader confidence unusually quickly because a name is among the simplest persistent facts a novel is expected to maintain.

Readers naturally ask:

> If the book cannot remember her name, what else isn't it remembering?

---

# 16. Personality drift

A more subtle continuity problem:

the character keeps their name but stops being themselves.

A selfish protagonist becomes strangely altruistic for one scene.

A coward suddenly behaves fearlessly without an arc.

A brilliant strategist becomes stupid to enable the plot.

A restrained character delivers an ornate emotional monologue.

Then the old characterization returns.

Royal Road discussions describe plot-serving characters whose motivation, intelligence or behavior changes whenever needed. ([Royal Road](https://www.royalroad.com/forums/thread/173903?utm_source=chatgpt.com))

Human authors absolutely commit this error.

AI seems especially vulnerable because it can optimize the immediate scene without sufficiently protecting the character model that earlier scenes established.

---

# 17. “Character growth” that is actually character replacement

This is the stronger version of personality drift.

A genuine arc has causality:

experience → resistance → consequence → changed belief → changed behavior.

AI-generated arcs sometimes jump directly from:

**old personality → dramatic scene → new personality.**

The prose announces transformation but the reader hasn't *experienced* the transformation.

This produces characters who appear to have developed when they have merely been rewritten.

---

# 18. Characters exist to perform the scene's function

A recurring criticism in community discussions is that secondary characters behave less like independent people and more like mechanisms.

They arrive to:

- encourage the protagonist,
- deliver exposition,
- misunderstand something,
- praise the hero,
- start an argument,
- introduce the next quest,
- validate the romance,
- deliver thematic wisdom.

Then vanish.

Readers often describe this as **plot-serving characterization**. 

Human genre fiction does this frequently too.

The AI version becomes especially noticeable because characters can be *very

## User

I want you to do a very, very, very deep research. You are to delve into other sites. Yes. This research is to basically find the problems people have with AI-written books, novels, etc. Go to discussions to find the exact problem people get, or people see, when they are reading AI-written works. Research deeply, discussions in communities. Research very, very deeply the problems people have, people see, people come across when they are reading AI-generated or written works. All type of written works: novels, web novels, etc. All.

## ChatGPT

I’m expanding this beyond Reddit. I’ll sample reader/author communities around general books, fanfiction, web novels/serials, LitRPG/progression fantasy, self-publishing/Kindle, and AI-writing communities themselves, then cross-check recurring complaints against publishing/editorial and research sources. The goal is to identify **specific textual failure modes readers actually notice**, not just ethical objections to AI.

## ChatGPT

A second important distinction is emerging: readers complain about **two different layers of failure**. At the sentence level, they report templated rhetorical patterns, adjective stacking, purple prose, bland “perfect” grammar, and repeated emphasis; over many chapters, they report plot/character memory failures, scene-function repetition, voice homogenization, and loss of causal continuity. Royal Road readers in particular say the long-form defects become much easier to notice after 10–20 chapters than from a paragraph-sized “AI tell.” 

## ChatGPT

The community evidence and the research literature line up unusually well on the long-form problems. A 2026 ACL benchmark found factual and temporal consistency errors are especially common in long AI-generated stories; a 2026 survey of 57 story-generation papers still lists narrative coherence, character consistency, storyline diversity, and plot control as open problems. Separately, recent work finds AI-assisted writing becomes more stylistically homogeneous at scale. 

## ChatGPT

# Deep research: what readers actually dislike about AI-written fiction

I researched this as a **reader-experience problem**, rather than starting from the assumption that “AI writing is bad.” I reviewed discussions from r/books, r/kindle, Kindle Unlimited communities, r/litrpg, r/royalroad, r/FanFiction, r/AO3 and other fanfiction communities; Royal Road's own forums; Scribble Hub; SpaceBattles; Goodreads reviews; AI-writing communities where people openly discuss the defects they have to edit out; official Royal Road/Amazon policies; and recent academic work on long-form story generation.

There is a surprisingly coherent picture across these communities.

The central complaint is **not that AI cannot produce grammatically correct sentences**. In fact, readers often say the grammar is suspiciously clean. The deeper problem is this:

> **AI fiction can be locally fluent while being globally unintelligent.**

A paragraph can sound polished. A description can sound literary. A dialogue exchange can sound superficially plausible. But after enough pages, readers start noticing that the story does not seem to understand what deserves emphasis, what has already happened, what a character should know, how one event psychologically changes the next, or why a particular sentence is being written at all.

That distinction explains a huge portion of the complaints I found.

---

## 1. The single biggest prose complaint: everything sounds *written*

One of the most repeated descriptions is some variation of **overwritten, flowery, overly dramatic, overly polished, sterile, exhausting, or “trying to sound literary.”**

A LitRPG reader described suspected AI books as “over the top, floraly, soulless” and repetitive. A Royal Road forum user said AI prose may combine sophisticated-sounding words but fails to control where the emphasis belongs: it is like hearing somebody read a passage while **emphasizing every single word**. Scribble Hub users similarly complain about grammatically correct but excessively flowery prose. ([Reddit](https://www.reddit.com/r/litrpg/comments/1i9y3b7?utm_source=chatgpt.com))

This is an important distinction from ordinary purple prose. Human purple prose often comes from an identifiable artistic obsession: the writer loves Gothic imagery, sensual description, nature, architecture, grotesquerie, etc. What readers call “AI purple prose” frequently feels **ornamental without a governing aesthetic**. It embellishes because embellishment sounds like Writing™, rather than because the point-of-view character or scene requires it.

SpaceBattles readers repeatedly complained about superfluous details, unnecessary adjectives, elaborate comparisons and metaphors that collapse when examined closely. One commenter described a recurring pattern in which a character walks through a location while their clothes and accessories somehow become symbols of contrasting personality traits. Another complained that generated metaphors appear everywhere yet often do not withstand literal or thematic scrutiny. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-usage-in-stories.1272482/?utm_source=chatgpt.com))

The result is something several communities independently describe as **exhausting**. The prose constantly asks the reader to feel that something is significant without earning that significance.

---

## 2. The infamous “not X, but Y” problem is real — but the real issue is frequency

This was probably the most consistently named sentence-level pattern across the communities I searched.

Readers describe variations such as:

“Not X, but Y.”

“Not A. Not B. Just C.”

“It wasn't X. It was Y.”

“Not merely X, but something deeper.”

One Kindle reader complained of encountering the same “not A, not B, just/but C” structure hundreds of times across books. Royal Road readers call it the “Digiorno cadence.” Fanfiction readers report fics riddled with constructions like “not x, not y, but z.” Even people in communities specifically devoted to **writing with AI** complain that models keep reverting to the structure after being explicitly told not to. ([Reddit](https://www.reddit.com/r/kindle/comments/1wbsj8z/books_obviously_written_by_ai/?utm_source=chatgpt.com))

The rhetorical device itself is ancient and perfectly legitimate human writing. Shakespeare used contrastive structures. The community complaint is therefore not **presence**, but **density and inappropriate placement**.

A useful observation from one discussion was that humans normally deploy this construction when there is some reason to correct, distinguish, intensify or persuade. AI-like prose may use it for trivial observations where nothing actually needs reframing. That creates a strange sensation that the narrator is perpetually arguing against an interpretation the reader never had. ([Reddit](https://pl.reddit.com/r/antiai/comments/1u7ugzj/what_is_it_that_makes_ai_writing_so_bad/?utm_source=chatgpt.com))

That leads to a broader problem.

## 3. AI prose frequently **pre-interprets itself**

Readers repeatedly object to prose that tells them what a moment means immediately after showing the moment.

A character performs an action. Then the narration explains the psychological significance of the action. Then it explains how the other character interpreted it. Then it explains what this says about their relationship. Sometimes it then concludes with a pseudo-profound sentence.

A user in r/WritingWithAI said they routinely cut roughly a third of generated prose because of its “constant overexplaining,” psychological analysis of every action, and apparent inability to remain comfortably inside a limited point of view. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1uadqis/this_is_what_its_like_writing_with_ai/?utm_source=chatgpt.com))

This destroys **subtext**.

Good fiction often lets the reader infer:

He did not answer.

She folded the letter and placed it back inside the envelope.

Neither looked at the empty chair.

AI-like prose has a tendency to convert those moments into explanations of grief, hesitation, unresolved tension, suppressed resentment or emotional distance. The reader is deprived of the pleasure of interpretation.

This is why people often describe the writing as paradoxically both **verbose and shallow**. There can be a great deal of language while very little remains for the reader to discover.

---

# 4. “Pseudo-depth”: sentences that sound profound without adding information

Fanfiction readers specifically complained about repeated “pseudo-profound” sentences, including dramatic one-sentence paragraphs and closing formulations such as “…and that was enough.” One Harry Potter fanfiction reader described a story containing multiple metaphors that went nowhere, vague worldbuilding, constant drama and little payoff. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

This is a recurring phenomenon across other discussions too: **abstract nouns replacing concrete insight**.

The prose talks about silence, weight, truth, darkness, destiny, possibility, tension, something unspoken, something shifting, something ancient, something fragile, the space between people, the gravity of a moment, and so forth.

These abstractions are not automatically bad. The complaint is that the language often creates **the shape of meaning without committing to a specific meaning**.

A Scribble Hub discussion of an apparently AI-like passage noted heavy reliance on sweeping abstractions such as honor, loyalty, sacrifice, death and pain. ([Scribble Hub Forum](https://forum.scribblehub.com/threads/first-chapter-ai-check-for-shoots-and-giggles.23104/?utm_source=chatgpt.com))

That is closely connected to another complaint: **vagueness masquerading as sophistication**.

---

# 5. Strange allocation of detail

One unusually specific complaint from fanfiction readers was that AI-like writing can be extraordinarily detailed about the wrong things.

A room receives an extravagant description.

A corridor gets three metaphors.

Weather receives symbolic significance.

A character's coat receives multiple adjectives.

Yet an important secondary character remains visually, psychologically and socially vague.

One fanfiction reader described exactly this imbalance: highly detailed locations but barely any meaningful characterization of side characters, even original characters who should matter to the story. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

This produces the sensation that the prose knows how to **decorate a scene** but does not know what information the story requires.

SpaceBattles discussions repeatedly return to the same issue under different names: meaningless details, superfluous description and “purple prose emphasizing the wrong actions.” ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/?utm_source=chatgpt.com))

This is one reason AI prose may feel visually rich yet strangely unmemorable.

---

# 6. Repetition occurs at several different levels simultaneously

“Repetitive” is probably the most common general adjective I encountered, but it actually describes several separate phenomena.

### Lexical repetition

The same words, adjectives, gestures and phrases recur. Goodreads reviewers of suspected AI-generated fantasy have complained about words and even whole sentences being repeated. ([Goodreads](https://www.goodreads.com/book/show/230030991-elven-blood?utm_source=chatgpt.com))

### Syntactic repetition

Different sentences contain the same underlying rhetorical machine:

Not X, but Y.

Three-item sequences.

One-sentence dramatic paragraph.

Description → contrast → emotional interpretation.

Dialogue → enormous reaction paragraph.

Question → rhetorical reframing → tidy conclusion.

This is what causes readers to say they recognize the same “sentence structure” over and over even when the vocabulary changes. ([Reddit](https://www.reddit.com/r/kindle/comments/1wbsj8z/books_obviously_written_by_ai/?utm_source=chatgpt.com))

### Scene repetition

More seriously, entire **dramatic functions** repeat. Characters argue about essentially the same issue, reconcile in approximately the same way, encounter another obstacle fulfilling the same purpose, or repeat emotional revelations without actually evolving.

Royal Road users have described AI-heavy serials as repeating essentially the same action and lack-of-growth cycle with names or surface details changed. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

That is much more damaging than an overused word because the reader begins feeling that **nothing accumulates**.

---

# 7. Characters repeatedly return to baseline

This emerged strongly in discussions of web novels and long fanfiction.

A human-written character should normally have a history inside the book itself. After betrayal, intimacy, injury, revelation or failure, later behavior should be influenced by what occurred earlier.

Readers complain that AI-generated characters instead seem prone to **psychological resetting**.

The character learns something but behaves later as though they never learned it.

A relationship deepens, but the next conversation has the same emotional distance as before.

Someone resolves an insecurity, then repeats the original insecurity almost unchanged.

A conflict is apparently settled, yet the same conversation comes back because the generator finds that conflict statistically appropriate for those characters.

This is partly why readers describe AI characters as “flat” even when the prose contains a huge amount of emotion. An OpenAI community discussion on book generation similarly identified repeated actions/dialogue, weak psychological depth and the feeling that each continuation starts afresh rather than genuinely inheriting everything that happened before. ([OpenAI Developer Community](https://community.openai.com/t/can-ai-really-write-books/976399?utm_source=chatgpt.com))

That complaint is not merely anecdotal. Current research on long-form LLM narratives finds precisely these broader consistency challenges.

---

# 8. Characterization whiplash

The opposite of resetting also occurs: characters suddenly become someone else.

SpaceBattles readers gave very concrete examples: a protagonist may abruptly change personality without sufficient setup; characters talk or behave in ways that contradict their portrayal just paragraphs earlier; characterization becomes increasingly irregular as the story grows. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

Another reader called this **“immersion breaking characterization whiplash.”** ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-2?utm_source=chatgpt.com))

This is particularly damaging in fanfiction because readers already possess a detailed model of the canonical character. An AI can reproduce obvious traits—sarcasm, sternness, cleverness, timidity—while missing the constraints underneath them.

A character may therefore say something that resembles their surface voice while reasoning in a way they never would.

---

# 9. Everyone slowly acquires the same voice

This complaint appears at two levels.

First, **characters inside one story begin sounding alike**. A Royal Road discussion explicitly lists dialogue where characters sound too similar among the common AI-like defects readers notice. ([Reddit](https://www.reddit.com/r/royalroad/comments/1uwps94/nightmare_fuel_being_accused_of_using_ai_because/?utm_source=chatgpt.com))

Second, **completely unrelated books begin sounding like the same author**.

A Royal Road forum reader said that after sampling story after story, the authorial voice appeared strangely identical despite changes in character and setting: “snappy, sharp, modern.” ([Royal Road](https://www.royalroad.com/forums/thread/164373?utm_source=chatgpt.com))

Royal Road's own official policy acknowledges this issue indirectly. It defines AI assistance as situations where the author's creativity and structure remain but the prose may acquire the **AI's “voice and tone.”** ([Royal Road](https://www.royalroad.com/blog/57/royal-road-ai-text-policy?utm_source=chatgpt.com))

Recent research supports the broader homogenization concern. A 2026 *Nature Human Behaviour* research briefing reports results across roughly 880,000 texts showing that LLM writing assistance preserved meaning while reducing linguistic variation and altering signals of author identity. A separate 2025 study comparing humans with GPT writing found lower collective idea diversity in GPT outputs even after attempts to increase model creativity. ([Nature](https://www.nature.com/articles/s41562-026-02549-7?utm_source=chatgpt.com))

And a *Science Advances* experiment on short fiction found something particularly important: AI ideas could improve individual writers' rated creativity and enjoyment, particularly for weaker writers, **while simultaneously making the resulting stories more similar to one another**. ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com))

So “everything is beginning to sound the same” is not merely an aesthetic complaint. There is empirical evidence for a homogenizing effect.

---

# 10. Dialogue often feels like generated dialogue rather than conversation

Readers describe several recurring problems.

One is **excessive explicitness**. People say exactly what they feel and what the conflict is about.

Another is **symmetry**: one character makes a carefully shaped point, another provides a neatly complementary response, and the exchange proceeds almost too logically.

Another is the recurring corrective pattern:

“You're saying X.”

“I'm saying Y. There's a difference.”

SpaceBattles readers specifically identified this as a recurring generated-dialogue cadence. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

A more structural version is **short dialogue followed by an enormous analytical reaction**. One reader described exchanges where a single curt sentence receives a reaction paragraph ten times its length, containing elaborate internal analysis and unlikely deductions. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-2?utm_source=chatgpt.com))

The conversation therefore stops feeling temporally real. Two people are supposedly interacting, yet every utterance creates enough interior analysis to fill several minutes.

Readers also complain about conversations that simply **go nowhere**—characters exchange polished statements without anything materially changing. ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

---

# 11. Emotional writing can be extremely explicit but strangely unfelt

This is where the word **“soulless”** appears constantly.

It would be easy to dismiss “soulless” as anti-AI ideology, but when readers explain what they mean, the complaint becomes much more specific.

There may be lots of emotional vocabulary but little **emotional causality**.

The story knows that a scene requires grief, anger, desire or fear, so it supplies the conventional language associated with grief, anger, desire or fear. But the emotion does not necessarily arise from the character's individual history in a surprising or revealing way.

Royal Road commenters describe this as technically sophisticated prose without consistent underlying meaning; Scribble Hub readers call it grammatically correct yet off-putting; Goodreads reviewers of suspected AI works describe “words on a page” without emotional substance. ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

The distinction is roughly:

**Emotion described** is not the same as **emotion dramatized**.

And **emotion dramatized** is not necessarily the same as **emotion specifically belonging to this character**.

---

# 12. AI frequently “shows” and then immediately “tells”

This deserves separate treatment because it explains why some generated prose feels simultaneously detailed and patronizing.

An AI may successfully produce a gesture:

Her fingers tightened around the glass.

But then it may add the interpretation:

The gesture betrayed the anger she had tried so desperately to suppress.

Then perhaps an abstraction:

It was the anger of someone who had spent years being unseen.

The first sentence may already have done the work.

Readers and AI-writing users complain about this pattern because every action becomes self-commentary. ([Reddit](https://www.reddit.com/r/WritingWithAI/comments/1uadqis/this_is_what_its_like_writing_with_ai/?utm_source=chatgpt.com))

Over hundreds of pages, this makes prose feel padded.

---

# 13. The narration often does not understand importance

This may be the deepest sentence-level criticism I found.

Good narrative prose constantly performs **selection**.

A writer decides this door matters but that door doesn't.

This facial reaction deserves half a sentence.

This kiss deserves three pages.

This battle can be summarized in two paragraphs.

This cup should never be mentioned.

Generated prose often gives readers the impression that it has weaker discrimination between **high-value and low-value narrative information**.

Hence the recurring complaint that everything is dramatic, everything gets metaphorical treatment, every silence is weighted, every glance is meaningful, every choice is “something more.”

One community participant summarized the underlying aesthetic problem well: experienced writers learn that **if everything is emphasized, nothing is**. ([Reddit](https://pl.reddit.com/r/antiai/comments/1u7ugzj/what_is_it_that_makes_ai_writing_so_bad/?utm_source=chatgpt.com))

This also explains why readers can find AI text tiring even when no individual sentence is technically wrong.

---

# 14. Pacing problems: lots happens, yet nothing moves

Readers describe AI pacing in apparently contradictory ways:

too fast;

too slow;

too much filler;

too much summary;

constant dramatic events;

nothing meaningful happening.

Those complaints can coexist.

A story can generate many **events** while producing little **narrative movement**.

Royal Road discussions describe repeated action without character growth. Fanfiction readers complain about conversations that lead nowhere. LitRPG readers report logical inconsistencies and poor pacing even in relatively short AI-like books. ([Royal Road](https://www.royalroad.com/forums/thread/163455?utm_source=chatgpt.com))

Some SpaceBattles readers also report a deterioration pattern: intriguing initial premise, followed by increasingly repetitive prose and rapid introduction of new alternate-universe or invented elements that are immediately glossed over rather than integrated. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-15?utm_source=chatgpt.com))

That is a particularly important problem for web novels, where constant generation makes it easy to substitute **more content** for **development**.

---

# 15. Weak setup and payoff

A story can constantly promise significance but fail to cash those promises.

One fanfiction reader summarized the sensation as “everything feeling dramatic with no payout.” ([Reddit](https://www.reddit.com/r/harrypotterfanfiction/comments/1tcohk0/alright_i_concede_sometimes_you_can_tell_a_fic_is/?utm_source=chatgpt.com))

AI-generated prose is quite good at producing the *language* of foreshadowing:

A strange feeling.

A meaningful glance.

An unexplained object.

A warning.

A secret.

A name the protagonist vaguely recognizes.

The challenge is making those elements converge dozens of chapters later in ways that feel inevitable but not obvious.

Long-form plotting requires remembering not merely facts but **narrative obligations**.

Once a story introduces a mystery, it has implicitly promised a resolution of appropriate magnitude.

When generators lose those obligations, readers experience apparently meaningful details that dissolve into nothing.

---

# 16. Long-form continuity is one of the most serious failures

This was one of the strongest points of agreement between communities and academic research.

Community examples include characters occupying different physical positions when a scene resumes; information appearing as though previously introduced when it was not; people referring to years-long relationships even though the characters met recently; items being handed over twice; actions occurring before necessary preparatory actions; and characters apparently forgetting what they just experienced. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

A particularly good SpaceBattles description called it an entire story “struggling with the linear passage of time.” ([SpaceBattles Forums](https://forums.spacebattles.com/threads/dealing-with-ai-isms-how-to-criticise-works-that-might-be-ai-generated.1307253/page-4?utm_source=chatgpt.com))

That is almost exactly what recent research finds.

The 2026 ACL paper **“Lost in Stories: Consistency Bugs in Long Story Generation by LLMs”** evaluated long narratives using 2,000 prompts and a taxonomy covering five categories with 19 subtypes. The researchers found that LLMs still contradict established facts, character traits and world rules; factual and temporal errors were particularly common. ([ACL Anthology](https://aclanthology.org/2026.findings-acl.410/?utm_source=chatgpt.com))

A 2026 systematic survey of 57 story-generation studies likewise identifies narrative coherence, character consistency, storyline diversity and plot controllability as continuing challenges. ([ACL Anthology](https://aclanthology.org/2026.eacl-srw.39/?utm_source=chatgpt.com))

This is therefore one of the complaints I would put in the **highest-confidence category**.

---

# 17. Spatial continuity breaks too

This receives less attention than timeline errors but is highly immersion-breaking.

A sword is used before it has been drawn.

An object gets handed over twice.

A character is standing beside someone and is suddenly across the room.

Someone exits and then participates in a conversation without re-entering.

The geography of a chase ceases to make sense.

The scene continues across chapter boundaries with people inexplicably repositioned.

These are exactly the sorts of errors human readers notice once they stop merely admiring sentence fluency and start maintaining a mental simulation of the scene. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-3?utm_source=chatgpt.com))

---

# 18. Characters know things they should not know

A SpaceBattles discussion supplied a very revealing example: a character raised in a desert uses a concept tied to the deep sea despite lacking the experience that would plausibly give them that comparison. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-14?utm_source=chatgpt.com))

This is broader than factual hallucination.

Fiction depends on **epistemic boundaries**:

What does the narrator know?

What does this character know?

What vocabulary would they possess?

What cultural assumptions would occur naturally to them?

What secrets have they heard?

What metaphors would their life experience make available?

An LLM possesses far more world knowledge than the character it is portraying. Unless this boundary is actively managed, inappropriate knowledge leaks into narration or dialogue.

The resulting sentence can be perfectly elegant and completely wrong for the character.

---

# 19. Fanfiction has an additional problem: “surface canon” without deep canon

Fanfiction readers are especially sensitive to this.

A model may know the catchphrases, relationships, setting terminology and headline personality traits of a franchise.

That does not mean it possesses a coherent causal model of the canon.

SpaceBattles users experimenting with crossover generation describe outputs that seem unable to fully “master” the source fiction; generated scenarios drift toward generic storytelling expectations rather than the specific logic of the original works. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/page-13?utm_source=chatgpt.com))

This produces characters who look canon-compliant sentence by sentence yet make decisions that a longtime fan immediately recognizes as alien.

---

# 20. Plot invention tends toward high-probability solutions

Another recurring complaint is **genericness**.

This does not necessarily mean every premise is generic. AI can be prompted with a bizarre premise.

The genericness tends to appear when the system must answer questions such as:

What should happen next?

How should these characters reconcile?

How should the villain's arc end?

What revelation would explain this mystery?

How should the protagonist overcome this insecurity?

Royal Road commenters argue that these questions often pull generated stories toward highly conventional average solutions. ([Royal Road](https://www.royalroad.com/forums/thread/163455?page=5&utm_source=chatgpt.com))

The empirical research on creative homogenization reinforces the concern. AI-assisted short stories can score well individually while becoming more similar as a population. ([PubMed](https://pubmed.ncbi.nlm.nih.gov/38996021/?utm_source=chatgpt.com))

So an AI story may feel surprising at the **premise** level while becoming highly predictable at the **development** level.

---

# 21. The “technically good, aesthetically bad” uncanny valley

This is one of the most interesting findings.

Many readers are not complaining that AI writes like an incompetent beginner.

They're complaining that it combines abilities in an unnatural way:

very clean grammar;

large vocabulary;

complex metaphors;

smooth sentence construction;

yet poor scene logic;

weak characterization;

repetitive rhetoric;

bad pacing;

shallow subtext;

obvious contradictions.

SpaceBattles participants explicitly note this combination: technically proficient but stylistically clumsy, highly prolific and narratively confused. ([SpaceBattles Forums](https://forums.spacebattles.com/threads/ai-writing-tell-vent-rant.1266359/?utm_source=chatgpt.com))

That mismatch can create the **uncanny feeling** readers keep describing.

A normal beginner tends to make beginner mistakes across several dimensions simultaneously. A generated text can produce immaculate punctuation while forgetting where a character is standing.

---

# 22. The prose lacks idiosyncrasy

Human authors are often interesting partly because of their irregularities.

They may favor fragments.

They may hate adjectives.

They may use absurdly long sentences.

They may be obsessed with food.

They may almost never describe faces.

They may create strange analogies nobody else would choose.

They may possess regional syntax, professional vocabulary, private humor or peculiar rhythms.

AI editing can remove precisely those irregularities.

Royal Road readers explicitly complain that AI assistance can make prose “sound the same as everything else.” ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This is why some people prefer flawed human prose to more technically correct generated prose: the flaws can be **evidence of selection, personality and intention** rather than noise.

---

# 23. Readers often experience a missing author behind the text

This is not a technical prose defect, but it is central to the reading experience.

A considerable group of readers views literature partly as contact with another mind.

They do not merely want to know what happens next. They want to encounter somebody's choices:

Why did this person choose this image?

Why did they make the protagonist cruel here?

Why does this writer keep returning to fathers and sons?

Why did they leave that ending ambiguous?

When readers believe those decisions were generated statistically, some feel that the interpretive relationship collapses.

A recent essay about AI and reading describes the resulting uncertainty as damaging the implicit human connection on which literary reading often depends. ([The Atlantic](https://www.theatlantic.com/ideas/2026/06/ai-writing-reading-nazir/687419/?utm_source=chatgpt.com))

Royal Road users make the point more bluntly: why invest time reading something the poster could not be bothered to write? ([Royal Road](https://www.royalroad.com/forums/thread/170127?utm_source=chatgpt.com))

This objection will not affect every reader. Some people actively enjoy custom AI fiction, interactive storytelling and highly personalized generated fantasies. Recent reporting documents a real audience for that experience. ([WIRED](https://www.wired.com/story/chatbot-generated-fiction-i-like-my-big-rat-wife?utm_source=chatgpt.com))

So this is a **value difference**, not an objective defect.

But it is a major market reality.

---

# 24. Nondisclosure creates a feeling of betrayal

This is stronger than simple dislike.

One r/books reader described enjoying an indie novel until the later pages abruptly became what they perceived as AI-generated prose: generic phrases, nonsensical passages and “word salad.” Their reaction was not merely “this got bad”; they described feeling **betrayed**. ([Reddit](https://www.reddit.com/r/books/comments/1qygilu/a_really_fun_book_i_was_reading_turned_out_to_be/?utm_source=chatgpt.com))

That reaction appears because readers believe they made one kind of transaction and received another.

This is why labeling matters disproportionately.

Royal Road requires stories to distinguish AI-assisted from AI-generated material. Amazon KDP requires publishers to disclose AI-generated text, images and translations **to Amazon**, although AI-assisted content does not require such disclosure. ([Royal Road](https://www.royalroad.com/support/knowledgebase/114?utm_source=chatgpt.com))

---

# 25. AI suspicion itself is now damaging reading

This was one of the most unexpected consequences.

Some readers say they can no longer comfortably read modern prose containing:

em dashes;

flowery descriptions;

similes;

contrastive sentences;

triplets;

very polished grammar;

certain elevated words.

A reader in r/literature described abandoning books after developing a constant suspicion of AI writing, even while acknowledging that the supposed signals are perfectly legitimate human techniques. ([Reddit](https://www.reddit.com/r/literature/comments/1ox7too/constant_exposure_to_aigenerated_writing_has/?utm_source=chatgpt.com))

Writers report the corresponding anxiety: they are afraid ordinary beginner mistakes, poetic descriptions, em dashes or clean prose will make readers accuse them of AI use. ([Reddit](https://www.reddit.com/r/royalroad/comments/1uwps94/nightmare_fuel_being_accused_of_using_ai_because/?utm_source=chatgpt.com))

This is a genuine secondary harm: **AI has contaminated certain stylistic features by association**.

---

# 26. There is no reliable single “AI tell”

This is critical.

An em dash is not proof.

“Not X but Y” is not proof.

Purple prose is not proof.

Perfect grammar is not proof.

Triplets are not proof.

A metaphor is not proof.

Bad continuity is not proof.

Humans have done every one of these things for centuries.

Experienced readers repeatedly say that what convinces them is **density plus interaction**: several recurring patterns combined with deeper narrative failures over many chapters. ([Reddit](https://www.reddit.com/r/royalroad/comments/1rg903j/not_every_poorly_written_story_is_ai/?utm_source=chatgpt.com))

Long-form problems are far more informative than one punctuation mark.

And automated detectors should not be treated as definitive evidence either. Recent studies find substantial variation among detectors, particularly for hybrid or lightly AI-polished text. An ACL study found detectors frequently flag AI-polished human text and cannot reliably distinguish degrees of AI involvement; another 2026 study found commercial tools performed particularly poorly on hybrid writing. ([ACL Anthology](https://aclanthology.org/2025.findings-acl.1303/?utm_source=chatgpt.com))

So a responsible conclusion should be:

**“This prose exhibits patterns readers frequently associate with generated writing”** is defensible.

**“This phrase proves ChatGPT wrote this”** generally is not.

---

# 27. AI makes discovery worse even for readers who never open an AI book

This is the marketplace problem.

Kindle and Kindle Unlimited readers complain that finding books now requires additional investigation: checking publication frequency, reviews, author history, covers and samples. One user said they did not want to have to “thoroughly investigate every author.” Another Cozy Fantasy reader said avoiding suspected AI content had made choosing the next book significantly more laborious. ([Reddit](https://www.reddit.com/r/kindle/comments/1un1a9q/how_we_avoiding_ai_slop/?utm_source=chatgpt.com))

LitRPG readers similarly describe searching through rapidly published books and short AI-like titles with weak pacing and logical inconsistencies before finding something they consider normally written. ([Reddit](https://www.reddit.com/r/litrpg/comments/1uz10oy/ai_book_covers_and_ai_slop/?utm_source=chatgpt.com))

Scribble Hub users describe spending substantial time opening stories only to immediately close them because multiple synopses possess the same generated style. ([Scribble Hub Forum](https://www.scribblehubforum.com/threads/we-need-a-new-content-warning-asap.22004/?utm_source=chatgpt.com))

So there is a **search-cost externality**: low-cost generation makes everybody else spend more time sorting.

---

# 28. It damages trust in self-publishing and web fiction

This may become one of the most economically important consequences.

Kindle Unlimited readers report becoming reluctant to try unknown self-published authors because they no longer trust whether a new book represents ordinary amateur writing or mass-produced generated text. ([Reddit](https://www.reddit.com/r/KindleUnlimited/comments/1sxqjut/concerns_about_ai_slop_in_ku/?utm_source=chatgpt.com))

That harms precisely the human indie writers who most need readers willing to experiment.

The problem therefore is not merely “bad AI books compete with good books.”

It is that **AI suspicion increases the risk of trying an unfamiliar author**.

---

# 29. High output itself becomes suspicious

Web-fiction and Kindle communities repeatedly bring up impossible-looking publication schedules.

Ten thousand words every day.

Several enormous books within months.

Multiple simultaneous series.

A new 500-page title every few weeks.

This is not textual evidence, and highly productive human writers certainly exist. But readers increasingly combine extreme release velocity with stylistic and continuity problems as circumstantial evidence. ([Reddit](https://www.reddit.com/r/royalroad/comments/1tjepgh/i_hate_ai_and_i_hate_that_people_dont_see_it_when/?utm_source=chatgpt.com))

That creates another unfortunate consequence: genuinely prolific writers can now be treated with suspicion.

---

# 30. Covers, blurbs and reviews have become trust signals for the text

Readers frequently use an AI-looking cover as a **risk indicator**, not necessarily because the cover proves the manuscript is AI-written, but because it changes their prior expectation.

Some Royal Road readers explicitly say a visibly generated cover makes them expect similar lack of refinement inside. Kindle/LitRPG users say an obviously generated blurb can make them distrust the manuscript before opening it. ([Reddit](https://www.reddit.com/r/ProgressionFantasy/comments/1vy6kiz/removed/?utm_source=chatgpt.com))

There is an important counterpoint: communities repeatedly warn that plenty of genuine indie writers use inexpensive AI covers while writing their text themselves. ([Reddit](https://www.reddit.com/r/litrpg/comments/1vs2t6a/ai_written_books/?utm_source=chatgpt.com))

Again, the issue is probabilistic perception, not proof.

---

# What problems are strongest across *all* the material?

After separating ethical objections from complaints about actual reading, I would rank the recurrent problems approximately like this:

| Reader problem | How consistently it appeared | Research support |
|---|---|---|
| Repetitive rhetorical/sentence structures | Extremely strong | Indirect support through homogenization research |
| Purple/overdramatic prose | Extremely strong | Primarily community evidence |
| Overexplaining / lack of subtext | Very strong | Primarily community evidence |
| Generic or homogenized authorial voice | Extremely strong | Strong empirical support |
| Repetitive scenes and emotional beats | Very strong | Consistent with story-generation research |
| Character inconsistency | Extremely strong | Strong research support |
| Timeline/factual continuity errors | Extremely strong | Direct 2026 ACL evidence |
| Weak long-range plot coherence | Extremely strong | Strong survey/research support |
| Dialogue voices becoming similar | Strong | Supporting dialogue/persona research |
| Character knowledge leaking incorrectly | Strong | Consistent with long-context/persona limitations |
| Everything receiving too much emphasis | Very strong | Community evidence |
| Generic/clichéd solutions to plot problems | Strong | Supported indirectly by homogenization studies |
| Poor setup/payoff | Strong | Consistent with long-form planning limitations |
| Emotional flatness despite emotional vocabulary | Extremely strong reader perception | Harder to quantify objectively |
| Loss of author-reader connection | Extremely strong among anti-AI readers | Value-dependent rather than technical |
| Suspicion/false accusations contaminating human writing | Strong and growing | Detector research supports caution |
| Discovery fatigue / marketplace flooding | Extremely strong in Kindle/web-fiction communities | Ecosystem rather than prose issue |

---

# The most useful insight from all of this

If someone wanted to create AI-assisted fiction that readers **do not experience as AI writing**, simply banning words such as *delve*, removing em dashes and deleting “not X but Y” would solve only the superficial layer.

The deeper reader complaints operate in a hierarchy:

**Level 1 — vocabulary:** favorite words, stock adjectives, cliché metaphors.

**Level 2 — syntax:** contrastive reframing, triplets, staccato fragments, repeated rhetorical structures.

**Level 3 — paragraph logic:** saying the same thing multiple ways, explaining the meaning of actions, unnecessary emotional interpretation.

**Level 4 — scene logic:** repetitive conversations, excessive introspection, bad information prioritization, no subtext.

**Level 5 — character logic:** same voices, unstable motivations, forgotten experiences, incorrect knowledge.

**Level 6 — narrative logic:** contradictions, repeated plot functions, weak causality, poor setups/payoffs, abandoned threads.

**Level 7 — artistic identity:** the absence of a peculiar, coherent sensibility controlling what the book notices, ignores, emphasizes, finds funny, finds ugly, refuses to explain, or chooses to leave unresolved.

Most “AI detector” discussions obsess over Levels 1–2.

The communities with the most experienced long-form readers keep pointing toward **Levels 4–7**.

That is probably the single most important conclusion of this research.

A generated novel does not usually fail because one sentence contains an em dash.

It fails when, after 150 pages, the reader realizes that **the book can continuously produce prose without continuously accumulating meaning**.

That is the complaint underneath “soulless,” “slop,” “word salad,” “repetitive,” “generic,” “AI cadence,” “nothing happens,” and “something feels off.”

And that conclusion is remarkably consistent across conventional book readers, Kindle readers, fanfiction communities, Royal Road/web-fiction readers, people who actively write with AI, and current long-form narrative research. ([Reddit](https://www.reddit.com/r/books/comments/1qygilu/a_really_fun_book_i_was_reading_turned_out_to_be/?utm_source=chatgpt.com))

One important counterweight should remain in view: this does **not** mean AI-assisted fiction is automatically worse. Experimental evidence has found AI ideas can make individual short stories better written and more enjoyable, especially for weaker writers, and some readers genuinely enjoy AI-driven personalized fiction. The more defensible conclusion is narrower: **current AI-heavy writing has characteristic failure modes that become particularly damaging when generation replaces sustained human control over voice, causality, character memory and narrative selection.** ([DOI](https://doi.org/10.1126/sciadv.adn5290?utm_source=chatgpt.com))

If your purpose behind this research is to **design a writing system or prompt that produces novels without these problems**, this material can be taken much further: the next step would be to turn these findings into a **comprehensive “anti-AI-writing” specification**—possibly 100+ concrete prohibitions, tests and revision rules covering prose, dialogue, characterization, emotional logic, continuity, pacing, worldbuilding and chapter-to-chapter memory.



---

*Generated with [ChatGPT Pro Tools](https://chromewebstore.google.com/detail/chatgpt-pro-tools/blehigjjjlnlbbgjghhfnllglnelijkg?utm_source=extension&utm_medium=export-footer)*
